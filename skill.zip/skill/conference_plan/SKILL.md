---
name: conference_plan
description: >
  Top-tier AI conference research planning skill for bioinformatics + LLM/Agent projects.
  Produces complete publication-ready deliverables targeting AAAI, IJCAI, ICML, NeurIPS, or ICLR.
  Given a research direction (or helps discover one), it executes a full pipeline: conference selection,
  literature survey with latest LLM/Agent tech, feasibility-validated proposal, complete PyTorch code
  with analysis scripts, conference-specific LaTeX paper draft, technical manual, and presentation.
  Use this skill when the user wants to: plan a conference submission, prepare a research project
  for a top AI venue, design experiments for bioinformatics+AI research, produce publication-quality
  deliverables, or explore trending research directions in AI for biology. Also triggers for:
  conference paper preparation, research proposal for AAAI/IJCAI/ICML/NeurIPS/ICLR,
  experiment design for single-cell/drug-design/virtual-cell/biomolecular-generation research.
---

# Conference Plan Skill

This skill takes a research direction (or helps the user discover one) and produces a complete,
publication-ready research package targeting a specific top AI conference. Every deliverable is
designed to be handed directly to students for execution — no ambiguity, no placeholder logic,
no missing pieces.

**Target conferences**: AAAI, IJCAI, ICML, NeurIPS, ICLR
**Domain focus**: AI/LLM/Agent for bioinformatics (virtual cells, single-cell, drug design, biomolecular generation)
**Research type**: Purely computational (no wet-lab experiments; all validation is in silico using public datasets and computational tools)
**Hardware constraint**: 1x NVIDIA A100 80GB (strict, no multi-GPU)
**Tech focus**: LLM and Agent-based approaches
**Timeline**: 1-2 months (8 weeks) for experiment completion, with parallel execution schedule
**Framework**: PyTorch + HuggingFace Transformers
**Language convention**: Survey, proposal, technical manual, and post-experiment guide in Chinese; paper and code in English
**Writing style**: Direct, precise, technical academic English. No AI-sounding text (no excessive em-dashes, no "leverages/utilizes", no vague superlatives). See `references/paper_guide.md` Writing Style Standards.

## Output Structure

All outputs go into a project directory named after the research topic:

```
{project_name}/
├── survey.md                    # 文献调研报告 (Chinese)
├── proposal.md                  # 研究方案 (Chinese, feasibility-validated)
├── code/                        # Complete code project
│   ├── configs/
│   ├── data/
│   ├── models/
│   ├── baselines/
│   ├── training/
│   ├── evaluation/
│   ├── analysis/                # Result analysis scripts (maps to paper)
│   ├── scripts/
│   ├── ablation/
│   ├── main.py
│   ├── requirements.txt
│   └── README.md
├── paper/                       # LaTeX paper (conference-specific template)
│   ├── main.tex
│   ├── references.bib
│   ├── {conference}_20XX.sty
│   ├── figures/
│   └── tables/
├── technical_manual.md          # 技术手册 (Chinese)
├── presentation.html            # 项目介绍幻灯片
└── post_experiment_guide.md     # 实验后指南 (Chinese)
```

---

## Phase 0: Conference Selection & Topic Discovery

This is an **interactive** phase. Present options and wait for user selection before proceeding.

### Step 1: Conference Selection

If the user has not already specified a target conference, present the five options with brief descriptions:

1. **AAAI** — 7 pages, broadest AI scope, strong in applications and agent systems
2. **IJCAI** — 7 pages, values theoretical depth, strong in reasoning and planning
3. **ICML** — 8 pages, premier ML venue, expects mathematical rigor
4. **NeurIPS** — 9 pages, highest prestige, values conceptual novelty
5. **ICLR** — 9 pages, representation learning focus, open review, LLM-friendly

Read `references/conference_profiles.md` and load the selected conference's profile. Set `{CONFERENCE}` for all subsequent phases.

### Step 2: Topic Discovery

Branch based on user input:

**Path A — User provides a direction**:
The user gives a research direction (e.g., "LLM-based virtual cell modeling"). Use WebSearch to expand this into 3-5 specific research questions, each with a one-paragraph feasibility sketch covering:
- What exactly would be built
- Key datasets available
- Estimated novelty level
- Fit to the selected conference

Present these options and let the user select or refine.

**Path B — Trending topic search**:
If the user has no specific direction, use WebSearch to find trending topics. Run queries like:
- `{CONFERENCE} 2025 2026 accepted papers LLM bioinformatics`
- `AI agent single-cell drug design trending 2025 2026`
- `foundation model biomolecular generation latest breakthrough`
- `virtual cell digital cell model LLM 2025`
- `{CONFERENCE} workshop bioinformatics AI 2025`

Compile 5-8 candidate topics, each with:
- Topic name and one-sentence description
- Why it is timely (cite recent papers/trends)
- Estimated novelty level (High/Medium/Low)
- Fit to target conference (High/Medium/Low)
- Data availability (Good/Limited)

Present the ranked list and let the user select.

### Step 3: Confirmation

Once the user selects a topic, confirm the full configuration:
- **Conference**: {CONFERENCE}
- **Research direction**: {DIRECTION}
- **Hardware**: 1x A100 80GB
- **Domain**: AI/LLM/Agent for bioinformatics

Wait for user confirmation before proceeding. All subsequent phases (1-9) run automatically without stopping.

---

## Phase 1: Literature Survey

The survey is the foundation — it determines what innovation is possible and credible.

### Research Strategy

Use WebSearch to find papers from the past 3 years (2024-2026) across these venues:

**CS Conferences**: AAAI, IJCAI, ICML, NeurIPS, ICLR, KDD, WWW, RECOMB
**Journals**: Nature Methods, Nature Biotechnology, Nature Machine Intelligence, Cell Systems, Genome Biology, Bioinformatics

Run at least 10 search queries (replace `{DIR}` with the research direction):

**Direction-specific (3)**:
1. `{DIR} large language model 2024 2025 2026`
2. `{DIR} foundation model deep learning benchmark SOTA`
3. `{DIR} state of the art open source code GitHub dataset`

**LLM-specific (3)**:
4. `{DIR} LLM fine-tuning prompt engineering`
5. `{DIR} pre-trained language model transfer learning`
6. `{DIR} retrieval augmented generation RAG`

**Agent-specific (2)**:
7. `{DIR} AI agent tool use reasoning planning`
8. `{DIR} multi-agent collaboration automated discovery`

**Conference-specific (1)**:
9. `{CONFERENCE} 2024 2025 {DIR} accepted paper`

**Novelty verification (1+)**:
10. `[proposed idea keywords] arXiv OpenReview` — verify no prior work does the same thing

### Survey Output

Read `references/survey_guide.md` for the detailed template. The survey must include:
- Background overview of the field
- **Latest technology radar**: LLM, Agent, and Bio-AI advances (2024-2026)
- Summary table of 15-30 key papers with reproducibility and 1xA100 feasibility columns
- Methods taxonomy with LLM/Agent-specific categories
- Public datasets and benchmarks table
- Research gaps analysis with **feasibility pre-screening** (infeasible gaps marked and excluded)
- **Innovation novelty verification** via targeted search
- Recommended direction with conference-fit analysis referencing `references/conference_profiles.md`

Write to `{project_name}/survey.md` in Chinese, keeping paper titles and technical terms in English.

---

## Phase 2: Research Proposal

Based on the survey's gap analysis, design a novel method combining latest LLM/Agent techniques with the target domain.

### Innovation Requirements

The proposal must contain **at least 3 clear innovation points**, each one:
- Grounded in an identified research gap from the survey
- Technically feasible with **1x A100 80GB** (strict — compute check required)
- Differentiated from existing work in a concrete, measurable way
- Based on or extending open-source implementations (cite specific repos and files)
- Has a concrete **implementation path** (step-by-step)
- Has a **minimum verification experiment** (smallest test to validate the innovation)

**Theoretical depth requirement**: At least one innovation must be a **theoretical contribution** — not just a new module or pipeline, but a formal result (new problem formulation with formal properties, generalization bound, convergence proof, expressiveness analysis, or information-theoretic justification). Read the "Innovation Depth Levels" and "Theoretical Innovation Patterns" sections in `references/proposal_guide.md` for specific patterns. Pure engineering innovations without theoretical grounding are frequently rejected at ICML/NeurIPS as "nice engineering but limited novelty."

### Feasibility Validation (Mandatory)

After drafting the proposal, run the feasibility checklist from `references/proposal_guide.md`:

1. **Compute check**: Peak GPU memory must be <75GB. Show the calculation:
   - Model params (bf16) + optimizer states + activations + buffers < 75GB
   - If exceeds: reduce model, use LoRA/QLoRA, enable gradient checkpointing
2. **Data check**: Use WebSearch to verify all dataset URLs are accessible. Record status.
3. **Code check**: Verify base repo exists, is compatible with PyTorch 2.x, and has a license allowing modification.
4. **Timeline check**: Total experiment time (training + baselines + ablations) must be completable in <30 days on 1x A100.

If any check fails, revise the proposal before proceeding.

### Proposal Structure

Read `references/proposal_guide.md` for the detailed template. Key sections:
1. Research question and motivation
2. Innovation points (3+) with implementation path and novelty evidence
3. **Feasibility verification checklist** (compute, data, code, timeline)
4. Method overview with architecture diagram and open-source dependency graph
5. Datasets with verified download status — **minimum 3 datasets** (see `references/acceptance_checklist.md` Section 1)
6. Baselines with reproduction status — **minimum 5 baselines** covering diverse paradigms (see `references/acceptance_checklist.md` Section 1.3)
7. Evaluation metrics — **minimum 3 metrics per dataset**
8. **Fair comparison protocol** — identical training conditions for all methods (see `references/acceptance_checklist.md` Section 2)
9. **Hypothesis-driven experiment plan** — each experiment answers a specific RQ with expected outcomes (see `references/experiment_narrative_guide.md` Section 1.4)
10. Ablation study design — 5+ experiments using diverse ablation types: removal, replacement, degradation, cross-condition (see `references/experiment_narrative_guide.md` Section 1.3)
11. **Biological validation plan** — domain-specific validation experiments mapped to the task (see `references/bio_validation_guide.md` Section 1)
12. Compute budget (strict 1x A100)
13. **Method performance strategy** — design validation loop, diagnosis plan for underperformance, improvement decomposition (see `references/acceptance_checklist.md` Section 4)
14. **Rebuttal emergency experiments** — pre-plan 3-4 quick experiments for common reviewer demands (see `references/acceptance_checklist.md` Section 8.3)
15. Risk assessment with milestone-based go/no-go decisions
16. **Minimum Publishable Unit** — fallback if full plan fails
17. Timeline with completion criteria

Write to `{project_name}/proposal.md` in Chinese.

---

## Phase 3: Code Implementation

Build a complete, runnable code project. Every file must be real code — no stubs, no TODOs, no "implement this" comments.

### Project Structure

Read `references/code_structure.md` for conventions, patterns, and analysis directory design. Create the full project layout including:

- `configs/` — Default config + baseline configs + ablation configs. All configs use `num_gpus: 1`.
- `data/` — Download, preprocess, dataset, collator
- `models/` — Main model, sub-modules, losses
- `baselines/` — One file per baseline method
- `training/` — Trainer (single-GPU, mixed precision, gradient accumulation), optimizer, callbacks
- `evaluation/` — Metrics, evaluation pipeline, visualization
- `analysis/` — **Result analysis scripts mapped to paper elements**:
  - `parse_results.py` — Parse all eval outputs into structured DataFrames
  - `statistical_tests.py` — Paired t-test, Wilcoxon, bootstrap CI
  - `generate_tables.py` — Generate LaTeX tables (bold best, underline 2nd)
  - `generate_figures.py` — Generate matplotlib/seaborn figures
  - `comparison_analysis.py` — Ours vs each baseline
  - `ablation_analysis.py` — Process ablation results
  - `case_study.py` — Extract qualitative examples
  - `bio_validation.py` — Biological validation (marker genes, GO enrichment, embedding quality) — see `references/bio_validation_guide.md`
  - `bio_visualization.py` — Domain-specific visualizations (UMAP, attention-on-network, expression heatmaps)
  - `run_all_analysis.sh` — Master analysis script
- `scripts/` — Shell scripts for train, eval, baselines, ablation, analysis
- `ablation/` — Ablation orchestrator
- `main.py` — Entry point with timing instrumentation
- `requirements.txt` — Pinned dependencies
- `README.md` — English documentation

### Code Quality Standards

- Use `torch.amp` (PyTorch 2.x API) for mixed-precision training
- Implement gradient accumulation for large batch simulation
- Add wandb/tensorboard logging for all metrics
- **Single GPU only**: Use `CUDA_VISIBLE_DEVICES=0`, no `torch.distributed`
- Include checkpointing (save every N epochs + best model)
- Use type hints for function signatures
- Include docstrings for all public classes and functions
- Config-driven: all hyperparameters in YAML, no magic numbers
- Reproducibility: set all random seeds, log full config, run 3 seeds for std
- Memory-efficient: use gradient checkpointing if needed for A100 80GB
- **Analysis scripts**: Each must declare which paper element it produces (header comment)
- Results saved as JSON (parseable by `analysis/parse_results.py`)
- Timing saved to `timing.json` for efficiency analysis

---

## Phase 4: Code Review

After writing all code, do a thorough review following the checklist in `references/code_structure.md`.

### Automated Checks

1. **Syntax check**: Run `python -c "import ast; ast.parse(open(f).read())"` on every .py file
2. **Import check**: Verify all imports reference real packages or project modules
3. **Completeness**: No TODO, FIXME, or placeholder comments

### Memory Simulation

Compute peak GPU memory for the default config and produce a table:

| Component | Memory (GB) |
|-----------|:-----------:|
| Model parameters (bf16) | X.X |
| Optimizer states (Adam) | X.X |
| Activations (batch=B, seq=S) | X.X |
| Gradient accumulation buffer | X.X |
| **Total** | **X.X / 80 GB** |

Total must be <75GB. If not, fix the code immediately (reduce default batch size, enable gradient checkpointing, etc.).

### Analysis Folder Validation

- `parse_results.py` correctly parses the `eval_results.json` format from `evaluation/evaluate.py`
- `generate_tables.py` produces valid LaTeX
- `generate_figures.py` references correct columns from the results DataFrame
- Every paper table/figure has a corresponding analysis script (check the mapping table)

### End-to-End Pipeline Trace

Mentally trace the full pipeline: `download.py` → `preprocess.py` → `main.py --mode train` → `evaluate.py` → `parse_results.py` → `generate_tables.py`. Verify all file paths and data formats are consistent.

### Config Consistency

Verify every config YAML references valid model classes, datasets, and metrics that exist in the code.

### Training Stability Check

Verify the training code includes all stability essentials from `references/acceptance_checklist.md` Section 7:
- Gradient clipping (max_norm=1.0)
- Learning rate warmup
- NaN loss detection and early termination
- Gradient norm monitoring
- Checkpoint saving every N epochs
- Early stopping with patience
- Resume from checkpoint support

### Fair Comparison Protocol Check

Verify that `scripts/run_baselines.sh` and `scripts/train.sh` use:
- Same random seeds for all methods
- Same data splits
- Same training epochs or early stopping criteria
- Same GPU configuration (CUDA_VISIBLE_DEVICES=0)

Fix any issues found immediately.

---

## Phase 5: Technical Manual

Write a step-by-step guide that enables a student to reproduce all experiments without asking questions.

Read `references/code_structure.md` for the manual template. Include:

1. **环境配置** (Environment Setup): conda/pip commands, CUDA version, exact versions. Specify 1x A100.
2. **数据准备** (Data Preparation): Exact download commands, expected sizes
3. **运行基线** (Running Baselines): Exact commands for each baseline
4. **训练模型** (Training Our Model): Commands, multi-seed run, expected training time
5. **评估** (Evaluation): How to run eval, where results appear
6. **消融实验** (Ablation Studies): Commands and what each tests
7. **结果分析** (Result Analysis): Commands for each analysis script, how to update paper
8. **常见问题** (Troubleshooting): OOM solutions, common errors, resume training

Write to `{project_name}/technical_manual.md` in Chinese.

---

## Phase 6: Paper Draft

Write a complete paper draft in LaTeX, targeting the selected conference's format.

### Template Acquisition

Use WebSearch to find the official LaTeX template for `{CONFERENCE}`:
- Search: `{CONFERENCE} 2026 LaTeX template`
- Search: `{CONFERENCE} 2026 author kit Overleaf`

Read `references/conference_profiles.md` for the template source URL. If the exact 2026 template is not found, use the most recent available year and note this.

Create `paper/` with the conference-specific style file. The directory structure:
```
paper/
├── main.tex
├── references.bib
├── {conference}_20XX.sty
├── figures/
│   ├── fig_comparison.tex
│   ├── fig_architecture.tex
│   ├── fig_data_pipeline.tex
│   ├── fig_main_results.tex      # Placeholder
│   ├── fig_ablation.tex          # Placeholder
│   └── fig_case_study.tex        # Placeholder
└── tables/
    ├── tab_main_results.tex      # XX.X placeholders
    ├── tab_ablation.tex          # XX.X placeholders
    └── tab_efficiency.tex        # XX.X placeholders
```

### Paper Sections

Read `references/paper_guide.md` for detailed writing standards, page budgets, and supplementary material strategy.
Read `references/figure_guide.md` for TikZ templates.
Read `references/experiment_narrative_guide.md` for hypothesis-driven experiment structure and results narrative patterns.
Read `references/bio_validation_guide.md` for biological validation experiments and domain-specific visualizations.

**Writing style**: Follow `references/paper_guide.md` "Writing Style Standards" strictly. Write in direct, precise technical English. No AI-sounding patterns: avoid excessive em-dashes, semicolon chains, "leverages/utilizes", vague superlatives. Every sentence should carry specific information. Read the paper aloud as a check.

**All sections EXCEPT Experiments results**: Write complete, polished, publication-ready prose.

1. **Title**: Concise, includes method name and domain
2. **Abstract**: ~200-250 words (adjust for conference)
3. **Introduction**: Problem motivation → limitations → contributions (numbered, must include at least one theoretical contribution) → paper organization
4. **Related Work**: Organized by category, clear positioning
5. **Method**: Formal notation → framework → component details → **theoretical analysis (required)** → training objective with principled derivation. See `references/paper_guide.md` for the Theoretical Analysis subsection template with theorem format.
6. **Experiments**: Structure as hypothesis-driven RQs (see `references/experiment_narrative_guide.md`):
   - RQ1 (Main Results): Does our method work? → XX.X tables with analysis annotations
   - RQ2 (Ablation): Why does it work? → Diverse ablation types (removal, replacement, degradation)
   - RQ3 (Analysis): How does it work? → Mechanism analysis, visualization, sensitivity
   - RQ4 (Biological Validation): What biological insights does it provide? → Marker gene recovery, GO enrichment, domain-specific visualizations (see `references/bio_validation_guide.md`)
   - Results narrative follows the 4-sentence pattern: finding → pattern → thesis connection → honest limitation
   - All tables with XX.X placeholders and `% [Analysis:...]` annotations
7. **Discussion**: Interpret results, limitations, broader impact
8. **Conclusion**: Summarize contributions, future work

### Conference-Specific Additions

Based on `{CONFERENCE}`:
- **AAAI**: Include ethical considerations paragraph. Concise method (fit in 7 pages). Formal problem definition required; full proofs in supplementary.
- **IJCAI**: Emphasize formal problem definition with theoretical properties. Strict 7+2 layout. Theorems in main paper, proofs in supplementary.
- **ICML**: Dedicated Theoretical Analysis subsection required with propositions/theorems. Derive loss from principled framework. Complexity analysis. Mathematical rigor throughout — this is non-negotiable for ICML.
- **NeurIPS**: Frame around key theoretical insight. Include formal analysis explaining WHY the method works. Broader Impact section and Reproducibility Checklist appendix.
- **ICLR**: Include representation analysis with formal characterization (information-theoretic or geometric). Anticipate reviewer objections with rigorous arguments.

### Figures (LaTeX/TikZ)

Read `references/figure_guide.md` for templates. Create at minimum:
- **Figure 1**: Comparison diagram (traditional vs. ours) — fully drawn
- **Figure 2**: Full model architecture in TikZ — fully drawn
- **Figure 3**: Data pipeline or method detail — fully drawn
- **Figures 4-6**: Results, ablation, case study — structure with placeholders

Use compact variants for AAAI/IJCAI (7-page limit).

### Bibliography

Include 30-50 references in `references.bib`. Use real entries from the survey. Match citation style to conference (numbered vs. author-year).

### Results Section Strategy

The Experiments section uses the pre-experiment draft strategy:
- All table structures defined with XX.X±X.X placeholders
- All analysis narrative written with expected patterns described
- Every placeholder has a LaTeX comment annotation: `% [Analysis: script_name; what to compute; expected outcome; diagnostic if unexpected]`
- Annotations reference specific scripts in `code/analysis/`
- Paper compiles cleanly — annotations are comments

Write all paper files to `{project_name}/paper/`.

---

## Phase 7: Presentation

Create an HTML presentation explaining the research project. Read the template from
`assets/presentation_template.html` and customize it.

### Slides to include (10 slides):

1. **Title slide**: Project name, research direction, target conference (show conference name prominently)
2. **Problem & Motivation**: Why this research matters
3. **Related Work Overview**: Key prior methods and their limitations
4. **Our Method**: Architecture overview, innovation points (3 cards)
5. **Technical Details**: Key components explained
6. **Experiment Design**: Datasets, baselines, metrics
7. **Expected Results**: What we expect to show, analysis plan overview
8. **Analysis Plan**: Which scripts produce which paper elements (new slide)
9. **Timeline & Task Assignment**: 1-2 month plan breakdown
10. **References**: Key papers

Hardware line should read: "1x NVIDIA A100 80GB"

Write to `{project_name}/presentation.html`.

---

## Phase 8: Final Assembly & Verification

After all phases complete:

### File Verification

Verify every expected file exists in the project directory. List all files with sizes.

### Analysis-Paper Alignment Check

Verify that:
- Every XX.X placeholder in the paper has a corresponding `% [Analysis:...]` annotation
- Every annotation references a script that exists in `code/analysis/`
- Every analysis script's declared paper element matches the actual paper structure
- The `generate_tables.py` and `generate_figures.py` output paths match what `main.tex` expects

### Conference Compliance Check

Read the conference profile from `references/conference_profiles.md` and verify:
- Paper is within page limit (estimate page count from section lengths)
- Style file is correct for the selected conference
- Citation format matches conference requirements
- Conference-specific requirements are met (e.g., NeurIPS reproducibility checklist, AAAI ethics statement)

### Acceptance Readiness Check

Read `references/acceptance_checklist.md` and verify against the mandatory experiment checklist (Section 5):
- [ ] **Experimental scope**: >= 3 datasets, >= 5 baselines, >= 3 metrics per dataset
- [ ] **Fair comparison**: Protocol stated in paper, identical conditions for all methods
- [ ] **Statistical rigor**: All results have ±std, p-values computed, significance marked
- [ ] **Mandatory tables**: Main results, ablation, efficiency, hyperparameters (appendix)
- [ ] **Mandatory figures**: Comparison, architecture, data pipeline, results viz, ablation viz, case study
- [ ] **Required analyses**: Sensitivity, efficiency, visualization (UMAP/t-SNE), case study (success+failure)
- [ ] **Training stability**: Gradient clipping, warmup, NaN detection, checkpointing in code
- [ ] **Reviewer anticipation**: Top 10 rejection patterns addressed (Section 6.1)
- [ ] **Self-review checklist**: All items in Section 6.2 checked

### Deliverables Summary

Print summary table:

| Deliverable | File | Status | Conference Check |
|---|---|---|---|
| Literature Survey | survey.md | ... | Latest tech covered |
| Research Proposal | proposal.md | ... | Feasibility validated |
| Code Project | code/ | ... | 1x A100 confirmed |
| Analysis Scripts | code/analysis/ | ... | Maps to paper |
| Technical Manual | technical_manual.md | ... | Analysis section included |
| Paper Draft | paper/ | ... | {CONFERENCE} format |
| Presentation | presentation.html | ... | Conference badge shown |
| Post-Experiment Guide | post_experiment_guide.md | ... | Checklist included |

---

## Phase 9: Post-Experiment Guide

Generate a guide for what to do after experiments are complete.

Write `{project_name}/post_experiment_guide.md` in Chinese with:

### 实验后操作流程

1. **收集结果**: `bash analysis/run_all_analysis.sh outputs/ analysis_outputs/`
2. **检查统计显著性**: Review `analysis_outputs/stats_report.txt`
3. **生成论文表格**: Results auto-placed in `paper/tables/`
4. **生成论文图表**: Results auto-placed in `paper/figures/`
5. **替换占位符**: Replace all XX.X in `paper/main.tex` with actual numbers
6. **完成分析段落**: Follow `% [Analysis:...]` annotations to write analysis text
7. **移除注释**: Remove all `% [Analysis:...]` comments from final version
8. **检查页数**: Compile LaTeX and verify within {CONFERENCE} page limit
9. **最终审查**: Proofread, check figures, verify bibliography

### 结果不如预期时的应对

Follow the diagnosis checklist from `references/acceptance_checklist.md` Section 4.2:

- **方法未超过基线**: 
  1. 先排除实现bug（数据加载、loss计算、梯度流）
  2. 再调超参数（LR: {1e-5, 3e-5, 1e-4, 3e-4, 1e-3}）
  3. 检查数据预处理是否与baseline一致
  4. 如仍不行：回到proposal中的Minimum Publishable Unit
- **改进很小 (< 2%)**:
  1. 增加种子数到5-10个，检验是否统计显著
  2. 验证改进是否在所有数据集上一致（一致的小改进也可接受）
  3. 做改进分解（架构贡献 vs 调参贡献），确保是方法本身的功劳
  4. 强化其他贡献角度（理论分析、效率、可解释性）
- **某个数据集表现差**: 分析该数据集特征，在论文limitations中诚实讨论
- **消融实验某组件无贡献**: 简化方法（移除该组件），更简洁的方法更好
- **统计不显著 (p > 0.05)**: 增加种子数(5+)；如仍不显著，不能在abstract中claim"超越"，改为"comparable performance with additional advantages in..."
- **某个强baseline打不过**: 承认它强，展示互补优势（效率、可解释性、不同指标）

### 提交前检查清单

```
=== 实验完整性 ===
□ 所有实验完成 (All experiments completed)
□ 数据集 ≥ 3个 (Minimum 3 datasets)
□ 基线 ≥ 5个，且质量经过检查 (Minimum 5 quality baselines)
□ 每个数据集 ≥ 3个评估指标 (Minimum 3 metrics per dataset)
□ 多种子运行 ≥ 3次 (3+ seeds, recommend 5+)
□ 所有结果格式: XX.X ± X.X (mean ± std)

=== 统计显著性 ===
□ 统计检验完成 (Paired t-test for all comparisons)
□ 所有claim的改进 p < 0.05 (All claimed improvements significant)
□ 效果量 Cohen's d ≥ 0.5 (Effect sizes meaningful)
□ 表格中 * 标记 p<0.05, ** 标记 p<0.01

=== 公平对比 ===
□ 所有方法使用相同数据划分 (Same splits)
□ 所有方法使用相同种子 (Same seeds)
□ 所有方法使用相同训练条件 (Same epochs/hardware)
□ 超参数表在附录中 (Hyperparameter table in appendix)
□ 基线复现与原文偏差 < 2% (Baseline verification)

=== 论文质量 ===
□ 论文表格已更新 (Tables updated with real numbers)
□ 论文图表已更新 (Figures updated, 300 DPI)
□ 所有 XX.X 占位符已替换 (All placeholders replaced)
□ 所有 [Analysis] 注释已移除 (All annotations removed)
□ 失败案例分析已包含 (Failure cases discussed)
□ 改进分解已完成 (Improvement decomposition done)
□ 贡献列表包含理论贡献 (Theoretical contribution listed)

=== 格式与合规 ===
□ 页数符合会议要求 (Page limit: {CONFERENCE})
□ 参考文献格式正确 (Citation format matches conference)
□ 匿名检查 (No identifying information for double-blind)
□ LaTeX 编译无错误 (Compiles without errors)
□ 补充材料准备好 (Supplementary: proofs, extra tables, hyperparameters)

=== 可复现性 ===
□ 代码清理并可复现 (Code cleaned and reproducible)
□ README 更新 (README with setup instructions)
□ requirements.txt 完整 (All dependencies listed)
□ 随机种子记录在config中 (Seeds in config files)

=== 审稿人视角自查 (参考 acceptance_checklist.md Section 6.2) ===
□ 以敌意审稿人视角读了一遍论文
□ 准备好了常见质疑的回答 (rebuttal preparation)
```

Write to `{project_name}/post_experiment_guide.md`.

---

## Important Notes

- **Phase 0 is interactive** — wait for user selection. All other phases (1-9) run automatically.
- If WebSearch returns limited results for a niche topic, supplement with your knowledge and note which references need verification.
- All code must be genuinely runnable — treat this as production code.
- The paper should read as a complete draft minus numerical results. A reader should understand the full contribution from text alone.
- Analysis annotations bridge the code and the paper — ensure bidirectional consistency.
- **1x A100 is a hard constraint** — verify at Phase 2 (proposal), Phase 4 (code review), and Phase 8 (final assembly).
- For the research direction, always consider what makes a strong submission: novelty of approach, significance of the problem, thoroughness of experiments, and quality of writing.
