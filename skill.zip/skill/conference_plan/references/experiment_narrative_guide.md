# Hypothesis-Driven Experiment Design & Results Narrative Guide

Top-venue papers structure experiments as **hypothesis tests**, not comparison tables. Each experiment answers a specific question, and the results section tells a story.

---

## 1. Hypothesis-Driven Experiment Design

### 1.1 Experiment Design Template

For EVERY experiment subsection in the paper, define:

| Field | Content |
|-------|---------|
| **Research Question (RQ)** | What specific question does this experiment answer? |
| **Hypothesis** | What do we expect to find, and why? |
| **Confirming outcome** | What result would support the hypothesis? |
| **Refuting outcome** | What result would refute it? |
| **Implication either way** | What do we learn regardless of the outcome? |

Example for a bio-AI paper:

```markdown
### RQ1: Does GRN-guided sparse attention improve cell type annotation?
- **Hypothesis**: Incorporating gene regulatory network structure into the attention 
  mechanism improves cell type annotation because it constrains the model to attend 
  to biologically related genes rather than learning correlations from scratch.
- **Confirming**: Our method outperforms dense-attention baseline by >= 3% accuracy 
  on rare cell types (where prior knowledge matters most).
- **Refuting**: No significant difference, or dense attention is better.
- **Implication if refuted**: GRN quality may be too noisy, or the model can learn 
  equivalent structure from data alone — either way, an important finding.
```

### 1.2 Experiment Story Arc

The Experiments section should follow this narrative structure:

```
RQ1 (Main Results): "Does our method work?"
  → Establishes that the method achieves SOTA
  
RQ2 (Ablation): "Why does it work? Which components matter?"
  → Shows each innovation contributes to the result

RQ3 (Analysis): "How does it work? What mechanism explains the improvement?"
  → Reveals the underlying principle, not just the outcome
  
RQ4 (Robustness): "When does it work? Where does it break?"
  → Shows generality and honestly discusses limitations

RQ5 (Biological Insight): "What does it reveal about the biology?"
  → Connects computational findings to domain knowledge
```

Each RQ flows logically into the next — reviewers should never ask "why is this experiment here?"

### 1.3 Ablation Design Principles

**Beyond trivial "remove component" ablations:**

| Ablation Type | Design | What it tests | Example |
|---------------|--------|---------------|---------|
| **Removal** | Remove component entirely | Is it necessary? | w/o GRN attention |
| **Replacement** | Replace with standard alternative | Is YOUR design better than alternatives? | GRN attention → standard self-attention |
| **Degradation** | Progressively degrade an input | How sensitive is it? | Use 50%, 25%, 10% of GRN edges |
| **Oracle** | Give perfect information for one component | What is the upper bound? | Use ground-truth cell labels instead of predictions |
| **Cross-condition** | Test component under different conditions | When does it matter most? | GRN attention on rare vs common cell types |
| **Scaling** | Vary model/data size | How does it scale? | 100K, 500K, 1M cells |

**Rule**: For a paper with 3 innovations, you need at least:
- 3 removal ablations (one per innovation)
- 2 replacement ablations (for the 2 most important innovations)
- 1 degradation study (for the most novel component)
- 1 cross-condition analysis

### 1.4 Proposal Phase: Experiment Planning Table

Include in proposal.md:

| # | Experiment | RQ | Hypothesis | Datasets | Metrics | Expected Outcome |
|:-:|-----------|-----|-----------|----------|---------|-----------------|
| E1 | Main comparison | RQ1 | Our method > baselines | All | All | +3-5% on primary metric |
| E2 | Ablation: w/o component A | RQ2 | Component A is critical | D1 | Primary | -3-5% drop |
| E3 | Ablation: A → standard | RQ2 | Our design > standard | D1 | Primary | -2-3% drop |
| E4 | GRN quality degradation | RQ3 | More GRN = better | D1 | Primary | Monotonic improvement |
| E5 | Rare vs common analysis | RQ3 | Larger gain on rare types | D1, D2 | Per-class | Gap widens for rare |
| E6 | Scaling study | RQ4 | Consistent gain at scale | D1(subsets) | Primary | Stable or improving |
| E7 | Failure case analysis | RQ4 | Identify failure modes | All | Qualitative | Characterized failures |
| E8 | Biological validation | RQ5 | Captures known biology | D1 | GO enrichment | Significant overlap |

---

## 2. Results Narrative Writing Guide

### 2.1 The 4-Sentence Pattern

After every table/figure, write 4 sentences:

1. **State the main finding** (what happened):
   "Our method achieves 91.2% accuracy, outperforming the strongest baseline (CellPLM, 87.5%) by 3.7%."

2. **Explain the pattern** (what it means across conditions):
   "The improvement is consistent across all 4 datasets, with the largest gains on rare cell types (5.2%) compared to common types (1.8%)."

3. **Connect to your thesis** (why this matters for your story):
   "This confirms our hypothesis that GRN-guided attention provides stronger inductive bias when training data is scarce, as rare cell types have fewer examples."

4. **Address surprises or limitations** (intellectual honesty):
   "On the PBMC dataset, our advantage is smaller (1.3%), possibly because its simpler cell type hierarchy provides less benefit from structural priors."

### 2.2 Weak vs Strong Results Narrative

**Weak (common in rejected papers):**
> "Table 2 shows the results. Our method achieves the best performance on all datasets. The improvement is significant."

Problems: No interpretation, no pattern analysis, no connection to the paper's thesis, claims without evidence.

**Strong (common in accepted papers):**
> "Table 2 reveals three key findings. First, our method consistently outperforms all baselines across 4 datasets and 3 metrics, with the largest gains on the challenging Tabula Sapiens dataset (4.1% accuracy, p<0.01). Second, the improvement concentrates on rare cell types with fewer than 100 training samples (Fig. 4a), confirming that biological prior knowledge compensates for data scarcity — exactly the setting our GRN-guided attention is designed for. Third, the advantage diminishes on the simpler PBMC dataset (1.3%), where even dense attention can learn effective patterns from abundant training data. This pattern is consistent with our theoretical analysis (Theorem 1), which predicts larger gains when the effective hypothesis space is constrained by domain knowledge."

### 2.3 Negative Result Handling

When a result is disappointing, frame it as an insight:

**Don't write**: "Our method fails to outperform Baseline X on Dataset Y."

**Do write**: "Interestingly, our method shows no advantage on Dataset Y, where Baseline X leverages [specific feature]. This suggests that [your method's assumption] does not hold when [condition], pointing to [future direction]. We regard this as a valuable finding: it precisely characterizes the boundary of our approach's applicability."

### 2.4 Ablation Narrative Pattern

**For each ablation row, explain the "why":**

```
Removing Component A causes the largest drop (-3.7%), confirming it as the key 
innovation. This is expected: Component A injects GRN structure that constrains 
attention to biologically plausible gene-gene interactions, which dense attention 
must learn from data alone.

Replacing Component B with standard self-attention (row 3) yields a smaller but 
significant drop (-2.1%), suggesting that our modified attention mechanism captures 
information beyond what standard formulations provide. Notably, this replacement 
ablation is more informative than simple removal (row 2), as it isolates the 
design choice rather than the presence of attention.
```

---

## 3. Transitions and Paper Flow

### 3.1 Section Transition Templates

**Intro → Related Work**:
"Before describing our approach, we review existing methods and position our contributions within the literature."

**Related Work → Method**:
"The above analysis reveals a key gap: [specific limitation]. In the following section, we address this gap by proposing [method name]."

**Method → Experiments**:
"Having established the theoretical foundation of [method], we now empirically validate our approach through comprehensive experiments designed to answer four research questions."

**Experiments → Discussion**:
"Our experiments demonstrate that [key finding]. We now discuss the implications, limitations, and broader impact of these results."

### 3.2 Within Experiments: RQ Transitions

"Having established that our method achieves state-of-the-art performance (RQ1), we now investigate which components drive this improvement."

"The ablation study confirms that each component is necessary (RQ2). A natural follow-up question is: what mechanism explains the improvement?"

"While our method shows strong gains overall (RQ1-RQ3), it is important to characterize where it fails. We investigate this in the following analysis."

---

## 4. The "Hook" Factor

What makes reviewers write "interesting paper" in their review:

### 4.1 Counter-Intuitive Findings
If your results reveal something unexpected, highlight it:
"Surprisingly, we find that [unexpected result]. This challenges the common assumption that [widely held belief], and suggests that [new insight]."

### 4.2 Clear Practical Implications
Tie computational results to real-world impact:
"Our method's ability to [specific capability] could enable [practical application], reducing [current bottleneck] from [current time/cost] to [improved time/cost]."

### 4.3 Unifying Insight
If your work connects previously separate ideas:
"Our theoretical analysis reveals a surprising connection between [concept A] and [concept B], suggesting that [unifying principle]. This perspective may extend beyond [current domain]."
