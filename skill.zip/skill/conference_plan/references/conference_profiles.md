# AI Conference Profiles

## Quick Comparison

| | AAAI | IJCAI | ICML | NeurIPS | ICLR |
|---|------|-------|------|---------|------|
| Full Name | AAAI Conference on Artificial Intelligence | International Joint Conference on AI | International Conference on Machine Learning | Conference on Neural Information Processing Systems | International Conference on Learning Representations |
| Typical Deadline | Aug-Sep | Jan-Feb | Jan-Feb | May | Sep-Oct |
| Notification | ~Nov | ~Apr | ~Apr-May | ~Sep | ~Jan |
| Conference Date | Feb | Aug | Jul | Dec | May |
| Acceptance Rate | ~20-24% | ~15-20% | ~25-28% | ~25-28% | ~30-32% |
| Main Track Pages | 7 + 1 refs/ethics | 7 + 2 refs | 8 + unlimited refs/appendix | 9 + unlimited refs/appendix | 9 + unlimited refs/appendix |
| Review Process | Double-blind | Double-blind | Double-blind | Double-blind | Open review (OpenReview) |
| Reviewer Count | 3 | 3 | 3-4 | 4+ | 3-4 |
| Rebuttal | Yes (short) | Yes | Yes | Yes | Discussion period |
| h5-index (approx) | ~180 | ~120 | ~250 | ~280 | ~300 |

**Note**: Deadlines and formats change yearly. Always verify on the official conference website before submission.

---

## Detailed Profiles

### AAAI

**Identity**: Broadest-scope AI conference. Welcomes AI applications, NLP, CV, planning, reasoning, and ML. Strong tradition in knowledge representation, search, and multi-agent systems.

**What Reviewers Value**:
- Clear problem definition with real-world relevance
- Solid experimental evaluation (thoroughness over novelty)
- Accessible writing — audience is broader than ML-focused venues
- Application papers with genuine domain impact
- Ethical considerations and societal implications

**Official Review Criteria**:
1. Significance of the contribution
2. Novelty and originality
3. Soundness and completeness
4. Clarity of presentation
5. Relevant comparison with prior work
6. Reproducibility

**Common Rejection Reasons**:
- Incremental contribution over existing work
- Insufficient comparison with recent baselines
- Poor writing quality or unclear presentation
- Missing ablation studies
- Overclaiming results without sufficient evidence
- No ethical considerations discussion

**Theoretical Contribution Expectation** (LOW-MEDIUM):
AAAI is the most accepting of applied papers, but even here, purely engineering papers are increasingly rejected. At minimum, formally define the problem and provide principled justification for design choices. Theoretical analysis in the supplementary significantly strengthens the paper.

**Tips for AI/LLM/Agent Bioinformatics Papers**:
- Position as "AI contribution demonstrated in bio domain," not "bio paper using AI"
- Make the AI innovation clear even to non-bio reviewers
- AAAI has AI for Social Impact and special application tracks — bio papers can fit
- Keep 7-page limit in mind: be ruthlessly concise in Related Work
- Agent-based and multi-agent approaches are well-received (AAAI tradition)
- Include ethical statement about responsible AI in biology
- Even for AAAI, include formal problem definition and at least informal theoretical motivation

**Deadline Pattern**: Usually early-to-mid August for February conference

**Template**:
- Source: `https://aaai.org/authorkit` or search Overleaf "AAAI 2026 Author Kit"
- Style file: `aaai26.sty` + `aaai-named.bst`
- Key: Two-column, Times font, numbered citations

---

### IJCAI

**Identity**: Oldest AI conference. Values theoretical depth and international breadth. Strong in reasoning, planning, knowledge representation, and multi-agent systems.

**What Reviewers Value**:
- Theoretical novelty with clear formalization
- International relevance (not US/China-centric datasets only)
- Connections to classical AI concepts (search, planning, knowledge representation)
- Clean mathematical exposition
- Well-structured problem formulation

**Official Review Criteria**:
1. Relevance to AI
2. Significance
3. Originality
4. Technical quality
5. Clarity
6. References and comparison

**Common Rejection Reasons**:
- Paper is pure ML with no broader AI contribution
- Theoretical claims not supported
- Paper reads like a NeurIPS/ICML reject without sufficient revision
- Limited novelty beyond engineering effort
- Weak connection to AI principles

**Theoretical Contribution Expectation** (MEDIUM):
IJCAI explicitly values "theoretical novelty with clear formalization." Formal problem definition, theoretical properties of the proposed approach, and connections to classical AI principles (search, planning, knowledge representation) are valued. Papers that provide formal reasoning about agent behavior or provable properties of planning systems are well-received.

**Tips for AI/LLM/Agent Bioinformatics Papers**:
- IJCAI "AI and Social Good" track is relevant for bio applications
- Frame contributions in terms of **general AI principles with formal grounding**, not just benchmark numbers
- Reviewers appreciate formal problem definition with theoretical analysis of solution properties
- International datasets (beyond English/US) get positive attention
- Agent-based reasoning and planning papers are core IJCAI scope — include formal analysis of agent behavior (convergence of multi-agent systems, optimality of planning, correctness of reasoning)
- Strict 7+2 page limit — move full proofs to supplementary but state theorems in main paper

**Deadline Pattern**: Usually mid-January for August conference

**Template**:
- Source: `https://www.ijcai.org/authors_kit` or search Overleaf "IJCAI"
- Style file: `ijcai26.sty`
- Key: Two-column, named citations

---

### ICML

**Identity**: Premier ML venue focused on algorithms, theory, and methodology. Strong emphasis on mathematical rigor.

**What Reviewers Value**:
- Methodological novelty (new algorithm, formulation, or analysis)
- Strong theoretical grounding (convergence proofs, complexity analysis)
- Comprehensive experiments with proper baselines and error bars
- Reproducibility (code submission encouraged)
- Clean and precise mathematical notation
- Principled training objectives

**Official Review Criteria**:
1. Correctness
2. Novelty and significance
3. Clarity and quality of writing
4. Experimental evaluation
5. Reproducibility

**Common Rejection Reasons**:
- Method is straightforward application of existing technique to new domain
- Missing theoretical justification for design choices
- Baselines are outdated or unfairly compared
- Insufficient ablation to isolate contribution
- Reproducibility checklist deficiencies
- "Engineering paper" without algorithmic insight

**Theoretical Contribution Expectation** (HIGH):
ICML expects formal analysis. At minimum include: complexity analysis, convergence arguments, or formal justification for design choices. Papers that "just add a module and show it works" are routinely rejected. Derivation of the loss function from a principled objective (variational inference, information theory, etc.) is strongly valued. Include at least one proposition/theorem in the main paper.

**Tips for AI/LLM/Agent Bioinformatics Papers**:
- Frame as **methodological/theoretical** contribution first; bio application second
- Include a Theoretical Analysis subsection with formal results (propositions, theorems, bounds)
- Derive your training objective from a principled framework, not just design it empirically
- Agent papers: prove properties (convergence, optimality) of the agent architecture, don't just benchmark
- Mathematical depth matters — formalize everything: problem, method, analysis
- Show why the domain-specific design is principled with formal arguments, not ad-hoc intuition
- Example accepted paper pattern: "We formulate X as Y, prove property Z, and achieve SOTA on benchmarks"

**Deadline Pattern**: Usually late January for July conference

**Template**:
- Source: `https://icml.cc/Conferences/2026/StyleAuthorInstructions` or search Overleaf "ICML 2026"
- Style file: `icml2026.sty` + `fancyhdr.sty`
- Key: Two-column, 10pt, natbib author-year citations

---

### NeurIPS

**Identity**: Highest-prestige ML/AI venue. Values conceptual novelty above all. Strong empirical culture with rigorous evaluation standards.

**What Reviewers Value**:
- Strong conceptual novelty (new ideas, surprising insights)
- Thorough experimental validation including ablation
- Broader Impact statement (required and reviewed)
- Datasets & Benchmarks track for benchmark contributions
- High writing quality
- Reproducibility checklist (mandatory)

**Official Review Criteria**:
1. Significance and novelty
2. Technical quality and correctness
3. Clarity and presentation
4. Experimental evaluation
5. Reproducibility
6. Broader impact

**Common Rejection Reasons**:
- "Nice engineering but limited novelty"
- Broader Impact statement missing or perfunctory
- Not enough ablation to understand why the method works
- Overselling results or making unsupported claims
- Writing quality not at expected NeurIPS level
- Lack of insight beyond empirical gains

**Theoretical Contribution Expectation** (MEDIUM-HIGH):
NeurIPS values theoretical **insight** over formal machinery. The gold standard is: "We discover that X is true, prove it formally, and show it leads to better methods." Full proofs can go in the appendix, but the key theorem/insight must be in the main paper. Purely empirical papers can be accepted if the empirical findings reveal a surprising principle, but including formal analysis significantly strengthens the submission.

**Tips for AI/LLM/Agent Bioinformatics Papers**:
- NeurIPS loves "insight-driven" papers — frame around a **key theoretical insight** (e.g., "We prove that biological prior knowledge provably reduces sample complexity for cell type classification")
- Bio-AI papers should show the insight transfers beyond the specific domain
- Consider Datasets & Benchmarks track for new benchmark contributions
- Extra page (9 vs 7-8) means more room for theoretical analysis — use it for formal treatment
- ML4Science and Computational Biology tracks are receptive
- Reproducibility checklist must be complete and honest
- Broader Impact section should discuss responsible bio-AI implications
- Best pattern: deep theoretical insight + comprehensive experiments that validate the theory

**Deadline Pattern**: Usually mid-to-late May for December conference

**Template**:
- Source: `https://neurips.cc/Conferences/2026/PaperInformation/StyleFiles` or search Overleaf "NeurIPS 2026"
- Style file: `neurips_2026.sty`
- Key: Two-column, 10pt, natbib numbered citations (unsrtnat)

---

### ICLR

**Identity**: Representation learning focused, now broadly ML. Open review process on OpenReview. Strong in foundation models, pre-training, and learning paradigms.

**What Reviewers Value**:
- Novel representations or learning approaches
- Clear empirical contribution with thorough analysis
- Active engagement during discussion period
- Well-structured arguments that anticipate reviewer questions
- Foundation model and LLM papers are a natural fit
- Interpretability and analysis of learned representations

**Official Review Criteria**:
1. Significance of contributions
2. Novelty
3. Correctness
4. Technical quality
5. Clarity
6. Relevance to ICLR scope

**Common Rejection Reasons**:
- Inadequate engagement with reviewer concerns during discussion
- Contribution too domain-specific without general ML lessons
- Experimental setup has unfair advantages (more data, larger models)
- Open review reveals rushed revisions
- No clear learning/representation contribution
- Ambiguous or incomplete method description

**Theoretical Contribution Expectation** (MEDIUM):
ICLR values understanding of learned representations. Formal analysis of what the model captures (information-theoretic analysis, probing theory, representation geometry) is highly valued. Full formal proofs are less common than at ICML, but rigorous analysis of learned representations and principled loss function design are expected. "We show that our representation captures X because Y" with formal justification is the sweet spot.

**Tips for AI/LLM/Agent Bioinformatics Papers**:
- Best fit for foundation model papers — representation learning is core scope
- Agent papers with learning components fit well
- Open review means polished writing from submission — public scrutiny is immediate
- Engage actively and constructively during discussion period
- Workshop papers (ICLR has many bio-related workshops) can be stepping stones
- **Show what the model learns about biology with formal analysis** — not just benchmark numbers, but information-theoretic or geometric characterization of the representation space
- Pre-training and fine-tuning paradigms are core ICLR topics
- Include formal analysis of representation quality (mutual information, disentanglement metrics, identifiability)

**Deadline Pattern**: Usually late September to early October for May conference

**Template**:
- Source: `https://github.com/ICLR/Master-Template` or search Overleaf "ICLR 2026"
- Style file: `iclr2026_conference.sty`
- Key: Two-column, 10pt, natbib author-year citations

---

## Venue Selection Decision Tree

Given a bioinformatics + LLM/Agent paper, choose venue by primary contribution type:

1. **New representation/embedding method for biological data?**
   → ICLR (best fit), NeurIPS (close second)

2. **New algorithm with theoretical backing?**
   → ICML (best fit), NeurIPS (good alternative)

3. **AI application with strong domain impact?**
   → AAAI (most welcoming), IJCAI (if theoretical angle exists)

4. **New benchmark or dataset for bio-AI?**
   → NeurIPS Datasets & Benchmarks track

5. **Agent architecture or planning system for bio tasks?**
   → AAAI (strong agent/planning tradition), ICLR (if learning-focused), NeurIPS

6. **Multi-agent collaboration for biological discovery?**
   → IJCAI (reasoning/planning), AAAI (multi-agent systems)

7. **LLM fine-tuning for biological language (DNA/protein/cell)?**
   → ICLR (representation), NeurIPS (methodology)

**Deadline pressure?**
→ Check "Typical Deadline" row in quick comparison and target the next deadline that gives at least 6 weeks of writing time after experiments complete.

---

## 2026 Deadline Calendar (Approximate)

| Month | Deadline | Conference | Event Date |
|-------|----------|-----------|------------|
| Jan ~15 | IJCAI 2026 submission | IJCAI 2026 | Aug 2026 |
| Jan ~30 | ICML 2026 submission | ICML 2026 | Jul 2026 |
| May ~15 | NeurIPS 2026 submission | NeurIPS 2026 | Dec 2026 |
| Aug ~10 | AAAI 2027 submission | AAAI 2027 | Feb 2027 |
| Sep ~25 | ICLR 2027 submission | ICLR 2027 | May 2027 |

**IMPORTANT**: All dates are approximate. Always verify on official conference websites before planning.
