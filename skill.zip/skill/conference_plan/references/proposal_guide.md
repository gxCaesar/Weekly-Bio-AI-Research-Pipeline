# Research Proposal Guide

## Proposal Template (Chinese)

```markdown
# {项目名称} 研究方案

## 1. 研究问题与动机

### 1.1 问题定义
[清晰定义要解决的科学问题/技术问题]

### 1.2 研究动机
[为什么现在需要解决这个问题]
[当前方法的关键局限是什么]

### 1.3 目标
[本研究的具体目标，可量化]

## 2. 创新点

**要求**: 至少3个创新点，其中**至少1个必须是理论层面的贡献**（新的问题形式化、收敛保证、泛化界、表达能力分析等），而非纯工程创新。参见下方"Innovation Point Standards"中的理论创新模式。

### 创新点1: [名称] — 类型: [理论/方法/工程]
- **描述**: [具体描述这个创新]
- **创新层次**: [Level 1(工程) / Level 2(方法+理论动机) / Level 3(理论贡献)] (参见Innovation Depth Levels)
- **解决的问题**: [这个创新解决了什么问题]
- **与现有工作的区别**: [和最接近的相关工作相比，有什么不同]
- **技术依据**: [基于哪些论文/技术发展]
- **理论支撑**: [形式化证明/定理/界/分析 — 如果是理论创新，描述将要证明什么；如果是工程创新，描述理论动机]
- **实现路径**: [具体实现步骤，1-2-3列出]
- **依赖的开源实现**: [具体repo + 文件/类名]
- **最小可验证实验**: [最小规模的验证实验，确认创新有效]

### 创新点2: [名称] — 类型: [理论/方法/工程]
[同上结构]

### 创新点3: [名称] — 类型: [理论/方法/工程]
[同上结构]

### 创新点理论深度自检
- [ ] 至少1个创新点达到Level 2或Level 3
- [ ] 每个创新点都有"理论支撑"字段（即使是工程创新也需说明理论动机）
- [ ] 论文Method部分可以包含至少1个定理/命题/引理
- [ ] "So what?" — 每个创新超越了纯benchmark提升，有可解释的原理

## 3. 可行性验证清单

### 3.1 计算可行性 (1x A100 80GB 硬约束)
- [ ] 模型参数量: ~XX M/B
- [ ] 模型参数显存 (bf16): ~XX GB
- [ ] 优化器状态 (Adam): ~XX GB
- [ ] 激活值显存 (batch=B, seq=S): ~XX GB
- [ ] 梯度累积缓冲: ~XX GB
- [ ] **峰值显存合计: ~XX GB (必须 < 75 GB)**
- [ ] 如果 > 75GB: 必须使用 LoRA/QLoRA + gradient checkpointing + bf16

### 3.2 数据可行性
- [ ] 数据集1: [名称] — URL已验证可下载 ✓/✗
- [ ] 数据集2: [名称] — URL已验证可下载 ✓/✗
- [ ] 总存储需求: ~XX GB
- [ ] 预处理时间估算: ~XX 小时

### 3.3 代码可行性
- [ ] 基础代码仓库: [repo URL] — 已确认可运行 ✓/✗
- [ ] PyTorch 2.x 兼容性: ✓/✗
- [ ] 所需修改范围: [列出需要修改的文件]
- [ ] 无闭源API依赖: ✓/✗ (如需要GPT-4等，提供开源替代方案)

### 3.4 人力可行性
- [ ] 学生2周内可实现核心模块: ✓/✗
- [ ] 无特殊硬件依赖(仅需1x A100): ✓/✗
- [ ] 无需人工标注数据: ✓/✗

**验证结论**: FEASIBLE / NEEDS_ADJUSTMENT / INFEASIBLE
[如果 NEEDS_ADJUSTMENT，描述具体调整方案]

## 4. 方法概述

### 4.1 整体框架
[描述方法的整体pipeline/framework]

### 4.2 模型架构

#### ASCII架构图
```
[Input] --> [Module A] --> [Module B] --> [Module C] --> [Output]
                |              |
                v              v
           [Sub-module]   [Sub-module]
```

#### 架构详细说明
[逐个模块描述，包括输入输出维度，计算过程]

### 4.3 训练策略
[预训练/微调策略，损失函数设计，优化方法]

### 4.4 关键技术细节
[算法伪代码或关键公式]

### 4.5 开源代码依赖图

```
[Repo A: backbone] --> [Our Module 1: new component]
[Repo B: data pipeline] --> [Our preprocessing: modified tokenizer]
[From scratch: novel component C]
```

| 依赖仓库 | 使用部分 | 修改内容 | commit hash | 许可证 |
|---------|---------|---------|-------------|--------|
| [repo URL] | [文件/类] | [修改描述] | [hash] | MIT/Apache |

## 5. 数据集

| 数据集 | 来源 | 规模 | 用途 | 下载方式 | 预处理方法 | 下载验证 | 大小(GB) | 预处理时间 |
|-------|------|------|------|---------|-----------|:---:|---------|---------|
[列出所有使用的数据集]

### 5.1 数据预处理流程
[详细的预处理步骤]

### 5.2 数据划分
[训练/验证/测试集划分策略]

## 6. 基线方法

| 基线方法 | 论文 | 年份 | 开源代码链接 | 关键指标 | 复现状态 |
|---------|------|------|-------------|---------|---------|
[列出5-8个基线方法]

复现状态说明:
- 官方代码可运行: 已确认可在1x A100上运行
- 需要适配: 代码存在但需要适配当前环境
- 仅论文: 无可用代码，需自行实现

### 各基线简述
[简要描述每个基线的核心方法和复现命令]

## 7. 评估指标

| 指标名称 | 数学定义 | 评估维度 | 备注 |
|---------|---------|---------|------|
[列出所有评估指标]

## 8. 消融实验设计

| 实验编号 | 消融对象 | 具体做法 | 验证目的 |
|---------|---------|---------|---------|
| A1 | [组件1] | [移除/替换...] | [验证组件1的贡献] |
| A2 | [组件2] | [...] | [...] |
[至少设计5个消融实验]

## 9. 计算资源评估

### 9.1 GPU显存估算 (1x A100 80GB 硬约束)
- 模型参数量: ~XX M/B parameters
- 参数显存 (bf16): ~XX GB
- 优化器状态 (Adam bf16): ~XX GB
- 激活值 (batch=B, seq=S): ~XX GB
- 峰值显存: ~XX GB (**必须 ≤ 75 GB**)
- 如果 > 75GB: **停止**，必须缩减模型/使用LoRA/开启gradient checkpointing

### 9.2 训练时间估算 (1x A100)
- 单epoch时间: ~XX hours
- 总epoch数: XX
- 总训练时间: ~XX hours / XX days
- 如果 > 14天: **停止**，必须缩减训练规模

### 9.3 全部实验时间 (含并行调度)
- 主模型训练 (3 seeds): ~XX days
- 全部基线运行 (串行): ~XX days
- 消融实验 (可部分并行): ~XX days
- 分析+验证 (CPU为主): ~XX days
- 总GPU占用时间: ~XX days (**建议 ≤ 35 days, 为论文撰写留3周**)
- 参考时间规划(Section 12)中的并行执行方案以优化总工期

## 10. 基于的论文和开源代码

| 参考论文 | 使用方式 | GitHub链接 | 许可证 | 最后验证日期 | 兼容性 |
|---------|---------|-----------|--------|-----------|--------|
[列出我们模型的代码基础来源]

### 10.1 代码复用计划
[具体说明从哪个repo复用哪些组件，自己需要写哪些]

## 11. 风险评估与备选方案

### 11.1 技术风险矩阵

| 风险 | 概率(H/M/L) | 影响(H/M/L) | 检测时机 | 具体备选方案 |
|------|:---:|:---:|---------|-----------|
[识别主要风险，每个备选方案必须是具体可执行的]

### 11.2 关键里程碑与决策点

| 周 | 里程碑 | 成功标准 | 如果未达标 |
|---|--------|---------|-----------|
| 2 | 基线复现 | 结果与论文±2% | 切换到更简单的基线 |
| 4 | 方法v1训练完成 | Loss收敛 | 简化模型/减少创新点 |
| 6 | 初步实验结果 | 优于至少一个基线 | 调整创新点/参数 |
| 8 | 全部实验完成 | 完整结果 | 用现有结果写论文 |

### 11.3 最小可发表方案 (Minimum Publishable Unit)

如果完整方案失败，以下子集仍可构成有价值的发表:
- MPU创新点: [列出最核心的1-2个创新点]
- MPU预期结果: [哪些表格/实验仍然有效]
- MPU目标venue: [可能的备选venue]

## 12. 时间规划 (1-2 Month Sprint)

### 8周时间线 (含并行执行)

| 周 | 主线任务 | 并行任务 | 产出 | Go/No-go |
|---|---------|---------|------|---------|
| 1 | 环境搭建 + 数据下载预处理 | 开始写survey.md和proposal.md草稿 | 数据就绪 + 方案初稿 | |
| 2 | 实现我们的方法v0 (最小版本) | 下载/配置2-3个关键baseline的代码 | 方法v0可运行 | 方法v0在小数据上能跑通? |
| 3 | 方法v0小规模快速验证 (1个数据集, 1/10数据) | 并行跑2-3个关键baseline (优先级最高的) | 快速验证结果 | **方法比baseline好5%+?** 否则诊断/调整 |
| 4 | 方法改进 + 全量数据训练 (seed 1) | 并行: 剩余baseline训练 | 主模型v1完成 | Loss收敛? |
| 5 | 主模型多种子运行 (seed 2,3) | 并行: 消融实验 (ablation A,B,C同时跑) | 主结果 + 消融结果 | 多数据集上一致优于baseline? |
| 6 | 分析脚本运行 + 生物学验证 | 并行: 写论文 (Method + Related Work) | 全部实验数据 + 论文骨架 | 统计显著? |
| 7 | 论文撰写 (Intro + Experiments + figures) | 补充实验 (sensitivity, efficiency) | 论文初稿 | |
| 8 | 论文打磨 + 补充材料 + 检查清单 | Presentation制作 | 可提交版本 | 全部checklist通过? |

### 并行执行关键原则

**GPU使用调度** (1x A100):
- 同一时间只能训练1个模型
- 但可以: 白天跑训练, 晚上跑evaluation/analysis (不需要GPU)
- Baseline之间可以串行但应连续安排, 不要中间穿插其他任务

**实际可并行的工作**:
- 写代码/论文 (CPU) + 训练模型 (GPU) = 并行
- 跑分析脚本 (CPU为主) + 下一个模型训练 (GPU) = 并行
- 数据预处理 + 写survey = 并行

**不可并行**:
- 两个需要GPU的训练任务 (只有1张A100)
- 写论文Results段 + 等实验结果 (先跑完实验才能写)

### 优先级排序 (如果时间不够)

**必须完成 (核心)**:
1. 我们的方法在所有数据集上的完整结果 (3+ seeds)
2. 3个最重要的baseline (选最近、最强、最相关的)
3. 3个最关键的消融实验 (每个核心创新点1个)
4. 论文主体 (Method + main results table + ablation table)

**应该完成 (加强)**:
5. 剩余2-3个baseline
6. 剩余消融实验
7. 效率对比表
8. 生物学验证 (GO enrichment, UMAP)

**锦上添花 (如果有时间)**:
9. Sensitivity analysis
10. 更多种子 (5个而非3个)
11. 额外数据集
12. Case study

### 进度落后时的应急方案

| 落后程度 | 应对策略 |
|---------|---------|
| 落后1周 | 减少baseline数量(5→3), 减少消融实验(5→3), 周末加班 |
| 落后2周 | 切换到MPU(最小可发表方案), 只保留核心创新点, 减少到2个数据集 |
| 方法效果不好 | 第3周go/no-go: 如果v0验证失败, 立即调整方向或简化方法 |
| 代码bug严重 | 先确保1个数据集+1个baseline跑通, 再扩展 |
```

## Innovation Point Standards

For top-venue acceptance, innovation points must be:

1. **Novel**: Not a trivial combination of existing techniques
2. **Significant**: Solves a real limitation, not incremental improvement
3. **Generalizable**: Not ad-hoc to one dataset
4. **Technically sound**: Grounded in established theory or clear empirical evidence
5. **Clearly articulated**: A reviewer can understand the novelty in one sentence
6. **Theoretically grounded**: Has formal justification (proof, bound, or rigorous analysis) — not just "it works empirically"
7. **Implementable**: Can be coded in <2 weeks by one student with clear instructions
8. **Resource-compatible**: Fits within 1x A100 80GB, trains in <14 days

### Innovation Depth Levels

Top venues expect contributions at Level 2 or above. Pure Level 1 papers are frequently rejected as "engineering without insight."

| Level | Description | Example | Typical Verdict |
|:-----:|-------------|---------|----------------|
| 1 | **Engineering**: New module/pipeline, no theoretical analysis | "We add a GRN-guided attention layer" | Reject: "limited novelty" |
| 2 | **Methodological**: New formulation + theoretical motivation + formal analysis | "We formulate cell-type annotation as a structured prediction problem and prove our objective is a tight variational bound" | Borderline → Accept |
| 3 | **Theoretical**: New framework with formal guarantees, generalization bounds, or provable properties | "We derive generalization bounds for biological foundation models under distribution shift and prove our method is minimax optimal" | Accept |

### Theoretical Innovation Patterns (Required — choose at least 1)

Every proposal must include **at least one** theoretically grounded innovation from this list:

1. **New problem formulation**: Reformulate a biological task as a well-defined learning problem with formal notation. Not just "we apply X to Y" — define the problem space, state assumptions, and show why existing formulations are suboptimal.
   - Example: Reformulate drug-target interaction as a structured prediction over molecular graphs with provable expressiveness guarantees

2. **Theoretical analysis of method properties**: Prove or formally analyze why your method works — convergence guarantees, approximation bounds, sample complexity, or information-theoretic limits.
   - Example: Prove that your GRN-guided attention converges to the optimal sparse attention pattern under mild assumptions on the gene regulatory network

3. **Formal connection between domains**: Establish rigorous theoretical bridges between biological concepts and ML formulations — not just analogy, but mathematical correspondence.
   - Example: Show that cell state transitions in Waddington's landscape correspond to gradient flow in your learned representation space, with formal stability analysis

4. **Generalization bounds under domain shift**: Prove generalization guarantees when transferring from pre-training data to biological target domains, especially under covariate shift or label shift.
   - Example: Derive PAC-Bayes bounds for LLM fine-tuning on single-cell data, showing how biological prior knowledge tightens the bound

5. **Complexity and expressiveness analysis**: Formally characterize what your model can and cannot represent — expressiveness results, computational complexity of inference, hardness results.
   - Example: Prove that your agent architecture is strictly more expressive than standard prompt-based approaches for multi-step biological reasoning

6. **Information-theoretic analysis**: Use information theory to justify design choices — mutual information bounds, rate-distortion analysis, channel capacity arguments.
   - Example: Show that your cell embedding preserves maximal mutual information with downstream tasks via an information bottleneck formulation

### Engineering Innovation Patterns (Supplementary)

These are valid but should be paired with at least one theoretical contribution:
- New architecture component that addresses a specific limitation
- Novel training objective that captures previously ignored signals
- Cross-domain transfer of techniques with non-trivial adaptation
- Unified framework that connects previously separate approaches
- LLM/Agent-based paradigm shift for traditionally non-LLM tasks

### Innovation Quality Self-Check

Before finalizing, verify each innovation point against these questions:
- **"So what?"** — Can you explain why a reviewer should care beyond benchmark improvements?
- **"Why does it work?"** — Can you provide formal analysis, not just empirical evidence?
- **"What is the insight?"** — Is there a non-obvious principle or finding that other researchers can build on?
- **"Is it just engineering?"** — Would removing the theoretical analysis make the paper rejectable at ICML/NeurIPS?
- **"Does it generalize?"** — Does the theoretical result apply beyond this specific dataset/task?

## Compute Budget Guidelines (1x A100 80GB — Hard Constraint)

| Model Scale | Parameters | Memory (bf16) | Est. Time (1xA100) | Feasible? |
|------------|-----------|:---:|:---:|:---:|
| Small | 100M-500M | 15-30 GB | 1-3 days | YES |
| Medium | 500M-2B | 30-50 GB | 3-7 days | YES (may need grad ckpt) |
| Large (LoRA/QLoRA) | 7B | 25-40 GB | 2-5 days | YES |
| Large (full fine-tune) | 7B | 70-80 GB | 7-14 days | MARGINAL (use with caution) |
| XL (LoRA only) | 13B+ | 50-70 GB | 5-10 days | RISKY |

**Hard rules**:
- Peak memory > 75GB: MUST use gradient checkpointing + LoRA + bf16
- Single model training > 7 days: consider reducing epochs or model size (total GPU time budget is ~35 days)
- No multi-GPU assumptions. All experiments run on exactly 1x A100
- If using API-based LLM (GPT-4, Claude): estimate cost and provide open-source alternative (vLLM + local model)
- 8-week total project timeline: see Section 12 for parallel execution plan
