# Biological Validation Guide for AI/LLM/Agent Bioinformatics Papers

A bioinformatics paper at ML venues must bridge two worlds: computational results (accuracy, F1) AND biological meaning (does it capture real biology?). Papers that report only ML metrics are rejected as "lacking biological insight."

---

## 1. Required Biological Validation by Task

### 1.1 Single-Cell Analysis (Cell Type Annotation, Clustering, Integration)

| Validation | What it shows | Tool/Method | Include in |
|-----------|--------------|-------------|-----------|
| Marker gene recovery | Model identifies known cell-type markers | Wilcoxon rank-sum test on top features | Main paper |
| GO enrichment analysis | Learned features are biologically meaningful | `gseapy`, `goatools` | Main paper |
| UMAP/t-SNE with cell type labels | Embeddings capture cell identity | `scanpy.pl.umap` | Main paper Fig 6 |
| Batch effect assessment | Integration removes batch, keeps biology | kBET, iLISI/cLISI scores | Main paper or appendix |
| Trajectory consistency | Embeddings preserve developmental ordering | Diffusion pseudotime correlation | Appendix |

Code pattern for `analysis/bio_validation.py`:

```python
"""
Paper Element: Biological validation analysis
- Figure 6: UMAP visualization with cell type annotations
- Table: Marker gene recovery rates
- Table: GO enrichment analysis results
"""
import scanpy as sc
import gseapy as gp
import numpy as np
import pandas as pd
from scipy import stats


def marker_gene_recovery(
    adata, model_top_genes: dict, known_markers: dict
) -> pd.DataFrame:
    """Compare model's top-ranked genes with known cell type markers.

    Args:
        adata: AnnData with cell type labels
        model_top_genes: {cell_type: [gene1, gene2, ...]} from attention/importance
        known_markers: {cell_type: [known_marker1, ...]} from literature

    Returns: DataFrame with overlap statistics per cell type
    """
    records = []
    for ct in known_markers:
        if ct not in model_top_genes:
            continue
        model_set = set(model_top_genes[ct][:50])
        known_set = set(known_markers[ct])
        overlap = model_set & known_set
        # Fisher's exact test for significance
        total_genes = adata.n_vars
        _, pval = stats.fisher_exact([
            [len(overlap), len(model_set - known_set)],
            [len(known_set - model_set), total_genes - len(model_set | known_set)]
        ])
        records.append({
            "cell_type": ct,
            "model_top_50": len(model_set),
            "known_markers": len(known_set),
            "overlap": len(overlap),
            "overlap_rate": len(overlap) / len(known_set) if known_set else 0,
            "p_value": pval,
        })
    return pd.DataFrame(records)


def go_enrichment_analysis(
    gene_list: list, organism: str = "human", gene_sets: str = "GO_Biological_Process_2023"
) -> pd.DataFrame:
    """Run GO enrichment on a gene list.

    Returns: DataFrame with enriched GO terms, sorted by adjusted p-value
    """
    enr = gp.enrichr(gene_list=gene_list, gene_sets=gene_sets, organism=organism)
    results = enr.results
    significant = results[results["Adjusted P-value"] < 0.05]
    return significant.head(20)  # Top 20 enriched terms


def embedding_quality_metrics(adata, embedding_key: str, label_key: str) -> dict:
    """Compute biological quality metrics for learned embeddings.

    Returns: {silhouette_score, calinski_harabasz, ARI, NMI}
    """
    from sklearn.metrics import silhouette_score, calinski_harabasz_score
    from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
    from sklearn.cluster import KMeans

    X = adata.obsm[embedding_key]
    labels = adata.obs[label_key].values
    n_clusters = len(set(labels))

    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    pred_labels = kmeans.fit_predict(X)

    return {
        "silhouette": silhouette_score(X, labels, sample_size=min(5000, len(X))),
        "calinski_harabasz": calinski_harabasz_score(X, labels),
        "ARI": adjusted_rand_score(labels, pred_labels),
        "NMI": normalized_mutual_info_score(labels, pred_labels),
    }
```

### 1.2 Drug Design / Molecular Generation

| Validation | What it shows | Tool/Method | Include in |
|-----------|--------------|-------------|-----------|
| Drug-likeness (QED) | Generated molecules are drug-like | RDKit `Descriptors.qed` | Main paper |
| Synthetic accessibility (SA) | Molecules can be synthesized | RDKit SA Score | Main paper |
| Novelty check | Molecules are not in training set | Tanimoto similarity | Main paper |
| Property distribution match | Generated properties match target | KS test on property distributions | Main paper |
| In silico docking score | Computational binding affinity prediction | AutoDock Vina / GNINA (computational) | Main paper or appendix |
| ADMET prediction | Computational toxicity/absorption prediction | ADMETlab / pkCSM (computational) | Appendix |

### 1.3 Gene Regulatory Network Inference

| Validation | What it shows | Tool/Method | Include in |
|-----------|--------------|-------------|-----------|
| Known interaction recovery | Model recovers validated interactions | AUROC/AUPRC vs ChIP-seq database | Main paper |
| Pathway enrichment | Inferred edges enrich known pathways | KEGG/Reactome overlap | Main paper |
| TF binding site overlap | Predicted regulators match TF binding | ENCODE ChIP-seq peaks | Appendix |
| Perturbation prediction | GRN predicts gene knockout effects | Correlation with Perturb-seq data | Main paper |

### 1.4 Virtual Cell / Multi-Omics

| Validation | What it shows | Tool/Method | Include in |
|-----------|--------------|-------------|-----------|
| Cross-modality prediction | Predict one omics from another | Correlation/R² on held-out modality | Main paper |
| Biological consistency | Multi-omics embeddings are consistent | Cross-modal nearest neighbor accuracy | Main paper |
| Perturbation response | Model predicts drug/genetic perturbation | Correlation with published Perturb-seq datasets | Main paper |
| Cell state transition | Model captures differentiation trajectories | Pseudotime correlation | Appendix |

---

## 2. Biological Visualization Templates

### 2.1 UMAP with Cell Type Annotations (Must-Have)

```python
def plot_umap_celltypes(adata, embedding_key, label_key, output_path, title=""):
    """Publication-quality UMAP colored by cell types."""
    import matplotlib.pyplot as plt
    import scanpy as sc

    sc.settings.set_figure_params(dpi=300, fontsize=10, facecolor='white')

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    # Left: colored by cell type
    sc.pl.embedding(adata, basis=embedding_key, color=label_key,
                    ax=axes[0], show=False, title=f"{title} Cell Types",
                    legend_loc='right margin', frameon=False)

    # Right: colored by batch (to show batch effect removal)
    if 'batch' in adata.obs:
        sc.pl.embedding(adata, basis=embedding_key, color='batch',
                        ax=axes[1], show=False, title=f"{title} Batch",
                        legend_loc='right margin', frameon=False)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
```

### 2.2 Attention Weight on Biological Network

```python
def plot_attention_on_grn(
    attention_weights: np.ndarray,
    gene_names: list,
    grn_edges: list,  # [(gene_a, gene_b), ...]
    output_path: str,
    top_k: int = 50,
):
    """Overlay model attention weights on known gene regulatory network."""
    import networkx as nx
    import matplotlib.pyplot as plt

    G = nx.DiGraph()
    # Add known GRN edges
    for src, tgt in grn_edges:
        if src in gene_names and tgt in gene_names:
            i, j = gene_names.index(src), gene_names.index(tgt)
            G.add_edge(src, tgt,
                       weight=float(attention_weights[i, j]),
                       is_known=True)

    # Highlight top-k attention edges
    # Color: red = high attention on known edge, blue = high attention on unknown
    # This shows whether the model recovers known biology

    pos = nx.spring_layout(G, seed=42)
    plt.figure(figsize=(10, 10))
    # ... draw edges with width proportional to attention weight
    # ... highlight known vs discovered interactions
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
```

### 2.3 Gene Expression Heatmap

```python
def plot_expression_heatmap(
    adata, gene_list: list, group_key: str, output_path: str
):
    """Heatmap of gene expression across cell types / conditions."""
    import scanpy as sc
    sc.pl.heatmap(adata, var_names=gene_list, groupby=group_key,
                  swap_axes=True, show_gene_labels=True,
                  save=output_path)
```

---

## 3. Bridging ML and Biology in Paper Narrative

### 3.1 Sentence Templates

**Connecting attention weights to biology:**
"The top-K genes with highest attention weights in cell type X include [gene1], [gene2], and [gene3], which are established markers of [cell type/pathway] (PMID: XXXXX). This suggests the model captures biologically meaningful gene-gene interactions rather than spurious correlations."

**Connecting embeddings to cell identity:**
"UMAP visualization of our learned embeddings (Fig. 6) shows clear separation of cell types, with continuous trajectories connecting [progenitor] to [differentiated] cells. This organization recapitulates the known differentiation hierarchy of [tissue type], indicating that our representation captures biological state transitions."

**Connecting GRN inference to ground truth:**
"Our inferred regulatory network recovers 73% of known TF-target interactions from the ENCODE ChIP-seq database (p < 1e-10, Fisher's exact test), compared to 45% for the best baseline. Among the 12 high-confidence novel interactions, several involve TFs known to regulate [biological process], pointing to computationally predicted regulatory mechanisms worth further investigation."

**Connecting drug generation to pharmacology:**
"Generated molecules exhibit drug-like properties (mean QED = 0.72 +/- 0.08) with high synthetic accessibility (mean SA = 3.2 +/- 0.5). Computational docking against [target protein] shows that 34% of generated molecules achieve predicted binding affinity below -7.0 kcal/mol, comparable to known active compounds in the [database] library."

### 3.2 The "So What?" Test for Biological Significance

For every result, ask: "Would a biologist reading this paragraph learn something about biology, or only about our algorithm?"

**Fails the test**: "Our method achieves 91.2% accuracy on cell type annotation."
**Passes the test**: "Our method achieves 91.2% accuracy on cell type annotation, with the largest gains on rare immune subtypes (CD8+ naive T cells: +8.2%), suggesting that incorporating pathway knowledge is most valuable when training examples are scarce — a common challenge in clinical samples."

### 3.3 When to Cite Biological Literature

In a bio-AI paper, include citations to:
- The biological process you're modeling (e.g., hematopoiesis, drug metabolism)
- Known marker genes you reference (cite the original discovery)
- Databases you validate against (KEGG, GO, ENCODE, ChEMBL)
- The biological significance of your findings (e.g., why recovering TF X matters)

This signals to reviewers that you understand the domain, not just the algorithm.

---

## 4. Analysis Script Additions for Code Project

Add to `code/analysis/`:

```
analysis/
├── ... (existing scripts)
├── bio_validation.py          # Marker gene recovery, GO enrichment, embedding metrics
├── bio_visualization.py       # UMAP, attention-on-network, expression heatmap
└── domain_specific_analysis.py # Task-specific biological validation
```

These scripts must be:
- Pre-written with the correct function signatures
- Mapped to specific paper figures/tables
- Configurable for different biological tasks via YAML
