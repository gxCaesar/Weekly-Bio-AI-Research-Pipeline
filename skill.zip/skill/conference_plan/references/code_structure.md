# Code Project Structure & Conventions

## Project Layout

```
code/
├── configs/                      # All hyperparameters live here
│   ├── default.yaml              # Default config (inherited by others)
│   ├── baseline_method1.yaml     # Override for baseline 1
│   ├── baseline_method2.yaml     # Override for baseline 2
│   ├── ablation_no_component1.yaml
│   └── ablation_no_component2.yaml
├── data/
│   ├── __init__.py
│   ├── download.py               # Automated dataset download
│   ├── preprocess.py             # Raw → processed data pipeline
│   ├── dataset.py                # torch.utils.data.Dataset classes
│   └── collator.py               # Custom collate functions
├── models/
│   ├── __init__.py
│   ├── model.py                  # Main model class
│   ├── modules.py                # Reusable sub-modules
│   └── losses.py                 # Loss functions
├── baselines/
│   ├── __init__.py
│   └── {name}.py                 # One file per baseline
├── training/
│   ├── __init__.py
│   ├── trainer.py                # Training loop
│   ├── optimizer.py              # Optimizer & scheduler factory
│   └── callbacks.py              # Checkpointing, logging, early stop
├── evaluation/
│   ├── __init__.py
│   ├── metrics.py                # Metric computation functions
│   ├── evaluate.py               # Full evaluation pipeline
│   └── visualize.py              # Plot generation
├── analysis/                     # NEW: Result analysis for paper
│   ├── __init__.py
│   ├── parse_results.py          # Parse raw outputs into DataFrames
│   ├── statistical_tests.py      # Significance tests (t-test, Wilcoxon, bootstrap)
│   ├── generate_tables.py        # Generate LaTeX tables for paper
│   ├── generate_figures.py       # Generate matplotlib/seaborn figures
│   ├── comparison_analysis.py    # Ours vs each baseline detailed comparison
│   ├── ablation_analysis.py      # Process ablation results
│   ├── case_study.py             # Generate case study examples
│   └── run_all_analysis.sh       # Master script: runs everything
├── scripts/
│   ├── run_all.sh                # End-to-end pipeline
│   ├── train.sh                  # Train with args
│   ├── eval.sh                   # Evaluate checkpoint
│   ├── run_baselines.sh          # All baselines
│   ├── run_ablation.sh           # All ablations
│   └── run_analysis.sh           # Run all analysis scripts
├── ablation/
│   └── run_ablation.py           # Orchestrates ablation experiments
├── main.py                       # CLI entry point
├── requirements.txt              # Pinned versions
└── README.md                     # English: setup, usage, structure
```

---

## Analysis Directory Conventions

### Paper-Analysis Mapping

Each analysis script MUST have a header comment declaring which paper element it produces:

```python
"""
Paper Element: Table 1 - Main Results Comparison
Description: Compares our method vs all baselines across all datasets and metrics
Input: outputs/*/eval_results.json
Output: analysis_outputs/table1_main_results.tex, analysis_outputs/table1_main_results.csv
"""
```

### Mapping Table

| Paper Element | Analysis Script | Input | Output |
|---------------|----------------|-------|--------|
| Table 1: Main Results | `generate_tables.py --table main` | eval_results.json | `table1_main_results.tex` |
| Table 2: Ablation | `ablation_analysis.py` | ablation_results/ | `table2_ablation.tex` |
| Table 3: Efficiency | `generate_tables.py --table efficiency` | timing_logs/ | `table3_efficiency.tex` |
| Fig 4: Main Bar Chart | `generate_figures.py --fig main_bar` | eval_results.json | `fig4_main_bar.pdf` |
| Fig 5: Ablation Heatmap | `generate_figures.py --fig ablation` | ablation_results/ | `fig5_ablation.pdf` |
| Fig 6: Case Study | `case_study.py` | model predictions | `fig6_case_study.pdf` |
| Statistical Tests | `statistical_tests.py` | all results | `stats_report.txt` |

### parse_results.py Pattern

```python
"""
Paper Element: (utility - feeds into all other scripts)
"""
import json
import pandas as pd
from pathlib import Path
from typing import Optional


def load_experiment_results(output_dir: str) -> pd.DataFrame:
    """Load all eval_results.json files into a single DataFrame.

    Returns DataFrame with columns:
        method, dataset, seed, metric_name, metric_value
    """
    records = []
    for result_file in Path(output_dir).rglob("eval_results.json"):
        with open(result_file) as f:
            data = json.load(f)
        method = data.get("method", result_file.parent.name)
        dataset = data.get("dataset", "unknown")
        seed = data.get("seed", 0)
        for metric_name, metric_value in data.get("metrics", {}).items():
            records.append({
                "method": method,
                "dataset": dataset,
                "seed": seed,
                "metric_name": metric_name,
                "metric_value": metric_value,
            })
    return pd.DataFrame(records)


def load_ablation_results(ablation_dir: str) -> pd.DataFrame:
    """Load ablation experiment results.

    Returns DataFrame with columns:
        ablation_name, removed_component, dataset, metric_name, metric_value
    """
    records = []
    for result_file in Path(ablation_dir).rglob("eval_results.json"):
        with open(result_file) as f:
            data = json.load(f)
        ablation_name = data.get("ablation_name", result_file.parent.name)
        removed = data.get("removed_component", "unknown")
        dataset = data.get("dataset", "unknown")
        for metric_name, metric_value in data.get("metrics", {}).items():
            records.append({
                "ablation_name": ablation_name,
                "removed_component": removed,
                "dataset": dataset,
                "metric_name": metric_name,
                "metric_value": metric_value,
            })
    return pd.DataFrame(records)


def load_timing_results(output_dir: str) -> pd.DataFrame:
    """Load training/inference timing logs.

    Returns DataFrame with columns:
        method, dataset, train_time_hours, inference_time_seconds, gpu_memory_gb
    """
    records = []
    for timing_file in Path(output_dir).rglob("timing.json"):
        with open(timing_file) as f:
            data = json.load(f)
        records.append({
            "method": data.get("method", timing_file.parent.name),
            "dataset": data.get("dataset", "unknown"),
            "train_time_hours": data.get("train_time_hours", 0),
            "inference_time_seconds": data.get("inference_time_seconds", 0),
            "gpu_memory_gb": data.get("peak_gpu_memory_gb", 0),
        })
    return pd.DataFrame(records)
```

### statistical_tests.py Pattern

```python
"""
Paper Element: Statistical significance annotations for all tables
"""
import numpy as np
from scipy import stats
from typing import Optional


def paired_t_test(ours: list, baseline: list, alpha: float = 0.05) -> dict:
    """Run paired t-test between our method and a baseline.

    Returns: {t_stat, p_value, significant, effect_size (Cohen's d)}
    """
    ours_arr, base_arr = np.array(ours), np.array(baseline)
    t_stat, p_value = stats.ttest_rel(ours_arr, base_arr)
    diff = ours_arr - base_arr
    effect_size = np.mean(diff) / np.std(diff, ddof=1) if np.std(diff, ddof=1) > 0 else 0.0
    return {
        "t_stat": float(t_stat),
        "p_value": float(p_value),
        "significant": p_value < alpha,
        "effect_size": float(effect_size),
    }


def wilcoxon_signed_rank(ours: list, baseline: list, alpha: float = 0.05) -> dict:
    """Non-parametric alternative when normality assumption fails."""
    stat, p_value = stats.wilcoxon(np.array(ours), np.array(baseline))
    return {
        "statistic": float(stat),
        "p_value": float(p_value),
        "significant": p_value < alpha,
    }


def bootstrap_confidence_interval(
    scores: list, n_bootstrap: int = 10000, ci: float = 0.95
) -> tuple:
    """Compute bootstrap confidence interval.

    Returns: (mean, lower_ci, upper_ci)
    """
    scores_arr = np.array(scores)
    boot_means = np.array([
        np.mean(np.random.choice(scores_arr, size=len(scores_arr), replace=True))
        for _ in range(n_bootstrap)
    ])
    lower = np.percentile(boot_means, (1 - ci) / 2 * 100)
    upper = np.percentile(boot_means, (1 + ci) / 2 * 100)
    return float(np.mean(scores_arr)), float(lower), float(upper)


def run_all_significance_tests(results_df, our_method: str = "Ours") -> "pd.DataFrame":
    """Run pairwise tests: our method vs each baseline, for each metric.

    Returns DataFrame with columns:
        baseline, metric, dataset, p_value, significant, test_used
    """
    import pandas as pd
    records = []
    baselines = [m for m in results_df["method"].unique() if m != our_method]
    for baseline in baselines:
        for metric in results_df["metric_name"].unique():
            for dataset in results_df["dataset"].unique():
                ours_scores = results_df[
                    (results_df["method"] == our_method) &
                    (results_df["metric_name"] == metric) &
                    (results_df["dataset"] == dataset)
                ]["metric_value"].values
                base_scores = results_df[
                    (results_df["method"] == baseline) &
                    (results_df["metric_name"] == metric) &
                    (results_df["dataset"] == dataset)
                ]["metric_value"].values
                if len(ours_scores) < 3 or len(base_scores) < 3:
                    continue
                result = paired_t_test(ours_scores.tolist(), base_scores.tolist())
                records.append({
                    "baseline": baseline,
                    "metric": metric,
                    "dataset": dataset,
                    "p_value": result["p_value"],
                    "significant": result["significant"],
                    "effect_size": result["effect_size"],
                    "test_used": "paired_t_test",
                })
    return pd.DataFrame(records)
```

### generate_tables.py Pattern

```python
"""
Paper Element: Table 1 (Main Results), Table 3 (Efficiency)
"""
import pandas as pd
import numpy as np
from typing import Optional


def generate_main_results_table(
    results_df: pd.DataFrame,
    stats_df: Optional[pd.DataFrame] = None,
    metrics: list[str] = None,
    datasets: list[str] = None,
) -> str:
    """Generate LaTeX table for main results.

    Bold best, underline second-best. Add * for statistically significant.
    Returns LaTeX string ready for \\input{} in paper.
    """
    # Pivot: rows = methods, columns = (dataset, metric)
    pivot = results_df.groupby(["method", "dataset", "metric_name"])["metric_value"].agg(
        ["mean", "std"]
    ).reset_index()

    # Format: XX.X ± X.X, bold best, underline second
    lines = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\caption{Main results. Best in \\textbf{bold}, second-best \\underline{underlined}. "
                  "* indicates $p < 0.05$.}")
    lines.append("\\label{tab:main}")
    # ... build tabular structure based on datasets and metrics
    lines.append("\\end{table}")
    return "\n".join(lines)


def generate_efficiency_table(timing_df: pd.DataFrame) -> str:
    """Generate LaTeX table comparing training time, inference time, GPU memory."""
    lines = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\caption{Efficiency comparison.}")
    lines.append("\\label{tab:efficiency}")
    lines.append("\\begin{tabular}{l|ccc}")
    lines.append("\\toprule")
    lines.append("Method & Train (h) & Infer (s) & GPU (GB) \\\\")
    lines.append("\\midrule")
    for _, row in timing_df.iterrows():
        lines.append(f"{row['method']} & {row['train_time_hours']:.1f} & "
                      f"{row['inference_time_seconds']:.2f} & {row['gpu_memory_gb']:.1f} \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    return "\n".join(lines)
```

### generate_figures.py Pattern

```python
"""
Paper Element: Fig 4 (Main Results Bar), Fig 5 (Ablation Heatmap)
"""
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
import pandas as pd
import numpy as np

# Conference-appropriate style settings
CONFERENCE_STYLE = {
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif"],
    "font.size": 10,
    "axes.labelsize": 11,
    "axes.titlesize": 12,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.05,
}

# Color palette suitable for colorblind readers
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860"]


def setup_style():
    """Apply conference-appropriate matplotlib style."""
    matplotlib.rcParams.update(CONFERENCE_STYLE)


def plot_main_results_bar(results_df: pd.DataFrame, output_path: str):
    """Generate grouped bar chart comparing all methods."""
    setup_style()
    # Implementation: grouped bar chart with error bars
    # Save to output_path as PDF for LaTeX inclusion


def plot_ablation_heatmap(ablation_df: pd.DataFrame, output_path: str):
    """Generate heatmap showing ablation study results."""
    setup_style()
    # Implementation: heatmap with annotated values
    # Save to output_path as PDF


def plot_sensitivity(results_df: pd.DataFrame, param_name: str, output_path: str):
    """Generate line plot for hyperparameter sensitivity analysis."""
    setup_style()
    # Implementation: line plot with confidence bands


def plot_case_study(predictions: dict, output_path: str):
    """Generate domain-specific case study visualization."""
    setup_style()
    # Implementation depends on domain (e.g., UMAP for single-cell, molecule viz for drug)
```

### run_all_analysis.sh Pattern

```bash
#!/bin/bash
set -e

RESULTS_DIR=${1:-outputs}
ANALYSIS_OUT=${2:-analysis_outputs}

echo "=== Collecting results from $RESULTS_DIR ==="
python analysis/parse_results.py --output_dir $RESULTS_DIR --save_to $ANALYSIS_OUT/

echo "=== Running statistical tests ==="
python analysis/statistical_tests.py --results $ANALYSIS_OUT/all_results.csv --output $ANALYSIS_OUT/stats_report.txt

echo "=== Generating LaTeX tables ==="
python analysis/generate_tables.py --results $ANALYSIS_OUT/all_results.csv --output_dir paper/tables/

echo "=== Generating figures ==="
python analysis/generate_figures.py --results $ANALYSIS_OUT/all_results.csv --output_dir paper/figures/

echo "=== Running ablation analysis ==="
python analysis/ablation_analysis.py --results $ANALYSIS_OUT/ --output_dir paper/tables/

echo "=== Generating case studies ==="
python analysis/case_study.py --results $ANALYSIS_OUT/ --output_dir paper/figures/

echo "=== Analysis complete. Outputs in: $ANALYSIS_OUT and paper/ ==="
ls -la $ANALYSIS_OUT/
ls -la paper/tables/
ls -la paper/figures/
```

---

## Code Patterns

### Configuration (configs/default.yaml)

```yaml
# Model
model:
  name: "OurModel"
  hidden_dim: 768
  num_layers: 12
  num_heads: 12
  dropout: 0.1

# Data
data:
  dataset: "dataset_name"
  data_dir: "./data/processed"
  max_length: 512
  num_workers: 4

# Training
training:
  epochs: 100
  batch_size: 32
  gradient_accumulation_steps: 4
  learning_rate: 1e-4
  weight_decay: 0.01
  warmup_ratio: 0.1
  fp16: true
  gradient_checkpointing: false
  seed: 42

# Evaluation
evaluation:
  eval_every: 5
  metrics: ["accuracy", "f1", "auroc"]
  num_seeds: 3  # Run 3 seeds for std computation

# Logging
logging:
  wandb_project: "project-name"
  log_every: 100
  save_every: 10
  save_best: true
  save_timing: true  # Save timing info for efficiency analysis

# Hardware (STRICT: 1x A100 only)
hardware:
  num_gpus: 1
  gpu_ids: [0]
```

### Main Entry Point (main.py)

```python
import argparse
import yaml
import torch
import random
import numpy as np
import logging
import json
import time
from pathlib import Path

logger = logging.getLogger(__name__)


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True


def load_config(path: str) -> dict:
    with open(path) as f:
        config = yaml.safe_load(f)
    return config


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--mode", choices=["train", "eval", "train_eval"], default="train_eval")
    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--seed", type=int, default=None, help="Override config seed")
    args = parser.parse_args()

    config = load_config(args.config)
    seed = args.seed if args.seed is not None else config["training"]["seed"]
    set_seed(seed)

    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(Path(args.output_dir) / "train.log"),
        ],
    )

    logger.info(f"Config: {json.dumps(config, indent=2)}")
    logger.info(f"Seed: {seed}")
    logger.info(f"GPU: {torch.cuda.get_device_name(0)}")
    logger.info(f"GPU Memory: {torch.cuda.get_device_properties(0).total_mem / 1e9:.1f} GB")

    # Record timing
    start_time = time.time()

    # ... rest of pipeline (data loading, model creation, training, evaluation)

    # Save timing info for analysis
    timing = {
        "method": config["model"]["name"],
        "dataset": config["data"]["dataset"],
        "train_time_hours": (time.time() - start_time) / 3600,
        "peak_gpu_memory_gb": torch.cuda.max_memory_allocated() / 1e9,
        "seed": seed,
    }
    with open(Path(args.output_dir) / "timing.json", "w") as f:
        json.dump(timing, f, indent=2)
```

### Trainer Pattern (training/trainer.py)

Key requirements:
- Mixed precision with `torch.amp.GradScaler` (torch 2.x API)
- Gradient accumulation loop
- Periodic evaluation
- Best model checkpointing
- Wandb/tensorboard logging
- Resume from checkpoint support
- **Single-GPU only** (no DistributedDataParallel)
- Timing instrumentation

```python
class Trainer:
    def __init__(self, model, train_loader, val_loader, config, device):
        self.model = model.to(device)
        self.config = config
        self.device = device
        self.scaler = torch.amp.GradScaler(enabled=config["training"]["fp16"])
        self.best_metric = 0.0
        # ... setup optimizer, scheduler, logger

    def train_epoch(self, epoch: int):
        self.model.train()
        for step, batch in enumerate(self.train_loader):
            batch = {k: v.to(self.device) for k, v in batch.items()}
            with torch.amp.autocast("cuda", enabled=self.config["training"]["fp16"]):
                loss = self.model(**batch).loss
                loss = loss / self.config["training"]["gradient_accumulation_steps"]

            self.scaler.scale(loss).backward()

            if (step + 1) % self.config["training"]["gradient_accumulation_steps"] == 0:
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.scheduler.step()
                self.optimizer.zero_grad()
```

### Shell Scripts Pattern (scripts/train.sh)

```bash
#!/bin/bash
set -e

CONFIG=${1:-configs/default.yaml}
OUTPUT_DIR=${2:-outputs/default}

echo "Training with config: $CONFIG"
echo "Output: $OUTPUT_DIR"
mkdir -p $OUTPUT_DIR

# Single GPU only (1x A100)
CUDA_VISIBLE_DEVICES=0 python main.py \
    --config $CONFIG \
    --mode train_eval \
    --output_dir $OUTPUT_DIR
```

### Multi-Seed Script (scripts/run_seeds.sh)

```bash
#!/bin/bash
set -e

CONFIG=${1:-configs/default.yaml}
BASE_OUTPUT=${2:-outputs/default}
SEEDS="42 123 456"

for SEED in $SEEDS; do
    echo "=== Running seed $SEED ==="
    CUDA_VISIBLE_DEVICES=0 python main.py \
        --config $CONFIG \
        --mode train_eval \
        --output_dir ${BASE_OUTPUT}/seed_${SEED} \
        --seed $SEED
done

echo "=== All seeds complete ==="
```

### Requirements.txt Pattern

```
torch>=2.1.0
transformers>=4.36.0
datasets>=2.16.0
accelerate>=0.25.0
peft>=0.7.0
wandb>=0.16.0
scikit-learn>=1.3.0
scipy>=1.11.0
numpy>=1.24.0
pandas>=2.0.0
pyyaml>=6.0
tqdm>=4.65.0
matplotlib>=3.7.0
seaborn>=0.12.0
scanpy>=1.9.0
anndata>=0.10.0
```

(Adjust packages based on the specific research direction)

---

## Code Quality Standards

### Mandatory Standards

1. Type hints on ALL function signatures
2. Docstrings on ALL public classes and functions (Google style)
3. No magic numbers — all constants in config or named constants
4. No TODOs, FIXMEs, or placeholder comments in delivered code
5. All random seeds set and configurable
6. Logging via Python `logging` module (not `print` statements)
7. Error handling: meaningful error messages, not bare `except`
8. Memory management: explicit `del` + `torch.cuda.empty_cache()` in long loops
9. Results saved as structured JSON (parseable by analysis/ scripts)

### Naming Conventions

- Files: `snake_case.py`
- Classes: `PascalCase`
- Functions/methods: `snake_case`
- Constants: `UPPER_SNAKE_CASE`
- Config keys: `snake_case`

---

## Code Review Checklist

### Automated Checks

```bash
# 1. Syntax validation for all Python files
for f in $(find code/ -name "*.py"); do
    python -c "import ast; ast.parse(open('$f').read())"
done

# 2. Import validation
cd code/ && python -c "
import importlib, pkgutil, sys
for importer, modname, ispkg in pkgutil.walk_packages(path=['.'], onerror=lambda x: None):
    pass
print('All imports valid')
"

# 3. Requirements check
pip check 2>&1 | head -20
```

### Manual Review Checklist

**Data Pipeline**
- [ ] `download.py`: URLs are real and accessible
- [ ] `preprocess.py`: deterministic (same input → same output)
- [ ] `dataset.py`: `__len__` and `__getitem__` correct, edge cases handled
- [ ] `collator.py`: padding/truncation handles variable lengths
- [ ] Data types: tensors are correct dtype (float32/bfloat16 for features, long for labels)

**Model**
- [ ] Forward pass: input dimensions match documented architecture
- [ ] Output dimensions: match expected shape for loss/metrics
- [ ] No in-place operations that break autograd
- [ ] Dropout disabled during eval (`model.eval()` called)
- [ ] Weight initialization is explicit, not default

**Training**
- [ ] Loss computed correctly (reduction, weighting, masking)
- [ ] Gradient accumulation: loss divided by steps BEFORE backward
- [ ] Scaler: unscale before grad clipping, step after clipping
- [ ] Scheduler: step at correct frequency (per-step vs per-epoch)
- [ ] Checkpointing: saves model, optimizer, scheduler, epoch, best_metric
- [ ] Resume: loads all of the above correctly
- [ ] **Memory: peak GPU usage < 75GB** (leave 5GB headroom on A100 80GB)

**Evaluation**
- [ ] Metrics: implementations match standard definitions (sklearn reference)
- [ ] Multi-run: seeds configurable, std computed over 3+ runs
- [ ] Results saved to JSON in consistent, parseable format
- [ ] No data leakage: test set never seen during training/validation
- [ ] Timing information saved (training time, inference time, GPU memory)

**Analysis**
- [ ] Every paper table/figure has a corresponding analysis script
- [ ] Statistical tests use appropriate methods (parametric vs non-parametric)
- [ ] LaTeX output compiles without errors
- [ ] Figures are publication-quality (300 DPI, proper fonts, readable labels)
- [ ] `parse_results.py` correctly parses the eval output format

**Shell Scripts**
- [ ] `set -e` at top of every script
- [ ] Arguments have defaults
- [ ] GPU visibility controlled via `CUDA_VISIBLE_DEVICES=0` (single GPU)
- [ ] Output directories created automatically (`mkdir -p`)
- [ ] No `torchrun --nproc_per_node > 1` (single GPU constraint)

---

## Technical Manual Template (Chinese)

```markdown
# {项目名称} 技术手册

## 1. 环境配置

### 1.1 系统要求
- OS: Linux (Ubuntu 20.04/22.04 推荐)
- GPU: NVIDIA A100 80GB × 1 (严格单卡)
- CUDA: 12.1+
- Python: 3.10+

### 1.2 安装步骤
conda create -n {project} python=3.10 -y
conda activate {project}
pip install -r requirements.txt

### 1.3 验证安装
python -c "import torch; print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0))"

## 2. 数据准备

### 2.1 下载数据
python data/download.py --dataset {name} --output_dir data/raw/

### 2.2 预处理
python data/preprocess.py --input_dir data/raw/ --output_dir data/processed/

### 2.3 验证数据
[期望的文件列表和大小]

## 3. 运行基线实验

### 3.1 基线1: {name}
bash scripts/run_baselines.sh baseline_method1

### 3.2 基线2: {name}
[...]

期望结果范围: [指标A: XX-XX, 指标B: XX-XX]

## 4. 训练我们的模型

### 4.1 默认配置训练
bash scripts/train.sh configs/default.yaml outputs/main

### 4.2 多种子运行 (计算标准差)
bash scripts/run_seeds.sh configs/default.yaml outputs/main

### 4.3 训练监控
- wandb: 浏览器打开 wandb.ai 查看训练曲线
- 日志: outputs/main/train.log
- 预期训练时间: ~XX 小时 (1x A100)

### 4.4 断点续训
python main.py --config configs/default.yaml --checkpoint outputs/main/last.pt

## 5. 评估

bash scripts/eval.sh outputs/main/best_model.pt

结果保存在: outputs/main/eval_results.json

## 6. 消融实验

bash scripts/run_ablation.sh

各消融实验说明:
- ablation_no_X: [移除了什么，验证什么]

## 7. 结果分析

### 7.1 收集所有实验结果
python analysis/parse_results.py --output_dir outputs/ --save_to analysis_outputs/

### 7.2 运行统计检验
python analysis/statistical_tests.py --results analysis_outputs/all_results.csv

### 7.3 生成论文表格
python analysis/generate_tables.py --results analysis_outputs/all_results.csv --output_dir paper/tables/

### 7.4 生成论文图表
python analysis/generate_figures.py --results analysis_outputs/all_results.csv --output_dir paper/figures/

### 7.5 案例分析
python analysis/case_study.py --output_dir analysis_outputs/case_studies/

### 7.6 一键运行全部分析
bash analysis/run_all_analysis.sh outputs/ analysis_outputs/

### 7.7 更新论文
参考 analysis/ 中各脚本的 Paper Element 注释，将生成的表格和图表替换论文中的 XX.X 占位符。

## 8. 常见问题

### OOM (显存不足)
- 减小 batch_size
- 开启 gradient_checkpointing: true
- 减小 max_length
- 使用 LoRA/QLoRA

### 训练loss不下降
- 检查学习率（尝试1e-5 到 1e-3范围）
- 检查数据预处理是否正确

### CUDA版本不匹配
pip install torch --index-url https://download.pytorch.org/whl/cu121
```
