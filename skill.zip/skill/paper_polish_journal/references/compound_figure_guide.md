# Compound Figure Guide (Phase 3, Journal Version)

Journal papers use compound multi-panel figures to tell a story in one visual unit. This guide
defines the workflow, standards, and examples. Used by `paper_polish_journal/SKILL.md` Phase 3.

## What is a Compound Figure?

A compound figure contains multiple panels (typically 4-8) arranged in a grid, with each panel
showing a different aspect of the same finding. Panel labels (a, b, c, ...) allow the text to
reference specific parts. The figure caption is a self-contained paragraph describing all
panels.

Example (Nature Methods-style):

```
Figure 2 | CellAgent identifies rare cell types missed by existing methods.

┌────────────────┬────────────────────────────┐
│ a              │ b                          │
│ [Schematic of  │ [Bar chart showing F1      │
│  task setup]   │  across 6 methods]         │
│                │                            │
├────────────────┴────────┬───────────────────┤
│ c                       │ d                 │
│ [UMAP of rare cells]    │ [Attention        │
│                         │  weights on GRN]  │
│                         │                   │
├─────────────────────────┴───────────────────┤
│ e                                           │
│ [Performance stratified by abundance]       │
│                                             │
└─────────────────────────────────────────────┘
```

Each panel contributes to a coherent story about one finding.

## Panel Planning

Before generating panels, plan the figure:

1. **Finding statement**: What is the one-sentence finding this figure supports?
2. **Panel inventory**: What panels are needed to convince a reader?
3. **Panel order**: What is the visual story flow?
4. **Panel sizes**: Large central panels for main findings, smaller flanking panels for
   supporting details

### Typical Panel Archetypes

**Schematic panel** (a):
- Task setup or method overview
- Hand-drawn or TikZ
- Simple, clean, iconic
- Usually first panel

**Main result panel** (b):
- Primary quantitative finding
- Bar chart, line plot, or heatmap
- Statistical significance clearly marked
- Error bars visible

**Visualization panel** (c):
- UMAP, t-SNE, or PCA showing cell populations
- Clusters colored by label
- Rare populations highlighted
- Legend clear

**Biological interpretation panel** (d):
- Marker gene expression, GO enrichment, or attention weights
- Links method to known biology
- Uses familiar biological concepts

**Stratification / breakdown panel** (e):
- Performance by condition, subset, or stratum
- Shows where the method excels and where it fails

**Validation panel** (f, optional):
- Independent dataset, orthogonal measurement, or literature validation
- Triangulates the finding

## Panel Generation

For each panel, use matplotlib:

```python
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Standardized style
plt.rcParams.update({
    'font.family': 'Arial',
    'font.size': 8,
    'axes.labelsize': 9,
    'xtick.labelsize': 7,
    'ytick.labelsize': 7,
    'legend.fontsize': 7,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.format': 'pdf',
    'savefig.bbox': 'tight',
})

# Colorblind-friendly palette (Okabe-Ito 8)
OKABE_ITO = ['#000000', '#E69F00', '#56B4E9', '#009E73',
             '#F0E442', '#0072B2', '#D55E00', '#CC79A7']

# Panel a: Bar chart
fig, ax = plt.subplots(figsize=(3, 2.5))
methods = ['Seurat', 'scGPT', 'CellAgent', ...]
scores = [0.65, 0.71, 0.83, ...]
errors = [0.02, 0.03, 0.02, ...]
bars = ax.bar(methods, scores, yerr=errors, color=OKABE_ITO[:len(methods)])
ax.set_ylabel('F1 score')
ax.set_ylim([0, 1])
# Mark significance
ax.text(2, 0.85, '***', ha='center', fontsize=9)
plt.savefig('paper_journal/figures/fig2/panel_b.pdf')
plt.close()
```

Save each panel as `paper_journal/figures/figN/panel_X.pdf`.

## Compound Assembly

### Option A: Matplotlib + GridSpec (programmatic)

```python
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.gridspec import GridSpec

# Set up compound figure
fig = plt.figure(figsize=(7, 6))  # 7-inch width fits Nature double column
gs = GridSpec(3, 2, figure=fig, hspace=0.3, wspace=0.3)

# Load each panel from PDF (or recreate)
# ... load and place panels ...

# Panel labels
for i, label in enumerate('abcdef'):
    ax = fig.add_subplot(gs[...])  # appropriate grid cell
    ax.text(-0.1, 1.1, label, transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')

plt.savefig('paper_journal/figures/fig2/compound.pdf',
            bbox_inches='tight', dpi=300)
```

Save the assembly script as `paper_journal/figures/figN/assembly.py` for reproducibility.

### Option B: Inkscape / Illustrator (manual, high-quality final)

For the final publication-ready version, many researchers use Inkscape:
1. Import each panel PDF
2. Arrange in a grid
3. Add panel labels with the Text tool (Arial Bold 10pt)
4. Align panels precisely
5. Export as PDF

### Option C: LaTeX subcaption (simpler, less flexible)

```latex
\begin{figure*}[t]
\centering
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/fig2/panel_a.pdf}
    \caption{}
    \label{fig:2a}
\end{subfigure}
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/fig2/panel_b.pdf}
    \caption{}
    \label{fig:2b}
\end{subfigure}
% ... more subfigures ...
\caption{\textbf{CellAgent identifies rare cell types...}
(\textbf{a}) Schematic of the annotation task.
(\textbf{b}) F1 score comparison across 6 methods...}
\label{fig:2}
\end{figure*}
```

## Panel Labels

- Font: Arial Bold
- Size: 10pt (or 1.2x body text)
- Position: Top-left of each panel, outside the axes
- Format: Lowercase letters (a, b, c, ...) per Nature/Science convention
- Some journals use uppercase (A, B, C) — check journal style guide

## Figure Legend (Caption)

The compound figure caption is a **self-contained paragraph** that describes every panel.
Typical length: 150-300 words.

### Structure

1. **Title sentence**: One-sentence finding statement (same as Results subsection title)
2. **Panel descriptions**: (a), (b), (c), ... Each panel 1-2 sentences.
3. **Statistical details**: N, test type, significance thresholds
4. **Dataset or method details**: Brief, only what's needed to understand the figure

### Template

```
Figure N | [Title sentence - one-line finding statement].

(a) [Panel a description, 1-2 sentences].
(b) [Panel b description, including relevant statistics: n = X biological replicates,
     mean ± s.e.m., two-tailed paired t-test, *p < 0.05, **p < 0.01, ***p < 0.001].
(c) [Panel c description].
(d) [Panel d description].
(e) [Panel e description].

Data from [dataset name and reference].
```

### Example

```
Figure 2 | CellAgent identifies rare cell types missed by existing methods.

(a) Schematic of the rare cell-type annotation task on the Tabula Sapiens dataset. Rare cell
    types (<5% abundance) are highlighted in red.
(b) F1 score on rare cell-type identification across six methods (Seurat, scanpy, scGPT,
    Geneformer, scBERT, CellAgent). Bars show mean ± s.e.m., n = 5 seeds. CellAgent achieves
    the highest F1 (0.83 ± 0.02) with a 12.3% improvement over the next-best method
    (paired t-test, p < 0.001).
(c) UMAP embedding of pancreas cells colored by predicted type, showing CellAgent correctly
    identifies a population of delta cells (arrow) that existing methods classify as beta cells.
(d) Gene regulatory network attention weights for the top 20 rare-cell markers, showing 78%
    overlap with a literature-curated marker set (hypergeometric test, p < 10⁻¹⁰).
(e) F1 score stratified by rare-cell abundance, showing CellAgent's advantage grows as
    populations become rarer (linear regression, slope = -0.03, R² = 0.87).
```

## Color Palette

Use the same palette across all figures in the paper. Recommended options:

### Option 1: Okabe-Ito (8-color, colorblind-friendly)
```python
OKABE_ITO = ['#000000', '#E69F00', '#56B4E9', '#009E73',
             '#F0E442', '#0072B2', '#D55E00', '#CC79A7']
```
Strengths: Accessible to all vision types. Works in grayscale.

### Option 2: ColorBrewer Set2 (qualitative)
```python
SET2 = ['#66C2A5', '#FC8D62', '#8DA0CB', '#E78AC3',
        '#A6D854', '#FFD92F', '#E5C494', '#B3B3B3']
```

### Option 3: Viridis (sequential, for ordered data)
```python
import matplotlib.cm as cm
viridis = cm.get_cmap('viridis')
```

## Font Standards

Journal figures require consistent fonts:
- **Family**: Arial, Helvetica, or Nimbus Sans (Free/open alternative)
- **Sizes**:
  - Panel labels (a, b, c): 10pt bold
  - Axis labels: 9pt
  - Tick labels: 7-8pt
  - Legend: 7pt
  - In-figure annotations: 8pt
- **Style**: Regular weight unless emphasis needed
- **No**: Times, Computer Modern, Comic Sans

## Dimensions

Target journal column width:
- Nature single column: 89 mm (3.5 inches)
- Nature double column: 180 mm (7 inches)
- Science single column: 55 mm (2.2 inches)
- Science double column: 115 mm (4.5 inches) or 175 mm (7 inches)

Match your compound figure width to the target.

## Resolution and Format

- **Final format**: PDF (vector preferred, embedded raster if needed)
- **Resolution**: 300 DPI for raster, vector for line art
- **Transparency**: White background, no transparent regions
- **Bleed**: None
- **Crop**: Tight crop around the content

## Quality Audit per Figure

Before moving on:

- [ ] All panels use the same font family
- [ ] All panels use the same color palette
- [ ] Panel labels are consistently placed
- [ ] Legend describes every panel
- [ ] Statistical details in legend
- [ ] Figure width fits target journal column
- [ ] Text is readable at final print size (print a sample)
- [ ] Grayscale conversion readable (for accessibility)
- [ ] No clipped axis labels or legends
- [ ] No Matplotlib / Python error messages in the PDF
- [ ] File size reasonable (<5 MB per figure)
- [ ] Figure tells the story without reading main text

## Common Pitfalls

1. **Inconsistent panel sizes**: Makes the figure look unprofessional
2. **Mixed fonts**: Arial on some panels, Times on others
3. **Inconsistent colors**: Method X is blue in Figure 2 but orange in Figure 3
4. **Missing error bars**: Every experimental result needs uncertainty
5. **Missing significance marks**: Claims in text without visual marks on figure
6. **Overstuffed figures**: More than 8 panels is hard to read
7. **Tiny text**: 6pt text is unreadable at final print size
8. **Busy backgrounds**: Gradient fills or textures distract from data
9. **Misleading axes**: Y-axis not starting at 0 without clear indication
10. **Poor captions**: Caption doesn't describe all panels

## Extended Data Figures

Nature family journals allow 10+ Extended Data figures for supporting analyses:
- Same quality standards as main figures
- Referenced from main text as "Extended Data Fig. 1", etc.
- Often contain ablations, robustness checks, additional datasets
- Captioned like main figures

## Supplementary Figures

Supplementary figures are for the less important supporting analyses:
- Can be lower resolution / quicker quality
- Often numbered S1, S2, etc.
- Always have captions

## Graphical Abstract (Cell Family)

A graphical abstract is a single-page visual summary for Cell family journals:
- One page, portrait orientation
- Top: Biological question
- Middle: Method schematic
- Bottom: Key finding
- Highly stylized, often with icons
- Biology-forward, not algorithm-forward
- Use TikZ or Inkscape for final version
