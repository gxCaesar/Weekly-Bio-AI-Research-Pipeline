# Journal-Specific Supplements Guide (Phase 6)

Detailed guide for generating the journal-specific materials beyond the main paper:
cover letter, reviewer suggestions, data/code availability statements, CRediT, Highlights,
and Graphical Abstract. Used by `paper_polish_journal/SKILL.md` Phase 6.

## Overview

Unlike conference submissions, journal submissions require **a cover letter, reviewer
suggestions, and journal-specific supplements** in addition to the main paper. These materials
are often the first thing an editor reads — **they decide whether the paper goes to peer
review or gets desk rejected**.

Time investment on these supplements is high-leverage:
- 2-4 hours on the cover letter can make the difference between desk reject and peer review
- Reviewer suggestions can determine which experts see the paper
- Data/code availability is a binary check for reproducibility

## Cover Letter

### Purpose

The cover letter is a 1-page pitch to the editor:
1. Why your paper fits their journal
2. What is the significance of the finding
3. Why peer reviewers will find it valuable

### Structure (Nature/Science family)

```
[Your Institution Letterhead]
[Date]

Dear Dr. [Editor Name],

[Paragraph 1 — Submission statement + title]
We are pleased to submit our manuscript titled "[Manuscript Title]" for consideration for
publication as [Article Type, e.g., Article / Brief Communication / Resource] in [Journal Name].

[Paragraph 2 — Significance statement]
[2-4 sentences explaining the biological significance. Answer: Why does this matter to the
field? What new capability does this enable?]

[Paragraph 3 — Key findings]
In this study, we [one-sentence method description]. Using this approach, we [finding 1 with
number]. We further show that [finding 2 with number]. These findings [broader implication].

[Paragraph 4 — Why this journal]
This work is well-suited to [Journal Name] because [reason 1, referencing journal scope].
Our findings build on recent work published in [Journal Name] by [Author et al., Year], who
[their contribution]. Our work [how you extend/contrast].

[Paragraph 5 — Additional recent journal papers]
Our approach also complements recent [Journal Name] papers on [topic 2, Author et al., Year]
and [topic 3, Author et al., Year].

[Paragraph 6 — Declarations]
All authors have agreed to the submission. The work has not been published elsewhere and is
not under consideration at another journal. We declare [competing interests / none].

[Paragraph 7 — Reviewer suggestions and closing]
We suggest [names of 3-5 potential reviewers provided in a separate file]. We thank you for
considering our submission and look forward to your editorial response.

Sincerely,

[Corresponding author name]
[Title]
[Affiliation]
[Email]
```

### Length

1 page. Editors skim; long cover letters are a negative signal.

### Tone

- Confident but not arrogant
- Specific, not vague
- Biology-focused, not algorithm-focused
- Respectful of the journal's editorial process

### Common Mistakes

1. **Generic "this is a great paper"** without specifics
2. **Over-claiming** ("revolutionary", "first", "solves X")
3. **Under-selling** ("a preliminary exploration", "small improvement")
4. **No reference to the target journal** ("this work is relevant to ML")
5. **Too long** (> 1 page makes editors suspicious)
6. **Wrong editor name** (check recent issues for active editors in your area)

### Journal-Specific Variants

**Nature**:
- Very brief, high-significance framing
- Must cite 1-2 recent Nature papers
- Significance statement first

**Nature Methods**:
- Emphasize new methodological capability
- Cite 2-3 recent Nature Methods papers (tools)
- Reproducibility matters

**Nature Communications**:
- More room for nuance
- Emphasize broad interest
- Cite 2-3 recent NatComm papers

**Cell**:
- Biology first, always
- Physiological or disease relevance preferred
- Cite recent Cell papers

**Cell Systems**:
- Systems-level framing
- Computational + experimental integration welcomed
- Cite recent Cell Systems papers

**Science**:
- Very concise (1/2 page often sufficient)
- Broad-impact framing
- Cite Science papers selectively

**PLOS Computational Biology / Bioinformatics**:
- More technical content allowed
- Open science framing
- Cite recent papers in the journal

### Cover Letter Template File

Save as `paper_journal/cover_letter.tex`:

```latex
\documentclass[11pt]{letter}
\usepackage[margin=1in]{geometry}
\usepackage{times}

\address{[Your Name] \\ [Title] \\ [Affiliation] \\ [Email]}
\signature{[Your Name]}

\begin{document}

\begin{letter}{Dr. [Editor Name] \\ Editor, [Journal Name] \\ [Publisher Address]}

\opening{Dear Dr. [Editor Name],}

% Paragraph 1: Submission statement
We are pleased to submit our manuscript titled ``[Manuscript Title]'' for consideration for
publication as an Article in \emph{[Journal Name]}.

% Paragraph 2: Significance statement
[2-4 sentences]

% Paragraph 3: Key findings
In this study, we [method description]. Using this approach, we [finding 1]. We further show
that [finding 2]. These findings [broader implication].

% Paragraph 4: Why this journal
This work is well-suited to \emph{[Journal Name]} because [reason]. Our findings build on
recent work by [Author et al., Year] [cite], who [their contribution]. Our work extends this
by [your contribution].

% Paragraph 5: Additional context
Our approach also complements recent \emph{[Journal Name]} papers on [topic 2] and [topic 3].

% Paragraph 6: Declarations
All authors have agreed to the submission. The work has not been published elsewhere and is
not under consideration at another journal. We declare no competing interests.

% Paragraph 7: Closing
We suggest potential reviewers in the separate reviewer suggestions file. We thank you for
considering our submission and look forward to your editorial response.

\closing{Sincerely,}

\end{letter}

\end{document}
```

## Reviewer Suggestions

### Purpose

Editors often ask authors for suggested reviewers. Well-chosen reviewers:
- Understand the work deeply
- Are not conflicted with the authors
- Are likely to respond quickly
- Will provide constructive feedback

### Structure

Provide 3-5 suggestions in `reviewer_suggestions.md`:

```markdown
# Suggested Reviewers

## 1. Dr. [Name]
- **Affiliation**: [University / Institute]
- **Email**: [email@institution.edu]
- **Expertise**: [1 sentence on their relevant expertise]
- **Why suggested**: [1-2 sentences on why they are appropriate]
- **No conflict**: We have no personal or professional conflict with this reviewer.

## 2. Dr. [Name]
...
```

### Selection Criteria

**Suggest**:
- Senior authors of papers you cite heavily
- Leaders in the specific sub-field
- Researchers with complementary expertise
- Authors of recent papers in the target journal

**Do NOT suggest**:
- Your former advisor or advisees (conflict of interest)
- Collaborators within the past 4 years
- People from your own department
- Direct competitors (may sabotage or delay)
- Junior researchers without established profile (editors may distrust)

### Finding Reviewers

Sources:
1. **Recent papers citing your work area**: Google Scholar search
2. **Journal editorial board**: Check the journal website for editorial board members in your area
3. **Key references in your paper**: Senior authors of your top 10 cited papers
4. **Conference program committees**: People who serve on NeurIPS / ICML / RECOMB program
   committees in your area

### Balance

Provide a mix of:
- 1-2 senior leaders (well-known names)
- 1-2 mid-career researchers (active in the field)
- 1 specialized expert (for technical aspects)

## Data Availability Statement

### Purpose

Journals require explicit statements about data access for reproducibility.

### Structure

Write `data_availability.md`:

```markdown
# Data Availability Statement

## Public Datasets Used
- **Tabula Sapiens v1.0**: Available at https://tabula-sapiens-portal.ds.czbiohub.org/,
  accessed YYYY-MM-DD. Processed data files used in this study are deposited on Zenodo
  (DOI: 10.5281/zenodo.XXXXXXX).
- **Pancreas scRNA-seq (Baron et al. 2016)**: GEO accession GSE84133.
- **[Additional datasets...]**

## Generated Data
[If you generated new data, describe it and provide accession numbers or deposition plan.]

Processed datasets and intermediate results generated in this study are deposited at Zenodo
(DOI: to be assigned upon acceptance). These include:
- Preprocessed expression matrices
- Trained model checkpoints
- Prediction outputs
- Analysis notebooks

## Access Requirements
All data are openly available without access restrictions.
```

### Pre-submission vs Post-acceptance

- Pre-submission: State the plan (e.g., "will be deposited upon acceptance")
- Post-acceptance: Actual DOIs and accession numbers must be provided before publication

## Code Availability Statement

Write `code_availability.md`:

```markdown
# Code Availability Statement

The CellAgent implementation is available at https://github.com/username/CellAgent under the
MIT License. The specific version used in this study is tagged as v1.0.0 (commit hash:
abc1234def56789).

The repository includes:
- Full source code for model training and inference
- Preprocessing scripts for all datasets used
- Configuration files for reproducing main experiments
- Analysis notebooks used to generate figures
- A detailed README with installation and usage instructions
- A Dockerfile for reproducible environment setup

Dependencies: Python 3.10, PyTorch 2.1, scanpy 1.9, see requirements.txt for full list.
```

### Best Practices

- Use a public GitHub repository (or GitLab, Bitbucket)
- Tag a specific version/commit for the submitted paper
- Include a DOI via Zenodo GitHub integration (guaranteed to be citable)
- License clearly (MIT, Apache 2.0, GPL-3.0 are common choices)
- Include setup instructions and example usage

## CRediT Author Contribution Statement

### Purpose

The CRediT (Contributor Roles Taxonomy) standardizes how author contributions are described.
Most journals now require CRediT statements.

### 14 Roles

1. **Conceptualization** — ideas, formulation of research goals
2. **Methodology** — development or design of methodology
3. **Software** — programming, software development
4. **Validation** — verification of the outputs
5. **Formal analysis** — application of statistical, mathematical, computational techniques
6. **Investigation** — conducting the research process, experiments
7. **Resources** — provision of study materials, reagents
8. **Data Curation** — management activities to produce metadata
9. **Writing — Original Draft** — preparation of the initial draft
10. **Writing — Review & Editing** — critical review, revision
11. **Visualization** — preparation of data presentation
12. **Supervision** — responsibility for research activity planning and execution
13. **Project administration** — management and coordination
14. **Funding acquisition** — acquisition of financial support

### Structure

Write `credit_statement.md`:

```markdown
# CRediT Author Contribution Statement

**[Author 1 Full Name]**: Conceptualization, Methodology, Software, Investigation, Formal
analysis, Writing — Original Draft, Visualization.

**[Author 2 Full Name]**: Conceptualization, Data Curation, Investigation, Writing — Review & Editing.

**[Author 3 Full Name]**: Methodology, Software, Formal analysis, Writing — Review & Editing.

**[Author 4 Full Name]** (corresponding author): Conceptualization, Supervision, Writing —
Review & Editing, Funding acquisition, Project administration.
```

### Interactive Pause

Because the CRediT statement requires author-specific knowledge, the skill should pause and
ask the user to fill it in. Do not guess author roles.

## Highlights (Nature Methods and similar)

### Purpose

Nature Methods requires 3-4 Highlight bullets of ~15 words each. These appear at the top of the
paper in the online format.

### Structure

Write `highlights.md`:

```markdown
# Highlights

- CellAgent identifies rare cell types in scRNA-seq with 12% higher accuracy than existing tools
- Gene regulatory network structure guides attention to biologically relevant features
- The method reveals three previously uncharacterized rare cell populations in Tabula Sapiens
- Open-source implementation enables community use and reproducibility
```

### Rules

- 3-4 bullets (not 2, not 5)
- ~15 words each (range: 10-20)
- Each bullet is a complete sentence or strong noun phrase
- First bullet is the headline finding
- Second bullet is the methodological innovation
- Third bullet is the biological implication
- Fourth bullet (optional) is the availability/impact

## Graphical Abstract (Cell Family)

### Purpose

Cell family journals often ask for a single-page graphical abstract: a visual summary that
stands alone. Think of it as the figure version of the abstract.

### Structure

- Top: Biological question (1 sentence)
- Middle: Method schematic (or data flow)
- Bottom: Key finding (visual + 1 sentence)
- Biology-forward icons (cells, genes, pathways)

### Format

- Single page, portrait orientation
- Width: 180 mm (Cell full-page)
- Vector graphics (PDF)
- Minimal text
- High visual impact

### Tools

- Inkscape (free, vector)
- Adobe Illustrator (paid, industry standard)
- BioRender (paid, biology-specific icons)
- PowerPoint (basic, but workable)

### Template File

Save as `paper_journal/graphical_abstract.tex` (TikZ version):

```latex
\documentclass[tikz]{standalone}
\usepackage{tikz}
\usetikzlibrary{shapes, arrows.meta, positioning}

\begin{document}
\begin{tikzpicture}[
    question/.style={align=center, font=\bfseries\Large},
    method/.style={draw, rounded corners, align=center, fill=blue!20, minimum width=5cm},
    finding/.style={align=center, font=\itshape},
    arrow/.style={->, >=Stealth, thick}
]

% Top: Question
\node[question] (q) at (0, 4) {How can we identify rare cell types \\ missed by existing methods?};

% Middle: Method
\node[method] (m) at (0, 0) {CellAgent \\ (GRN-guided attention)};

% Inputs
\node (input) at (-4, 0) {scRNA-seq};
\draw[arrow] (input) -- (m);

% Outputs
\node (output) at (4, 0) {Rare cell types};
\draw[arrow] (m) -- (output);

% Bottom: Finding
\node[finding] at (0, -3) {CellAgent identifies three previously uncharacterized \\
                          rare cell populations in human pancreas.};

\end{tikzpicture}
\end{document}
```

## Interactive Pauses

This phase requires user input in several places:
1. Editor name (look up from journal website)
2. CRediT author-role mapping (author-specific)
3. Reviewer suggestions (research-dependent)
4. Cover letter finalization (judgment call)

Default behavior: pause at each, allow user to approve/edit.

Express mode: auto-generate drafts, mark as `[TO BE CONFIRMED BY USER]` placeholders, let user
fix before submission.

## Submission Package Checklist

Before submission, verify:
- [ ] Main manuscript (`main.tex`)
- [ ] Methods file (`methods.tex`)
- [ ] Supplementary information (`supplementary.tex`)
- [ ] Extended data figures (Nature family)
- [ ] Cover letter (`cover_letter.tex`)
- [ ] Reviewer suggestions (`reviewer_suggestions.md`)
- [ ] Data availability statement (`data_availability.md`)
- [ ] Code availability statement (`code_availability.md`)
- [ ] CRediT statement (`credit_statement.md`) [user-confirmed]
- [ ] Highlights (if Nature Methods) (`highlights.md`)
- [ ] Graphical abstract (if Cell family) (`graphical_abstract.tex`)
- [ ] All figures in PDF format, 300+ DPI
- [ ] All references.bib entries complete
- [ ] Author list and affiliations finalized
- [ ] Corresponding author designated
