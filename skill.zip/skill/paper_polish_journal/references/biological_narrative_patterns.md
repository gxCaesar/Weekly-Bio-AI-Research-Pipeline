# Biological Narrative Patterns (Phase 1, Journal Version)

Guide for constructing a **biology-first** story line for journal submissions. Consumed by
`paper_polish_journal/SKILL.md` Phase 1. Complements the 5 result types defined in
`paper_polish_conf/references/narrative_patterns.md` (which focuses on algorithm-centric
framing).

## Core Principle

**Journal papers are about biology, not algorithms.** A tool paper that says "we built a
transformer that achieves SOTA on cell typing" belongs at a conference. The same work, framed
as "we discovered that rare cell types can be identified through GRN-guided attention, leading
to the identification of three previously uncharacterized populations", belongs at a journal.

Same work. Same code. Different framing. The journal framing wins at Nature Methods; the
conference framing wins at NeurIPS. Know your venue.

## The Biology-First Reframing Pipeline

For each result, apply this transformation:

### Step 1: Identify the biological finding

Not: "Our model achieved 85% accuracy"
But: "We could identify [biological entity] that was previously [limitation]"

Examples:
- "We identified 5 rare cell types in Tabula Sapiens that were missed by existing methods"
- "We uncovered a pattern of gene co-regulation that links disease X to pathway Y"
- "We characterized the relationship between drug structure and off-target effects in class Z"

### Step 2: State the biological significance

Why does the biology matter? Connect to:
- Disease relevance
- Mechanism understanding
- Drug discovery potential
- Fundamental biological insight
- Tool availability (method as service to the community)

### Step 3: Contextualize within field

Whose problem does this solve? Reference 2-3 recent papers in the target journal (these become
your cover letter citations).

### Step 4: State methodological contribution LAST

After the biological story is established, briefly note the methodological innovation.

## Narrative Templates by Result Type

### Strong Results → "Discovery paper"

Frame the paper as a biological discovery enabled by a new method.

**Title pattern**: "[Biological finding] revealed by [method name]"
- "Rare cell types in human tissues revealed by GRN-guided language modeling"
- "Drug-target interaction landscape revealed by agent-based virtual screening"

**Abstract first sentence**: Biology problem, not method
- ❌ "Cell-type annotation is a fundamental task in single-cell analysis."
- ✅ "Rare cell populations account for less than 5% of cells in most tissues but play outsized roles in disease."

**Contribution framing**: What was discovered, not what was built
- ❌ "We propose CellAgent, a transformer-based model for cell typing."
- ✅ "Using a new computational approach, CellAgent, we identify five rare cell types in human pancreas that were missed by existing tools. These populations exhibit expression signatures consistent with previously hypothesized but unobserved intermediate states."

### Marginal Results → "Characterization paper"

Frame the paper as a systematic characterization of a biological phenomenon.

**Title pattern**: "Characterization of [biological thing] using [approach]"
- "Characterization of GRN-guided representations for rare cell type identification"

**Key move**: Make the quantitative improvement a secondary finding, and make the
characterization / systematic analysis the primary contribution.

**Contribution framing**: What did we learn about the biology from the systematic analysis?
- "We systematically evaluated GRN-guided attention across 12 tissue types, revealing that
  attention weights correlate with known regulatory relationships (Spearman ρ = 0.73) and
  predict unannotated regulatory links that we validate via ChIP-seq evidence."

### Mixed Results → "Trade-off paper"

Frame as mapping the conditions under which different biological approaches succeed.

**Title pattern**: "Conditions for [biological outcome] across [approach landscape]"
- "When specialized deep learning outperforms foundation models in single-cell analysis"

**Contribution**: Map of when each approach works, with biological reasoning.

### Counter-Intuitive Results → "Mechanism paper"

Frame as revealing a biological mechanism that was previously obscured.

**Title pattern**: "[Counter-intuitive finding] explained by [biological mechanism]"
- "Simpler cell-typing methods outperform large models due to avoidance of over-regularization on rare populations"

**Contribution**: The mechanism / biological explanation is the contribution.

### Negative Results → "Limits paper"

Frame as documenting the limits of current approaches and suggesting biological directions.

**Title pattern**: "Limits of [approach] in [biological domain]"

**Harder sell at journals**: Nature-family journals rarely publish pure negative results. Consider:
- Resubmit to a specialized journal (Bioinformatics, PLOS CB) where negative methodological
  results are more accepted
- Combine with a positive contribution (e.g., new benchmark dataset)

## Section Title Patterns

Journal sections should have **declarative titles**, not descriptive ones.

### Bad (descriptive)
- "Results"
- "Main results"
- "Ablation study"
- "Application to scRNA-seq"

### Good (declarative finding)
- "CellAgent identifies rare cell types missed by existing methods"
- "Gene regulatory network structure drives rare-cell detection"
- "Validation on five independent datasets confirms robustness"
- "Applied to Tabula Sapiens, CellAgent reveals three uncharacterized populations"

Each Results subsection has its own title stating the subsection's finding.

## Sentence-Level Patterns

### Opening Sentences

Always open a Results subsection with a **biological motivation**, not a methodological statement.

**Bad**:
> "We next evaluated our method on the pancreas dataset."

**Good**:
> "Rare cell populations in the pancreas have been challenging to characterize due to their
> sparsity and transcriptional similarity to abundant populations, motivating our next
> evaluation."

### Finding Sentences

Lead with the biology; follow with the number.

**Bad**:
> "Our method achieves 85.3% accuracy on pancreas rare cells."

**Good**:
> "CellAgent correctly identified 85.3% of rare pancreas endothelial cells, improving over the
> best existing method by 12%."

### Interpretation Sentences

Every finding needs a biological interpretation, not just a metric comparison.

**Bad**:
> "The 12% improvement suggests our method is state-of-the-art."

**Good**:
> "The 12% improvement is concentrated in populations with <2% abundance, indicating that our
> method's use of gene regulatory network structure is particularly valuable when transcriptomic
> information alone is insufficient to distinguish rare from abundant cell types."

## Avoiding Algorithm-First Language

### Banned patterns in main text (move to Methods)

- Transformer architecture details
- Attention mechanism internals
- Loss function notation
- Hyperparameter specifics
- Training procedure specifics
- Gradient descent language
- Benchmark conventions

### Preferred patterns in main text

- Named method ("CellAgent", "BioGPT")
- High-level description (1 sentence)
- Biological inputs and outputs
- Biological validation results
- Biological interpretation

## Cover Letter Connection

The cover letter should amplify the biology-first framing of the paper. Reference:

1. **Two recent papers from the target journal**:
   - "Our work extends the recent finding by [Author et al., Year, Nat Methods] that [biology X]
     by demonstrating [extension Y]..."
2. **Biological significance**:
   - "This advances our understanding of [biological question] by enabling [new capability]..."
3. **Broader impact**:
   - "The approach has immediate applications in [disease area / drug discovery / biology domain]..."

## Biological Narrative Document Template

Write to `biological_narrative.md` (Chinese):

```markdown
# Phase 1: 生物学叙事设计

## 结果类型分类
**判决**: Strong / Marginal / Mixed / Counter-Intuitive / Negative

## 生物学优先重构

### 原本的算法叙事
{quote from the pre-experiment draft}

### 新的生物学叙事
{one-paragraph biology-first version}

## 题目
**新题目**: {biology-first title}

## Abstract 开场
**新开场句**: {biology problem, not method}

## Results Subsection 标题

### Section 1: {finding-based title}
- 生物学动机: {motivation in one sentence}
- 主要发现: {finding referencing compound figure}
- 生物学意义: {what this means}

### Section 2: {finding-based title}
[...]

### Section 3: {finding-based title}
[...]

## Cover Letter 定位

### 目标期刊: {journal}
### 引用的近期论文 (2-3 篇)
1. {Author, Year, Journal} - 我们如何扩展
2. {Author, Year, Journal} - 我们如何对比
3. {Author, Year, Journal} - 我们如何补充

### 科学意义声明
{one paragraph for cover letter}

## Discussion 框架

1. 生物学洞见段落: {what we learned about biology}
2. 方法论贡献段落: {how the method enables new biology}
3. 局限与未来段落: {honest, specific}

## 需要生物学重写的章节
- [ ] Abstract
- [ ] Introduction opening
- [ ] Each Results subsection title
- [ ] Each Results opening sentence
- [ ] Discussion
- [ ] Cover letter
```
