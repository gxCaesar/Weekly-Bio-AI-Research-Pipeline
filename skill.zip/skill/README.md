# AI for Bioinformatics Research Skills

九个 Claude Code 自定义 skill，覆盖 AI/LLM/Agent 应用于生物信息学（单细胞、药物设计、虚拟细胞等）研究的完整生命周期：从日常论文追踪 → 想法积累 → 项目规划 → 论文打磨 → 投稿后应对审稿意见。

## 九个 Skill 概览

### 日常积累阶段（2 个）— NEW

| Skill | 定位 | 何时使用 | 交互性 | 关键能力 |
|-------|------|---------|:------:|---------|
| **`paper_reader`** | 论文日常追踪 + 知识库 | 每日 arXiv 扫描、深读重要论文 | 双模式 | 3 分钟快读 → 15 分钟深度 → 知识库关联 → 启发笔记 |
| **`idea_library`** | 研究想法积累 + 新颖性验证 | 想法冒出的瞬间、开始新项目前选方向 | 双模式 | 3 层新颖性验证 + 2D 评分（T×B）+ Portfolio 矩阵 |

### 项目规划阶段（4 个）

| Skill | 定位 | 目标 Venue | 交互性 | 推荐使用场景 |
|-------|------|-----------|:------:|------------|
| `research_plan` | 基础版 | 通用 | 无 | 快速原型/入门 |
| `conference_plan` | 顶会专用 | AAAI/IJCAI/ICML/NeurIPS/ICLR | Phase 0 | 明确要投顶会 |
| `journal_plan` | 期刊专用 | Nature/Science/Cell 系列 18+ 期刊 | Phase 0 | 明确要投期刊 |
| **`research_copilot`** | **统一版（推荐）** | **顶会 + 期刊，支持双轨** | **每个Phase都交互** | **首选，全功能** |

### 论文打磨与应对审稿阶段（3 个）

| Skill | 定位 | 何时使用 | 交互性 | 关键能力 |
|-------|------|---------|:------:|---------|
| **`paper_polish_conf`** | 会议论文打磨 | 学生跑完实验后，投稿前 | 可切换全交互/Express | 结果验证 + 故事构建 + 图表精修 + 去 AI 腔 |
| **`paper_polish_journal`** | 期刊论文打磨 | 学生跑完实验后，投稿前 | 可切换全交互/Express | 生物学叙事 + 复合图 + Cover Letter + Reviewer 建议 |
| **`rebuttal_plan`** | 审稿意见应对 | 收到 reviewer 意见后 | 双模式 | 意见分类 + 逐条回应 + 补充实验设计 + Response Letter |

### 完整研究故事线

```
┌── 日常流（持续进行，独立于项目）────────────────┐
│  paper_reader (每日 arXiv 扫描 + 知识库积累)   │
│            │                                  │
│            │ 触发 idea                         │
│            ↓                                  │
│  idea_library (新颖性验证 + 2D 评分)          │
│            │                                  │
│            │ 选中 idea 启动项目                │
│            ↓                                  │
└────────────┼──────────────────────────────────┘
             ↓
┌── 项目启动 ──────────────────────────────────┐
│  research_copilot --from-idea-library        │
│  (或 conference_plan / journal_plan)         │
│            ↓ 生成方案 + 代码骨架              │
│     [学生执行实验 — 人工阶段]                │
└──────────────────────────────────────────────┘
             ↓
┌── 论文打磨 ──────────────────────────────────┐
│  paper_polish_conf / paper_polish_journal    │
│     Phase 0: 结果验证（强制 gatekeeper）      │
│     Phase 1-6/7: 故事构建→填数据→图表→精修   │
└──────────────────────────────────────────────┘
             ↓
            [投稿]
             ↓
     ┌───────┼───────┐
     ↓       ↓       ↓
   [接收]  [返修]  [拒稿]
     ↓       ↓       ↓
  publish  rebuttal_plan  (resubmission_plan, 未实现)
```

**9 个 skill 形成完整的研究闭环**：日常层持续积累论文和想法 → 项目层将想法变成具体研究 → 论文层打磨成发表品 → 应对层处理审稿 → 数据反哺知识库。

---

## 安装方法

### 方法一：全局安装（推荐，所有项目可用）

使用符号链接，源文件留在原位方便编辑：

```bash
# 安装全部 9 个 skill

# 日常积累阶段（最常用，建议立即安装）
ln -s /Users/cgxmac/Desktop/skill/paper_reader ~/.claude/skills/paper_reader
ln -s /Users/cgxmac/Desktop/skill/idea_library ~/.claude/skills/idea_library

# 项目规划阶段
ln -s /Users/cgxmac/Desktop/skill/research_plan ~/.claude/skills/research_plan
ln -s /Users/cgxmac/Desktop/skill/conference_plan ~/.claude/skills/conference_plan
ln -s /Users/cgxmac/Desktop/skill/journal_plan ~/.claude/skills/journal_plan
ln -s /Users/cgxmac/Desktop/skill/research_copilot ~/.claude/skills/research_copilot

# 论文打磨与应对审稿阶段
ln -s /Users/cgxmac/Desktop/skill/paper_polish_conf ~/.claude/skills/paper_polish_conf
ln -s /Users/cgxmac/Desktop/skill/paper_polish_journal ~/.claude/skills/paper_polish_journal
ln -s /Users/cgxmac/Desktop/skill/rebuttal_plan ~/.claude/skills/rebuttal_plan
```

安装后验证：
```bash
ls -la ~/.claude/skills/
# 应该看到 9 个符号链接
```

### 初始化日常积累的知识库

paper_reader 和 idea_library 会在 home 目录创建持久化的知识库：

```bash
# 第一次使用时，skill 会询问是否创建这些目录
# 你也可以手动预创建：
mkdir -p ~/paper_library/{papers,topics,insights,connections}
mkdir -p ~/idea_library/{ideas,clusters,retired}

# 强烈建议用 git 管理（都是纯 markdown 文件）
cd ~/paper_library && git init && git add . && git commit -m "Initial paper library"
cd ~/idea_library && git init && git add . && git commit -m "Initial idea library"
```

### 方法二：只安装推荐的 research_copilot

```bash
ln -s /Users/cgxmac/Desktop/skill/research_copilot ~/.claude/skills/research_copilot
```

### 方法三：项目级安装（仅当前项目可用）

在任意项目目录下：
```bash
mkdir -p .claude/skills
ln -s /Users/cgxmac/Desktop/skill/research_copilot .claude/skills/research_copilot
```

### 卸载

```bash
rm ~/.claude/skills/research_copilot  # 只删符号链接，不影响源文件
```

---

## 使用方法

### 方式一：斜杠命令直接调用

在 Claude Code 中输入：
```
/research_copilot
```
或带参数：
```
/research_copilot 基于LLM的单细胞分析研究
```

### 方式二：自然语言触发

直接描述需求，Claude 会自动识别并调用对应 skill：
```
帮我规划一个AI+单细胞的研究项目，目标投NeurIPS
```

### 方式三：指定 skill 名称

```
请使用 conference_plan 帮我规划投 ICML 的研究
```

---

## 各 Skill 使用实例

---

### 实例 0A: `paper_reader`（日常论文追踪）

**使用场景**：每天扫描 arXiv、深读重要论文、建立个人知识库。

**Express 模式：批量早上扫描**

```
/paper_reader --express
```

```
> 提供一批 arXiv IDs（今天要扫描的）:
你回答: "2404.01234, 2404.02345, 2404.03456, 2404.04567, 2404.05678"

> 处理中...
>
> 📄 2404.01234: "Sparse Attention for Efficient Transformers"
>    ⭐ 相关度: 4/5 (adjacent to your current project on attention mechanisms)
>    ✓ Quick archived to ~/paper_library/papers/2024_sparse_attention.md
>
> 📄 2404.02345: "Fine-tuning BERT for Clinical Notes"
>    ⭐ 相关度: 1/5 (not relevant)
>    ✗ Skipped
>
> 📄 2404.03456: "GRN-Guided Cell Typing with Foundation Models"
>    ⭐ 相关度: 5/5 (directly relevant to current project)
>    🔍 触发深度阅读...
>    （进入 Phase 1-4 full flow）
>    ✓ Deep read complete. Knowledge base updated.
>    💡 Triggered idea: "GRN + sparse attention for rare cells" → offered to idea_library
>
> [continues for remaining papers...]
>
> ✅ 今日阅读完成:
>    - 扫描: 5 篇
>    - Quick archived: 2 篇
>    - Deep read: 1 篇
>    - Skipped: 2 篇
>    - 触发想法: 1 个
>    - 耗时: 25 分钟
```

**全交互模式：深读单篇论文**

```
/paper_reader 2404.03456
```

```
> 📄 Paper: "GRN-Guided Cell Typing with Foundation Models"
> 📅 2024 | arXiv preprint
> 👥 Wang et al.
>
> 🎯 Problem: Existing cell typing methods struggle with rare cell populations
>    (<5% abundance), and don't leverage known gene regulatory structure.
>
> 🔧 Method: Transformer with attention masks derived from GRN edges.
>
> 📊 Key finding: 15% improvement on rare cell F1 across 3 scRNA-seq datasets.
>
> 💡 Relevance to your research: Directly relevant to your work on rare cell
>    identification. The attention mask approach is different from your planned
>    sparse attention - worth comparing.
>
> ⭐ Relevance score: 5/5
>
> 下一步:
>   (A) 深度阅读（Phase 1-4 全流程，~15 分钟）
>   (B) 快速存档
>   (C) 跳过

你回答: "A"

==================== Phase 1: Deep Analysis ====================
（skill 深度阅读论文，填写 5 个 section）

==================== Phase 2: Knowledge Base Linking ====================

> 知识库中可能相关的论文:
>   1. [[2024_lotfollahi_scvi]] - 同为 VAE-based 方法
>   2. [[2024_ma_scgpt]] - 同样用 transformer 做 cell typing
>   3. [[2024_yang_grn_gnn]] - 同样用 GRN prior
>
> 选择要建立连接的论文（可多选）：

你回答: "全部 3 个"

> 为每个连接分类关系:
>   - 2024_ma_scgpt: Extends (继承 scGPT 的 transformer backbone)
>   - 2024_yang_grn_gnn: Contrasts (用 attention mask 而非 GNN)
>   - 2024_lotfollahi_scvi: Complements (annotation vs integration)

==================== Phase 3: Personal Insight Notes ====================

> 这篇论文触发了 1 个新想法:
> "GRN attention mask + sparse attention 或许在极稀有 cell (<1%) 上更有效"
>
> 保存到 idea_library? (y/n)

你回答: "y"

==================== Phase 4: Index Update ====================

> ✅ 论文已加入知识库:
>   📁 ~/paper_library/papers/2024_wang_grn_cell_typing.md
>   📁 ~/paper_library/topics/single_cell_llm.md (updated)
>   📁 ~/paper_library/insights/rare_cell_identification.md (appended)
>   📁 ~/paper_library/reading_log.md (today's entry)
>
> 📊 统计:
>   - 相关度: 5/5
>   - 知识库连接: 3 个新 edge
>   - 触发想法: 1 个 (saved to idea_library)
>   - 阅读耗时: 18 分钟
```

**知识库布局**：
```
~/paper_library/
├── index.md                    # 主索引（时间排序 + 主题标签）
├── papers/                     # 每篇论文一个 markdown
│   ├── 2024_wang_grn_cell_typing.md
│   └── ...
├── topics/                     # 主题归类
│   ├── single_cell_llm.md
│   └── ...
├── insights/                   # 跨论文洞见
│   ├── rare_cell_identification.md
│   └── ...
├── connections/connections.json  # 知识图谱（可选机读层）
└── reading_log.md              # 阅读日志
```

---

### 实例 0B: `idea_library`（研究想法积累）

**使用场景**：想法冒出时立即捕获，新颖性验证，2D 评分，长期积累。

**完整流程：新想法捕获**

```
/idea_library
```

```
> 让我们捕获这个想法:
>
> 标题 (短): ________

你回答: "GRN-guided sparse attention for rare cells"

> 类型:
>   (A) 新方法 (novel technique)
>   (B) 新应用
>   (C) 新理论
>   (D) 新基准
>   (E) 新观察
>   (F) 综合

你回答: "A"

> 核心想法 (1-3 段):

你回答: "结合 GRN structure 和 sparse attention，在 <1% 稀有 cell 识别上应该比 Wang et al. 2024 的 dense GRN attention 更好。sparse 的 inductive bias 可以避免在 abundant cell 上过拟合，同时 GRN edge 保证 attention 聚焦在生物学上相关的基因。"

> 触发来源:
>   (A) 自发思考
>   (B) 阅读论文: [paper ID]
>   (C) 讨论/会议
>   (D) 其他想法的演化

你回答: "B, 2024_wang_grn_cell_typing"

> 目标应用领域:
>   [x] single-cell analysis
>   [ ] drug discovery
>   [ ] ...

> 初步可行性 gut feel (1-5): ___
> 初步创新度 gut feel (1-5): ___
> 初步生物意义 gut feel (1-5): ___

你回答: "4, 4, 4"

==================== Phase 1: Novelty Verification ====================

> Layer 1: Internal idea_library
>   检查中... 未发现相同想法
>
> Layer 2: Your paper_library
>   [[2024_wang_grn_cell_typing]] - 使用 dense GRN attention
>   [[2024_ma_scgpt]] - 标准 transformer
>   [[2024_child_sparse_transformer]] - 通用 sparse attention
>
> 你的想法是否已被做过?
>   (A) 没有，相关但不同
>   (B) 部分重叠但有明显差异
>   (C) 已被完全做过

你回答: "A"

> Layer 3: Web Search
>   Query 1: "GRN sparse attention rare cell" → 3 相关结果
>   Query 2: "graph-guided sparse transformer cell typing" → 1 相关
>   Query 3: "sparse biological prior attention 2024 2025" → 5 相关
>
>   发现可能相关:
>     1. Johnson et al. 2024 "Sparse graph attention" - NeurIPS workshop
>        (但用于通用 graph learning，不是 cell typing)
>     2. Chen et al. 2025 (arXiv preprint) "Biological priors for transformers"
>        (理论 paper，但没实现 sparse mechanism)
>
>   你的想法与它们的差异是什么?

你回答: "前者不是 cell typing，后者只有理论没有 sparse mechanism 的具体实现。我的想法是把两者结合，专注于 rare cell 识别这个具体任务。"

> 判决: **Differentiated**
> 建议 differentiation 表述: "First to combine GRN-derived sparsity patterns
> with rare-cell-targeted attention, addressing the <1% abundance regime
> that existing dense GRN methods fail on."

==================== Phase 2: 2D Scoring ====================

> 理论深度 (T) 自评 (1-5): ___
> 我的估计: T=3 (Compositional) - 新颖组合，但用到的每个技术都存在
>
> 如果添加 theoretical analysis (e.g., 为什么 sparse 在 rare cell 更好),
> 可能达到 T=4.

你回答: "3，暂时，之后可能深挖到 4"

> 生物意义 (B) 自评 (1-5): ___
> 我的估计: B=4 (Discovery-enabling) - 识别 <1% cell 是重要生物问题,
> 现有方法做不到

你回答: "4"

> 可行性 (F) 自评 (1-5): ___
> 我的估计: F=4 - 代码可基于 Wang et al. 2024 repo 改造,
> 数据集 Tabula Sapiens 已有，1x A100 足够

你回答: "4"

> 热点对齐 (Tr) 自评 (1-5): ___
> 我的估计: Tr=5 - single-cell + LLM/transformer 当下极热

你回答: "5"

> ==== 评分结果 ====
> T (理论): 3/5
> B (生物): 4/5
> F (可行性): 4/5
> Tr (热点): 5/5
>
> Portfolio 定位: **TB (Balanced, T=3-4, B=3-4)**
> 推荐 Venue:
>   - 主要: NeurIPS (if T 能提升到 4)
>   - 主要: Nature Methods (生物意义强)
>   - 双轨: research_copilot 可能合适
>
> 你的 idea library 现在有 12 个 active ideas
> Heatmap 更新: 新增一个 T=3 B=4 节点
>
> 下一步:
>   (A) 完成
>   (B) 再补充细节
>   (C) 启动 research_copilot 开始执行
>   (D) 暂时 sleeping，先做别的

你回答: "D, 先 sleeping, 下个月再评估"

> ✅ 想法已保存:
>   📁 ~/idea_library/ideas/2026-04-11_grn_sparse_attention.md
>   📁 ~/idea_library/index.md (updated)
>   📁 ~/idea_library/heatmap.md (updated)
```

**2D Heatmap 示例** (`~/idea_library/heatmap.md`)：

```
                    Biological (B)
                    1    2    3    4    5
                ┌────┬────┬────┬────┬────┐
              5 │    │    │    │ ●  │    │  T=5
                ├────┼────┼────┼────┼────┤
              4 │    │ ●  │    │ ●● │ ●  │  T=4
                ├────┼────┼────┼────┼────┤
  Theoretical 3 │    │ ●  │ ●● │ ●● │    │  T=3  ← 新想法在这里
                ├────┼────┼────┼────┼────┤
              2 │ ●  │    │ ●  │    │    │  T=2
                ├────┼────┼────┼────┼────┤
              1 │    │    │    │    │    │  T=1
                └────┴────┴────┴────┴────┘
```

揭示：你的 library 现在有 1 个 PEAK 想法 (T=4, B=4)，2 个 TB 想法 (T=3, B=4)。

---

### 实例 1: `research_plan`（基础版）

**使用场景**：快速生成一套完整的研究材料，无需交互。

**调用**：
```
/research_plan 基于LLM的单细胞RNA-seq分析
```

**过程**：自动运行 8 个 Phase，无停顿。

**产出**：
```
scRNA-LLM/
├── survey.md              # 文献调研 (中文)
├── proposal.md            # 研究方案 (中文)
├── code/                  # 完整代码项目
├── paper/                 # LaTeX 论文 (NeurIPS 格式)
├── technical_manual.md    # 技术手册 (中文)
└── presentation.html      # HTML 幻灯片
```

---

### 实例 2: `conference_plan`（顶会专用）

**使用场景**：明确目标是 AAAI/IJCAI/ICML/NeurIPS/ICLR 中的某个。

**调用**：
```
/conference_plan
```

**交互过程**：

```
Phase 0 开始，skill 会问你：

> 请选择目标会议：
> 1. AAAI — 7页, 最广AI范围
> 2. IJCAI — 7页, 重视理论深度
> 3. ICML — 8页, 数学严谨性不可商量
> 4. NeurIPS — 9页, 最高声望
> 5. ICLR — 9页, 表征学习, 开放评审

你回答: "NeurIPS"

> 请提供研究方向，或者我帮你搜索热门方向。

你回答: "基于LLM Agent的虚拟细胞建模"

> 确认: NeurIPS 2026 + LLM Agent虚拟细胞 + 1x A100。开始？

你回答: "开始"

（后续 Phase 1-9 自动运行）
```

**产出**：
```
virtual-cell-agent/
├── survey.md              # 含前沿技术速递 + 创新验证
├── proposal.md            # 3+ 创新点 (含理论贡献) + 可行性验证
├── code/
│   ├── ...                # 完整项目
│   └── analysis/          # 11 个分析脚本 (统计检验, 生成表格, 生物验证)
├── paper/
│   ├── main.tex           # NeurIPS 格式, XX.X 占位符 + [Analysis:] 注释
│   ├── neurips_2026.sty
│   ├── figures/
│   └── tables/
├── technical_manual.md
├── presentation.html
└── post_experiment_guide.md   # 实验后流程 + 30项提交清单
```

---

### 实例 3: `journal_plan`（期刊专用）

**使用场景**：目标是 Nature/Science/Cell 系列期刊。

**调用**：
```
/journal_plan
```

**交互过程**：

```
Phase 0:

> 请选择目标期刊（按 tier 分组）：
> Tier 1: Nature Methods, Nature Machine Intelligence, Nature Biotechnology
> Tier 2: Nature Communications, Nature Computational Science, Science Advances
> Tier 3: Genome Biology, Cell Systems, PLOS Computational Biology
> ...

你回答: "Nature Methods"

> 请提供研究方向：

你回答: "LLM-based single-cell analysis tool"

> 确认: Nature Methods + LLM单细胞工具 + 1x A100。开始？

（后续自动运行）
```

**产出**：
```
sc-llm-tool/
├── survey.md
├── proposal.md            # 科学意义框架 + cover letter 计划 + reviewer 建议
├── code/
│   └── analysis/          # 含 bio_validation.py, compound_figures.py
├── paper_journal/         # ← 期刊格式 (非会议格式)
│   ├── main.tex           # Abstract > Intro > Results(叙事) > Discussion
│   ├── methods.tex        # Methods 单独文件
│   ├── supplementary.tex
│   ├── extended_data.tex  # Nature 系列 Extended Data
│   ├── cover_letter.tex   # 投稿信
│   ├── figures/
│   │   ├── fig1/          # 复合图 (每图一个目录)
│   │   ├── fig2/
│   │   └── ...
│   └── reviewer_suggestions.md
├── technical_manual.md
├── presentation.html
└── post_experiment_guide.md
```

---

### 实例 4: `research_copilot`（推荐，全功能统一版）

**使用场景**：任何研究规划需求。支持顶会、期刊、或双轨投稿。每步都可以交互调整。

**调用**：
```
/research_copilot
```

**完整交互过程**（全交互模式）：

```
==================== Phase 0: Research Discovery ====================

> 我扫描了 6 大 bio-AI 热点领域，发现 15 个研究 gap：
>
> | # | Gap | 理论潜力 | 生物意义 | 工程影响 | 可行性 |
> |---|-----|:---:|:---:|:---:|:---:|
> | 1 | LLM Agent 自动化单细胞分析流程 | 3 | 5 | 5 | High |
> | 2 | 基于信息瓶颈的细胞表征学习 | 5 | 4 | 3 | High |
> | 3 | GRN引导的稀疏注意力机制 | 4 | 4 | 4 | High |
> | ...
>
> [PAUSE 1] 哪 2-3 个 gap 最感兴趣？

你回答: "1 和 3"

> 基于你选的 gap，我细化出 4 个研究问题：
> 1. LLM Agent + GRN-guided attention for rare cell type annotation
> 2. ...
>
> [PAUSE 2] 选哪个？

你回答: "1"

==================== Phase 1: Venue Strategy ====================

> 跨 venue 分析结果：
>
> | Venue | 适配度 | 理由 |
> |-------|:---:|------|
> | NeurIPS | ★★★★☆ | 方法+理论+bio验证，ML4Science track |
> | Nature Methods | ★★★★★ | 工具型论文最佳匹配 |
> | ICLR | ★★★☆☆ | 表征学习角度可行 |
>
> 推荐: 双轨 — NeurIPS (conference) + Nature Methods (journal)
>
> [PAUSE 3] 选: (A) NeurIPS, (B) Nature Methods, (C) 双轨, (D) 其他？

你回答: "C 双轨"

> [PAUSE 4] 交互模式: (A) 全交互, (B) Express, (C) 自定义？

你回答: "A 全交互"

==================== Phase 2: Literature Survey ====================

> 调研完成，发现 top 5 gap：
> Gap #1 理论潜力最高 (信息瓶颈公式化)
> Gap #3 生物意义最高 (GRN结构利用)
> Gap #5 工程影响最高 (Agent流程自动化)
>
> [PAUSE 5] 创新点应该瞄准哪些 gap？

你回答: "1, 3, 5"

==================== Phase 3: Innovation Design ====================

> 设计了 5 个候选创新点：
>
> | # | 名称 | T | B | E | 总分 |
> |---|------|:-:|:-:|:-:|:---:|
> | A | 信息瓶颈细胞表征理论 | 5 | 3 | 2 | 10 |
> | B | GRN引导稀疏注意力 | 3 | 5 | 4 | 12 |
> | C | Agent自动化分析流程 | 2 | 4 | 5 | 11 |
> | D | 对比学习+细胞层次结构 | 4 | 4 | 3 | 11 |
> | E | 多数据集自适应微调 | 2 | 3 | 4 | 9 |
>
> 推荐组合: B + A + C (T=10, B=12, E=11)
> 备选(会议优化): A + D + B (T=12, B=12, E=9)
> 备选(期刊优化): B + C + D (T=9, B=13, E=12)
>
> [PAUSE 6] 接受推荐组合？还是调整？

你回答: "接受推荐 B+A+C"

==================== Phase 4: Research Proposal ====================

> 方案完成。可行性: PASS
> - 峰值显存: 42GB / 80GB ✓
> - 数据集: Tabula Sapiens, PBMC, Pancreas (全部可下载) ✓
> - 训练时间: ~28 GPU天 / 35天预算 ✓
>
> [PAUSE 7] 审批方案？

你回答: "通过"

==================== Phase 5: Code Architecture ====================

> 架构蓝图:
> - Backbone: scGPT (from GitHub)
> - 新增模块: GRNAttention, InfoBottleneck, AgentPipeline
> - 峰值显存: 42GB
> - 分析脚本: 12 个，映射到论文 6 张表 + 6 张图
>
> [PAUSE 8] 审批架构？

你回答: "通过"

==================== Phase 6: Code + Review ====================

> 代码完成: 47 个 Python 文件, 全部语法正确
> 显存: 42GB / 80GB, 管道: PASS
>
> [PAUSE 9] 有问题吗？

你回答: "继续"

==================== Phase 7: Paper Draft ====================

> 双轨论文完成:
>
> NeurIPS 版: RQ结构, 理论分析章节, TikZ图
> Nature Methods 版: 叙事Results, 复合图, Cover Letter
>
> Abstract (NeurIPS): "Single-cell analysis requires..."
> Abstract (Nature Methods): "Characterizing cellular heterogeneity..."
>
> [PAUSE 10] 审查哪部分？

你回答: "Nature Methods 的 abstract 改一下，第二句更强调生物学意义"

（修改后继续）

==================== Phase 8: Quality Gate ====================

> 质量评分卡:
> ✓ 实验规模 (3 数据集, 6 基线, 4 指标)
> ✓ 公平对比协议
> ✓ 分析-论文对齐 (12 脚本 → 12 paper元素)
> ✓ 生物学验证 (3 类型)
> ✓ NeurIPS 格式合规
> ✓ Nature Methods 格式合规
> ✓ Cover letter 已写
> 0 问题
>
> [PAUSE 11] 全部通过，继续？

你回答: "继续"

==================== Phase 9: Student Handoff ====================

> HANDOFF_README.md 已生成
> 学生需要: 1x A100, ~50GB 磁盘, ~4 周实验时间
>
> [PAUSE 12] 确认交付？

你回答: "确认"
```

**最终产出**（双轨模式）：
```
cell-agent/
├── research_discovery_notes.md    # 探索记录
├── venue_strategy.md              # 双轨: NeurIPS + Nature Methods
├── survey.md                      # 文献调研
├── innovation_design_notes.md     # 5选3 创新组合
├── proposal.md                    # 完整方案 + 可行性 PASS
├── architecture_blueprint.md      # 代码架构
├── code/                          # 完整代码
│   ├── configs/ data/ models/ baselines/ training/ evaluation/
│   ├── analysis/                  # 12 个分析脚本
│   ├── scripts/ ablation/
│   ├── main.py, requirements.txt, README.md
├── paper/                         # NeurIPS 版论文
│   ├── main.tex (RQ结构, 理论分析, TikZ图)
│   ├── references.bib, neurips_2026.sty
│   ├── figures/, tables/
├── paper_journal/                 # Nature Methods 版论文
│   ├── main.tex (叙事Results, 复合图结构)
│   ├── methods.tex, supplementary.tex, extended_data.tex
│   ├── cover_letter.tex
│   ├── figures/fig1/ fig2/ fig3/ fig4/
│   └── reviewer_suggestions.md
├── technical_manual.md            # 学生技术手册
├── presentation.html              # 项目介绍
├── quality_gate_report.md         # 质量评分卡
├── post_experiment_guide.md       # 实验后指南
└── HANDOFF_README.md              # 学生一页入口
```

---

### 实例 5: `paper_polish_conf`（学生跑完实验后，打磨会议论文）

**使用场景**：学生给了实验结果（JSON/CSV/log），需要把会议论文骨架打磨成投稿版。

**前置条件**：项目目录里已经有 `conference_plan` 或 `research_copilot` 生成的 `paper/` 骨架和 `code/analysis/` 分析脚本。

**调用**：
```
/paper_polish_conf
```

或自然语言：
```
帮我用学生的实验结果打磨 NeurIPS 论文，我们目标是打磨完投稿
```

**交互过程（全交互模式）**：

```
==================== Phase 0: Result Validation ====================

> 我检测到项目状态:
>   - code/outputs/ 存在: ✓
>   - analysis_outputs/ 存在: ✗（未发现）
>   - 最新结果文件: outputs/experiment_20260410.json
>
> 请确认 code/analysis/ 脚本的执行状态:
>   (A) 已全部执行
>   (B) 部分执行
>   (C) 尚未执行（需要先跑 bash code/analysis/run_all_analysis.sh）
>   (D) 想让 skill 自动执行

你回答: "C, 我先去跑"

（返回执行，稍后重新调用）

你重新调用后:
> 开始 Phase 0 的 5 大检查...

> ✅ Check 1: 统计严谨性 - 通过
> ✅ Check 2: 公平比较 - 通过
> ⚠️ Check 3: 数据泄漏 - WARN（donor leakage 可能，但未确认）
> ✅ Check 4: 过拟合检测 - 通过
> ✅ Check 5: 反直觉结果 - 2 个需要验证
>
> 判决: WARN
> 建议: 确认 donor leakage 是否真实，2 个反直觉结果的验证

你回答: "donor 没问题，已确认；反直觉结果是真发现，我有新的 hypothesis"

==================== Phase 1: Narrative Construction ====================

> 结果类型分类: Counter-Intuitive
> 推荐叙事策略: "Discovery framing — we reveal a surprising phenomenon"
>
> 主要发现:
>   - 主实验: 83.4% F1 (vs 71.2% best baseline)
>   - Counter-intuitive: 小模型 (100M) 反而比大模型 (1B) 强 12%
>   - Ablation: GRN 引导的注意力机制是关键
>
> 推荐的 contribution bullets:
>   1. 揭示了 rare cell 识别中模型规模的饱和现象
>   2. 提出 GRN 引导注意力机制，实现参数效率与性能双重改进
>   3. 新增 3 个 pancreas rare cell 类型的生物学表征
>
> 接受叙事策略？

你回答: "接受"

==================== Phase 2: Data Filling ====================
（自动扫描 XX.X 占位符，填入实际数据）

==================== Phase 3: Figure Polishing ====================
（自动精修图表，生成 TikZ + 高质量 PDF）

==================== Phase 4: Writing Polish ====================
（打磨 Abstract、Introduction、Results、Discussion）

==================== Phase 5: Style Audit ====================
（去除 AI 腔，生成 style_report.md）

==================== Phase 6: Final Quality Gate ====================

> 质量检查:
>   ✓ 所有 XX.X 占位符已替换
>   ✓ 所有 [Analysis:] 注释已移除
>   ✓ 页数: 8.7 / 9 (NeurIPS)
>   ✓ 引用 42 篇完整
>   ✓ Reproducibility Checklist 完成
>   ✓ Broader Impact 段落存在
>
> 总体就绪度: Ready
>
> 审批投稿？
```

**产出**：
```
cell-agent/
├── paper/                      # 完成版（不再有 XX.X 或 [Analysis:]）
│   ├── main.tex
│   ├── figures/                # 300 DPI TikZ + PDF
│   └── tables/
├── validation_report.md        # Phase 0
├── narrative_design.md         # Phase 1
├── paper_diff.md               # Phase 2
├── style_report.md             # Phase 5
└── quality_check_report.md     # Phase 6
```

---

### 实例 6: `paper_polish_journal`（学生跑完实验后，打磨期刊论文）

**使用场景**：目标是 Nature Methods / Nature Communications / Cell Systems 等期刊。

**与 paper_polish_conf 的区别**：
- Phase 1: **生物学叙事**而非 RQ 驱动（section titles 陈述发现）
- Phase 3: **复合多面板图**（每图 4-8 panels）而非单图
- Phase 6: **Cover letter + Reviewer suggestions + Data/Code availability + CRediT**

**调用**：
```
/paper_polish_journal
```

**交互示例（Phase 1 生物学叙事）**：
```
> 结果类型: Strong
> 生物学叙事框架: "Discovery paper — rare cell types revealed by GRN-guided modeling"
>
> Results Subsection Titles (declarative, finding-based):
>   1. "CellAgent identifies rare cell types missed by existing methods"
>   2. "Gene regulatory network structure drives rare-cell detection"
>   3. "Three uncharacterized cell populations in human pancreas"
>   4. "Validation across five independent datasets confirms robustness"
>
> Cover Letter 引用建议 (2-3 篇 Nature Methods 近期论文):
>   1. Lotfollahi et al. 2024 - 我们扩展了他们的 conditional VAE 框架
>   2. Ma et al. 2024 - 我们对比他们的 transformer 方法
>
> 接受生物学叙事框架？
```

**产出**（含期刊特有材料）：
```
cell-agent/
├── paper_journal/
│   ├── main.tex (narrative results)
│   ├── methods.tex (独立 methods 章节)
│   ├── cover_letter.tex (针对 Nature Methods 定制)
│   ├── supplementary.tex
│   ├── extended_data.tex
│   ├── figures/fig1/, fig2/, fig3/, fig4/  # 复合图目录
│   ├── reviewer_suggestions.md
│   ├── data_availability.md
│   ├── code_availability.md
│   ├── credit_statement.md
│   └── highlights.md  # Nature Methods 要求
├── validation_report.md
├── biological_narrative.md
├── paper_diff.md
├── style_report.md
└── quality_check_report.md
```

---

### 实例 7: `rebuttal_plan`（收到审稿意见后应对）

**使用场景**：顶会或期刊审稿意见到了，需要 7-14 天内完成 rebuttal（顶会）或 2-3 个月修订（期刊）。

**调用**：
```
/rebuttal_plan
```

**交互过程（全交互模式）**：

```
> 请提供输入:
>   1. 审稿意见文本路径: /path/to/neurips_reviews.txt
>   2. 原论文项目路径: /path/to/project/
>   3. Venue 类型: conference / journal
>   4. 截止日期: 2026-04-25 (距今 14 天)

你回答: "conference; NeurIPS; 14天"

==================== Phase 0: 审稿意见解析 ====================

> 解析 3 位审稿人的意见:
>   Reviewer 1: 7 comments (2 Critical, 4 Important, 1 Minor)
>   Reviewer 2: 5 comments (1 Critical, 3 Important, 1 Minor)
>   Reviewer 3: 6 comments (1 Critical, 3 Important, 2 Minor)
>
> 跨审稿人共同关注:
>   - [Critical] 缺少 XYZ baseline (R1, R2 都提到)
>   - [Important] 理论分析的独立性假设 (R1, R3 都提到)
>
> 按类型分类:
>   A. 技术质疑: 4
>   B. 实验缺失: 5 (含 2 critical)
>   C. 写作问题: 4
>   D. 理解错误: 3
>   E. 主观偏好: 2
>
> 最大风险: 缺少 XYZ baseline (两位 reviewer 都强调)
>
> 分类和优先级正确吗？

你回答: "正确，继续"

==================== Phase 1: 逐条回应策略 ====================

> 策略统计:
>   - Accept: 6 comments
>   - Refute: 2 comments
>   - Supplement: 5 comments (需要补实验)
>   - Clarify: 5 comments
>
> Critical comments 回应:
>   R1.1: [Supplement] 添加 XYZ baseline - 运行 XYZ 在 3 个数据集
>   R2.3: [Clarify + Refute] 澄清 independence assumption，添加 relaxed theorem
>   R3.5: [Accept + Supplement] 补充 ablation on GRN 结构
>
> 审批策略？

你回答: "通过"

==================== Phase 2: 补充实验设计 ====================

> 补充实验计划:
>
> Critical (必须做):
>   - Exp 1: XYZ baseline × 3 datasets → 6 GPU-hours
>   - Exp 2: Relaxed theorem experiments → 4 GPU-hours
>
> Important (应该做):
>   - Exp 3: Additional ablation on GRN → 3 GPU-hours
>
> Nice-to-have (时间允许):
>   - Exp 4: Sensitivity on hyperparameter → 2 GPU-hours
>
> 无法完成:
>   - Exp N: 大规模预训练 (2 周，远超窗口)
>     → response letter 解释限制
>
> 总时间需求: 15 GPU-hours / ~270 GPU-hours 可用
> 可行性: Feasible
>
> 决策: (A) 按此执行 (B) 调整 (C) 扩展时间

你回答: "A，按此执行"

（在接下来几天，学生运行实验，完成后你重新调用 skill 进入 Phase 3）

==================== Phase 3: 论文修订 ====================
（自动根据 response 和实验结果更新 paper/main.tex）

==================== Phase 4: 提交前检查 ====================

> Rebuttal 包已就绪:
>   ✓ 所有 critical comment 已回应
>   ✓ 补充实验已完成 (3 Critical + 1 Important)
>   ✓ Response letter 字数 4823/5000 chars (NeurIPS 限制)
>   ✓ 论文 diff 与 response 一致
>   ✓ 语气检查: 礼貌 + 自信
>
> 总体就绪度: Ready
>
> 审批提交？
```

**产出**：
```
cell-agent/
├── rebuttal/
│   ├── review_analysis.md           # Phase 0
│   ├── response_draft.md            # Phase 1
│   ├── additional_experiments.md    # Phase 2
│   ├── paper_diff.md                # Phase 3
│   ├── response_letter.tex          # 最终 response (英文)
│   └── rebuttal_checklist.md        # Phase 4
└── paper/main.tex                   # 已修订 (in place)
└── paper/main.tex.pre_rebuttal.bak  # 修订前备份
```

---

## 常见问题

### Q: 装了多个 skill 会冲突吗？
不会。每个 skill 有独立的名字，通过 `/skill_name` 调用指定的。Claude 也会根据你的需求描述自动选择最匹配的 skill。

### Q: Express 模式和全交互模式有什么区别？
研究规划 skill（research_copilot 等）：Express 模式只在 Phase 0-1 暂停，其余自动。
Paper polish skill：Express 模式只在 Phase 0 (结果验证有问题时) 和 Phase 2 (缺失结果时) 暂停。
Rebuttal plan：Express 模式只在 Phase 2 (实验决策) 暂停 — 这个暂停是**强制**的，无法跳过，因为实验提交 GPU 时间需要用户确认。

### Q: 双轨模式是同时投两个 venue 吗？
不是。双轨模式生成两份论文（会议版+期刊版），共享代码和实验。建议先投会议（有固定截止日期），会议结果出来后再投期刊。不可同时投。

### Q: 可以只生成论文不生成代码吗？
不可以。这些 skill 设计为完整的 pipeline，代码是论文的基础。但你可以在 Phase 5（代码架构审批）告诉 Claude 你已有代码，让它适配。

### Q: 中文部分可以改成英文吗？
可以，在调用 skill 时说明："所有文档用英文"。但默认 survey/proposal/manual 用中文，paper/code 用英文。

### Q: paper_polish_* 会不会覆盖学生的原始数据？
不会。Phase 0 会询问 analysis 脚本是否执行过；如果执行过，skill 不会重跑覆盖结果。Phase 3 修订论文前会备份原版到 `paper/main.tex.pre_rebuttal.bak`。

### Q: rebuttal_plan 支持 PDF 格式的审稿意见吗？
不支持。请将审稿意见从 OpenReview 或期刊系统复制为纯文本或 markdown，skill 会自动识别格式。PDF 解析容易出错，不如用户手动复制可靠。

### Q: 如果 Phase 0 结果验证失败（NO-GO）怎么办？
表示你的实验有严重问题（如数据泄漏、fair comparison 违规）。skill 会停止并生成 `validation_report.md` 指出具体问题。你应该先回到 code/ 修复问题，重新跑实验，然后重新调用 paper_polish_*。**强行往下走会发表一个有问题的论文**。

### Q: 第一次用 paper_polish_*，我的项目是 research_plan 生成的（不是 conference_plan），能用吗？
可以，但功能受限。research_plan 的 code/ 目录没有 analysis/ 子目录，XX.X 占位符和 [Analysis:] 注释可能不完整。建议未来项目用 conference_plan 或 research_copilot，以确保 paper_polish 的完整效果。

### Q: 9 个 skill 我应该怎么组合使用？
推荐闭环：
1. **日常（持续进行）**:
   - 每天早上: `paper_reader --express` 扫描 arXiv
   - 想法冒出时: `/idea_library` 立即捕获
   - 每周回顾: 查看 `~/idea_library/heatmap.md`，评估 ideas
2. **启动项目**: `research_copilot --from-idea-library` 从想法库选一个 idea 开始（或 conference_plan / journal_plan 如果 venue 明确）
3. **学生执行**: 学生根据 technical_manual.md 跑实验
4. **论文打磨**: paper_polish_conf 或 paper_polish_journal（Phase 0 强制结果验证）
5. **投稿**
6. **收到审稿**: rebuttal_plan（意见分类 + 逐条应对 + 补充实验规划）
7. **重新投稿**: 接收则准备 camera-ready；返修则再用 rebuttal_plan；拒稿则等待未来的 `resubmission_plan`

### Q: paper_reader 的知识库多大才有价值？
30 篇以上开始显现结构（主题聚合、连接涌现）。100 篇以后成为不可替代的个人资产。500 篇以后可以支撑跨项目的 insight 写作。建议每天 3 篇（2 快读 + 1 深读），一年 700 篇左右，2-3 年就能建起一个有分量的个人图书馆。

### Q: idea_library 和 research_copilot 的 Phase 0 有什么区别？
- `research_copilot` Phase 0 是"项目级"的 — 一次性扫描热点，选方向，之后进入项目 pipeline
- `idea_library` 是"日常级"的 — 持续积累想法，长期维护，等到启动项目时再从中挑选
- 两者通过 `research_copilot --from-idea-library` 连接：日常积累 → 项目启动

### Q: 2D 评分（T × B）为什么不是 3D？
research_copilot 的 innovation_rubric 用 3D（理论 × 生物 × 工程）做**项目执行**决策，因为工程实现性影响 pipeline 设计。
idea_library 只用 2D，因为**想法捕获阶段**关心的是"这想法值不值得做"，工程难度是次要的（可以在执行阶段再评估）。简化到 2D 降低了想法捕获的摩擦。

### Q: 如果知识库被污染了（如错误分类、重复），怎么办？
所有存储都是纯 markdown + git。直接手动编辑纠正，然后 git commit 记录变更。skill 下次读取时会使用更新后的内容。

### Q: paper_reader 能读 PDF 吗？
能读本地 PDF 文件（通过 Read tool）。不能从 URL 自动下载 PDF（会触发 WebFetch 但大多数期刊网站要订阅）。推荐使用 arXiv ID，是最顺畅的方式。
