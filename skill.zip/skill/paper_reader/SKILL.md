---
name: paper_reader
description: >
  Daily paper reading and knowledge base accumulation skill for AI/bioinformatics research.
  Takes a paper from any academic source (arXiv, bioRxiv, PubMed, Papers with Code, OpenReview,
  local PDF, or keyword search) and produces a structured, searchable, personal knowledge entry:
  3-minute quick read → deep analysis → knowledge base linking → personal insight notes → index
  update. Builds a persistent ~/paper_library/ that accumulates over time and integrates with
  idea_library and research_copilot. Use for daily paper scanning, deep reading of important
  papers, literature review preparation, and knowledge capture. Also triggers for: read paper,
  analyze paper, arXiv scanning, bioRxiv scanning, literature note, paper summary, build
  knowledge base, 论文阅读, 文献整理, pubmed, biorxiv, paper with code.
---

# Paper Reader Skill

This skill is your personal research librarian. Every day, arXiv publishes 100-300 new AI/ML/
bioinformatics papers. Reading them all deeply is impossible. This skill helps you **scan
broadly, read selectively, and accumulate persistently** — turning transient reading into
lasting knowledge.

Unlike the `survey` phase in `conference_plan` / `research_copilot` (which does a one-time,
project-level literature search), `paper_reader` is a **daily, continuous** tool. The knowledge
you build up here feeds future surveys, ideas, and projects.

**Primary storage**: `~/paper_library/` (default; configurable)
**Interaction mode**: Full interactive (pauses at Phase 0 for relevance decision). Express mode available.
**Language convention**: Notes in Chinese; paper titles, authors, technical terms in English.
**Integration**: Feeds `idea_library` (via paper insights) and `research_copilot` (via literature context).

## When to Use

Invoke this skill when:
- Scanning daily arXiv feed for relevant papers
- Deep-reading an important paper (one that shapes your next project)
- Preparing literature notes for a collaboration or discussion
- Reviewing a paper for a conference / journal
- Building your knowledge base systematically

**Do NOT** use this skill if:
- You are doing a project-level literature review (use `conference_plan` / `research_copilot` Phase 1)
- You are chasing a single fact and don't need structured notes (just use WebSearch)
- The paper is already in your knowledge base (unless revisiting for new insights)

## Input Formats

Read `references/sources_guide.md` for complete API details, rate limits, and field mappings
for all sources. Inputs are resolved in 3 layers:

### Layer 1: Direct Fetch (知道 ID/URL)

Provide a specific identifier — the skill fetches directly without searching:

| Identifier format | Source |
|---|---|
| `2403.12345` or `arXiv:2403.12345` | arXiv |
| `https://arxiv.org/abs/2403.12345` | arXiv URL |
| `2024.03.15.585XXX` (bioRxiv DOI suffix) | bioRxiv |
| `https://www.biorxiv.org/content/...` | bioRxiv URL |
| `PMID:12345678` or `12345678` (8 digits) | PubMed |
| `PMC12345678` | PubMed Central |
| `10.1038/s41592-024-XXXX` (starts with `10.`) | DOI → CrossRef resolve |
| `https://openreview.net/forum?id=XXXX` | OpenReview |
| `https://paperswithcode.com/paper/XXXX` | Papers with Code |
| `/path/to/paper.pdf` | Local PDF |

Auto-detects format from string pattern. If ambiguous, asks user.

### Layer 2: Search (不知道 ID, 知道关键词/标题)

Provide a keyword query or partial title — the skill searches and presents candidates:

```
/paper_reader "LLM gene regulatory network attention"
/paper_reader "attention sparse single-cell"
```

Search order (by speed and relevance):
1. Semantic Scholar (broad, fast, cross-domain)
2. arXiv API (CS/AI focus)
3. PubMed (biology, peer-reviewed)
4. bioRxiv API (biology preprints)
5. WebSearch fallback (catches everything else)

Presents top 3-5 matches for user selection.

### Layer 3: Graph Traversal (从已知论文出发)

Starting from a paper already in your library, find related papers:

```
/paper_reader --forward 2024_ma_scgpt       # Papers that cite scGPT
/paper_reader --backward 2024_ma_scgpt      # Papers that scGPT cites
/paper_reader --cocite 2024_ma_scgpt        # Papers sharing citations
```

Uses Semantic Scholar graph API for traversal. See `references/sources_guide.md` Layer 3 section.

### Source Coverage Summary

| Source | Best for |
|---|---|
| **arXiv** | CS/AI/ML papers (daily scan) |
| **bioRxiv** | Biology preprints (genomics, scRNA-seq, bioinformatics) |
| **PubMed/PMC** | Peer-reviewed biology and medical literature |
| **Papers with Code** | Finding baseline code + benchmark leaderboards |
| **Semantic Scholar** | Cross-domain search, citation graph traversal |
| **OpenReview** | Conference papers + reading reviewer feedback |
| **chemRxiv** | Chemistry / drug design preprints |
| **Local PDF** | Offline papers, paywalled content you already have |

## Knowledge Base Layout

```
~/paper_library/
├── index.md                         # Master index (chronological + topic tags)
├── topics/                          # Topic-based organization
│   ├── single_cell_llm.md
│   ├── drug_design_agents.md
│   ├── virtual_cells.md
│   └── ...
├── papers/                          # Individual paper notes
│   ├── 2024_lotfollahi_scvi.md
│   ├── 2025_ma_scgpt.md
│   └── ...
├── insights/                        # Personal insight notes (cross-paper)
│   ├── rare_cell_identification.md
│   └── transformer_scale_saturation.md
├── connections/                     # Knowledge graph edges
│   └── connections.json             # Machine-readable graph
└── reading_log.md                   # Daily reading log (when/how long/what)
```

If `~/paper_library/` doesn't exist, Phase 0 offers to create it with a default structure.

## Workflow

### Phase 0: Input Parsing and 3-Minute Quick Read

Goal: Decide in 3 minutes whether this paper deserves deeper reading.

#### Step 0.1: Parse Input

Auto-detect input format (see "Input Formats" section above). For each format:

- **arXiv ID/URL**: Fetch via arXiv API (`export.arxiv.org/api/query?id_list={id}`); fall back to WebFetch
- **bioRxiv ID/URL**: Fetch via bioRxiv API (`api.biorxiv.org/details/biorxiv/{doi_suffix}`); fall back to WebFetch
- **PMID**: Fetch abstract via PubMed E-utilities (`eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id={pmid}&rettype=abstract`)
- **DOI**: Resolve via CrossRef (`api.crossref.org/works/{doi}`) to get source, then fetch from that source
- **OpenReview URL/ID**: Fetch via OpenReview API (`api.openreview.net/notes?id={id}`); optionally fetch reviews
- **Papers with Code URL**: Fetch paper metadata + code link via Papers with Code API
- **Local PDF**: Use Read tool to extract text; get first 2-3 pages
- **Keyword search**: Search Semantic Scholar first, then arXiv API, then PubMed, then bioRxiv; present top 3-5 matches → user selects
- **Paper title**: Same as keyword search, then disambiguate → fetch

See `references/sources_guide.md` for API endpoints, rate limits, and graceful degradation for each source.

Record in `reading_log.md`:
```
2026-04-11 14:32 — Started reading: {title} ({arxiv_id or ref})
```

#### Step 0.2: 3-Minute Quick Read

Extract from the paper:
1. **Title & Authors**: Full title, author list (up to 3 + et al.), year
2. **Venue**: arXiv, NeurIPS 2024, Nature Methods 2025, etc.
3. **Problem**: What biological/technical problem does the paper address? (1-2 sentences)
4. **Method skeleton**: What kind of approach? (1 sentence naming the technique family)
5. **Key finding**: The one most important result (1 sentence with a number)
6. **Relevance to me**: Why does this matter for my research? (1-3 sentences)

**Sources** (in priority order):
- Abstract (must read)
- Introduction first paragraph (often restates the finding)
- Main result table (look for bolded numbers)
- Conclusion first sentence (often a restatement)

**Relevance scoring** (1-5):
- 5: Directly relevant to my current project — must read deeply
- 4: Adjacent to my current project — deep read recommended
- 3: Relevant to my broader research interests — add to library, deep read optional
- 2: Tangentially interesting — quick note only
- 1: Not relevant — skip (don't even save)

#### Step 0.3: Interactive Decision (Full Mode)

Present to user:
```
> 📄 Paper: {title}
> 📅 {year} | {venue}
> 👥 {authors}
>
> 🎯 Problem: {1-2 sentences}
> 🔧 Method: {1 sentence}
> 📊 Key finding: {1 sentence with number}
>
> 💡 Relevance to your research: {1-3 sentences}
> ⭐ Relevance score: {1-5}
>
> 下一步:
>   (A) 深度阅读（Phase 1-4 全流程，~15 分钟）
>   (B) 快速存档（只保存 3-min 笔记到 library）
>   (C) 跳过（不保存）
>   (D) 先看更多细节再决定
```

Express mode: Auto-decide based on relevance score:
- Score 5 → deep read (Phase 1-4)
- Score 3-4 → quick archive
- Score 1-2 → skip

### Phase 1: Deep Analysis

Only executed if user selected (A) or if express mode + score 5.

Read `references/reading_patterns.md` for detailed patterns by paper type. The 5 sections to extract:

#### Section 1: Problem and Motivation
- Exact problem definition
- Why existing methods are insufficient
- What would success look like

#### Section 2: Method
- Core technical idea (the "trick")
- Formal formulation if present
- Architecture / pipeline
- Key design choices and their rationale
- **What's new?** — Distinguish from prior work

Handle different paper types:
- **Method paper**: Focus on the technical innovation
- **Empirical study**: Focus on the findings and how they challenge existing beliefs
- **Theoretical paper**: Focus on the theorems, proofs, implications
- **Survey/Position paper**: Focus on the taxonomy and open problems
- **Dataset/Benchmark paper**: Focus on the data and evaluation protocol

Use the appropriate template from `references/reading_patterns.md`.

#### Section 3: Experiments
- Datasets used (with versions)
- Baselines compared (fair comparison check)
- Primary metric and its value
- Statistical significance (if reported)
- Ablation findings (which components matter)
- Failure modes (if discussed)

#### Section 4: Limitations and Open Questions
- Explicit limitations (author-acknowledged)
- Implicit limitations (your critical reading)
- What questions remain unanswered
- What would you do differently

#### Section 5: Related Work
- Which prior papers does this build on? (top 5)
- What does this NOT cite that it should? (if you notice)

### Phase 2: Knowledge Base Linking

Connect this paper to existing library entries. Read `references/knowledge_linking.md` for the
linking taxonomy.

#### Step 2.1: Find Related Papers in Your Library

Scan `~/paper_library/papers/` for papers with related topics:
- Keyword overlap (use the paper's own keywords + your knowledge)
- Citation overlap (papers cited by both)
- Topic tag overlap (papers with shared topic tags)

Present candidates to user:
```
> 知识库中可能相关的论文:
>   1. 2024 Lotfollahi scVI — 同为 VAE-based 方法
>   2. 2025 Ma scGPT — 同样用 transformer 做 cell typing
>   3. 2024 Yang KnowledgeGraphNN — 同样用 GRN prior
>
> 选择要建立连接的论文（可多选）：
```

#### Step 2.2: Classify the Relationship

For each connection, classify as one of:
- **Extends**: This paper directly builds on that one
- **Contrasts**: This paper takes an opposite approach
- **Complements**: This paper solves a related but different problem
- **Supersedes**: This paper replaces that one with a better approach
- **Validates**: This paper's experiments confirm that one's theory
- **Inspired by**: This paper's idea came from that one's insight

#### Step 2.3: Write Connection Notes

For each connection, add a short note explaining the relationship:
```
2024_new_paper.md ↔ 2024_lotfollahi_scvi.md
  Relationship: Extends
  Note: "This paper uses Lotfollahi's conditional VAE architecture as backbone,
         but replaces the attention mechanism with a GRN-guided one. Result: 8%
         improvement on rare cell types. The core contribution is compatible
         with the scVI framework."
```

Update `connections.json` (the machine-readable graph).

### Phase 3: Personal Insight Notes

Write notes that are specifically about what this paper means for **your** work.

#### Step 3.1: Project Relevance

For each of your active projects (read from `~/paper_library/index.md` or ask user):
- Does this paper change my approach? How?
- Is there a baseline to compare against?
- Is there a dataset to use?
- Is there a technique to borrow?
- Does this validate or refute one of my hypotheses?

#### Step 3.2: Idea Triggers

Does this paper suggest a new research idea? If yes:
- Describe the idea in 1 paragraph
- Note what's different from the current paper
- Flag for `idea_library` intake

**Cross-skill integration**: If an idea is triggered, suggest to the user:
```
> 这篇论文触发了一个新想法：{brief}
> 要保存到 idea_library 吗？(y/n)
> (选择 y 后会交由 idea_library skill 处理)
```

#### Step 3.3: Future Reference

Tag this paper for future situations:
- "Cite when writing about rare cell types"
- "Use as baseline for GRN-guided methods"
- "Reference for single-cell transformer scaling behavior"

These tags help when you later write papers or prepare discussions.

#### Step 3.4: Write Insight Note

Save as `~/paper_library/insights/{topic}_{date}.md` or append to an existing topic insight file.

### Phase 4: Index Update

Update the library's index files to make the new paper findable.

#### Step 4.1: Paper Note File

Save as `~/paper_library/papers/{year}_{first_author}_{keyword}.md`:

```markdown
---
title: {full title}
authors: [...]
year: {year}
venue: {venue}
arxiv_id: {id}
doi: {doi}
date_added: {YYYY-MM-DD}
relevance_score: {1-5}
topics: [topic1, topic2, topic3]
tags: [tag1, tag2, tag3]
---

# {Short Title}

## 一句话概括 (One-Line Summary)
{one sentence capturing the main contribution}

## 问题 (Problem)
{1-2 paragraphs}

## 方法 (Method)
{2-3 paragraphs describing the core technique}

## 关键发现 (Key Findings)
- {Finding 1 with number}
- {Finding 2 with number}
- {Finding 3 with number}

## 实验 (Experiments)
- **Datasets**: {...}
- **Baselines**: {...}
- **Main metric**: {...}
- **Result**: {...}

## 局限性 (Limitations)
- {Explicit limitation 1}
- {Explicit limitation 2}
- {Your critical observation}

## 与我的工作的关系 (Relevance to My Work)
{3-5 sentences on why this matters for my research}

## 相关论文 (Related Papers in My Library)
- [2024_lotfollahi_scvi.md] — Extends
- [2025_ma_scgpt.md] — Contrasts
- ...

## 可能的用途 (Potential Uses)
- [ ] Cite as baseline in {project}
- [ ] Reference for {topic}
- [ ] Compare against in future experiments
- [ ] Adapt technique for {other task}

## Idea 触发 (Idea Triggers)
{if any ideas came from reading this, describe them briefly — detailed ones go to idea_library}

## 原文链接 (Source Link)
{arXiv URL or DOI}

## 阅读时长
- Quick read: {minutes}
- Deep read: {minutes}
- Total: {minutes}
```

#### Step 4.2: Topic File Update

If the paper's topics include one of your tracked topics, append to the topic file at
`~/paper_library/topics/{topic}.md`:

```markdown
## 2024_new_paper_short_title (added 2026-04-11)
- **Key finding**: {1 sentence}
- **Why it matters for this topic**: {1-2 sentences}
- **Link**: [papers/2024_new_paper.md]
```

Sort topic files chronologically (newest first) within sections.

#### Step 4.3: Master Index Update

Append to `~/paper_library/index.md`:

```markdown
- **2026-04-11**: [2024_new_paper_short_title](papers/2024_new_paper.md) — {one-line summary}, relevance ⭐{score}, topics: {topic1}, {topic2}
```

#### Step 4.4: Reading Log Update

Append to `~/paper_library/reading_log.md`:

```markdown
## 2026-04-11 14:32 – 14:47 (15 min)
- Paper: {title}
- Depth: Deep read
- Key takeaway: {one sentence}
- Triggered ideas: 1 (logged to idea_library)
- Library connections: 3 new
```

### Phase 5: Summary and Next Actions

Present to user:
```
> ✅ 论文已加入知识库:
>   📁 papers/{filename}.md
>
> 📊 统计:
>   - 相关度: {score}/5
>   - 知识库连接: {N} 个新 edge
>   - 触发想法: {M} 个
>   - 阅读耗时: {minutes} 分钟
>
> 📌 推荐后续行动:
>   (A) 阅读相关论文: {list of 2-3 next papers to read}
>   (B) 保存 idea 到 idea_library: {brief}
>   (C) 今天阅读结束，生成阅读总结
>   (D) 继续读下一篇
```

---

## Interaction Modes

### Full Interactive Mode (Default)

Pauses at:
- Phase 0 Step 0.3 — Relevance decision (Deep read / Archive / Skip)
- Phase 1 — Optionally pause mid-deep-read for user notes
- Phase 2 Step 2.1 — Connection candidate selection
- Phase 3 Step 3.2 — Idea save-to-idea_library confirmation
- Phase 5 — Next action selection

### Express Mode

Auto-decides based on relevance score:
- Score 5 → Full Phase 0-4, summary at Phase 5
- Score 3-4 → Phase 0 + Phase 4 only (quick archive with basic note)
- Score 1-2 → Skip entirely (paper not saved)

Useful for daily arXiv scanning: feed 30 papers, get 5 relevant ones auto-archived.

---

## Daily Workflow Suggestions

### Morning arXiv Scan (express mode)

```
/paper_reader --express
> 提供一批 IDs（今天要扫描的）:
你回答: "2404.01234, 2404.02345, 2404.03456, ..."
```

Skill processes each one, auto-archives relevant ones, skips irrelevant ones. Reading log
at `~/paper_library/reading_log.md` tracks the day's reading.

### Morning bioRxiv Scan (biology preprints)

```
/paper_reader --express --source biorxiv --date today
```

Skill fetches today's bioRxiv papers in bioinformatics/genomics categories, processes them
in batch express mode. Useful for tracking biology-side literature alongside arXiv CS papers.

### Deep-Dive Session (full mode)

```
/paper_reader 2404.01234          # arXiv
/paper_reader PMID:12345678       # PubMed peer-reviewed paper
/paper_reader 2024.03.15.585XXX   # bioRxiv preprint
```

One paper, full treatment. 15-30 minutes of structured reading, comprehensive notes.

### Baseline Search (Papers with Code mode)

```
/paper_reader --baseline "sparse attention cell typing"
```

Searches Papers with Code for implementations. Returns papers ranked by code quality and
GitHub stars. Useful when you need to find implementations to compare against.

### Citation Traversal (from known paper)

```
/paper_reader --forward 2024_ma_scgpt    # Who cited scGPT recently?
/paper_reader --backward 2024_ma_scgpt  # What did scGPT build on?
```

Uses Semantic Scholar citation graph. Returns papers sorted by year (forward) or citation
count (backward). Good for finding the "what came after" and "what inspired this" papers.

### Literature Search (keyword mode)

```
/paper_reader "LLM gene regulatory network attention"
```

Skill searches Semantic Scholar, arXiv, PubMed, and bioRxiv; finds top 5 matching papers
across all sources, lets you pick, then processes.

### OpenReview Conference Paper (with reviews)

```
/paper_reader https://openreview.net/forum?id=XXXX
```

Fetches paper + optionally reads the peer review comments. Useful for understanding what
the community found important or problematic in a paper. See `references/sources_guide.md`
for details on reading review summaries.

---

## Integration with Other Skills

### With `idea_library`

When Phase 3 detects an idea trigger, the skill offers to hand off to `idea_library`:
```
> 这篇论文让你想到:
> "如果把 GRN structure 作为 sparse attention 的 mask，可能在 rare cell 识别上有效"
>
> 保存到 idea_library? (y/n)
```

If yes, the skill creates an entry in `~/idea_library/` with a link back to the source paper.

### With `research_copilot`

When starting a new project, `research_copilot` can read from your `~/paper_library/` to
bootstrap the literature survey. This saves hours of WebSearch — you already have a curated
collection.

Usage: `research_copilot --from-paper-library` (future integration)

### With `paper_polish_conf` / `paper_polish_journal`

When writing related work, the polish skills can reference your library to check:
- "Did we cite all the papers we should?"
- "Are any important related papers missing?"

---

## Important Notes

- **Persistent knowledge base**: `~/paper_library/` is the core asset. It accumulates over time
  and becomes more valuable. Back it up (it's just markdown — use git).
- **Don't read every paper deeply**. Most papers deserve a 3-minute quick read; a few deserve
  15+ minutes. The relevance score helps you decide.
- **Notes should be useful to future-you**. Write for the you-of-6-months-from-now who has
  forgotten everything.
- **Insights are the real value**. The insight notes in `~/paper_library/insights/` are where
  you synthesize multiple papers into one coherent understanding. These are gold.
- **Language convention**: Notes in Chinese for personal use; paper titles, authors, technical
  terms kept in English for searchability.
- **Reading is non-linear**. It's fine to re-read a paper months later and update the note.
  Git tracks the history.
- **Don't over-engineer the knowledge graph**. Simple markdown links are enough. The
  `connections.json` is an optional machine-readable layer, not the source of truth.
- **Daily cadence matters**. Reading 3 papers a day, 5 days a week = 750+ papers a year. Over
  3 years, that's a deep personal library.
