# Note Templates

Structured templates for paper notes, insights, and indices. Used by Phase 4 of
`paper_reader/SKILL.md`.

## Paper Note Template (Full)

Used for Phase 1 deep reads. Save as `~/paper_library/papers/{year}_{first_author}_{keyword}.md`.

```markdown
---
title: "{Full paper title}"
authors: [{Author 1}, {Author 2}, ..., et al.]
year: {YYYY}
venue: "{arXiv | NeurIPS 2024 | Nature Methods 2025 | ...}"
arxiv_id: "{2403.12345}"
doi: "{10.xxx/yyy}"
date_added: "{YYYY-MM-DD}"
relevance_score: {1-5}
topics: [{topic1}, {topic2}, {topic3}]
tags: [{tag1}, {tag2}, {tag3}]
---

# {Short Title}

## 一句话概括 (One-Line Summary)
{The one most important sentence capturing the main contribution.}

## 问题 (Problem)
### 研究问题
{What specific question does this paper address?}

### 现有方法的局限
{What do existing methods fail to do?}

### 为什么重要
{Why does this problem matter?}

## 方法 (Method)
### 核心思想
{The one technical idea in 2-3 sentences.}

### 架构/算法
{2-4 paragraphs describing the method in enough detail to understand it.}

### 训练过程
{Training data, loss function, optimizer, hyperparameters. Only if relevant.}

### 与已有方法的区别
{What exactly is novel? Distinguish from closest prior work.}

## 关键发现 (Key Findings)
1. **{Finding 1 with number}**: {brief}
2. **{Finding 2 with number}**: {brief}
3. **{Finding 3 with number}**: {brief}

## 实验 (Experiments)

### 设置
- **Datasets**: {list with sizes}
- **Baselines**: {list}
- **Metrics**: {list}
- **Hardware**: {if relevant}
- **Code**: {URL if available}

### 主要结果
| Method | Dataset 1 | Dataset 2 | Dataset 3 |
|---|:---:|:---:|:---:|
| Baseline 1 | X.X | X.X | X.X |
| Baseline 2 | X.X | X.X | X.X |
| Proposed | **X.X** | **X.X** | **X.X** |

{Commentary on the main results.}

### Ablation
{What ablations were done? What components matter?}

### 失败模式
{When does it break? What did they observe that doesn't work?}

## 局限性 (Limitations)

### 作者承认的
- {Explicit limitation 1}
- {Explicit limitation 2}

### 我的批判性观察
- {Your critical observation 1}
- {Your critical observation 2}
- {Things the authors didn't discuss but should have}

## 与我的工作的关系 (Relevance to My Work)
{3-5 sentences explaining why this paper matters for your research.}

### Project: {Current project name}
- {How this affects this project}
- {Whether to cite, borrow technique, compare against, etc.}

### Project: {Another project name} (if applicable)
- {How this affects another project}

## 相关论文 (Related Papers in My Library)
- [[{related_paper_1}]] — **{Relationship: Extends/Contrasts/Complements/etc.}**: {note}
- [[{related_paper_2}]] — **{Relationship}**: {note}
- [[{related_paper_3}]] — **{Relationship}**: {note}

## 可能的用途 (Potential Uses)
- [ ] Cite in {project} as {baseline / related work / motivation}
- [ ] Borrow {technique} for {project}
- [ ] Use {dataset} for future experiments
- [ ] Reference for {topic} discussions
- [ ] Challenge my assumption that {X}

## Idea 触发 (Idea Triggers)

### Idea 1: {brief title}
{1-2 paragraph description of the idea this paper sparked.}

**Differentiation**: {How is this different from the current paper?}
**Next step**: Save to idea_library (done: {yes/no})

## 有用的引用 (Useful Quotes)
> "{Direct quote that is memorable or important}"
> — p. X

{Another useful quote}

## 原文链接 (Source Link)
- **arXiv**: {URL}
- **DOI**: {URL}
- **Code**: {URL or "not available"}
- **PDF in local cache**: {path if saved locally}

## 阅读记录 (Reading Record)
- **Quick read**: {minutes} minutes on {YYYY-MM-DD}
- **Deep read**: {minutes} minutes on {YYYY-MM-DD}
- **Re-read**: {date, reason}
```

## Paper Note Template (Quick Archive)

Used for Phase 0 papers that score 3-4 (quick archive without deep read). Shorter version.

```markdown
---
title: "{Full paper title}"
authors: [{First author et al.}]
year: {YYYY}
venue: "{venue}"
arxiv_id: "{id}"
date_added: "{YYYY-MM-DD}"
relevance_score: {3 or 4}
topics: [{topic1}, {topic2}]
tags: [{tag1}]
read_depth: quick_archive
---

# {Short Title}

## 一句话概括
{One sentence.}

## 问题
{1-2 sentences.}

## 方法
{1-2 sentences.}

## 关键发现
{Main result with number, 1-2 sentences.}

## 相关度
**Score**: {3 or 4}/5
**为什么保存**: {1 sentence on why you kept it instead of skipping}

## 待决定
- [ ] 以后可能需要深度阅读
- [ ] 可能作为 baseline
- [ ] 可能作为 related work 引用

## 原文链接
{URL}
```

## Insight Note Template

Used for synthesizing multiple papers. Save as `~/paper_library/insights/{topic}.md`.

```markdown
---
topic: "{topic name}"
created: "{YYYY-MM-DD}"
last_updated: "{YYYY-MM-DD}"
related_papers: [
  {paper_1},
  {paper_2},
  ...
]
---

# Insight: {Topic Title}

## 核心洞见 (Core Insight)
{1-2 paragraphs summarizing what you've learned across the papers.}

## 支持证据 (Supporting Evidence)

### From [[{paper_1}]]
{What this paper contributes to the insight.}

### From [[{paper_2}]]
{What this paper contributes.}

### From [[{paper_3}]]
{What this paper contributes.}

## 矛盾和争议 (Contradictions and Debates)
{Where do papers disagree? What's unresolved?}

## 开放问题 (Open Questions)
1. {Question 1}
2. {Question 2}
3. {Question 3}

## 对我的研究的含义 (Implications for My Research)
{How does this insight shape your projects and future work?}

## 相关 Idea (Related Ideas in idea_library)
- [[idea_1]]: {brief}
- [[idea_2]]: {brief}

## 更新日志 (Update Log)
- **{YYYY-MM-DD}**: Initial note
- **{YYYY-MM-DD}**: Added paper {X}, updated insight
- **{YYYY-MM-DD}**: Revised after reading {Y}
```

## Topic Index Template

Used for topic-based organization. Save as `~/paper_library/topics/{topic}.md`.

```markdown
---
topic: "{topic name}"
description: "{1-sentence description}"
created: "{YYYY-MM-DD}"
last_updated: "{YYYY-MM-DD}"
---

# Topic: {Topic Name}

{1 paragraph describing the topic and what you're tracking.}

## Foundational Papers
- **[[{paper_1}]]** ({year}) — {1 sentence on why it's foundational}
- **[[{paper_2}]]** ({year}) — {...}

## Recent Advances (Last 12 Months)
- **[[{paper_3}]]** ({year_month}) — {1 sentence finding}
- **[[{paper_4}]]** ({year_month}) — {...}

## Debates and Open Problems
- {Debate 1}: [[{paper_A}]] argues X; [[{paper_B}]] argues not-X
- {Open problem 1}: no paper has addressed this yet

## Key Datasets
- {Dataset 1}: Used by [[{paper_X}]], [[{paper_Y}]]
- {Dataset 2}: Used by [[{paper_Z}]]

## Connection to Other Topics
- [[topic_1]] — {relationship}
- [[topic_2]] — {relationship}

## My Projects in This Topic
- {project_1}: {status}
- {project_2}: {status}

## Ideas in This Topic (idea_library)
- [[idea_1]]
- [[idea_2]]
```

## Master Index Template

The main `~/paper_library/index.md` file tracks all papers chronologically.

```markdown
# Paper Library Index

Last updated: {YYYY-MM-DD}
Total papers: {N}
Topics: {list of topics}

## Recent Reads ({month})

- **{YYYY-MM-DD}**: [[{paper}]] — {one-line summary} ⭐{score} [{topic1}, {topic2}]
- **{YYYY-MM-DD}**: [[{paper}]] — {...} ⭐{score}

## Topics
- [[topics/topic_1.md|Topic 1]] ({N} papers)
- [[topics/topic_2.md|Topic 2]] ({M} papers)
- ...

## Insights
- [[insights/topic_a.md|Topic A Insight]]
- [[insights/topic_b.md|Topic B Insight]]
- ...

## Statistics
- Papers read this month: {N}
- Papers read this year: {N}
- Average papers per week: {N}
- Topics covered: {N}
```

## Reading Log Template

Daily log of reading activity. Save as `~/paper_library/reading_log.md`.

```markdown
# Reading Log

## {YYYY-MM} (Month)

### Week of {YYYY-MM-DD}

#### {YYYY-MM-DD} (Monday)
- **Morning scan** (20 min)
  - Scanned 15 arXiv papers
  - Quick archived 3: [[{paper_a}]], [[{paper_b}]], [[{paper_c}]]
  - Skipped 12
- **Deep read** (45 min)
  - [[{paper_d}]] — relevance 5
  - Triggered 1 idea → idea_library
  - Found 3 library connections

#### {YYYY-MM-DD} (Tuesday)
- **Deep read** (20 min)
  - [[{paper_e}]] — relevance 4
- **Review** (15 min)
  - Updated topic [[topics/single_cell_llm]]
  - Added insight [[insights/rare_cell_detection]]

## Weekly Summary

### Week of {YYYY-MM-DD}
- Papers read: 5 (3 quick, 2 deep)
- Ideas triggered: 2
- Insights updated: 1
- Topics expanded: 1

## Monthly Summary

### {Month Year}
- Total papers: 28 (18 quick, 10 deep)
- Most active topics: {topic1, topic2}
- Key insights: {1-sentence list}
- Standout papers: {top 3}
```

## Frontmatter Guidelines

Every paper note has YAML frontmatter. Fields:

- `title`: Full paper title (use `"..."` if contains colons or special chars)
- `authors`: List of authors (first author, then "et al." if >3)
- `year`: Publication year (YYYY)
- `venue`: Where published (arXiv, conference name + year, journal name + year)
- `arxiv_id`: If from arXiv
- `doi`: If assigned
- `date_added`: When you added to your library (YYYY-MM-DD)
- `relevance_score`: Your score (1-5)
- `topics`: List of topic tags (match `~/paper_library/topics/` file names)
- `tags`: Free-form tags (e.g., `transformer`, `rare-cell`, `benchmark`)
- `read_depth`: `quick_archive` or `deep_read`
- (Optional) `project_relevance`: List of project names this applies to

## Naming Conventions

### Paper Note Filenames

Format: `{year}_{first_author_lowercase}_{keyword}.md`

Examples:
- `2024_lotfollahi_scvi.md`
- `2025_ma_scgpt.md`
- `2024_smith_transformer_cell_typing.md`

Rules:
- Year first (enables sorting)
- First author lowercase (search-friendly)
- 1-3 keywords that identify the paper
- No spaces (use underscores)
- Keep under 50 characters

### Topic Filenames

Format: `{topic_name_with_underscores}.md`

Examples:
- `single_cell_llm.md`
- `drug_design_agents.md`
- `virtual_cells.md`

Keep topic list manageable (10-20 topics).

### Insight Filenames

Format: `{topic}_{specific_insight}.md` or `{topic}.md` if general

Examples:
- `rare_cell_identification.md`
- `transformer_scale_saturation.md`
