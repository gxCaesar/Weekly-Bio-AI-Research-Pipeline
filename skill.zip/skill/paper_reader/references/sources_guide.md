# Paper Sources Guide

Comprehensive guide to paper source platforms supported by `paper_reader`. Covers access
patterns, identifier formats, metadata field mapping, rate limits, and graceful degradation
for each source.

## Source Tier Overview

| Tier | Sources | Coverage |
|------|---------|----------|
| **Tier 1 (Required)** | arXiv, bioRxiv, PubMed/PMC | Primary CS+AI and biology preprint/literature |
| **Tier 2 (Recommended)** | Papers with Code, Semantic Scholar, OpenReview | Supplementary metadata and peer review |
| **Tier 3 (Supplementary)** | chemRxiv, CrossRef (DOI) | Chemistry + broad DOI resolution |

---

## 3-Layer Input Architecture

When the user provides a paper reference, the skill resolves it in 3 layers:

### Layer 1: Direct Fetch (知道 ID/URL)

The user provides a specific identifier. Skill fetches directly without search.

**Identifiers by source**:
- arXiv: `2403.12345`, `arXiv:2403.12345`, `https://arxiv.org/abs/2403.12345`
- bioRxiv: `2024.03.15.585XXX` or `https://www.biorxiv.org/content/10.1101/XXXX`
- PubMed: `PMID:12345678` or `12345678` (8-digit number)
- PMC: `PMC12345678`
- DOI: `10.1038/s41592-024-XXXX-X` (any source)
- OpenReview: `https://openreview.net/forum?id=XXXX` or just the ID `XXXX`
- Papers with Code: URL `https://paperswithcode.com/paper/XXXX` or paper slug

**Auto-detection logic**:
1. If string matches `^\d{4}\.\d{4,5}` → arXiv ID
2. If starts with `10\.` → DOI → use CrossRef to resolve source
3. If 8 digits → PMID → PubMed fetch
4. If starts with `PMC` → PMC fetch
5. If `bioRxiv` or `biorxiv.org` in string → bioRxiv
6. If `openreview.net` in string → OpenReview
7. If `http(s)://arxiv.org` → arXiv URL
8. Otherwise → try Layer 2 (search)

### Layer 2: Search (不知道 ID, 知道关键词/标题)

The user provides a title or keywords. Skill searches multiple sources and presents candidates.

**Search order** (by return speed and relevance):
1. Semantic Scholar (unauthenticated) — fast, broad coverage, good title search
2. arXiv API — fast, covers CS/AI/ML/Stat
3. PubMed E-utilities — slower but authoritative for biology
4. bioRxiv API — for preprints not yet on arXiv
5. WebSearch (fallback) — catches everything else

**Candidate presentation**:
```
> 搜索 "{query}" 找到以下候选论文:
>   1. [arXiv 2403.12345] Title A — Authors — Year
>   2. [bioRxiv 2024.03.xx] Title B — Authors — Year
>   3. [PMID 12345678] Title C — Authors — Year
>
> 请选择 (1/2/3) 或输入更多关键词缩小范围:
```

### Layer 3: Graph Traversal (从已知论文出发)

The user has already read a paper and wants to find related papers via citation/reference graph.

**Traversal options**:
- **Forward**: Papers that cite the seed paper (who built on this)
- **Backward**: Papers cited by the seed paper (what this builds on)
- **Co-citation**: Papers that share citations with the seed paper (related work)

**Sources for graph data**:
- Semantic Scholar `/graph/v1/paper/{id}/citations` and `/references`
- arXiv "Related Papers" (from abstract similarity)

**Use case**: "I finished reading scGPT. Show me 5 papers that recently cited it."

---

## Source Details

### arXiv

**Coverage**: CS, AI/ML, Statistics, Quantitative Biology, Physics, Math
**Preprint**: Yes (not peer-reviewed unless stated)
**Access**: Fully open, no authentication required
**Rate limit**: 3 requests/second for the API; 1 request/second is safe

**Fetch via API**:
```
Base URL: http://export.arxiv.org/api/query
Example:  http://export.arxiv.org/api/query?id_list=2403.12345
Returns:  Atom XML
```

**Fetch via WebFetch** (alternative):
```
https://arxiv.org/abs/{arxiv_id}   → HTML abstract page
https://arxiv.org/pdf/{arxiv_id}   → PDF (large, prefer API for metadata)
```

**Key metadata fields → paper_library frontmatter mapping**:

| arXiv field | paper_library field |
|-------------|---------------------|
| `entry.title` | `title` |
| `entry.author[*].name` | `authors` |
| `entry.published` (year) | `year` |
| "arXiv {year}" | `venue` |
| `entry.id` (last segment) | `arxiv_id` |
| `entry.summary` | abstract (for quick read) |
| `entry.link[@type="pdf"]` | pdf_url (optional) |

**Graceful degradation**: If arXiv API is unavailable, fall back to `WebFetch` on the abstract page and parse HTML.

---

### bioRxiv

**Coverage**: Biology, Biomedical Sciences, Biochemistry, Neuroscience, Genomics
**Preprint**: Yes (primary biology preprint server; some papers later peer-reviewed)
**Access**: Fully open, no authentication required
**Rate limit**: 10 requests/second; 1-2 requests/second is safe

**Fetch via API**:
```
Base URL: https://api.biorxiv.org/details/biorxiv/{doi_suffix}
Example:  https://api.biorxiv.org/details/biorxiv/2024.03.15.585XXX/na/json
Returns:  JSON

For date-range scans:
          https://api.biorxiv.org/details/biorxiv/{start}/{end}/0/json
Example:  https://api.biorxiv.org/details/biorxiv/2026-04-01/2026-04-11/0/json
```

**Also works** for medRxiv (medical preprints) by replacing `biorxiv` with `medrxiv` in the URL.

**Key metadata fields → paper_library frontmatter mapping**:

| bioRxiv API field | paper_library field |
|-------------------|---------------------|
| `collection[0].title` | `title` |
| `collection[0].authors` | `authors` |
| `collection[0].date` (year) | `year` |
| "bioRxiv {year}" | `venue` |
| `collection[0].doi` | `doi` |
| `collection[0].abstract` | abstract |
| `collection[0].category` | topics (partial) |
| `collection[0].published` (journal DOI if peer-reviewed) | peer_review_status |

**Important**: bioRxiv papers may have a corresponding published journal article. Check the
`published` field — if it contains a journal DOI, note it in the paper note and use the
journal version as the canonical reference.

**Graceful degradation**: If the API returns no data, use `WebFetch` on the bioRxiv paper URL
and parse the abstract from the HTML.

---

### PubMed / PMC (NCBI E-utilities)

**Coverage**: All peer-reviewed biomedical and life sciences literature (25M+ articles)
**Preprint**: No — peer-reviewed only
**Access**: Open for most content; some full-text articles require institutional access
**Authentication**: Not required (unauthenticated) but NCBI recommends registering an API key
  for higher rate limits (10 requests/sec vs 3/sec). Registration: https://www.ncbi.nlm.nih.gov/account/
**Rate limit**: 3 requests/sec (unauthenticated); 10 requests/sec (with API key)

**Note**: Use unauthenticated access by default (user likely has not registered). If rate-limit
errors are encountered, suggest the user register a free API key.

**Fetch via E-utilities (metadata)**:
```
Base URL: https://eutils.ncbi.nlm.nih.gov/entrez/eutils/
Summary:  esummary.fcgi?db=pubmed&id={pmid}&retmode=json
Full XML: efetch.fcgi?db=pubmed&id={pmid}&rettype=xml&retmode=xml
Search:   esearch.fcgi?db=pubmed&term={query}&retmode=json&retmax=10
```

**Fetch abstract** (lightweight):
```
https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id={pmid}&rettype=abstract&retmode=text
```

**Key metadata fields → paper_library frontmatter mapping**:

| PubMed field | paper_library field |
|--------------|---------------------|
| `result[pmid].title` | `title` |
| `result[pmid].authors[*].name` | `authors` |
| `result[pmid].pubdate` (year) | `year` |
| `result[pmid].source` | `venue` (journal name) |
| `result[pmid].uid` → `PMID:{uid}` | `doi` (use PMID as identifier if no DOI) |
| `result[pmid].doi` | `doi` |
| abstract from efetch | abstract |
| `result[pmid].pubtype` | type hint |

**PMC full text** (when available):
```
https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pmc&id={pmcid}&rettype=xml
```
Not all articles are in PMC. Use PMC only when the full text is needed (rare in paper_reader).

**Graceful degradation**: PubMed is the authoritative source for peer-reviewed bio literature.
If E-utilities are unavailable, use `WebFetch` on `https://pubmed.ncbi.nlm.nih.gov/{pmid}/`.
If the paper has a DOI, fall through to CrossRef for basic metadata.

---

### Papers with Code

**Coverage**: ML/AI/CS papers with associated code repositories (GitHub)
**Preprint**: Often links to arXiv papers + code; sometimes links to peer-reviewed papers
**Access**: Open API, no authentication required
**Rate limit**: Undocumented; treat as 5 requests/sec to be safe
**Primary value**: Linking paper → code → dataset; finding baselines with existing implementations

**Fetch via API**:
```
Base URL: https://paperswithcode.com/api/v1/
By paper: https://paperswithcode.com/api/v1/papers/?title={title}
By arXiv: https://paperswithcode.com/api/v1/papers/?arxiv_id={arxiv_id}
Results:  https://paperswithcode.com/api/v1/results/?paper_id={id}  ← benchmark results
Code:     https://paperswithcode.com/api/v1/repositories/?paper_id={id}
```

**Key metadata → paper_library frontmatter + note mapping**:

| Papers with Code field | paper_library field |
|------------------------|---------------------|
| `results.tasks[*].task_name` | topics (task names) |
| `repositories[*].url` | `code_url` (optional) |
| `repositories[*].stars` | code_stars (optional) |
| `results[*].dataset`, `result[*].metric` | benchmark results table |

**When to use**: Check Papers with Code when:
- You need to add baselines to a project (find implementations)
- You want to see if your method's task has a known leaderboard
- You want code for a paper you just read

**Note**: Papers with Code is supplementary to other sources, not a primary identifier.
If a paper is on Papers with Code, it's also on arXiv or another source that provides
full metadata. Use Papers with Code for the code/results supplement, not for primary fetch.

**Graceful degradation**: If the API is unavailable, use `WebSearch` for
`"{paper title}" site:paperswithcode.com`.

---

### Semantic Scholar

**Coverage**: 220M+ papers across all disciplines (broad cross-domain coverage)
**Preprint**: Yes — indexes arXiv, bioRxiv, and peer-reviewed simultaneously
**Access**: Open API, unauthenticated access available
**Authentication**: Optional partner API key for higher rate limits
  (100 requests/sec vs 10/sec). Registration not assumed.
**Rate limit**: 10 requests/sec (unauthenticated, per IP); safer to use 1-2/sec
**Primary value**: Citation graph traversal, semantic paper search, cross-domain coverage

**Fetch via API**:
```
Base URL: https://api.semanticscholar.org/graph/v1/
By ID:    /paper/{paperId}?fields=title,authors,year,venue,abstract,externalIds
By arXiv: /paper/arXiv:{arxiv_id}?fields=...
Search:   /paper/search?query={query}&fields=...&limit=10
Citations: /paper/{paperId}/citations?fields=...&limit=20
Refs:     /paper/{paperId}/references?fields=...&limit=20
```

**Key metadata fields**:

| Semantic Scholar field | paper_library field |
|------------------------|---------------------|
| `title` | `title` |
| `authors[*].name` | `authors` |
| `year` | `year` |
| `venue` | `venue` |
| `externalIds.ArXiv` | `arxiv_id` |
| `externalIds.DOI` | `doi` |
| `externalIds.PubMed` | (link to PubMed) |
| `abstract` | abstract |

**Primary uses for paper_reader**:
1. **Search**: Fast, semantically-aware keyword search → find paper by topic
2. **Citation graph**: For Layer 3 traversal (who cites this paper)
3. **Cross-domain**: One search hits CS + biology + chemistry simultaneously
4. **Novelty verification (idea_library)**: Check if similar ideas have been published

**Usage in novelty verification (idea_library Phase 1)**:
The Semantic Scholar search API is well-suited for checking broad prior art because:
- It indexes both arXiv (ML papers) and PubMed (bio papers) in one query
- Semantic similarity ranking surfaces conceptually related papers even with different terminology
- No authentication needed for reasonable novelty check volume

**Graceful degradation**: If API rate-limit hit (429 response), wait 10 seconds and retry once.
If still unavailable, fall back to `WebSearch` for `"{query}" site:semanticscholar.org`.

---

### OpenReview

**Coverage**: Papers submitted to conferences using OpenReview (ICLR, NeurIPS, ICML, UAI,
EMNLP, COLM, and others). Includes reviews, decisions, and discussion threads.
**Preprint**: No — conference submissions (some rejected; some only shown after decision)
**Access**: Open API for public venues; some venues restrict pre-decision access
**Authentication**: Not required for reading public data
**Rate limit**: Be conservative; treat as 5 requests/sec

**Fetch via API**:
```
Base URL: https://api.openreview.net/
By ID:    /notes?id={submission_id}
By forum: /notes?forum={forum_id}
Reviews:  /notes?forum={forum_id}&details=replyCount
Search:   /notes?content.title={title}&details=replyCount
Venue:    /notes?invitation={venue_invitation_string}
```

**Key metadata fields → paper_library frontmatter mapping**:

| OpenReview field | paper_library field |
|------------------|---------------------|
| `content.title.value` | `title` |
| `content.authors.value` | `authors` |
| `cdate` (year) | `year` |
| venue invitation string | `venue` |
| `content.abstract.value` | abstract |
| `content.keywords.value` | topics/tags |
| reviews from replies | (append to paper note as review summary) |

**When to use OpenReview**:
1. You want to learn **why a paper was accepted/rejected** (reviewer comments)
2. You are studying **rebuttal writing** patterns (see `rebuttal_plan`)
3. You want to find accepted papers at a specific venue (e.g., all ICLR 2025 papers)
4. You want to check if a specific paper was submitted somewhere

**Review summary (valuable for paper_reader)**:
When deep-reading a conference paper, optionally fetch the acceptance reviews:
```
> 这篇论文在 {venue} 的审稿意见:
>   - Reviewer 1 (Score {X}): {key point 1}, {key point 2}
>   - Reviewer 2 (Score {Y}): 主要关切是 {concern}
>   - 接受原因: {AC comment if available}
>
> 审稿人认为最重要的贡献: {synthesis}
> 审稿人的主要顾虑: {synthesis}
```
This helps calibrate what aspects of a paper the research community values.

**Graceful degradation**: If a paper is not in OpenReview (most journal papers, pre-2013 conferences),
skip gracefully without error. OpenReview is purely supplementary.

---

### chemRxiv

**Coverage**: Chemistry and chemical biology preprints
**Preprint**: Yes
**Access**: Open via Figshare API
**Rate limit**: 5 requests/sec
**Relevance**: Supplementary for cross-disciplinary work (AI + chemistry/drug design)

**Fetch via API**:
```
Base URL: https://chemrxiv.org/engage/chemrxiv/public-api/v1/
Search:   /items?term={query}&limit=10
By DOI:   /items/doi/{doi_without_slash}  (replace / with %2F)
```

**Graceful degradation**: chemRxiv is tier 3 and rarely needed. If unavailable or unreachable,
note it and proceed without it.

---

### CrossRef (DOI Resolution)

**Coverage**: All academic publishers; resolves any DOI to metadata
**Access**: Open, no authentication (but provides an email as a courtesy)
**Rate limit**: Polite pool: 50 requests/sec; be safe with 5/sec
**Use case**: When you have a DOI and don't know which source to query

**Fetch via API**:
```
Base URL: https://api.crossref.org/works/
By DOI:   https://api.crossref.org/works/{doi}
Returns:  JSON with publisher, title, authors, year, venue, ISSN, etc.
```

**Workflow**: DOI → CrossRef → identify publisher/journal → decide if need full text from PMC or direct URL

---

## Source Selection by Research Context

| User context | Primary sources | Supplement |
|---|---|---|
| CS/AI/ML paper on arXiv | arXiv API | Semantic Scholar (graph), Papers with Code |
| Biology preprint (today's new work) | bioRxiv API | PubMed (if peer-reviewed) |
| Peer-reviewed biology paper | PubMed E-utilities | PMC (full text if needed) |
| Conference paper (ICLR/NeurIPS/ICML) | arXiv (preprint) | OpenReview (reviews) |
| Drug design / chemistry | bioRxiv or chemRxiv | PubMed |
| Cross-domain keyword search | Semantic Scholar | arXiv + bioRxiv |
| Baseline search (need code) | arXiv + Papers with Code | — |
| Citation traversal | Semantic Scholar | arXiv (for CS papers) |

---

## Field Normalization

All sources feed into the same `paper_library` frontmatter schema. When a field is
unavailable from a source, use the indicated fallback:

| paper_library field | Required? | Fallback when missing |
|---------------------|-----------|----------------------|
| `title` | Yes | — (fail if missing) |
| `authors` | Yes | `["Unknown"]` |
| `year` | Yes | Current year (warn user) |
| `venue` | Yes | Source name (e.g., "arXiv", "bioRxiv", "PubMed") |
| `arxiv_id` | If arXiv | null |
| `doi` | If available | null |
| `date_added` | Yes | Today |
| `relevance_score` | Yes | Assigned in Phase 0 |
| `topics` | Yes | `[]` (user fills manually) |
| `tags` | No | `[]` |

---

## Paywalled Content: Graceful Degradation

Some papers (especially from journals) are behind paywalls. `paper_reader` handles this
by degrading to what's available:

1. **Abstract available** (most paywalled papers): Proceed with abstract-only quick read.
   Note in the paper note that full text was not accessed.

2. **Preprint on arXiv/bioRxiv** (most CS and many bio papers): Use the preprint.
   Note in the paper note: "Preprint version; peer-reviewed at {venue}."

3. **PMC Open Access** (many NIH-funded papers): Check PMC for full text before giving up.

4. **No access**: Save the metadata + abstract only. Add a `full_text_status: "unavailable"`
   field to the frontmatter. Mark next-steps item: "Obtain full text via [library/ResearchGate/
   author request]."

**NEVER attempt to access pirated content.** If access is unavailable, work with the
abstract and note the limitation.

---

## Daily arXiv Scan — Recommended Source Strategy

For the daily paper scanning workflow (`/paper_reader --express`):

1. **arXiv** (CS/AI section): The canonical feed for ML/AI papers
   - cs.LG, cs.AI, cs.CL, cs.CV, stat.ML, q-bio.QM, q-bio.GN
   - arXiv API with `search_query=cat:cs.LG+AND+submittedDate:[{today}+TO+{today}]`

2. **bioRxiv** (bioinformatics section): For biology preprints
   - bioRxiv API with date range: `https://api.biorxiv.org/details/biorxiv/{yesterday}/{today}/0/json`
   - Filter by category: `bioinformatics`, `genomics`, `systems biology`

3. **Semantic Scholar** (optional daily digest): Subscribe to topic-based alerts via email
   (outside the skill — a manual step). When you find something interesting in your email,
   use paper_reader to read it.

---

## Notes on API Stability

APIs can change or be unavailable. If any API call fails:
1. Report the error to the user briefly: "arXiv API returned 503; falling back to WebFetch."
2. Fall back to the next tier (direct WebFetch on the paper page).
3. If all fallbacks fail, ask the user to provide the abstract manually.

Never let an API failure block the reading session. Paper reading is the primary goal;
source fetching is a means to that end.
