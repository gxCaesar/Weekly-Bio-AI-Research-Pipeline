# Paper Reading Patterns

Guide for reading different types of papers efficiently. Used by Phase 0 (quick read) and
Phase 1 (deep analysis) of `paper_reader/SKILL.md`.

## The Three-Pass Method (Adapted from S. Keshav)

### Pass 1: 3-Minute Quick Read (Phase 0)

**Goal**: Decide whether to read the paper deeply.

**What to read**:
1. **Title** — Sets expectations
2. **Abstract** — Read every sentence
3. **Introduction** — Read first paragraph only
4. **Main result/finding** — Skim for key numbers (usually in abstract, or first table)
5. **Conclusion first sentence** — Often restates the headline finding

**Don't read**:
- Method details
- Related work
- Experiments section
- Proofs / derivations

**Output**: Relevance score (1-5) + 5-item summary (problem, method, finding, relevance, venue)

**Time budget**: 3 minutes maximum. If you can't decide in 3 minutes, default to "quick archive"
and move on.

### Pass 2: 15-Minute Structural Read (Phase 1)

**Goal**: Understand what the paper claims and how it's structured.

**What to read**:
1. **Abstract + Introduction** — All of it
2. **Section headers** — Get the structural outline
3. **Figures and captions** — Study each figure
4. **Tables** — Read the numbers in main tables
5. **Conclusion** — Read all of it
6. **First paragraph of each section** — Gets the main claim of each section

**Don't read yet**:
- Method math / derivations
- Proof details
- Appendix

**Output**: Structured note with problem, method summary, experiments summary, findings

**Time budget**: 15 minutes for a typical 8-10 page paper.

### Pass 3: 60+ Minute Deep Read (Optional, for important papers only)

**Goal**: Reproduce the paper's reasoning; understand every claim.

**What to read**:
- **Everything** — including proofs, supplementary, code (if available)

**Techniques**:
- Work through derivations on paper
- Try to anticipate the next sentence before reading it
- Note every assumption
- Check for internal consistency
- Critically evaluate claims

**Output**: Comprehensive notes + critical assessment + implementation-ready understanding

**Time budget**: 1-4 hours. Reserve for papers that directly affect your project.

---

## Paper Type-Specific Reading Patterns

### Type 1: Method Papers (Most Common)

**Signature**: Proposes a new technique to solve an existing problem.

**Reading focus**:
1. **What's the novel technique?** — Usually a new architecture component, training procedure, or algorithm
2. **What's the intuition?** — Why does it work? (Often in the Method section or a figure caption)
3. **How does it compare?** — Which baselines, how much better, on what metric
4. **What are the ablations?** — Which components matter? (This is often where the real insights are)
5. **What's the failure mode?** — When does it break? (Honest papers discuss this)

**Skim sections**: Background, Related Work (unless you're new to the area)
**Read sections**: Method, Experiments, Analysis, Discussion

**Key questions**:
- Is the technique genuinely novel, or a repackaging of known ideas?
- Are the baselines fair? (Same hyperparameters, same data, same compute?)
- Are the datasets chosen to favor the proposed method?
- Is the improvement large enough to matter in practice?

### Type 2: Empirical Studies

**Signature**: Measures some phenomenon; often doesn't propose a new method.

**Examples**:
- "How do transformers scale on [task]?"
- "What do attention heads learn in [model]?"
- "Systematic evaluation of [N] methods on [M] benchmarks"

**Reading focus**:
1. **What's the phenomenon being measured?**
2. **How was it measured?** — Protocol, datasets, metrics
3. **What was found?** — Key empirical observations
4. **Is the finding robust?** — Across datasets, seeds, settings
5. **What are the implications?** — For practitioners and future research

**Skim sections**: Detailed method descriptions (they're often off-the-shelf)
**Read sections**: Experimental setup, results, analysis, implications

**Key questions**:
- Is the finding surprising or expected?
- Could the finding be an artifact of the protocol?
- Is the finding likely to generalize?
- Does it change how I should think about [topic]?

### Type 3: Theoretical Papers

**Signature**: Proves something mathematically.

**Reading focus**:
1. **What's the theorem?** — State it precisely
2. **What are the assumptions?** — Are they realistic?
3. **What's the proof strategy?** — High-level idea of how the proof works
4. **What are the implications?** — What practical lessons can I draw?
5. **What are the limitations?** — When does the theorem not apply?

**Skim sections**: Detailed proofs (unless you need to implement them)
**Read sections**: Theorem statements, assumptions, proof sketches, implications

**Key questions**:
- Is this a new result, or a known result re-derived?
- Are the assumptions satisfied in practice?
- Can I cite this to justify a design choice?
- Does the proof reveal a useful intuition?

### Type 4: Surveys and Position Papers

**Signature**: Organizes the field; may propose a perspective.

**Reading focus**:
1. **What's the taxonomy?** — How does the survey organize the field?
2. **What are the main categories?** — Methods, applications, open problems
3. **What's the author's perspective?** — Implicit in how they categorize
4. **What are the open problems?** — These are research opportunities

**Skim sections**: Individual method summaries (you can go to the source papers for detail)
**Read sections**: Taxonomy, introduction, discussion of open problems

**Key questions**:
- Is the taxonomy useful for my understanding?
- What problems are highlighted that I could work on?
- Which cited papers should I read next?

### Type 5: Dataset / Benchmark Papers

**Signature**: Introduces a new dataset or evaluation protocol.

**Reading focus**:
1. **What's in the dataset?** — Size, type, source, annotations
2. **How was it collected?** — Protocol, quality control
3. **What's the evaluation protocol?** — Metric, splits, baselines
4. **What are the challenges?** — Biases, limitations, ethical concerns
5. **Where to get it?** — Download link, license

**Skim sections**: Detailed statistics (unless you plan to use the dataset)
**Read sections**: Overview, collection methodology, evaluation protocol, limitations

**Key questions**:
- Is this dataset relevant to my research?
- Are there ethical/licensing concerns?
- What are the known biases?
- How do existing methods perform?

### Type 6: Application Papers

**Signature**: Applies existing methods to a new domain or problem.

**Reading focus**:
1. **What's the new application?** — Domain, specific problem
2. **What methods were adapted?** — From where, with what changes
3. **What new insights did the application reveal?** — About the domain or the methods
4. **What's domain-specific about the approach?** — Cannot just use off-the-shelf ML

**Skim sections**: Standard method descriptions
**Read sections**: Problem setup, domain-specific adaptations, results, implications for domain

**Key questions**:
- Does this open a new research area?
- Are the domain-specific insights transferable to other domains?

---

## Reading for Different Goals

### Goal: "I'm looking for baselines for my project"

- Focus on Experiments section
- Note: dataset, metric, performance, code availability
- Check if it's reproducible (code + pretrained models)
- Skip: theoretical justification, related work

### Goal: "I'm looking for a technique to borrow"

- Focus on Method section (1-2 key technical ideas)
- Study the ablation table (which components matter)
- Check code (understand implementation details)
- Skip: experimental comparison

### Goal: "I'm looking for evidence for/against a hypothesis"

- Focus on Results and Discussion
- Read critically: are the experiments designed to test my hypothesis?
- Note effect sizes and significance
- Skip: method details

### Goal: "I'm writing a related work section"

- Focus on the abstract and contribution bullets
- Note: what's the claim, how does it position against prior work
- Look for the paper's own "related work" for additional references
- Don't need to understand every detail

### Goal: "I'm preparing for peer review"

- Read every section carefully
- Critically assess every claim
- Check for logical consistency
- Verify experiments are fair
- Note concerns to raise in review

---

## Quick Read Template (3 minutes, Phase 0)

```markdown
# Quick Read: {title}

**Venue**: {arxiv / conference / journal}
**Year**: {year}
**Authors**: {first author et al.}

**Problem** (1 sentence):
{what problem does this paper address?}

**Method** (1 sentence):
{what technique/approach does it use?}

**Key Finding** (1 sentence with number):
{what's the headline result?}

**Relevance to me** (1-3 sentences):
{why does this matter for my research?}

**Score**: {1-5}
- 5 = directly relevant, must deep read
- 4 = adjacent, deep read recommended
- 3 = related, add to library
- 2 = tangential, quick note
- 1 = not relevant

**Decision**: Deep read / Quick archive / Skip
```

## Deep Read Template (15 minutes, Phase 1)

```markdown
# Deep Read: {title}

## Problem and Motivation
{What exactly is the problem? Why is it hard? Why do existing methods fail?}

## Method
### Core idea
{The one technical innovation in 2-3 sentences.}

### Details
{Key components, architecture, training procedure. Enough detail to reimplement.}

### What's new?
{Distinguish from prior work. What exactly is the novelty?}

## Experiments
### Setup
- Datasets: {list}
- Baselines: {list}
- Metrics: {list}
- Hardware: {if relevant}

### Main Results
{The key numbers from Table 1 / Figure 2}

### Ablations
{What components matter? Which are unnecessary?}

### Failure Modes
{When does it break? What are the limitations?}

## Limitations and Open Questions
### Author-Acknowledged
{Explicit limitations from the paper}

### My Observations
{What did I notice that the authors didn't discuss?}

### Open Questions
{What follow-up work is needed?}

## Relation to Prior Work
{Top 3-5 related papers and how they compare}

## Relevance to My Research
{3-5 sentences on why this matters for my projects}

## Potential Uses
- [ ] Cite in {project} as {baseline/related work/motivation}
- [ ] Borrow {technique} for {project}
- [ ] Use {dataset} for future experiments
- [ ] Challenge my assumption about {topic}

## Ideas Triggered
{Any new research ideas this paper sparked? Details → idea_library}
```
