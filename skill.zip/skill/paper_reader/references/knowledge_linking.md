# Knowledge Linking Guide

How to connect papers in your knowledge base. Used by Phase 2 of `paper_reader/SKILL.md`.

## The Knowledge Graph Model

Your paper library is a **graph**, not a flat list. Each paper is a node; each connection is
an edge. Over time, the graph reveals:
- Chains of progress in a field
- Contested positions (papers that disagree)
- Forgotten foundations (old papers that shaped current work)
- Unexplored territories (gaps in the graph)

The value of the library grows faster than linearly as more connections are added.

## Edge Types

### 1. Extends

Paper A **extends** Paper B if A directly builds on B's method, data, or findings.

**Example**:
- A: "CellAgent — transformer-based cell typing with GRN attention"
- B: "scGPT — transformer-based cell typing"
- A extends B: CellAgent uses scGPT's architecture and adds GRN attention

**Signal**: A cites B prominently, uses B's code as base, reports improvement over B.

### 2. Contrasts

Paper A **contrasts** Paper B if they take opposite approaches to the same problem.

**Example**:
- A: "Simple MLPs outperform transformers for cell typing on small datasets"
- B: "scGPT — transformer-based cell typing"
- A contrasts B: A argues against using transformers; B advocates for them

**Signal**: Both target the same problem, reach different conclusions, may cite each other
critically.

### 3. Complements

Paper A **complements** Paper B if they solve adjacent but distinct problems, and together
form a more complete picture.

**Example**:
- A: "CellAgent — cell type annotation"
- B: "scVI — cell type integration across batches"
- A complements B: Different tasks (annotation vs integration), both important for scRNA-seq

**Signal**: Same domain, different subtask, often cited together in related work sections.

### 4. Supersedes

Paper A **supersedes** Paper B if A is a direct, strictly-better replacement for B.

**Example**:
- A: "Improved scGPT with better pretraining"
- B: "Original scGPT"
- A supersedes B: Same team, same architecture, better results

**Signal**: Direct replacement, often from same authors, B becomes obsolete.

### 5. Validates

Paper A **validates** Paper B if A provides evidence (empirical or theoretical) that supports
B's claims.

**Example**:
- A: "Empirical study of attention patterns in scGPT"
- B: "scGPT — claims attention focuses on regulatory relationships"
- A validates B: A's systematic analysis confirms B's interpretation

**Signal**: A cites B and runs experiments to verify B's claims.

### 6. Refutes

Paper A **refutes** Paper B if A provides evidence against B's claims.

**Example**:
- A: "Transformers don't learn regulatory relationships — attention is local"
- B: "scGPT — attention captures gene regulation"
- A refutes B: A directly contradicts B's interpretive claim

**Signal**: A cites B and challenges a specific claim.

### 7. Inspired By

Paper A is **inspired by** Paper B if A's core idea originates from B, even if A is in a
different domain.

**Example**:
- A: "CellAgent — GRN-guided attention for cell typing"
- B: "Graph Attention Networks — general GNN with attention"
- A inspired by B: A adapts the attention mechanism from B to a new domain

**Signal**: A cites B as motivation, borrows terminology, explicit "inspired by" language.

### 8. Same Author

Optional edge type: track papers by the same research group to see their line of work.

## Connection Examples

### Example 1: Method Chain

```
2023_scbert (transformer for scRNA) ─── inspired_by ─── 2018_bert
        │                                                  │
   extended_by                                        inspired_by
        ↓                                                  ↓
2024_scgpt (improved scBERT) ─── extends ─── 2023_scbert
        │                                                  │
   extended_by                                        critiqued_by
        ↓                                                  ↓
2025_cellagent (GRN-guided) ─── extends ─── 2024_scgpt
```

### Example 2: Debate

```
2024_paper_a (transformers best)
        │
   contrasts
        ↓
2024_paper_b (MLPs best)
        │
   contrasts
        ↓
2025_paper_c (it depends on dataset size)
        │
   validates & refines
        ↓
   (both a and b, under conditions)
```

### Example 3: Complementary Tools

```
2024_scvi (integration) ─── complements ─── 2024_scgpt (annotation)
        │                                         │
  complements                                 complements
        ↓                                         ↓
2024_scanpy (visualization) ←── complements ── 2024_scvi
                                                  │
                                             complements
                                                  ↓
                                       2024_harmony (batch correction)
```

## Finding Connections

### Automatic Signals

When you add a new paper, the skill can auto-detect potential connections:

1. **Citation overlap**: Papers that share >3 citations are often related
2. **Keyword overlap**: Papers with shared technical keywords
3. **Author overlap**: Same research group = same line of work
4. **Topic tag overlap**: Papers with shared topic tags
5. **Dataset overlap**: Papers using the same datasets are often comparable

### Manual Judgment

Automatic signals flag **candidates**; you choose which are **real connections**. The
classification (extends / contrasts / complements / etc.) is always manual — the skill cannot
reliably infer relationship types.

## Connection Format

### In Paper Note (Markdown)

At the bottom of each paper note:

```markdown
## Related Papers in My Library

- [[2024_lotfollahi_scvi]] — **Extends**: Uses scVI's conditional VAE as backbone
- [[2024_ma_scgpt]] — **Contrasts**: Different attention strategy
- [[2023_yang_grn_prior]] — **Inspired by**: Borrowed GRN prior idea from here
- [[2025_chen_ablation_study]] — **Validates**: Confirms the benefit of GRN-guided attention
```

### In connections.json (Machine-Readable)

```json
{
  "nodes": [
    {"id": "2024_cellagent", "title": "CellAgent: GRN-guided cell typing", "year": 2024},
    {"id": "2024_lotfollahi_scvi", "title": "scVI: conditional VAE for scRNA-seq", "year": 2024},
    {"id": "2024_ma_scgpt", "title": "scGPT: generative pretraining for cells", "year": 2024}
  ],
  "edges": [
    {
      "source": "2024_cellagent",
      "target": "2024_lotfollahi_scvi",
      "type": "extends",
      "note": "Uses scVI's conditional VAE as backbone; adds GRN attention",
      "date_added": "2026-04-11"
    },
    {
      "source": "2024_cellagent",
      "target": "2024_ma_scgpt",
      "type": "contrasts",
      "note": "Different attention: scGPT uses standard attention, CellAgent uses GRN-guided",
      "date_added": "2026-04-11"
    }
  ]
}
```

Keep `connections.json` as an optional layer — not required for the skill to work. The
primary source of truth is the markdown files.

## Graph Hygiene

### Don't Over-Connect

Not every paper needs 10 connections. A new paper typically has 2-5 meaningful connections to
existing papers. More than 10 is usually a sign you're connecting papers that are only
superficially related.

### Don't Connect Everything to Everything

If a topic has 20 papers in your library, you don't need 190 edges (fully connected). You need
a few key edges that capture the structure.

### Use Hubs

Some papers are "hub" papers — foundational works that many others extend. Let them be hubs.
Not every paper needs to connect to every other paper.

### Periodic Review

Every few months, review your graph:
- Are there clusters of highly-connected papers? (These are topics worth synthesizing)
- Are there isolated papers? (Either important but unconnected, or possibly not worth keeping)
- Are there missing connections? (Add them)

## Knowledge Graph as Insight Source

The graph itself is a source of insights. Patterns to look for:

### Pattern 1: Convergent Evolution

Multiple papers from different groups arrive at similar ideas independently. **Signal**: Field
is ripe for a unifying theory or method.

### Pattern 2: Abandoned Threads

Old papers with promising ideas that no one extended. **Signal**: Possible research opportunity.

### Pattern 3: Unresolved Debates

Chains of contrasting papers without a final word. **Signal**: Open research question.

### Pattern 4: Hidden Foundations

Recent papers that unknowingly reinvent older ideas. **Signal**: Citation oversight; possible
paper-writing opportunity (connecting old and new work).

### Pattern 5: Dataset Monoculture

Many papers using the same dataset. **Signal**: Results may not generalize; consider new
benchmarks.

## Connection Note Templates

### Extends

```markdown
- [[{target}]] — **Extends**: {what you keep from target} + {what you change}
```

### Contrasts

```markdown
- [[{target}]] — **Contrasts**: Target argues X; this paper argues not-X because {reason}
```

### Complements

```markdown
- [[{target}]] — **Complements**: Same domain, different task. Target does X; this does Y.
  Together they enable {combined capability}.
```

### Supersedes

```markdown
- [[{target}]] — **Supersedes**: Target is obsolete for {use case}; prefer this paper.
```

### Validates / Refutes

```markdown
- [[{target}]] — **Validates**: Target claimed X. This paper's experiments confirm X by
  {method}.

- [[{target}]] — **Refutes**: Target claimed X. This paper shows X is false because {reason}.
```

### Inspired By

```markdown
- [[{target}]] — **Inspired by**: Borrowed {idea} from target; adapted to {new domain}.
```

## Visualization (Optional)

If you want to visualize the graph, tools like:
- **Obsidian**: Treats markdown links as a graph natively
- **Logseq**: Similar to Obsidian
- **Org-roam**: For Emacs users
- **Cytoscape**: Scientific graph visualization (reads connections.json)

The skill generates markdown that works in any of these tools. The graph visualization is
useful but not required — the notes are valuable on their own.
