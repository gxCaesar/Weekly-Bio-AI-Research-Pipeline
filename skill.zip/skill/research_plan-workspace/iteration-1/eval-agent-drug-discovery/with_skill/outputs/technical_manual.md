# GenoDrug-Agent 技术手册

本手册提供完整的实验复现指南，使学生能够独立完成所有实验而无需额外指导。

## 1. 环境配置

### 1.1 系统要求

- **操作系统**: Linux (Ubuntu 20.04/22.04 推荐)
- **GPU**: NVIDIA A100 80GB x 1-2
- **CUDA**: 11.8 或 12.1
- **Python**: 3.10+
- **内存**: 32GB RAM 以上
- **硬盘**: 50GB 可用空间（数据 + 检查点）

### 1.2 安装步骤

```bash
# 创建conda环境
conda create -n genodrug python=3.10 -y
conda activate genodrug

# 安装PyTorch (CUDA 11.8)
pip install torch==2.1.2 torchvision==0.16.2 torchaudio==2.1.2 --index-url https://download.pytorch.org/whl/cu118

# 安装项目依赖
cd code/
pip install -r requirements.txt
```

### 1.3 验证安装

```bash
# 验证PyTorch和CUDA
python -c "import torch; print(f'PyTorch: {torch.__version__}'); print(f'CUDA available: {torch.cuda.is_available()}'); print(f'GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else \"N/A\"}')"

# 验证RDKit
python -c "from rdkit import Chem; mol = Chem.MolFromSmiles('CCO'); print(f'RDKit OK: {Chem.MolToSmiles(mol)}')"

# 验证transformers
python -c "import transformers; print(f'Transformers: {transformers.__version__}')"
```

**预期输出**:
```
PyTorch: 2.1.2
CUDA available: True
GPU: NVIDIA A100-SXM4-80GB
RDKit OK: CCO
Transformers: 4.36.x
```

## 2. 数据准备

### 2.1 下载数据

```bash
# 下载所有数据集
python data/download.py --dataset all --output_dir data/raw/

# 或分别下载
python data/download.py --dataset gdsc --output_dir data/raw/
python data/download.py --dataset ccle --output_dir data/raw/
```

**注意**: 
- DrugBank数据可能需要在 https://go.drugbank.com/ 注册后手动下载
- 如果自动下载失败，请手动访问上述URL下载文件，放入 `data/raw/` 目录
- GDSC数据下载约需5-10分钟，取决于网络速度

### 2.2 预处理

```bash
python data/preprocess.py \
    --expression_path data/raw/gdsc/gdsc_expression_raw.csv \
    --response_path data/raw/gdsc/gdsc_ic50_raw.csv \
    --smiles_path data/raw/gdsc/drug_smiles.csv \
    --output_dir data/processed/ \
    --max_genes 2048 \
    --seed 42
```

### 2.3 验证数据

预处理完成后，`data/processed/` 目录应包含以下文件：

| 文件 | 预期大小 | 说明 |
|------|---------|------|
| gene_expression.csv | ~50 MB | 标准化基因表达矩阵 |
| gene_list.txt | ~30 KB | 基因名称列表 |
| drug_info.csv | ~100 KB | 药物SMILES及分子属性 |
| drug_fingerprints.npy | ~5 MB | Morgan指纹矩阵 |
| drug_tanimoto_similarity.npy | ~500 KB | 药物间Tanimoto相似度矩阵 |
| split_train.csv | ~10 MB | 训练集 |
| split_val.csv | ~1.5 MB | 验证集 |
| split_test.csv | ~3 MB | 测试集 |
| split_test_cold_drug.csv | ~1 MB | 冷启动-新药物测试集 |
| split_test_cold_cell.csv | ~1 MB | 冷启动-新细胞系测试集 |
| split_test_cold_both.csv | ~200 KB | 冷启动-两者均新测试集 |
| data_summary.json | ~1 KB | 数据统计摘要 |

验证命令:
```bash
python -c "
import json
with open('data/processed/data_summary.json') as f:
    summary = json.load(f)
print(json.dumps(summary, indent=2))
"
```

## 3. 运行基线实验

### 3.1 基线1: DeepCDR

```bash
python main.py \
    --config configs/baseline_deepcdr.yaml \
    --mode train_eval \
    --output_dir outputs/baseline_deepcdr
```

- **预期训练时间**: ~2小时 (1x A100)
- **预期结果范围**: PCC 0.85-0.92, RMSE 0.8-1.0

### 3.2 基线2: GraphDRP

```bash
python main.py \
    --config configs/baseline_graphdrp.yaml \
    --mode train_eval \
    --output_dir outputs/baseline_graphdrp
```

- **预期训练时间**: ~3小时 (1x A100)
- **预期结果范围**: PCC 0.86-0.93, RMSE 0.75-0.95

### 3.3 运行所有基线

```bash
bash scripts/run_baselines.sh
```

## 4. 训练我们的模型

### 4.1 默认配置训练（阶段二: 仅训练CMCB桥接模块）

```bash
python main.py \
    --config configs/default.yaml \
    --mode train_eval \
    --output_dir outputs/main
```

- **预期训练时间**: ~8小时 (1x A100)
- **预期GPU显存**: ~15 GB
- **预期结果**: PCC > 0.92, RMSE < 0.80

### 4.2 训练监控

训练过程可以通过以下方式监控：

**日志文件**:
```bash
tail -f outputs/main/train.log
```

**Weights & Biases (如已配置)**:
- 打开浏览器访问 https://wandb.ai
- 找到 "genodrug-agent" 项目查看训练曲线

**检查点列表**:
```bash
ls -la outputs/main/*.pt
```

### 4.3 断点续训

如果训练中断，可以从最新检查点恢复：

```bash
python main.py \
    --config configs/default.yaml \
    --mode train_eval \
    --checkpoint outputs/main/last.pt \
    --output_dir outputs/main
```

### 4.4 多GPU训练

使用2张A100进行DDP训练：

```bash
bash scripts/train.sh configs/default.yaml outputs/main 2
```

## 5. 评估

### 5.1 评估最佳模型

```bash
python main.py \
    --config configs/default.yaml \
    --mode eval \
    --checkpoint outputs/main/best_model.pt \
    --output_dir outputs/eval
```

### 5.2 评估结果文件

评估完成后，在 `outputs/eval/` 中查看：

| 文件 | 内容 |
|------|------|
| eval_test.json | 标准测试集指标 |
| eval_test_cold_drug.json | 冷启动(新药物)测试指标 |
| eval_test_cold_cell.json | 冷启动(新细胞系)测试指标 |
| eval_summary.json | 所有测试集指标汇总 |
| predictions_test.npz | 预测值与真实值 |
| plots/scatter_test.png | 预测vs真实散点图 |
| plots/training_curves.png | 训练曲线 |

### 5.3 查看结果

```bash
python -c "
import json
with open('outputs/eval/eval_summary.json') as f:
    summary = json.load(f)
for dataset, metrics in summary.items():
    print(f'{dataset}:')
    for k, v in metrics.items():
        print(f'  {k}: {v:.4f}')
    print()
"
```

## 6. 消融实验

### 6.1 运行所有消融实验

```bash
python ablation/run_ablation.py --output_dir outputs/ablations
```

- **预期总时间**: ~40小时 (1x A100)
- 共8个实验，每个约5小时

### 6.2 运行单个消融实验

```bash
# 例如：仅运行"移除对比学习"实验
python ablation/run_ablation.py --output_dir outputs/ablations --experiment no_contrastive
```

### 6.3 各消融实验说明

| 实验名称 | 消融内容 | 验证目的 |
|---------|---------|---------|
| full_model | 完整模型（对照组） | 基准性能 |
| no_contrastive | 移除对比学习损失 | 验证跨模态对齐的必要性 |
| no_hardneg | 移除难负样本挖掘 | 验证难负样本策略的效果 |
| fixed_temperature | 使用固定温度 | 验证自适应温度的贡献 |
| no_geneformer | 替换Geneformer为随机MLP | 验证基因组预训练的贡献 |
| fingerprint_only | 替换Uni-Mol为Morgan指纹 | 验证3D分子预训练的贡献 |
| no_agent | 禁用Agent框架 | 验证Agent架构的优势 |
| no_uncertainty | 禁用MC Dropout | 验证不确定度估计的价值 |

### 6.4 消融实验结果

实验完成后，查看汇总结果：

```bash
cat outputs/ablations/ablation_summary.json | python -m json.tool
```

## 7. 常见问题

### OOM (显存不足)

**症状**: `CUDA out of memory` 错误

**解决方案**:
1. 减小batch_size（修改config YAML中的 `training.batch_size`，例如从128改为64）
2. 开启梯度检查点（设置 `training.gradient_checkpointing: true`）
3. 减小max_genes（设置 `data.max_genes: 1024`）
4. 使用梯度累积（设置 `training.gradient_accumulation_steps: 2`，同时batch_size减半）

### 训练Loss不下降

**可能原因和解决方案**:
1. 学习率过大：尝试 `training.learning_rate: 1.0e-5`
2. 数据预处理问题：检查 `data/processed/data_summary.json` 确认数据量正确
3. 随机种子影响：尝试不同的seed（42, 0, 123）

### CUDA版本不匹配

```bash
# 检查CUDA版本
nvidia-smi
python -c "import torch; print(torch.version.cuda)"

# 如果不匹配，重新安装对应版本的PyTorch
# CUDA 12.1版本:
pip install torch==2.1.2 torchvision==0.16.2 torchaudio==2.1.2 --index-url https://download.pytorch.org/whl/cu121
```

### 数据下载失败

- 检查网络连接
- 某些数据源可能需要VPN
- DrugBank需要注册账号后手动下载
- 可以使用 `wget` 或 `curl` 手动下载后放入 `data/raw/` 目录

### wandb连接失败

```bash
# 如果不需要wandb，在config中设置:
# logging.wandb_project: null

# 或者首次使用时登录:
wandb login
```

## 8. 预期结果格式

### 8.1 主要结果表格

实验完成后，应该能生成如下格式的结果表格（用于论文Table 1）：

| Method | PCC | RMSE | Spearman | AUROC | AUPRC |
|--------|-----|------|----------|-------|-------|
| DeepCDR | XX.X | X.XX | XX.X | XX.X | XX.X |
| GraphDRP | XX.X | X.XX | XX.X | XX.X | XX.X |
| **GenoDrug-Agent** | **XX.X** | **X.XX** | **XX.X** | **XX.X** | **XX.X** |

### 8.2 冷启动结果表格

| Method | Cold-Drug PCC | Cold-Cell PCC | Cold-Both PCC |
|--------|--------------|--------------|--------------|
| DeepCDR | XX.X | XX.X | XX.X |
| GraphDRP | XX.X | XX.X | XX.X |
| **GenoDrug-Agent** | **XX.X** | **XX.X** | **XX.X** |

### 8.3 消融结果表格

| Configuration | PCC | RMSE | Delta PCC |
|--------------|-----|------|-----------|
| Full Model | XX.X | X.XX | - |
| w/o Contrastive | XX.X | X.XX | -X.X |
| w/o Hard Neg | XX.X | X.XX | -X.X |
| w/o Adaptive Temp | XX.X | X.XX | -X.X |
| w/o Geneformer | XX.X | X.XX | -X.X |
| w/o Uni-Mol | XX.X | X.XX | -X.X |

### 8.4 需要生成的图表

1. `plots/scatter_test.png` - 预测vs真实IC50散点图
2. `plots/training_curves.png` - 训练loss/PCC/RMSE曲线
3. `plots/dataset_comparison.png` - 方法对比柱状图

这些图表将直接用于论文的Figure 4-6。
