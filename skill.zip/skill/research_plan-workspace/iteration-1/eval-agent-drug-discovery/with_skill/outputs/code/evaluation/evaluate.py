"""Evaluation pipeline for GenoDrug-Agent.

Provides comprehensive model evaluation including standard metrics,
cold-start evaluation, and per-drug/per-cell analysis.
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn
from torch.cuda.amp import autocast
from torch.utils.data import DataLoader

from evaluation.metrics import compute_all_metrics

logger = logging.getLogger(__name__)


class Evaluator:
    """Comprehensive model evaluator.

    Runs evaluation on multiple test sets and generates detailed reports.

    Args:
        model: The model to evaluate.
        device: Device for inference.
        use_fp16: Whether to use FP16 for inference.
        output_dir: Directory to save evaluation results.
    """

    def __init__(
        self,
        model: nn.Module,
        device: torch.device,
        use_fp16: bool = True,
        output_dir: str = "./outputs/eval",
    ) -> None:
        self.model = model.to(device)
        self.device = device
        self.use_fp16 = use_fp16
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    @torch.no_grad()
    def evaluate_dataset(
        self,
        dataloader: DataLoader,
        dataset_name: str = "test",
    ) -> Dict[str, Any]:
        """Evaluate model on a single dataset.

        Args:
            dataloader: DataLoader for the evaluation dataset.
            dataset_name: Name of the dataset for reporting.

        Returns:
            Dictionary containing metrics and per-sample predictions.
        """
        self.model.eval()
        logger.info(f"Evaluating on {dataset_name}: {len(dataloader.dataset)} samples")

        all_preds = []
        all_labels = []
        all_logits = []
        all_sensitive = []
        all_cell_lines = []
        all_drug_ids = []

        for batch in dataloader:
            batch_device = {}
            for k, v in batch.items():
                if isinstance(v, torch.Tensor):
                    batch_device[k] = v.to(self.device)
                else:
                    batch_device[k] = v

            with autocast(enabled=self.use_fp16):
                outputs = self.model(**batch_device)

            all_preds.append(outputs["ic50_pred"].cpu().numpy())
            all_labels.append(batch["ic50"].numpy())

            if "sensitivity_logits" in outputs:
                all_logits.append(outputs["sensitivity_logits"].cpu().numpy())
            if "sensitive" in batch:
                all_sensitive.append(batch["sensitive"].numpy())
            if "cell_line" in batch:
                all_cell_lines.extend(batch["cell_line"])
            if "drug_id" in batch:
                all_drug_ids.extend(batch["drug_id"])

        preds = np.concatenate(all_preds)
        labels = np.concatenate(all_labels)
        logits = np.concatenate(all_logits) if all_logits else None
        sensitive = np.concatenate(all_sensitive) if all_sensitive else None

        # Overall metrics
        metrics = compute_all_metrics(
            y_pred=preds,
            y_true=labels,
            logits=logits,
            labels_binary=sensitive,
        )

        # Per-drug analysis
        per_drug_metrics = {}
        if all_drug_ids:
            unique_drugs = list(set(all_drug_ids))
            for drug_id in unique_drugs:
                mask = [d == drug_id for d in all_drug_ids]
                if sum(mask) >= 5:
                    drug_preds = preds[mask]
                    drug_labels = labels[mask]
                    per_drug_metrics[drug_id] = {
                        "pcc": float(
                            compute_all_metrics(drug_preds, drug_labels)["pcc"]
                        ),
                        "rmse": float(
                            compute_all_metrics(drug_preds, drug_labels)["rmse"]
                        ),
                        "n_samples": int(sum(mask)),
                    }

        result = {
            "dataset_name": dataset_name,
            "n_samples": len(preds),
            "metrics": metrics,
            "per_drug_metrics": per_drug_metrics,
        }

        # Save results
        result_path = self.output_dir / f"eval_{dataset_name}.json"
        with open(result_path, "w") as f:
            json.dump(
                {k: v for k, v in result.items() if k != "predictions"},
                f,
                indent=2,
                default=str,
            )

        # Save predictions
        pred_path = self.output_dir / f"predictions_{dataset_name}.npz"
        np.savez(
            pred_path,
            predictions=preds,
            labels=labels,
            cell_lines=np.array(all_cell_lines) if all_cell_lines else np.array([]),
            drug_ids=np.array(all_drug_ids) if all_drug_ids else np.array([]),
        )

        logger.info(f"{dataset_name} results: {metrics}")
        return result

    def evaluate_all(
        self,
        dataloaders: Dict[str, DataLoader],
    ) -> Dict[str, Dict]:
        """Evaluate on all provided datasets.

        Args:
            dataloaders: Dictionary mapping dataset names to DataLoaders.

        Returns:
            Dictionary mapping dataset names to results.
        """
        all_results = {}
        for name, loader in dataloaders.items():
            results = self.evaluate_dataset(loader, dataset_name=name)
            all_results[name] = results

        # Print summary table
        logger.info("\n" + "=" * 80)
        logger.info("EVALUATION SUMMARY")
        logger.info("=" * 80)
        header = f"{'Dataset':<25} {'PCC':>8} {'RMSE':>8} {'Spearman':>10} {'AUROC':>8}"
        logger.info(header)
        logger.info("-" * 80)
        for name, res in all_results.items():
            m = res["metrics"]
            row = (
                f"{name:<25} "
                f"{m.get('pcc', 0):>8.4f} "
                f"{m.get('rmse', 0):>8.4f} "
                f"{m.get('spearman', 0):>10.4f} "
                f"{m.get('auroc', 0):>8.4f}"
            )
            logger.info(row)
        logger.info("=" * 80)

        # Save combined summary
        summary_path = self.output_dir / "eval_summary.json"
        summary = {
            name: res["metrics"] for name, res in all_results.items()
        }
        with open(summary_path, "w") as f:
            json.dump(summary, f, indent=2, default=str)

        return all_results

    @torch.no_grad()
    def evaluate_with_uncertainty(
        self,
        dataloader: DataLoader,
        n_mc_samples: int = 10,
        dataset_name: str = "test_uncertainty",
    ) -> Dict[str, Any]:
        """Evaluate with MC Dropout uncertainty estimation.

        Args:
            dataloader: Evaluation DataLoader.
            n_mc_samples: Number of MC Dropout forward passes.
            dataset_name: Name for reporting.

        Returns:
            Results with uncertainty estimates.
        """
        logger.info(
            f"Evaluating with uncertainty (MC={n_mc_samples}) on {dataset_name}"
        )

        all_means = []
        all_stds = []
        all_labels = []

        for batch in dataloader:
            batch_device = {}
            for k, v in batch.items():
                if isinstance(v, torch.Tensor):
                    batch_device[k] = v.to(self.device)
                else:
                    batch_device[k] = v

            unc_outputs = self.model.predict_with_uncertainty(
                gene_expression=batch_device["gene_expression"],
                drug_fingerprint=batch_device["drug_fingerprint"],
                n_samples=n_mc_samples,
            )

            all_means.append(unc_outputs["ic50_mean"].cpu().numpy())
            all_stds.append(unc_outputs["ic50_std"].cpu().numpy())
            all_labels.append(batch["ic50"].numpy())

        means = np.concatenate(all_means)
        stds = np.concatenate(all_stds)
        labels = np.concatenate(all_labels)

        metrics = compute_all_metrics(y_pred=means, y_true=labels)
        metrics["mean_uncertainty"] = float(stds.mean())
        metrics["uncertainty_correlation"] = float(
            np.abs(np.corrcoef(stds, np.abs(means - labels))[0, 1])
        )

        result = {
            "dataset_name": dataset_name,
            "metrics": metrics,
            "n_mc_samples": n_mc_samples,
        }

        result_path = self.output_dir / f"eval_{dataset_name}.json"
        with open(result_path, "w") as f:
            json.dump(result, f, indent=2, default=str)

        logger.info(f"Uncertainty eval results: {metrics}")
        return result
