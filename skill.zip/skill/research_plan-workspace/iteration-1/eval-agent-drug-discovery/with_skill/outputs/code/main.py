"""GenoDrug-Agent: Genome-Aware Multi-Agent Drug Discovery Framework.

Main entry point for training, evaluation, and inference.

Usage:
    python main.py --config configs/default.yaml --mode train_eval
    python main.py --config configs/default.yaml --mode eval --checkpoint outputs/best_model.pt
"""

import argparse
import json
import logging
import random
import sys
from pathlib import Path
from typing import Any, Dict

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader

from data.dataset import build_datasets
from data.collator import DrugSensitivityCollator, ContrastiveCollator
from models.model import GenoDrugAgent, build_model
from baselines.deepcdr import DeepCDR
from baselines.graphdrp import GraphDRP
from training.trainer import Trainer
from evaluation.evaluate import Evaluator
from evaluation.visualize import plot_results

logger = logging.getLogger(__name__)


def set_seed(seed: int) -> None:
    """Set random seeds for reproducibility.

    Args:
        seed: Random seed value.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_config(path: str) -> Dict[str, Any]:
    """Load configuration from YAML file.

    Args:
        path: Path to YAML configuration file.

    Returns:
        Configuration dictionary.
    """
    with open(path) as f:
        config = yaml.safe_load(f)
    return config


def build_model_from_config(config: Dict[str, Any]) -> torch.nn.Module:
    """Build the appropriate model based on configuration.

    Args:
        config: Full configuration dictionary.

    Returns:
        Model instance.
    """
    model_name = config["model"]["name"]

    if model_name == "GenoDrugAgent":
        model = build_model(config)
    elif model_name == "DeepCDR":
        gene_cfg = config["model"]["genomic_encoder"]
        drug_cfg = config["model"]["drug_encoder"]
        model = DeepCDR(
            gene_input_dim=gene_cfg.get("input_dim", 735),
            drug_input_dim=2048,
            dropout=gene_cfg.get("dropout", 0.1),
        )
    elif model_name == "GraphDRP":
        gene_cfg = config["model"]["genomic_encoder"]
        drug_cfg = config["model"]["drug_encoder"]
        model = GraphDRP(
            gene_input_dim=gene_cfg.get("input_dim", 735),
            drug_input_dim=2048,
            gene_hidden_dim=gene_cfg.get("hidden_dim", 256),
            drug_hidden_dim=drug_cfg.get("hidden_dim", 128),
            dropout=gene_cfg.get("dropout", 0.1),
        )
    else:
        raise ValueError(f"Unknown model: {model_name}")

    return model


def build_dataloaders(
    config: Dict[str, Any],
) -> Dict[str, DataLoader]:
    """Build DataLoaders for all splits.

    Args:
        config: Full configuration dictionary.

    Returns:
        Dictionary mapping split names to DataLoaders.
    """
    data_dir = config["data"]["data_dir"]
    max_genes = config["data"].get("max_genes", 2048)
    batch_size = config["training"]["batch_size"]
    num_workers = config["data"].get("num_workers", 4)
    pin_memory = config["data"].get("pin_memory", True)

    datasets = build_datasets(data_dir, max_genes=max_genes)

    # Choose collator
    contrastive_weight = config["training"].get("contrastive_weight", 0)
    if contrastive_weight > 0:
        drug_info_path = Path(data_dir) / "drug_info.csv"
        tanimoto_path = Path(data_dir) / "drug_tanimoto_similarity.npy"
        if drug_info_path.exists() and tanimoto_path.exists():
            import pandas as pd

            drug_df = pd.read_csv(drug_info_path)
            drug_id_list = drug_df["drug_id"].astype(str).tolist()
            collator = ContrastiveCollator(
                drug_tanimoto_path=str(tanimoto_path),
                drug_id_list=drug_id_list,
            )
        else:
            collator = DrugSensitivityCollator()
    else:
        collator = DrugSensitivityCollator()

    dataloaders = {}
    for name, dataset in datasets.items():
        is_train = name == "train"
        dataloaders[name] = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=is_train,
            num_workers=num_workers,
            pin_memory=pin_memory,
            collate_fn=collator,
            drop_last=is_train,
        )

    return dataloaders


def train(config: Dict[str, Any], output_dir: str) -> None:
    """Run training pipeline.

    Args:
        config: Full configuration dictionary.
        output_dir: Output directory for checkpoints and logs.
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Device: {device}")

    # Build model
    model = build_model_from_config(config)
    logger.info(f"Model: {config['model']['name']}")

    # Build dataloaders
    dataloaders = build_dataloaders(config)

    # Train
    trainer = Trainer(
        model=model,
        train_loader=dataloaders["train"],
        val_loader=dataloaders["val"],
        config=config,
        device=device,
        output_dir=output_dir,
    )

    best_metrics = trainer.train()
    logger.info(f"Training complete. Best metrics: {best_metrics}")

    return best_metrics


def evaluate(
    config: Dict[str, Any],
    checkpoint_path: str,
    output_dir: str,
) -> None:
    """Run evaluation pipeline.

    Args:
        config: Full configuration dictionary.
        checkpoint_path: Path to model checkpoint.
        output_dir: Output directory for results.
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Build model and load checkpoint
    model = build_model_from_config(config)
    checkpoint = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    logger.info(f"Loaded checkpoint from: {checkpoint_path}")

    # Build dataloaders
    dataloaders = build_dataloaders(config)

    # Evaluate on all test sets
    evaluator = Evaluator(
        model=model,
        device=device,
        use_fp16=config["training"].get("fp16", True),
        output_dir=output_dir,
    )

    test_loaders = {
        name: loader
        for name, loader in dataloaders.items()
        if name.startswith("test")
    }
    evaluator.evaluate_all(test_loaders)

    # Generate plots
    plot_results(output_dir)


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="GenoDrug-Agent: Genome-Aware Drug Discovery"
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to YAML configuration file",
    )
    parser.add_argument(
        "--mode",
        choices=["train", "eval", "train_eval"],
        default="train_eval",
        help="Run mode (default: train_eval)",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help="Path to checkpoint for evaluation or resume",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="./outputs",
        help="Output directory (default: ./outputs)",
    )
    args = parser.parse_args()

    # Setup logging
    log_dir = Path(args.output_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_dir / "train.log"),
        ],
    )

    # Load config
    config = load_config(args.config)
    logger.info(f"Config loaded from: {args.config}")

    # Save config to output dir
    with open(log_dir / "config.yaml", "w") as f:
        yaml.dump(config, f, default_flow_style=False)

    # Set seed
    seed = config["training"].get("seed", 42)
    set_seed(seed)
    logger.info(f"Random seed: {seed}")

    # Run
    if args.mode in ("train", "train_eval"):
        train(config, args.output_dir)

    if args.mode in ("eval", "train_eval"):
        checkpoint = args.checkpoint
        if checkpoint is None:
            checkpoint = str(log_dir / "best_model.pt")
        if Path(checkpoint).exists():
            evaluate(config, checkpoint, args.output_dir)
        else:
            logger.warning(
                f"Checkpoint not found: {checkpoint}. "
                "Skipping evaluation."
            )


if __name__ == "__main__":
    main()
