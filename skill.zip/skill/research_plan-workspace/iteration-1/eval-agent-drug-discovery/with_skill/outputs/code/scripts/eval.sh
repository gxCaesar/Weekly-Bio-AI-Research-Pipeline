#!/bin/bash
# Evaluate a trained model checkpoint
set -e

CHECKPOINT=${1:-outputs/main/best_model.pt}
CONFIG=${2:-configs/default.yaml}
OUTPUT_DIR=${3:-outputs/eval}

echo "Evaluating checkpoint: $CHECKPOINT"
echo "Config: $CONFIG"
echo "Output: $OUTPUT_DIR"

mkdir -p "$OUTPUT_DIR"

python main.py \
    --config "$CONFIG" \
    --mode eval \
    --checkpoint "$CHECKPOINT" \
    --output_dir "$OUTPUT_DIR"

echo "Evaluation complete. Results saved to: $OUTPUT_DIR"
