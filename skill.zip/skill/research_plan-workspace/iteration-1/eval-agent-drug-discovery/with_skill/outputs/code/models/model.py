"""Main GenoDrug-Agent model.

Integrates genomic encoder, drug encoder, cross-modal contrastive bridge,
and prediction head into a unified architecture.
"""

import logging
from typing import Any, Dict, Optional

import torch
import torch.nn as nn

from models.modules import (
    CrossModalContrastiveBridge,
    DrugEncoder,
    GenomicEncoder,
    PredictionHead,
)
from models.losses import CMCBLoss

logger = logging.getLogger(__name__)


class GenoDrugAgent(nn.Module):
    """GenoDrug-Agent: Genome-Aware Drug Discovery Model.

    Combines pretrained genomic and drug encoders with a cross-modal
    contrastive bridge for drug sensitivity prediction.

    Args:
        config: Full model configuration dictionary.
    """

    def __init__(self, config: Dict[str, Any]) -> None:
        super().__init__()
        self.config = config

        # Build encoders
        self.genomic_encoder = GenomicEncoder(config["model"]["genomic_encoder"])
        self.drug_encoder = DrugEncoder(config["model"]["drug_encoder"])

        # Determine dimensions
        genomic_dim = self.genomic_encoder.output_dim
        drug_dim = self.drug_encoder.output_dim

        # Build bridge
        bridge_cfg = config["model"]["bridge"]
        genomic_proj_dims = bridge_cfg.get("genomic_proj_dims", [512, 512])
        drug_proj_dims = bridge_cfg.get("drug_proj_dims", [512, 512])

        # Use the maximum of the two projection output dims as shared dim
        shared_dim = genomic_proj_dims[-1]

        self.bridge = CrossModalContrastiveBridge(
            genomic_dim=genomic_dim,
            drug_dim=drug_dim,
            proj_dims=genomic_proj_dims,
            dropout=bridge_cfg.get("dropout", 0.1),
            activation=bridge_cfg.get("activation", "gelu"),
            layer_norm=bridge_cfg.get("layer_norm", True),
            temperature=config["training"].get("temperature", 0.07),
            temperature_learnable=config["training"].get(
                "temperature_learnable", True
            ),
        )

        # Build a separate drug projector if dims differ
        if drug_proj_dims != genomic_proj_dims:
            from models.modules import MLPEncoder

            self.drug_bridge_projector = MLPEncoder(
                input_dim=drug_dim,
                hidden_dim=drug_proj_dims[0] if len(drug_proj_dims) > 1 else drug_dim,
                output_dim=drug_proj_dims[-1],
                num_layers=len(drug_proj_dims),
                dropout=bridge_cfg.get("dropout", 0.1),
            )
        else:
            self.drug_bridge_projector = None

        # Build prediction head
        head_cfg = config["model"]["prediction_head"]
        # Input is concatenation + elementwise product: 3 * shared_dim
        pred_input_dim = 3 * shared_dim

        self.prediction_head = PredictionHead(
            input_dim=pred_input_dim,
            hidden_dim=head_cfg.get("hidden_dim", 256),
            dropout=head_cfg.get("dropout", 0.2),
            num_layers=head_cfg.get("num_layers", 2),
        )

        # Adjust prediction head input if needed
        self.prediction_head.shared_layers = nn.Sequential(
            nn.Linear(pred_input_dim, head_cfg.get("hidden_dim", 256)),
            nn.LayerNorm(head_cfg.get("hidden_dim", 256)),
            nn.GELU(),
            nn.Dropout(head_cfg.get("dropout", 0.2)),
            *[
                layer
                for _ in range(head_cfg.get("num_layers", 2) - 1)
                for layer in [
                    nn.Linear(
                        head_cfg.get("hidden_dim", 256),
                        head_cfg.get("hidden_dim", 256),
                    ),
                    nn.LayerNorm(head_cfg.get("hidden_dim", 256)),
                    nn.GELU(),
                    nn.Dropout(head_cfg.get("dropout", 0.2)),
                ]
            ],
        )

        # Build loss
        training_cfg = config["training"]
        self.loss_fn = CMCBLoss(
            contrastive_weight=training_cfg.get("contrastive_weight", 1.0),
            regression_weight=training_cfg.get("regression_weight", 0.5),
            hard_negative_threshold=training_cfg.get("hard_negative_threshold", 0.7),
            hard_negative_ic50_delta=training_cfg.get("hard_negative_ic50_delta", 1.0),
        )

        # MC Dropout for uncertainty estimation
        self.mc_dropout_enabled = False

        # Log model size
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(
            p.numel() for p in self.parameters() if p.requires_grad
        )
        logger.info(
            f"Model: {total_params:,} total params, "
            f"{trainable_params:,} trainable params"
        )

    def forward(
        self,
        gene_expression: torch.Tensor,
        drug_fingerprint: torch.Tensor,
        ic50: Optional[torch.Tensor] = None,
        sensitive: Optional[torch.Tensor] = None,
        drug_tanimoto: Optional[torch.Tensor] = None,
        **kwargs: Any,
    ) -> Dict[str, torch.Tensor]:
        """Forward pass.

        Args:
            gene_expression: Gene expression features (B, N_genes) or
                pre-extracted genomic embeddings (B, genomic_dim).
            drug_fingerprint: Drug fingerprint features (B, fp_dim) or
                pre-extracted drug embeddings (B, drug_dim).
            ic50: Ground truth IC50 values (B,). Optional, for loss computation.
            sensitive: Ground truth sensitivity labels (B,). Optional.
            drug_tanimoto: Pairwise drug Tanimoto similarity (B, B). Optional.

        Returns:
            Dictionary with predictions and optionally loss values.
        """
        # Encode
        h_g = self.genomic_encoder(gene_expression)
        h_d = self.drug_encoder(drug_fingerprint)

        # Bridge: project to shared space
        z_g, z_d = self.bridge(h_g, h_d)

        # Prediction
        pred_outputs = self.prediction_head(z_g, z_d)

        outputs = {
            "z_g": z_g,
            "z_d": z_d,
            "ic50_pred": pred_outputs["ic50_pred"],
            "sensitivity_logits": pred_outputs["sensitivity_logits"],
        }

        # Compute loss if labels provided
        if ic50 is not None:
            # Get adaptive temperature
            temp = self.bridge.get_adaptive_temperature(drug_tanimoto)

            loss_dict = self.loss_fn(
                z_g=z_g,
                z_d=z_d,
                ic50_pred=pred_outputs["ic50_pred"],
                ic50_true=ic50,
                sensitivity_logits=pred_outputs["sensitivity_logits"],
                sensitivity_true=sensitive,
                temperature=temp,
                drug_tanimoto=drug_tanimoto,
            )
            outputs.update(loss_dict)

        return outputs

    def predict_with_uncertainty(
        self,
        gene_expression: torch.Tensor,
        drug_fingerprint: torch.Tensor,
        n_samples: int = 10,
    ) -> Dict[str, torch.Tensor]:
        """Predict with MC Dropout uncertainty estimation.

        Args:
            gene_expression: Gene expression features (B, N_genes).
            drug_fingerprint: Drug fingerprint features (B, fp_dim).
            n_samples: Number of MC Dropout forward passes.

        Returns:
            Dictionary with mean predictions and uncertainty estimates.
        """
        self.train()  # Enable dropout
        ic50_samples = []
        logit_samples = []

        with torch.no_grad():
            for _ in range(n_samples):
                outputs = self.forward(gene_expression, drug_fingerprint)
                ic50_samples.append(outputs["ic50_pred"])
                logit_samples.append(outputs["sensitivity_logits"])

        self.eval()

        ic50_stack = torch.stack(ic50_samples, dim=0)
        logit_stack = torch.stack(logit_samples, dim=0)

        return {
            "ic50_mean": ic50_stack.mean(dim=0),
            "ic50_std": ic50_stack.std(dim=0),
            "ic50_uncertainty": ic50_stack.var(dim=0),
            "sensitivity_mean": torch.softmax(logit_stack, dim=-1).mean(dim=0),
            "sensitivity_uncertainty": torch.softmax(logit_stack, dim=-1).var(dim=0).sum(dim=-1),
        }

    def freeze_pretrained(self) -> None:
        """Freeze pretrained encoder parameters."""
        if hasattr(self.genomic_encoder, 'encoder'):
            for param in self.genomic_encoder.encoder.parameters():
                param.requires_grad = False
        if hasattr(self.drug_encoder, 'encoder'):
            for param in self.drug_encoder.encoder.parameters():
                param.requires_grad = False
        logger.info("Froze pretrained encoder parameters")

    def unfreeze_last_n_layers(self, n: int) -> None:
        """Unfreeze the last n layers of pretrained encoders for fine-tuning.

        Args:
            n: Number of layers to unfreeze from the end.
        """
        if n <= 0:
            return

        # Unfreeze genomic encoder
        if hasattr(self.genomic_encoder, 'encoder'):
            params = list(self.genomic_encoder.encoder.parameters())
            for param in params[-n * 2:]:  # Each layer has weight + bias
                param.requires_grad = True

        # Unfreeze drug encoder
        if hasattr(self.drug_encoder, 'encoder'):
            params = list(self.drug_encoder.encoder.parameters())
            for param in params[-n * 2:]:
                param.requires_grad = True

        logger.info(f"Unfroze last {n} layers of pretrained encoders")


def build_model(config: Dict[str, Any]) -> GenoDrugAgent:
    """Build GenoDrugAgent model from configuration.

    Args:
        config: Full configuration dictionary.

    Returns:
        Initialized GenoDrugAgent model.
    """
    model = GenoDrugAgent(config)

    # Handle pretrained weight loading
    genomic_cfg = config["model"]["genomic_encoder"]
    if genomic_cfg["name"] == "geneformer" and genomic_cfg.get("pretrained_path"):
        logger.info(
            f"Note: Geneformer pretrained weights from "
            f"'{genomic_cfg['pretrained_path']}' should be loaded externally. "
            f"Use: model.genomic_encoder = load_geneformer(path)"
        )

    drug_cfg = config["model"]["drug_encoder"]
    if drug_cfg["name"] == "unimol" and drug_cfg.get("pretrained_path"):
        logger.info(
            f"Note: Uni-Mol pretrained weights from "
            f"'{drug_cfg['pretrained_path']}' should be loaded externally. "
            f"Use: model.drug_encoder = load_unimol(path)"
        )

    # Freeze/unfreeze
    if genomic_cfg.get("freeze", True):
        model.freeze_pretrained()

    unfreeze_n = genomic_cfg.get("unfreeze_last_n", 0)
    if unfreeze_n > 0:
        model.unfreeze_last_n_layers(unfreeze_n)

    return model
