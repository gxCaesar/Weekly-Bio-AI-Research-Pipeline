"""Evaluation metrics for GenoDrug-Agent.

Implements PCC, RMSE, Spearman correlation, AUROC, AUPRC, and Hit Rate
for drug sensitivity prediction.
"""

from typing import Dict, List, Optional

import numpy as np
from scipy import stats
from sklearn.metrics import (
    average_precision_score,
    mean_squared_error,
    roc_auc_score,
)


def pearson_correlation(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    """Compute Pearson correlation coefficient.

    Args:
        y_pred: Predicted values.
        y_true: Ground truth values.

    Returns:
        Pearson correlation coefficient.
    """
    if len(y_pred) < 2:
        return 0.0
    pcc, _ = stats.pearsonr(y_pred, y_true)
    return float(pcc) if not np.isnan(pcc) else 0.0


def spearman_correlation(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    """Compute Spearman rank correlation coefficient.

    Args:
        y_pred: Predicted values.
        y_true: Ground truth values.

    Returns:
        Spearman correlation coefficient.
    """
    if len(y_pred) < 2:
        return 0.0
    rho, _ = stats.spearmanr(y_pred, y_true)
    return float(rho) if not np.isnan(rho) else 0.0


def rmse(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    """Compute Root Mean Squared Error.

    Args:
        y_pred: Predicted values.
        y_true: Ground truth values.

    Returns:
        RMSE value.
    """
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))


def auroc(
    logits: Optional[np.ndarray],
    labels: Optional[np.ndarray],
) -> float:
    """Compute Area Under ROC Curve.

    Args:
        logits: Prediction logits (N, 2) or probabilities (N,).
        labels: Binary ground truth labels (N,).

    Returns:
        AUROC score, or 0.0 if inputs are invalid.
    """
    if logits is None or labels is None:
        return 0.0
    if len(np.unique(labels)) < 2:
        return 0.0

    if logits.ndim == 2:
        # Use softmax probability of positive class
        from scipy.special import softmax

        probs = softmax(logits, axis=1)[:, 1]
    else:
        probs = logits

    try:
        return float(roc_auc_score(labels, probs))
    except ValueError:
        return 0.0


def auprc(
    logits: Optional[np.ndarray],
    labels: Optional[np.ndarray],
) -> float:
    """Compute Area Under Precision-Recall Curve.

    Args:
        logits: Prediction logits (N, 2) or probabilities (N,).
        labels: Binary ground truth labels (N,).

    Returns:
        AUPRC score, or 0.0 if inputs are invalid.
    """
    if logits is None or labels is None:
        return 0.0
    if len(np.unique(labels)) < 2:
        return 0.0

    if logits.ndim == 2:
        from scipy.special import softmax

        probs = softmax(logits, axis=1)[:, 1]
    else:
        probs = logits

    try:
        return float(average_precision_score(labels, probs))
    except ValueError:
        return 0.0


def hit_rate_at_k(
    y_pred: np.ndarray,
    y_true: np.ndarray,
    k: int = 10,
    threshold_percentile: float = 25.0,
) -> float:
    """Compute Hit Rate@K for drug recommendation.

    Among the top-K predictions (lowest predicted IC50 = most sensitive),
    what fraction are truly sensitive?

    Args:
        y_pred: Predicted IC50 values (lower = more sensitive).
        y_true: Ground truth IC50 values.
        k: Number of top predictions to consider.
        threshold_percentile: Percentile of true IC50 below which a drug
            is considered 'truly sensitive'.

    Returns:
        Hit rate (fraction of top-K that are truly sensitive).
    """
    if len(y_pred) < k:
        k = len(y_pred)
    if k == 0:
        return 0.0

    # True sensitive threshold (low IC50 = sensitive)
    threshold = np.percentile(y_true, threshold_percentile)

    # Top-K predicted sensitive (lowest predicted IC50)
    top_k_indices = np.argsort(y_pred)[:k]

    # Count how many of top-K are truly sensitive
    truly_sensitive = np.sum(y_true[top_k_indices] <= threshold)

    return float(truly_sensitive) / float(k)


def compute_all_metrics(
    y_pred: np.ndarray,
    y_true: np.ndarray,
    logits: Optional[np.ndarray] = None,
    labels_binary: Optional[np.ndarray] = None,
    hit_rate_ks: Optional[List[int]] = None,
) -> Dict[str, float]:
    """Compute all evaluation metrics.

    Args:
        y_pred: Predicted IC50 values (N,).
        y_true: Ground truth IC50 values (N,).
        logits: Classification logits (N, 2). Optional.
        labels_binary: Binary sensitivity labels (N,). Optional.
        hit_rate_ks: List of K values for Hit Rate@K.

    Returns:
        Dictionary mapping metric names to values.
    """
    if hit_rate_ks is None:
        hit_rate_ks = [10, 20, 50]

    metrics = {
        "pcc": pearson_correlation(y_pred, y_true),
        "spearman": spearman_correlation(y_pred, y_true),
        "rmse": rmse(y_pred, y_true),
    }

    # Classification metrics
    if logits is not None and labels_binary is not None:
        metrics["auroc"] = auroc(logits, labels_binary)
        metrics["auprc"] = auprc(logits, labels_binary)

    # Hit rate metrics
    for k in hit_rate_ks:
        metrics[f"hit_rate@{k}"] = hit_rate_at_k(y_pred, y_true, k=k)

    return metrics
