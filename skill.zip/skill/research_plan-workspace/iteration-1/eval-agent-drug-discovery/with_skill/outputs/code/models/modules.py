"""Sub-modules for GenoDrug-Agent.

Includes genomic encoders, drug encoders, the cross-modal contrastive
bridge (CMCB), and prediction heads.
"""

import math
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class MLPEncoder(nn.Module):
    """Multi-layer perceptron encoder for tabular features.

    Args:
        input_dim: Input feature dimension.
        hidden_dim: Hidden layer dimension.
        output_dim: Output embedding dimension.
        num_layers: Number of hidden layers.
        dropout: Dropout rate.
        activation: Activation function name ('relu' or 'gelu').
        layer_norm: Whether to apply layer normalization.
    """

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: int,
        num_layers: int = 3,
        dropout: float = 0.1,
        activation: str = "gelu",
        layer_norm: bool = True,
    ) -> None:
        super().__init__()

        act_fn = nn.GELU() if activation == "gelu" else nn.ReLU()
        layers: List[nn.Module] = []

        # Input layer
        layers.append(nn.Linear(input_dim, hidden_dim))
        if layer_norm:
            layers.append(nn.LayerNorm(hidden_dim))
        layers.append(act_fn)
        layers.append(nn.Dropout(dropout))

        # Hidden layers
        for _ in range(num_layers - 2):
            layers.append(nn.Linear(hidden_dim, hidden_dim))
            if layer_norm:
                layers.append(nn.LayerNorm(hidden_dim))
            layers.append(act_fn)
            layers.append(nn.Dropout(dropout))

        # Output layer
        layers.append(nn.Linear(hidden_dim, output_dim))
        if layer_norm:
            layers.append(nn.LayerNorm(output_dim))

        self.network = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass.

        Args:
            x: Input tensor of shape (batch_size, input_dim).

        Returns:
            Output embeddings of shape (batch_size, output_dim).
        """
        return self.network(x)


class GCNLayer(nn.Module):
    """Simple Graph Convolutional Network layer.

    Args:
        in_dim: Input feature dimension.
        out_dim: Output feature dimension.
    """

    def __init__(self, in_dim: int, out_dim: int) -> None:
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim)

    def forward(
        self, x: torch.Tensor, adj: torch.Tensor
    ) -> torch.Tensor:
        """Forward pass.

        Args:
            x: Node features (N, in_dim).
            adj: Adjacency matrix (N, N).

        Returns:
            Updated node features (N, out_dim).
        """
        # Degree normalization
        deg = adj.sum(dim=1, keepdim=True).clamp(min=1)
        adj_norm = adj / deg
        h = adj_norm @ x
        h = self.linear(h)
        return F.relu(h)


class GenomicEncoder(nn.Module):
    """Encoder for genomic features.

    Supports multiple backends:
    - 'geneformer': Uses pretrained Geneformer (loaded externally)
    - 'mlp': Simple MLP on gene expression vector
    - 'cnn_1d': 1D CNN on gene expression vector

    Args:
        config: Genomic encoder configuration dictionary.
    """

    def __init__(self, config: Dict) -> None:
        super().__init__()
        self.encoder_name = config["name"]
        self.hidden_dim = config["hidden_dim"]
        self.freeze = config.get("freeze", True)

        if self.encoder_name == "geneformer":
            # Geneformer outputs 256-dim embeddings
            # Placeholder: actual Geneformer model loaded in build_model()
            self.projection = nn.Identity()
            self.output_dim = self.hidden_dim

        elif self.encoder_name == "mlp":
            input_dim = config.get("input_dim", 2048)
            num_layers = config.get("num_layers", 3)
            dropout = config.get("dropout", 0.1)
            self.encoder = MLPEncoder(
                input_dim=input_dim,
                hidden_dim=self.hidden_dim,
                output_dim=self.hidden_dim,
                num_layers=num_layers,
                dropout=dropout,
            )
            self.output_dim = self.hidden_dim

        elif self.encoder_name == "cnn_1d":
            input_dim = config.get("input_dim", 2048)
            kernel_size = config.get("kernel_size", 7)
            num_layers = config.get("num_layers", 3)
            dropout = config.get("dropout", 0.1)

            cnn_layers: List[nn.Module] = []
            in_ch = 1
            for i in range(num_layers):
                out_ch = self.hidden_dim // (2 ** (num_layers - 1 - i))
                out_ch = max(out_ch, 32)
                cnn_layers.extend([
                    nn.Conv1d(in_ch, out_ch, kernel_size, padding=kernel_size // 2),
                    nn.BatchNorm1d(out_ch),
                    nn.ReLU(),
                    nn.Dropout(dropout),
                    nn.MaxPool1d(2),
                ])
                in_ch = out_ch

            self.cnn = nn.Sequential(*cnn_layers)
            # Compute output size
            test_len = input_dim
            for _ in range(num_layers):
                test_len = test_len // 2
            self.fc = nn.Linear(in_ch * test_len, self.hidden_dim)
            self.output_dim = self.hidden_dim

        else:
            raise ValueError(f"Unknown genomic encoder: {self.encoder_name}")

    def forward(self, gene_expression: torch.Tensor) -> torch.Tensor:
        """Encode genomic features.

        Args:
            gene_expression: Gene expression tensor.
                For MLP/CNN: (batch_size, n_genes)
                For Geneformer: pre-extracted embeddings (batch_size, hidden_dim)

        Returns:
            Genomic embeddings of shape (batch_size, output_dim).
        """
        if self.encoder_name == "geneformer":
            return self.projection(gene_expression)
        elif self.encoder_name == "mlp":
            return self.encoder(gene_expression)
        elif self.encoder_name == "cnn_1d":
            x = gene_expression.unsqueeze(1)  # (B, 1, N_genes)
            x = self.cnn(x)
            x = x.flatten(1)
            x = self.fc(x)
            return x
        else:
            raise ValueError(f"Unknown encoder: {self.encoder_name}")


class DrugEncoder(nn.Module):
    """Encoder for drug molecular features.

    Supports multiple backends:
    - 'unimol': Uses pretrained Uni-Mol embeddings (loaded externally)
    - 'gcn': Graph convolutional network on molecular graph
    - 'gin': Graph isomorphism network
    - 'fingerprint': MLP on Morgan fingerprints

    Args:
        config: Drug encoder configuration dictionary.
    """

    def __init__(self, config: Dict) -> None:
        super().__init__()
        self.encoder_name = config["name"]
        self.hidden_dim = config["hidden_dim"]
        self.freeze = config.get("freeze", True)

        if self.encoder_name == "unimol":
            self.projection = nn.Identity()
            self.output_dim = self.hidden_dim

        elif self.encoder_name in ("gcn", "gin"):
            num_layers = config.get("num_layers", 3)
            dropout = config.get("dropout", 0.1)
            # For fingerprint-based encoding (simplified GCN on fingerprint)
            self.encoder = MLPEncoder(
                input_dim=2048,  # Morgan fingerprint size
                hidden_dim=self.hidden_dim,
                output_dim=self.hidden_dim,
                num_layers=num_layers,
                dropout=dropout,
                activation="relu",
                layer_norm=False,
            )
            self.output_dim = self.hidden_dim

        elif self.encoder_name == "fingerprint":
            self.encoder = MLPEncoder(
                input_dim=2048,
                hidden_dim=self.hidden_dim,
                output_dim=self.hidden_dim,
                num_layers=3,
                dropout=0.1,
            )
            self.output_dim = self.hidden_dim

        else:
            raise ValueError(f"Unknown drug encoder: {self.encoder_name}")

    def forward(self, drug_features: torch.Tensor) -> torch.Tensor:
        """Encode drug features.

        Args:
            drug_features: Drug feature tensor.
                For Uni-Mol: pre-extracted embeddings (batch_size, hidden_dim)
                For others: fingerprint vector (batch_size, fp_dim)

        Returns:
            Drug embeddings of shape (batch_size, output_dim).
        """
        if self.encoder_name == "unimol":
            return self.projection(drug_features)
        else:
            return self.encoder(drug_features)


class CrossModalContrastiveBridge(nn.Module):
    """Cross-Modal Contrastive Bridge (CMCB) module.

    Projects genomic and drug embeddings into a shared semantic space
    using separate projection heads. Supports structure-aware temperature
    scaling for the contrastive objective.

    Args:
        genomic_dim: Dimension of genomic encoder output.
        drug_dim: Dimension of drug encoder output.
        proj_dims: List of projection layer dimensions.
        dropout: Dropout rate.
        activation: Activation function name.
        layer_norm: Whether to use layer normalization.
        temperature: Initial contrastive temperature.
        temperature_learnable: Whether temperature is a learnable parameter.
    """

    def __init__(
        self,
        genomic_dim: int,
        drug_dim: int,
        proj_dims: Optional[List[int]] = None,
        dropout: float = 0.1,
        activation: str = "gelu",
        layer_norm: bool = True,
        temperature: float = 0.07,
        temperature_learnable: bool = True,
    ) -> None:
        super().__init__()

        if proj_dims is None:
            proj_dims = [512, 512]

        shared_dim = proj_dims[-1]

        # Genomic projection head
        g_layers: List[nn.Module] = []
        g_in = genomic_dim
        act_fn = nn.GELU() if activation == "gelu" else nn.ReLU()

        for dim in proj_dims:
            g_layers.append(nn.Linear(g_in, dim))
            if layer_norm:
                g_layers.append(nn.LayerNorm(dim))
            g_layers.append(act_fn)
            g_layers.append(nn.Dropout(dropout))
            g_in = dim

        self.genomic_projector = nn.Sequential(*g_layers)

        # Drug projection head
        d_layers: List[nn.Module] = []
        d_in = drug_dim

        for dim in proj_dims:
            d_layers.append(nn.Linear(d_in, dim))
            if layer_norm:
                d_layers.append(nn.LayerNorm(dim))
            d_layers.append(act_fn)
            d_layers.append(nn.Dropout(dropout))
            d_in = dim

        self.drug_projector = nn.Sequential(*d_layers)

        # Temperature parameter
        if temperature_learnable:
            self.log_temperature = nn.Parameter(
                torch.tensor(math.log(temperature))
            )
        else:
            self.register_buffer(
                "log_temperature", torch.tensor(math.log(temperature))
            )

        # Structure-aware temperature scaling parameter
        self.alpha = nn.Parameter(torch.tensor(0.1))

        self.shared_dim = shared_dim

    @property
    def temperature(self) -> torch.Tensor:
        """Current temperature value."""
        return self.log_temperature.exp()

    def forward(
        self,
        genomic_emb: torch.Tensor,
        drug_emb: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Project genomic and drug embeddings into shared space.

        Args:
            genomic_emb: Genomic embeddings (batch_size, genomic_dim).
            drug_emb: Drug embeddings (batch_size, drug_dim).

        Returns:
            Tuple of (projected_genomic, projected_drug), each
            L2-normalized and of shape (batch_size, shared_dim).
        """
        z_g = self.genomic_projector(genomic_emb)
        z_d = self.drug_projector(drug_emb)

        # L2 normalize
        z_g = F.normalize(z_g, p=2, dim=-1)
        z_d = F.normalize(z_d, p=2, dim=-1)

        return z_g, z_d

    def get_adaptive_temperature(
        self, drug_tanimoto: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """Compute structure-aware adaptive temperature matrix.

        Args:
            drug_tanimoto: Pairwise Tanimoto similarity (B, B).
                If None, returns scalar base temperature.

        Returns:
            Temperature scalar or matrix (B, B).
        """
        base_temp = self.temperature
        if drug_tanimoto is None:
            return base_temp
        # Structure-aware scaling: higher temp for structurally similar pairs
        temp_matrix = base_temp * (1.0 + self.alpha * drug_tanimoto)
        return temp_matrix


class PredictionHead(nn.Module):
    """Prediction head for IC50 regression and sensitivity classification.

    Takes concatenated genomic and drug embeddings from the bridge
    and predicts drug sensitivity.

    Args:
        input_dim: Input dimension (2 * shared_dim from bridge).
        hidden_dim: Hidden layer dimension.
        dropout: Dropout rate.
        num_layers: Number of hidden layers.
    """

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int = 256,
        dropout: float = 0.2,
        num_layers: int = 2,
    ) -> None:
        super().__init__()

        layers: List[nn.Module] = []

        # Hidden layers
        in_dim = input_dim
        for _ in range(num_layers):
            layers.extend([
                nn.Linear(in_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(dropout),
            ])
            in_dim = hidden_dim

        self.shared_layers = nn.Sequential(*layers)

        # Regression head (IC50 prediction)
        self.regression_head = nn.Linear(hidden_dim, 1)

        # Classification head (sensitive/resistant)
        self.classification_head = nn.Linear(hidden_dim, 2)

    def forward(
        self, z_g: torch.Tensor, z_d: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """Forward pass.

        Args:
            z_g: Projected genomic embeddings (batch_size, shared_dim).
            z_d: Projected drug embeddings (batch_size, shared_dim).

        Returns:
            Dictionary with:
                - ic50_pred: Predicted IC50 (batch_size, 1)
                - sensitivity_logits: Classification logits (batch_size, 2)
                - shared_repr: Shared representation (batch_size, hidden_dim)
        """
        # Concatenate and elementwise product
        combined = torch.cat([z_g, z_d, z_g * z_d], dim=-1)

        # This requires input_dim = 3 * shared_dim
        # If input_dim was set to 2 * shared_dim, adjust by using a linear layer
        if hasattr(self, '_input_adapter'):
            combined = self._input_adapter(combined)

        shared = self.shared_layers(combined)

        ic50_pred = self.regression_head(shared)
        sensitivity_logits = self.classification_head(shared)

        return {
            "ic50_pred": ic50_pred.squeeze(-1),
            "sensitivity_logits": sensitivity_logits,
            "shared_repr": shared,
        }
