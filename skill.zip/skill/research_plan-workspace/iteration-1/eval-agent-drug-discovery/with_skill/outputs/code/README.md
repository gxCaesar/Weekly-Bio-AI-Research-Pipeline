# GenoDrug-Agent: Genome-Aware Multi-Agent Drug Discovery Framework

A multi-agent framework for drug sensitivity prediction that bridges genomic representations and drug molecular representations via cross-modal contrastive learning.

## Overview

GenoDrug-Agent integrates pretrained genomic foundation models (Geneformer) with drug molecular models (Uni-Mol) through a novel Cross-Modal Contrastive Bridge (CMCB) module. The framework uses a multi-agent architecture for end-to-end drug discovery from genomic data.

## Project Structure

```
code/
├── configs/          # YAML configuration files
├── data/             # Data download, preprocessing, dataset classes
├── models/           # Model architecture (encoders, bridge, losses)
├── baselines/        # Baseline implementations (DeepCDR, GraphDRP)
├── training/         # Training loop, optimizer, callbacks
├── evaluation/       # Metrics, evaluation pipeline, visualization
├── scripts/          # Shell scripts for running experiments
├── ablation/         # Ablation study orchestrator
├── main.py           # CLI entry point
└── requirements.txt  # Python dependencies
```

## Quick Start

### 1. Environment Setup

```bash
conda create -n genodrug python=3.10 -y
conda activate genodrug
pip install -r requirements.txt
```

### 2. Download Data

```bash
python data/download.py --dataset all --output_dir data/raw/
```

### 3. Preprocess Data

```bash
python data/preprocess.py \
    --expression_path data/raw/gdsc/gdsc_expression_raw.csv \
    --response_path data/raw/gdsc/gdsc_ic50_raw.csv \
    --smiles_path data/raw/gdsc/drug_smiles.csv \
    --output_dir data/processed/
```

### 4. Train Model

```bash
python main.py --config configs/default.yaml --mode train_eval --output_dir outputs/main
```

### 5. Run Baselines

```bash
bash scripts/run_baselines.sh
```

### 6. Run Ablation Studies

```bash
bash scripts/run_ablation.sh
```

## Hardware Requirements

- GPU: NVIDIA A100 80GB (1-2 recommended)
- RAM: 32GB minimum
- Disk: 50GB for data and checkpoints

## Configuration

All hyperparameters are controlled via YAML configs in `configs/`. Key parameters:

- `training.learning_rate`: Learning rate (default: 1e-4)
- `training.batch_size`: Batch size (default: 128)
- `training.contrastive_weight`: Weight for contrastive loss
- `training.temperature`: InfoNCE temperature

## Citation

If you use this code, please cite our paper (forthcoming, ICML 2026 submission).

## License

MIT License
