"""PyTorch Dataset classes for GenoDrug-Agent.

Provides DrugSensitivityDataset for standard training and
ColdStartDataset for cold-start evaluation.
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

logger = logging.getLogger(__name__)


class DrugSensitivityDataset(Dataset):
    """Dataset for drug sensitivity prediction.

    Each sample is a (cell_line_expression, drug_features, ic50_label) triple.

    Args:
        split_csv: Path to the split CSV file (e.g., split_train.csv).
        expression_csv: Path to preprocessed gene expression CSV.
        drug_info_csv: Path to drug info CSV with SMILES.
        drug_fingerprints_path: Path to precomputed drug fingerprints .npy.
        max_genes: Maximum number of genes to use.
        return_smiles: Whether to include SMILES string in output.
    """

    def __init__(
        self,
        split_csv: str,
        expression_csv: str,
        drug_info_csv: str,
        drug_fingerprints_path: str,
        max_genes: int = 2048,
        return_smiles: bool = False,
    ) -> None:
        super().__init__()
        self.return_smiles = return_smiles
        self.max_genes = max_genes

        # Load split data
        self.split_df = pd.read_csv(split_csv)
        logger.info(f"Loaded split with {len(self.split_df)} records")

        # Load expression data
        self.expression_df = pd.read_csv(expression_csv, index_col=0)
        self.gene_names = self.expression_df.columns.tolist()[:max_genes]
        self.expression_df = self.expression_df[self.gene_names]
        logger.info(
            f"Expression: {self.expression_df.shape[0]} cell lines, "
            f"{len(self.gene_names)} genes"
        )

        # Load drug info
        self.drug_df = pd.read_csv(drug_info_csv)
        self.drug_id_to_idx = {
            did: idx for idx, did in enumerate(self.drug_df["drug_id"])
        }
        self.drug_smiles = dict(
            zip(self.drug_df["drug_id"], self.drug_df["canonical_smiles"])
        )

        # Load fingerprints
        self.drug_fingerprints = np.load(drug_fingerprints_path)
        logger.info(f"Drug fingerprints shape: {self.drug_fingerprints.shape}")

        # Build cell line expression cache
        self._expression_cache: Dict[str, np.ndarray] = {}

    def _get_expression(self, cell_line: str) -> np.ndarray:
        """Get gene expression vector for a cell line (with caching).

        Args:
            cell_line: Cell line name.

        Returns:
            Expression vector of shape (max_genes,).
        """
        if cell_line not in self._expression_cache:
            if cell_line in self.expression_df.index:
                expr = self.expression_df.loc[cell_line].values.astype(np.float32)
            else:
                logger.warning(
                    f"Cell line {cell_line} not found in expression data, "
                    "using zeros"
                )
                expr = np.zeros(len(self.gene_names), dtype=np.float32)
            self._expression_cache[cell_line] = expr
        return self._expression_cache[cell_line]

    def _get_drug_features(self, drug_id: str) -> np.ndarray:
        """Get drug fingerprint features.

        Args:
            drug_id: Drug identifier.

        Returns:
            Fingerprint vector.
        """
        if drug_id in self.drug_id_to_idx:
            idx = self.drug_id_to_idx[drug_id]
            return self.drug_fingerprints[idx].astype(np.float32)
        else:
            logger.warning(f"Drug {drug_id} not found, using zeros")
            return np.zeros(self.drug_fingerprints.shape[1], dtype=np.float32)

    def __len__(self) -> int:
        return len(self.split_df)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """Get a single sample.

        Args:
            idx: Sample index.

        Returns:
            Dictionary with keys:
                - gene_expression: (max_genes,) float tensor
                - drug_fingerprint: (fp_dim,) float tensor
                - ic50: scalar float tensor
                - sensitive: scalar long tensor (binary label)
                - cell_line: string (cell line name)
                - drug_id: string (drug identifier)
        """
        row = self.split_df.iloc[idx]

        gene_expr = self._get_expression(row["cell_line"])
        drug_fp = self._get_drug_features(row["drug_id"])

        sample = {
            "gene_expression": torch.from_numpy(gene_expr),
            "drug_fingerprint": torch.from_numpy(drug_fp),
            "ic50": torch.tensor(row["ic50_zscore"], dtype=torch.float32),
            "sensitive": torch.tensor(row["sensitive"], dtype=torch.long),
            "cell_line": row["cell_line"],
            "drug_id": str(row["drug_id"]),
        }

        if self.return_smiles:
            sample["smiles"] = self.drug_smiles.get(row["drug_id"], "")

        return sample


class ColdStartDataset(DrugSensitivityDataset):
    """Dataset for cold-start evaluation scenarios.

    Extends DrugSensitivityDataset with tracking of which entities
    are unseen during training.

    Args:
        split_csv: Path to cold-start split CSV.
        expression_csv: Path to expression CSV.
        drug_info_csv: Path to drug info CSV.
        drug_fingerprints_path: Path to fingerprints.
        train_cell_lines: Set of cell lines seen during training.
        train_drug_ids: Set of drug IDs seen during training.
        max_genes: Maximum number of genes.
    """

    def __init__(
        self,
        split_csv: str,
        expression_csv: str,
        drug_info_csv: str,
        drug_fingerprints_path: str,
        train_cell_lines: Optional[set] = None,
        train_drug_ids: Optional[set] = None,
        max_genes: int = 2048,
    ) -> None:
        super().__init__(
            split_csv=split_csv,
            expression_csv=expression_csv,
            drug_info_csv=drug_info_csv,
            drug_fingerprints_path=drug_fingerprints_path,
            max_genes=max_genes,
            return_smiles=True,
        )
        self.train_cell_lines = train_cell_lines or set()
        self.train_drug_ids = train_drug_ids or set()

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """Get sample with cold-start metadata.

        Returns:
            Sample dict with additional keys:
                - is_cold_cell: bool (cell line not in training)
                - is_cold_drug: bool (drug not in training)
        """
        sample = super().__getitem__(idx)
        sample["is_cold_cell"] = sample["cell_line"] not in self.train_cell_lines
        sample["is_cold_drug"] = sample["drug_id"] not in self.train_drug_ids
        return sample


def build_datasets(
    data_dir: str,
    max_genes: int = 2048,
) -> Dict[str, Dataset]:
    """Build all datasets from processed data directory.

    Args:
        data_dir: Path to processed data directory.
        max_genes: Maximum genes to use.

    Returns:
        Dictionary mapping split names to Dataset objects.
    """
    data_dir = Path(data_dir)

    expression_csv = str(data_dir / "gene_expression.csv")
    drug_info_csv = str(data_dir / "drug_info.csv")
    drug_fp_path = str(data_dir / "drug_fingerprints.npy")

    datasets = {}

    # Standard splits
    for split_name in ["train", "val", "test"]:
        split_csv = str(data_dir / f"split_{split_name}.csv")
        if Path(split_csv).exists():
            datasets[split_name] = DrugSensitivityDataset(
                split_csv=split_csv,
                expression_csv=expression_csv,
                drug_info_csv=drug_info_csv,
                drug_fingerprints_path=drug_fp_path,
                max_genes=max_genes,
            )

    # Get training entities for cold-start
    train_df = pd.read_csv(data_dir / "split_train.csv")
    train_cell_lines = set(train_df["cell_line"].unique())
    train_drug_ids = set(train_df["drug_id"].astype(str).unique())

    # Cold-start splits
    for cold_name in ["test_cold_drug", "test_cold_cell", "test_cold_both"]:
        split_csv = str(data_dir / f"split_{cold_name}.csv")
        if Path(split_csv).exists():
            datasets[cold_name] = ColdStartDataset(
                split_csv=split_csv,
                expression_csv=expression_csv,
                drug_info_csv=drug_info_csv,
                drug_fingerprints_path=drug_fp_path,
                train_cell_lines=train_cell_lines,
                train_drug_ids=train_drug_ids,
                max_genes=max_genes,
            )

    logger.info(f"Built datasets: {list(datasets.keys())}")
    return datasets
