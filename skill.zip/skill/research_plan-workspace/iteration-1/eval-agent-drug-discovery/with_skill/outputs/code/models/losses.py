"""Loss functions for GenoDrug-Agent.

Includes the combined CMCB loss (contrastive + regression) and
the Structure-Aware InfoNCE loss.
"""

from typing import Dict, Optional, Union

import torch
import torch.nn as nn
import torch.nn.functional as F


class StructureAwareInfoNCE(nn.Module):
    """Structure-Aware InfoNCE contrastive loss.

    Extends standard InfoNCE with:
    1. Structure-aware temperature scaling based on drug chemical similarity
    2. Hard negative mining based on structural similarity + activity difference

    Args:
        hard_negative_threshold: Tanimoto similarity threshold for hard negatives.
        hard_negative_ic50_delta: Minimum IC50 difference for hard negatives.
    """

    def __init__(
        self,
        hard_negative_threshold: float = 0.7,
        hard_negative_ic50_delta: float = 1.0,
    ) -> None:
        super().__init__()
        self.hard_neg_threshold = hard_negative_threshold
        self.hard_neg_delta = hard_negative_ic50_delta

    def forward(
        self,
        z_g: torch.Tensor,
        z_d: torch.Tensor,
        temperature: Union[torch.Tensor, float],
        drug_tanimoto: Optional[torch.Tensor] = None,
        ic50_true: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Compute Structure-Aware InfoNCE loss.

        Args:
            z_g: Normalized genomic embeddings (B, D).
            z_d: Normalized drug embeddings (B, D).
            temperature: Temperature scalar or matrix (B, B).
            drug_tanimoto: Pairwise drug Tanimoto similarity (B, B). Optional.
            ic50_true: Ground truth IC50 values (B,). Optional for hard neg mining.

        Returns:
            Scalar loss value.
        """
        batch_size = z_g.shape[0]
        device = z_g.device

        # Compute similarity matrix
        sim_matrix = z_g @ z_d.T  # (B, B)

        # Apply temperature scaling
        if isinstance(temperature, torch.Tensor) and temperature.dim() == 2:
            # Structure-aware temperature (B, B)
            logits = sim_matrix / temperature
        else:
            logits = sim_matrix / temperature

        # Labels: diagonal entries are positive pairs
        labels = torch.arange(batch_size, device=device)

        # Hard negative mining mask
        if (
            self.hard_neg_threshold > 0
            and drug_tanimoto is not None
            and ic50_true is not None
        ):
            # Compute IC50 pairwise distance
            ic50_diff = torch.abs(
                ic50_true.unsqueeze(1) - ic50_true.unsqueeze(0)
            )  # (B, B)

            # Hard negatives: structurally similar but different activity
            hard_neg_mask = (drug_tanimoto > self.hard_neg_threshold) & (
                ic50_diff > self.hard_neg_delta
            )

            # Boost hard negatives by adding a small positive value to logits
            hard_neg_boost = hard_neg_mask.float() * 0.5
            logits = logits + hard_neg_boost

        # Symmetric loss: genomic->drug and drug->genomic
        loss_g2d = F.cross_entropy(logits, labels)
        loss_d2g = F.cross_entropy(logits.T, labels)

        loss = (loss_g2d + loss_d2g) / 2.0
        return loss


class CMCBLoss(nn.Module):
    """Combined CMCB loss for GenoDrug-Agent.

    Combines:
    1. Structure-Aware InfoNCE contrastive loss (cross-modal alignment)
    2. IC50 regression loss (MSE)
    3. Sensitivity classification loss (cross-entropy, optional)

    Args:
        contrastive_weight: Weight for contrastive loss.
        regression_weight: Weight for regression loss.
        classification_weight: Weight for classification loss.
        hard_negative_threshold: Tanimoto threshold for hard negatives.
        hard_negative_ic50_delta: IC50 difference threshold for hard negatives.
    """

    def __init__(
        self,
        contrastive_weight: float = 1.0,
        regression_weight: float = 0.5,
        classification_weight: float = 0.1,
        hard_negative_threshold: float = 0.7,
        hard_negative_ic50_delta: float = 1.0,
    ) -> None:
        super().__init__()
        self.contrastive_weight = contrastive_weight
        self.regression_weight = regression_weight
        self.classification_weight = classification_weight

        self.contrastive_loss = StructureAwareInfoNCE(
            hard_negative_threshold=hard_negative_threshold,
            hard_negative_ic50_delta=hard_negative_ic50_delta,
        )
        self.regression_loss = nn.MSELoss()
        self.classification_loss = nn.CrossEntropyLoss()

    def forward(
        self,
        z_g: torch.Tensor,
        z_d: torch.Tensor,
        ic50_pred: torch.Tensor,
        ic50_true: torch.Tensor,
        sensitivity_logits: Optional[torch.Tensor] = None,
        sensitivity_true: Optional[torch.Tensor] = None,
        temperature: Union[torch.Tensor, float] = 0.07,
        drug_tanimoto: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """Compute combined loss.

        Args:
            z_g: Normalized genomic embeddings (B, D).
            z_d: Normalized drug embeddings (B, D).
            ic50_pred: Predicted IC50 values (B,).
            ic50_true: Ground truth IC50 values (B,).
            sensitivity_logits: Classification logits (B, 2). Optional.
            sensitivity_true: Ground truth sensitivity labels (B,). Optional.
            temperature: Contrastive temperature.
            drug_tanimoto: Drug structural similarity (B, B). Optional.

        Returns:
            Dictionary with:
                - loss: Total combined loss
                - loss_contrastive: Contrastive component
                - loss_regression: Regression component
                - loss_classification: Classification component (if applicable)
        """
        losses = {}
        total_loss = torch.tensor(0.0, device=z_g.device)

        # Contrastive loss
        if self.contrastive_weight > 0:
            l_contrastive = self.contrastive_loss(
                z_g=z_g,
                z_d=z_d,
                temperature=temperature,
                drug_tanimoto=drug_tanimoto,
                ic50_true=ic50_true,
            )
            losses["loss_contrastive"] = l_contrastive
            total_loss = total_loss + self.contrastive_weight * l_contrastive

        # Regression loss
        if self.regression_weight > 0:
            l_regression = self.regression_loss(ic50_pred, ic50_true)
            losses["loss_regression"] = l_regression
            total_loss = total_loss + self.regression_weight * l_regression

        # Classification loss
        if (
            self.classification_weight > 0
            and sensitivity_logits is not None
            and sensitivity_true is not None
        ):
            l_classification = self.classification_loss(
                sensitivity_logits, sensitivity_true
            )
            losses["loss_classification"] = l_classification
            total_loss = total_loss + self.classification_weight * l_classification

        losses["loss"] = total_loss
        return losses
