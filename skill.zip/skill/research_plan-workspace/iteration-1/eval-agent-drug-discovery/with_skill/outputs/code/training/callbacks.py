"""Training callbacks for GenoDrug-Agent.

Provides checkpointing, early stopping, and wandb logging callbacks.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

import torch

logger = logging.getLogger(__name__)


class CheckpointCallback:
    """Callback for saving model checkpoints.

    Saves the best model (by validation metric) and periodic checkpoints.

    Args:
        output_dir: Directory to save checkpoints.
        save_every: Save checkpoint every N epochs.
        save_best: Whether to save the best model.
        save_last: Whether to save the last model.
        metric_name: Metric to monitor for best model (higher is better).
    """

    def __init__(
        self,
        output_dir: str,
        save_every: int = 10,
        save_best: bool = True,
        save_last: bool = True,
        metric_name: str = "val_pcc",
    ) -> None:
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.save_every = save_every
        self.save_best = save_best
        self.save_last = save_last
        self.metric_name = metric_name
        self.best_metric = float("-inf")
        self.best_epoch = -1

    def on_epoch_end(
        self,
        epoch: int,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        metrics: Dict[str, float],
        config: Dict[str, Any],
    ) -> None:
        """Called at the end of each epoch.

        Args:
            epoch: Current epoch number.
            model: The model to save.
            optimizer: The optimizer state to save.
            metrics: Evaluation metrics dictionary.
            config: Training configuration.
        """
        checkpoint = {
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "metrics": metrics,
            "config": config,
        }

        # Save periodic checkpoint
        if self.save_every > 0 and (epoch + 1) % self.save_every == 0:
            path = self.output_dir / f"checkpoint_epoch_{epoch + 1}.pt"
            torch.save(checkpoint, path)
            logger.info(f"Saved checkpoint: {path}")

        # Save last checkpoint
        if self.save_last:
            path = self.output_dir / "last.pt"
            torch.save(checkpoint, path)

        # Save best checkpoint
        if self.save_best and self.metric_name in metrics:
            current_metric = metrics[self.metric_name]
            if current_metric > self.best_metric:
                self.best_metric = current_metric
                self.best_epoch = epoch
                path = self.output_dir / "best_model.pt"
                torch.save(checkpoint, path)
                logger.info(
                    f"New best model at epoch {epoch + 1}: "
                    f"{self.metric_name} = {current_metric:.4f}"
                )

        # Save metrics history
        metrics_path = self.output_dir / "metrics_history.jsonl"
        with open(metrics_path, "a") as f:
            record = {"epoch": epoch + 1, **metrics}
            f.write(json.dumps(record) + "\n")


class EarlyStoppingCallback:
    """Callback for early stopping based on validation metric.

    Args:
        patience: Number of epochs without improvement before stopping.
        metric_name: Metric to monitor (higher is better).
        min_delta: Minimum change to qualify as improvement.
    """

    def __init__(
        self,
        patience: int = 20,
        metric_name: str = "val_pcc",
        min_delta: float = 0.001,
    ) -> None:
        self.patience = patience
        self.metric_name = metric_name
        self.min_delta = min_delta
        self.best_metric = float("-inf")
        self.epochs_without_improvement = 0
        self.should_stop = False

    def on_epoch_end(self, metrics: Dict[str, float]) -> bool:
        """Check if training should stop.

        Args:
            metrics: Evaluation metrics dictionary.

        Returns:
            True if training should stop.
        """
        if self.metric_name not in metrics:
            return False

        current = metrics[self.metric_name]
        if current > self.best_metric + self.min_delta:
            self.best_metric = current
            self.epochs_without_improvement = 0
        else:
            self.epochs_without_improvement += 1

        if self.epochs_without_improvement >= self.patience:
            self.should_stop = True
            logger.info(
                f"Early stopping triggered after {self.patience} epochs "
                f"without improvement. Best {self.metric_name}: "
                f"{self.best_metric:.4f}"
            )
            return True

        return False


class WandbCallback:
    """Callback for Weights & Biases logging.

    Args:
        project: W&B project name.
        entity: W&B entity (team/user).
        config: Training configuration to log.
        run_name: Optional run name.
    """

    def __init__(
        self,
        project: str = "genodrug-agent",
        entity: Optional[str] = None,
        config: Optional[Dict] = None,
        run_name: Optional[str] = None,
    ) -> None:
        self.enabled = False
        try:
            import wandb

            self.wandb = wandb
            wandb.init(
                project=project,
                entity=entity,
                config=config,
                name=run_name,
            )
            self.enabled = True
            logger.info(f"W&B initialized: {project}")
        except ImportError:
            logger.warning(
                "wandb not installed. Install with: pip install wandb"
            )
        except Exception as e:
            logger.warning(f"Failed to initialize wandb: {e}")

    def log(self, metrics: Dict[str, float], step: int) -> None:
        """Log metrics to W&B.

        Args:
            metrics: Metrics dictionary.
            step: Current training step.
        """
        if self.enabled:
            self.wandb.log(metrics, step=step)

    def finish(self) -> None:
        """Finish the W&B run."""
        if self.enabled:
            self.wandb.finish()
