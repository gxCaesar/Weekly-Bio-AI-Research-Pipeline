"""Visualization utilities for GenoDrug-Agent.

Generates publication-quality plots for results analysis.
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

logger = logging.getLogger(__name__)

# Publication-quality plot settings
plt.rcParams.update({
    "font.size": 12,
    "axes.titlesize": 14,
    "axes.labelsize": 13,
    "xtick.labelsize": 11,
    "ytick.labelsize": 11,
    "legend.fontsize": 11,
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "font.family": "sans-serif",
})


def plot_scatter_predictions(
    predictions_path: str,
    output_path: str,
    title: str = "Predicted vs. True IC50",
) -> None:
    """Plot scatter plot of predicted vs true IC50 values.

    Args:
        predictions_path: Path to .npz file with predictions and labels.
        output_path: Path to save the plot.
        title: Plot title.
    """
    data = np.load(predictions_path)
    preds = data["predictions"]
    labels = data["labels"]

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(labels, preds, alpha=0.3, s=10, c="#2563eb")

    # Add diagonal line
    lims = [
        min(labels.min(), preds.min()),
        max(labels.max(), preds.max()),
    ]
    ax.plot(lims, lims, "r--", alpha=0.8, linewidth=1.5, label="y = x")

    # Compute correlation
    from scipy import stats

    pcc, _ = stats.pearsonr(preds, labels)
    ax.text(
        0.05, 0.95, f"PCC = {pcc:.4f}",
        transform=ax.transAxes, fontsize=12,
        verticalalignment="top",
        bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5),
    )

    ax.set_xlabel("True IC50 (z-score)")
    ax.set_ylabel("Predicted IC50 (z-score)")
    ax.set_title(title)
    ax.legend()
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Saved scatter plot: {output_path}")


def plot_method_comparison(
    results: Dict[str, Dict[str, float]],
    output_path: str,
    metrics: Optional[List[str]] = None,
) -> None:
    """Plot bar chart comparing methods across metrics.

    Args:
        results: Dict mapping method names to metric dictionaries.
        output_path: Path to save the plot.
        metrics: List of metric names to plot.
    """
    if metrics is None:
        metrics = ["pcc", "spearman", "auroc"]

    methods = list(results.keys())
    n_metrics = len(metrics)
    n_methods = len(methods)

    fig, axes = plt.subplots(1, n_metrics, figsize=(5 * n_metrics, 5))
    if n_metrics == 1:
        axes = [axes]

    colors = sns.color_palette("Set2", n_methods)

    for i, metric in enumerate(metrics):
        values = [results[m].get(metric, 0) for m in methods]
        bars = axes[i].bar(range(n_methods), values, color=colors)
        axes[i].set_xticks(range(n_methods))
        axes[i].set_xticklabels(methods, rotation=45, ha="right")
        axes[i].set_ylabel(metric.upper())
        axes[i].set_title(metric.upper())

        # Add value labels on bars
        for bar, val in zip(bars, values):
            axes[i].text(
                bar.get_x() + bar.get_width() / 2.0,
                bar.get_height() + 0.005,
                f"{val:.3f}",
                ha="center",
                va="bottom",
                fontsize=9,
            )

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Saved comparison plot: {output_path}")


def plot_ablation_heatmap(
    ablation_results: Dict[str, Dict[str, float]],
    output_path: str,
    metrics: Optional[List[str]] = None,
) -> None:
    """Plot heatmap of ablation study results.

    Args:
        ablation_results: Dict mapping ablation names to metric dicts.
        output_path: Path to save the plot.
        metrics: Metrics to include.
    """
    if metrics is None:
        metrics = ["pcc", "rmse", "spearman", "auroc"]

    ablation_names = list(ablation_results.keys())
    data = np.zeros((len(ablation_names), len(metrics)))

    for i, name in enumerate(ablation_names):
        for j, metric in enumerate(metrics):
            data[i, j] = ablation_results[name].get(metric, 0)

    fig, ax = plt.subplots(figsize=(8, max(4, len(ablation_names) * 0.6)))
    sns.heatmap(
        data,
        annot=True,
        fmt=".3f",
        xticklabels=[m.upper() for m in metrics],
        yticklabels=ablation_names,
        cmap="YlOrRd_r",
        ax=ax,
    )
    ax.set_title("Ablation Study Results")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Saved ablation heatmap: {output_path}")


def plot_training_curves(
    metrics_history_path: str,
    output_path: str,
) -> None:
    """Plot training curves from metrics history.

    Args:
        metrics_history_path: Path to metrics_history.jsonl file.
        output_path: Path to save the plot.
    """
    records = []
    with open(metrics_history_path) as f:
        for line in f:
            records.append(json.loads(line))

    if not records:
        logger.warning("No training records found")
        return

    epochs = [r["epoch"] for r in records]

    fig, axes = plt.subplots(1, 3, figsize=(15, 4))

    # Loss curve
    if "val_loss" in records[0]:
        losses = [r.get("val_loss", 0) for r in records]
        axes[0].plot(epochs, losses, "b-", linewidth=2)
        axes[0].set_xlabel("Epoch")
        axes[0].set_ylabel("Validation Loss")
        axes[0].set_title("Loss Curve")
        axes[0].grid(True, alpha=0.3)

    # PCC curve
    if "val_pcc" in records[0]:
        pccs = [r.get("val_pcc", 0) for r in records]
        axes[1].plot(epochs, pccs, "g-", linewidth=2)
        axes[1].set_xlabel("Epoch")
        axes[1].set_ylabel("Validation PCC")
        axes[1].set_title("PCC Curve")
        axes[1].grid(True, alpha=0.3)

    # RMSE curve
    if "val_rmse" in records[0]:
        rmses = [r.get("val_rmse", 0) for r in records]
        axes[2].plot(epochs, rmses, "r-", linewidth=2)
        axes[2].set_xlabel("Epoch")
        axes[2].set_ylabel("Validation RMSE")
        axes[2].set_title("RMSE Curve")
        axes[2].grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Saved training curves: {output_path}")


def plot_results(eval_dir: str) -> None:
    """Generate all visualization plots from evaluation results.

    Args:
        eval_dir: Directory containing evaluation result files.
    """
    eval_dir = Path(eval_dir)
    plots_dir = eval_dir / "plots"
    plots_dir.mkdir(exist_ok=True)

    # Scatter plot for main test set
    pred_path = eval_dir / "predictions_test.npz"
    if pred_path.exists():
        plot_scatter_predictions(
            str(pred_path),
            str(plots_dir / "scatter_test.png"),
        )

    # Training curves
    history_path = eval_dir / "metrics_history.jsonl"
    if history_path.exists():
        plot_training_curves(
            str(history_path),
            str(plots_dir / "training_curves.png"),
        )

    # Summary comparison if available
    summary_path = eval_dir / "eval_summary.json"
    if summary_path.exists():
        with open(summary_path) as f:
            summary = json.load(f)
        plot_method_comparison(
            summary,
            str(plots_dir / "dataset_comparison.png"),
        )

    logger.info(f"All plots saved to: {plots_dir}")
