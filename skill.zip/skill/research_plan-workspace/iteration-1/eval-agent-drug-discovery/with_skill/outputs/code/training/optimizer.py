"""Optimizer and scheduler factories for GenoDrug-Agent.

Supports AdamW optimizer with linear warmup + cosine decay schedule.
"""

import math
from typing import Any, Dict, Iterator

import torch
import torch.optim as optim
from torch.optim.lr_scheduler import LambdaLR


def build_optimizer(
    params: Iterator[torch.nn.Parameter],
    config: Dict[str, Any],
) -> optim.Optimizer:
    """Build optimizer from configuration.

    Args:
        params: Model parameters to optimize.
        config: Training configuration dictionary.

    Returns:
        Configured optimizer.
    """
    lr = config.get("learning_rate", 1e-4)
    weight_decay = config.get("weight_decay", 0.01)

    optimizer = optim.AdamW(
        params,
        lr=lr,
        weight_decay=weight_decay,
        betas=(0.9, 0.999),
        eps=1e-8,
    )

    return optimizer


def build_scheduler(
    optimizer: optim.Optimizer,
    config: Dict[str, Any],
    num_training_steps: int,
) -> LambdaLR:
    """Build learning rate scheduler with warmup and cosine decay.

    Args:
        optimizer: The optimizer to schedule.
        config: Training configuration dictionary.
        num_training_steps: Total number of training steps.

    Returns:
        Learning rate scheduler.
    """
    warmup_ratio = config.get("warmup_ratio", 0.1)
    num_warmup_steps = int(num_training_steps * warmup_ratio)

    def lr_lambda(current_step: int) -> float:
        """Compute learning rate multiplier.

        Linear warmup followed by cosine decay.
        """
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1, num_warmup_steps))
        progress = float(current_step - num_warmup_steps) / float(
            max(1, num_training_steps - num_warmup_steps)
        )
        return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))

    scheduler = LambdaLR(optimizer, lr_lambda)
    return scheduler
