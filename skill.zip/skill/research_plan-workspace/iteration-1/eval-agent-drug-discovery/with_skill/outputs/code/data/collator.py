"""Data collation functions for GenoDrug-Agent.

Handles batching of heterogeneous data types (tensors, strings, etc.)
for the DataLoader.
"""

from typing import Any, Dict, List

import torch


class DrugSensitivityCollator:
    """Custom collator for drug sensitivity prediction batches.

    Handles mixed data types: tensors are stacked, strings are kept as lists.
    """

    def __call__(self, batch: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Collate a list of samples into a batch.

        Args:
            batch: List of sample dictionaries from Dataset.__getitem__.

        Returns:
            Collated batch dictionary with stacked tensors and string lists.
        """
        collated = {}

        # Identify tensor keys and non-tensor keys
        tensor_keys = []
        string_keys = []
        bool_keys = []

        for key in batch[0].keys():
            val = batch[0][key]
            if isinstance(val, torch.Tensor):
                tensor_keys.append(key)
            elif isinstance(val, bool):
                bool_keys.append(key)
            elif isinstance(val, str):
                string_keys.append(key)

        # Stack tensor fields
        for key in tensor_keys:
            collated[key] = torch.stack([sample[key] for sample in batch])

        # Collect string fields as lists
        for key in string_keys:
            collated[key] = [sample[key] for sample in batch]

        # Collect bool fields as tensors
        for key in bool_keys:
            collated[key] = torch.tensor(
                [sample[key] for sample in batch], dtype=torch.bool
            )

        return collated


class ContrastiveCollator(DrugSensitivityCollator):
    """Collator that adds contrastive learning metadata to batches.

    Precomputes drug-drug structural similarity within the batch
    for hard negative mining.

    Args:
        drug_tanimoto_path: Path to precomputed Tanimoto similarity matrix.
        drug_id_list: Ordered list of drug IDs matching the Tanimoto matrix.
    """

    def __init__(
        self,
        drug_tanimoto_path: str,
        drug_id_list: List[str],
    ) -> None:
        super().__init__()
        import numpy as np

        self.tanimoto_matrix = np.load(drug_tanimoto_path)
        self.drug_id_to_idx = {did: i for i, did in enumerate(drug_id_list)}

    def __call__(self, batch: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Collate with additional Tanimoto similarity submatrix.

        Returns:
            Batch dict with additional key 'drug_tanimoto' (B x B matrix).
        """
        collated = super().__call__(batch)

        # Extract drug indices for this batch
        drug_ids = collated["drug_id"]
        batch_size = len(drug_ids)

        # Build batch Tanimoto submatrix
        tanimoto_sub = torch.zeros(batch_size, batch_size)
        for i, di in enumerate(drug_ids):
            for j, dj in enumerate(drug_ids):
                idx_i = self.drug_id_to_idx.get(str(di), -1)
                idx_j = self.drug_id_to_idx.get(str(dj), -1)
                if idx_i >= 0 and idx_j >= 0:
                    tanimoto_sub[i, j] = self.tanimoto_matrix[idx_i, idx_j]

        collated["drug_tanimoto"] = tanimoto_sub
        return collated
