#!/bin/bash
# GenoDrug-Agent: Full pipeline script
# Downloads data, preprocesses, trains, evaluates, and runs ablations.
set -e

echo "=============================================="
echo "GenoDrug-Agent Full Pipeline"
echo "=============================================="

# Step 1: Download data
echo "[1/6] Downloading datasets..."
python data/download.py --dataset all --output_dir data/raw/

# Step 2: Preprocess data
echo "[2/6] Preprocessing data..."
python data/preprocess.py \
    --expression_path data/raw/gdsc/gdsc_expression_raw.csv \
    --response_path data/raw/gdsc/gdsc_ic50_raw.csv \
    --smiles_path data/raw/gdsc/drug_smiles.csv \
    --output_dir data/processed/ \
    --max_genes 2048 \
    --seed 42

# Step 3: Train our model
echo "[3/6] Training GenoDrug-Agent..."
bash scripts/train.sh configs/default.yaml outputs/main

# Step 4: Run baselines
echo "[4/6] Running baselines..."
bash scripts/run_baselines.sh

# Step 5: Run ablation studies
echo "[5/6] Running ablation studies..."
bash scripts/run_ablation.sh

# Step 6: Evaluate all models
echo "[6/6] Final evaluation..."
bash scripts/eval.sh outputs/main/best_model.pt

echo "=============================================="
echo "Pipeline complete!"
echo "Results in: outputs/"
echo "=============================================="
