#!/bin/bash
# Run all ablation studies
set -e

echo "=============================================="
echo "Running Ablation Studies"
echo "=============================================="

python ablation/run_ablation.py --output_dir outputs/ablations

echo "=============================================="
echo "Ablation studies complete!"
echo "Results saved to: outputs/ablations/"
echo "=============================================="
