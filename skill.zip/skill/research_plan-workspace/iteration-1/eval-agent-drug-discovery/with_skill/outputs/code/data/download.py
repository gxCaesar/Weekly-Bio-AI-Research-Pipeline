"""Dataset download utilities for GenoDrug-Agent.

Downloads GDSC, CCLE, and DrugBank data from public repositories.
All downloads are verified with checksums when available.
"""

import os
import hashlib
import logging
from pathlib import Path
from typing import Optional
import urllib.request
import gzip
import shutil
import argparse

logger = logging.getLogger(__name__)

# Dataset URLs and expected checksums
DATASET_REGISTRY = {
    "gdsc": {
        "expression": {
            "url": "https://www.cancerrxgene.org/gdsc1000/GDSC1000_GeneExpression.csv",
            "filename": "gdsc_expression_raw.csv",
            "description": "GDSC gene expression data (RMA normalized)",
        },
        "ic50": {
            "url": "https://www.cancerrxgene.org/gdsc1000/GDSC2_fitted_dose_response.csv",
            "filename": "gdsc_ic50_raw.csv",
            "description": "GDSC fitted dose response (IC50 values)",
        },
    },
    "drugbank": {
        "structures": {
            "url": "https://go.drugbank.com/releases/latest/downloads/all-structures",
            "filename": "drugbank_structures.sdf.gz",
            "description": "DrugBank approved drug structures",
        },
    },
    "ccle": {
        "expression": {
            "url": "https://depmap.org/portal/download/api/download?file_name=OmicsExpressionProteinCodingGenesTPMLogp1.csv",
            "filename": "ccle_expression_raw.csv",
            "description": "CCLE gene expression (log2 TPM+1)",
        },
    },
}


def compute_md5(filepath: str) -> str:
    """Compute MD5 hash of a file.

    Args:
        filepath: Path to the file.

    Returns:
        Hex digest of the MD5 hash.
    """
    hash_md5 = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def download_file(
    url: str,
    output_path: str,
    expected_md5: Optional[str] = None,
    description: str = "",
) -> str:
    """Download a file from URL with progress reporting.

    Args:
        url: URL to download from.
        output_path: Local path to save the file.
        expected_md5: Optional MD5 checksum for verification.
        description: Human-readable description for logging.

    Returns:
        Path to the downloaded file.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if output_path.exists():
        logger.info(f"File already exists: {output_path}")
        if expected_md5:
            actual_md5 = compute_md5(str(output_path))
            if actual_md5 == expected_md5:
                logger.info("MD5 checksum verified.")
                return str(output_path)
            else:
                logger.warning(
                    f"MD5 mismatch: expected {expected_md5}, got {actual_md5}. "
                    "Re-downloading..."
                )
        else:
            return str(output_path)

    logger.info(f"Downloading {description}: {url}")
    logger.info(f"Saving to: {output_path}")

    try:
        urllib.request.urlretrieve(url, str(output_path), reporthook=_progress_hook)
        print()  # New line after progress
    except Exception as e:
        logger.error(f"Download failed: {e}")
        if output_path.exists():
            output_path.unlink()
        raise

    if expected_md5:
        actual_md5 = compute_md5(str(output_path))
        if actual_md5 != expected_md5:
            raise ValueError(
                f"MD5 mismatch after download: expected {expected_md5}, "
                f"got {actual_md5}"
            )
        logger.info("MD5 checksum verified.")

    # Decompress gzip files
    if str(output_path).endswith(".gz"):
        decompressed_path = str(output_path)[:-3]
        logger.info(f"Decompressing to: {decompressed_path}")
        with gzip.open(str(output_path), "rb") as f_in:
            with open(decompressed_path, "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)
        return decompressed_path

    return str(output_path)


def _progress_hook(count: int, block_size: int, total_size: int) -> None:
    """Progress hook for urllib.request.urlretrieve."""
    if total_size > 0:
        percent = min(100, count * block_size * 100 // total_size)
        print(f"\rProgress: {percent}%", end="", flush=True)


def download_dataset(dataset_name: str, output_dir: str) -> dict:
    """Download all files for a given dataset.

    Args:
        dataset_name: Name of the dataset (gdsc, ccle, drugbank).
        output_dir: Directory to save downloaded files.

    Returns:
        Dictionary mapping file keys to local paths.
    """
    if dataset_name not in DATASET_REGISTRY:
        raise ValueError(
            f"Unknown dataset: {dataset_name}. "
            f"Available: {list(DATASET_REGISTRY.keys())}"
        )

    dataset_info = DATASET_REGISTRY[dataset_name]
    downloaded_paths = {}

    for key, file_info in dataset_info.items():
        output_path = os.path.join(output_dir, file_info["filename"])
        path = download_file(
            url=file_info["url"],
            output_path=output_path,
            expected_md5=file_info.get("md5"),
            description=file_info["description"],
        )
        downloaded_paths[key] = path
        logger.info(f"Downloaded {key}: {path}")

    return downloaded_paths


def download_all(output_dir: str) -> dict:
    """Download all required datasets.

    Args:
        output_dir: Base directory for all downloads.

    Returns:
        Nested dictionary of dataset name -> file key -> local path.
    """
    all_paths = {}
    for dataset_name in ["gdsc", "ccle", "drugbank"]:
        dataset_dir = os.path.join(output_dir, dataset_name)
        try:
            paths = download_dataset(dataset_name, dataset_dir)
            all_paths[dataset_name] = paths
        except Exception as e:
            logger.warning(f"Failed to download {dataset_name}: {e}")
            logger.warning("Some datasets may require manual download or API keys.")
            all_paths[dataset_name] = {}

    return all_paths


def main() -> None:
    """CLI entry point for dataset download."""
    parser = argparse.ArgumentParser(
        description="Download datasets for GenoDrug-Agent"
    )
    parser.add_argument(
        "--dataset",
        type=str,
        choices=list(DATASET_REGISTRY.keys()) + ["all"],
        default="all",
        help="Dataset to download (default: all)",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="./data/raw",
        help="Output directory for downloads (default: ./data/raw)",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    if args.dataset == "all":
        download_all(args.output_dir)
    else:
        download_dataset(args.dataset, args.output_dir)

    logger.info("Download complete!")


if __name__ == "__main__":
    main()
