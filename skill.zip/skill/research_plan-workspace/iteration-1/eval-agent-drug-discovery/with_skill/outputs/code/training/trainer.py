"""Training loop for GenoDrug-Agent.

Supports mixed-precision training, gradient accumulation, multi-GPU
via DistributedDataParallel, and checkpoint resumption.
"""

import logging
import time
from pathlib import Path
from typing import Any, Dict, Optional

import torch
import torch.nn as nn
from torch.cuda.amp import GradScaler, autocast
from torch.utils.data import DataLoader

from training.optimizer import build_optimizer, build_scheduler
from training.callbacks import CheckpointCallback, EarlyStoppingCallback, WandbCallback
from evaluation.metrics import compute_all_metrics

logger = logging.getLogger(__name__)


class Trainer:
    """Main training class for GenoDrug-Agent.

    Handles the full training loop with:
    - Mixed precision (FP16) training
    - Gradient accumulation
    - Periodic evaluation
    - Best model checkpointing
    - W&B logging
    - Early stopping
    - Resume from checkpoint

    Args:
        model: The model to train.
        train_loader: Training DataLoader.
        val_loader: Validation DataLoader.
        config: Full configuration dictionary.
        device: Device to train on.
        output_dir: Directory for outputs (checkpoints, logs).
    """

    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        config: Dict[str, Any],
        device: torch.device,
        output_dir: str = "./outputs",
    ) -> None:
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.config = config
        self.device = device
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        training_cfg = config["training"]

        # Optimizer and scheduler
        self.optimizer = build_optimizer(
            params=filter(lambda p: p.requires_grad, model.parameters()),
            config=training_cfg,
        )

        num_training_steps = (
            len(train_loader)
            // training_cfg.get("gradient_accumulation_steps", 1)
            * training_cfg["epochs"]
        )
        self.scheduler = build_scheduler(
            self.optimizer, training_cfg, num_training_steps
        )

        # Mixed precision
        self.use_fp16 = training_cfg.get("fp16", True)
        self.scaler = GradScaler(enabled=self.use_fp16)

        # Training config
        self.epochs = training_cfg["epochs"]
        self.grad_accum_steps = training_cfg.get("gradient_accumulation_steps", 1)
        self.max_grad_norm = training_cfg.get("max_grad_norm", 1.0)
        self.eval_every = config["evaluation"].get("eval_every", 5)
        self.log_every = config["logging"].get("log_every", 50)

        # Callbacks
        self.checkpoint_cb = CheckpointCallback(
            output_dir=str(self.output_dir),
            save_every=config["logging"].get("save_every", 10),
            save_best=config["logging"].get("save_best", True),
            save_last=config["logging"].get("save_last", True),
        )

        self.early_stop_cb = EarlyStoppingCallback(patience=20)

        self.wandb_cb = WandbCallback(
            project=config["logging"].get("wandb_project", "genodrug-agent"),
            entity=config["logging"].get("wandb_entity"),
            config=config,
        )

        # Tracking
        self.global_step = 0
        self.start_epoch = 0

    def train(self) -> Dict[str, float]:
        """Run the full training loop.

        Returns:
            Best validation metrics.
        """
        logger.info(f"Starting training for {self.epochs} epochs")
        logger.info(f"Training samples: {len(self.train_loader.dataset)}")
        logger.info(f"Validation samples: {len(self.val_loader.dataset)}")
        logger.info(f"FP16: {self.use_fp16}")
        logger.info(f"Gradient accumulation steps: {self.grad_accum_steps}")

        best_metrics = {}

        for epoch in range(self.start_epoch, self.epochs):
            # Train one epoch
            train_metrics = self._train_epoch(epoch)

            # Log training metrics
            self.wandb_cb.log(
                {f"train/{k}": v for k, v in train_metrics.items()},
                step=self.global_step,
            )

            # Evaluate periodically
            if (epoch + 1) % self.eval_every == 0 or epoch == self.epochs - 1:
                val_metrics = self._evaluate(self.val_loader, prefix="val")

                logger.info(
                    f"Epoch {epoch + 1}/{self.epochs} | "
                    f"Train Loss: {train_metrics['loss']:.4f} | "
                    f"Val PCC: {val_metrics.get('val_pcc', 0):.4f} | "
                    f"Val RMSE: {val_metrics.get('val_rmse', 0):.4f}"
                )

                # Log validation metrics
                self.wandb_cb.log(val_metrics, step=self.global_step)

                # Checkpoint
                self.checkpoint_cb.on_epoch_end(
                    epoch=epoch,
                    model=self.model,
                    optimizer=self.optimizer,
                    metrics=val_metrics,
                    config=self.config,
                )

                # Early stopping
                if self.early_stop_cb.on_epoch_end(val_metrics):
                    logger.info(f"Early stopping at epoch {epoch + 1}")
                    break

                if val_metrics.get("val_pcc", 0) > best_metrics.get("val_pcc", 0):
                    best_metrics = val_metrics.copy()

        self.wandb_cb.finish()
        logger.info(f"Training complete. Best metrics: {best_metrics}")
        return best_metrics

    def _train_epoch(self, epoch: int) -> Dict[str, float]:
        """Train for one epoch.

        Args:
            epoch: Current epoch number.

        Returns:
            Average training metrics for the epoch.
        """
        self.model.train()
        total_loss = 0.0
        total_contrastive = 0.0
        total_regression = 0.0
        num_batches = 0

        self.optimizer.zero_grad()

        for step, batch in enumerate(self.train_loader):
            # Move batch to device
            batch_device = {}
            for k, v in batch.items():
                if isinstance(v, torch.Tensor):
                    batch_device[k] = v.to(self.device)
                else:
                    batch_device[k] = v

            # Forward pass with mixed precision
            with autocast(enabled=self.use_fp16):
                outputs = self.model(**batch_device)
                loss = outputs["loss"]
                loss = loss / self.grad_accum_steps

            # Backward pass
            self.scaler.scale(loss).backward()

            # Accumulate metrics
            total_loss += outputs["loss"].item()
            if "loss_contrastive" in outputs:
                total_contrastive += outputs["loss_contrastive"].item()
            if "loss_regression" in outputs:
                total_regression += outputs["loss_regression"].item()
            num_batches += 1

            # Optimizer step with gradient accumulation
            if (step + 1) % self.grad_accum_steps == 0:
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(), self.max_grad_norm
                )
                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.scheduler.step()
                self.optimizer.zero_grad()
                self.global_step += 1

                # Log periodically
                if self.global_step % self.log_every == 0:
                    lr = self.scheduler.get_last_lr()[0]
                    logger.info(
                        f"Step {self.global_step} | "
                        f"Loss: {loss.item() * self.grad_accum_steps:.4f} | "
                        f"LR: {lr:.2e}"
                    )

        avg_metrics = {
            "loss": total_loss / max(num_batches, 1),
            "loss_contrastive": total_contrastive / max(num_batches, 1),
            "loss_regression": total_regression / max(num_batches, 1),
            "learning_rate": self.scheduler.get_last_lr()[0],
        }

        return avg_metrics

    @torch.no_grad()
    def _evaluate(
        self,
        dataloader: DataLoader,
        prefix: str = "val",
    ) -> Dict[str, float]:
        """Evaluate model on a dataset.

        Args:
            dataloader: Evaluation DataLoader.
            prefix: Metric prefix (e.g., 'val', 'test').

        Returns:
            Dictionary of evaluation metrics.
        """
        self.model.eval()

        all_preds = []
        all_labels = []
        all_sensitive = []
        all_logits = []
        total_loss = 0.0
        num_batches = 0

        for batch in dataloader:
            batch_device = {}
            for k, v in batch.items():
                if isinstance(v, torch.Tensor):
                    batch_device[k] = v.to(self.device)
                else:
                    batch_device[k] = v

            with autocast(enabled=self.use_fp16):
                outputs = self.model(**batch_device)

            all_preds.append(outputs["ic50_pred"].cpu())
            all_labels.append(batch_device["ic50"].cpu())

            if "sensitivity_logits" in outputs:
                all_logits.append(outputs["sensitivity_logits"].cpu())
            if "sensitive" in batch_device:
                all_sensitive.append(batch_device["sensitive"].cpu())

            if "loss" in outputs:
                total_loss += outputs["loss"].item()
            num_batches += 1

        # Concatenate all predictions
        preds = torch.cat(all_preds, dim=0).numpy()
        labels = torch.cat(all_labels, dim=0).numpy()

        logits = None
        if all_logits:
            logits = torch.cat(all_logits, dim=0).numpy()

        sensitive = None
        if all_sensitive:
            sensitive = torch.cat(all_sensitive, dim=0).numpy()

        # Compute metrics
        metrics = compute_all_metrics(
            y_pred=preds,
            y_true=labels,
            logits=logits,
            labels_binary=sensitive,
        )

        # Add prefix
        prefixed = {f"{prefix}_{k}": v for k, v in metrics.items()}
        prefixed[f"{prefix}_loss"] = total_loss / max(num_batches, 1)

        self.model.train()
        return prefixed

    def resume_from_checkpoint(self, checkpoint_path: str) -> None:
        """Resume training from a checkpoint.

        Args:
            checkpoint_path: Path to checkpoint file.
        """
        logger.info(f"Resuming from checkpoint: {checkpoint_path}")
        checkpoint = torch.load(checkpoint_path, map_location=self.device)

        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        self.start_epoch = checkpoint["epoch"] + 1
        self.global_step = self.start_epoch * len(self.train_loader)

        if "metrics" in checkpoint:
            best_metric = checkpoint["metrics"].get("val_pcc", 0)
            self.checkpoint_cb.best_metric = best_metric
            logger.info(f"Resumed at epoch {self.start_epoch}, best PCC: {best_metric}")
