"""Data preprocessing pipeline for GenoDrug-Agent.

Converts raw GDSC/CCLE gene expression and drug response data into
processed formats suitable for model training.
"""

import argparse
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors
from sklearn.model_selection import train_test_split

logger = logging.getLogger(__name__)


def load_gene_expression(filepath: str, max_genes: int = 2048) -> pd.DataFrame:
    """Load and preprocess gene expression matrix.

    Args:
        filepath: Path to raw expression CSV file.
        max_genes: Maximum number of genes to retain (by variance).

    Returns:
        Preprocessed expression DataFrame (samples x genes).
    """
    logger.info(f"Loading gene expression from: {filepath}")
    expr_df = pd.read_csv(filepath, index_col=0)

    # Log2 transform if not already done
    if expr_df.max().max() > 100:
        logger.info("Applying log2(x+1) transformation")
        expr_df = np.log2(expr_df + 1)

    # Select top variable genes
    gene_vars = expr_df.var(axis=0)
    top_genes = gene_vars.nlargest(max_genes).index
    expr_df = expr_df[top_genes]

    # Z-score normalization per gene
    expr_df = (expr_df - expr_df.mean(axis=0)) / (expr_df.std(axis=0) + 1e-8)

    logger.info(
        f"Expression matrix: {expr_df.shape[0]} samples x {expr_df.shape[1]} genes"
    )
    return expr_df


def load_drug_response(filepath: str) -> pd.DataFrame:
    """Load and preprocess drug response (IC50) data.

    Args:
        filepath: Path to raw IC50 CSV file.

    Returns:
        Preprocessed IC50 DataFrame with columns:
        [cell_line, drug_id, drug_name, ic50, ic50_log, ic50_zscore, sensitive].
    """
    logger.info(f"Loading drug response from: {filepath}")
    resp_df = pd.read_csv(filepath)

    # Standardize column names
    column_map = {
        "CELL_LINE_NAME": "cell_line",
        "DRUG_ID": "drug_id",
        "DRUG_NAME": "drug_name",
        "LN_IC50": "ic50_log",
    }
    for old, new in column_map.items():
        if old in resp_df.columns:
            resp_df = resp_df.rename(columns={old: new})

    # Ensure required columns exist
    if "ic50_log" not in resp_df.columns and "IC50" in resp_df.columns:
        resp_df["ic50_log"] = np.log(resp_df["IC50"].clip(lower=1e-10))

    # Z-score normalization of IC50
    resp_df["ic50_zscore"] = (
        resp_df["ic50_log"] - resp_df["ic50_log"].mean()
    ) / (resp_df["ic50_log"].std() + 1e-8)

    # Binary sensitivity label (below median = sensitive)
    median_ic50 = resp_df["ic50_log"].median()
    resp_df["sensitive"] = (resp_df["ic50_log"] < median_ic50).astype(int)

    # Drop rows with missing values
    resp_df = resp_df.dropna(subset=["cell_line", "drug_id", "ic50_log"])

    logger.info(
        f"Drug response: {len(resp_df)} records, "
        f"{resp_df['cell_line'].nunique()} cell lines, "
        f"{resp_df['drug_id'].nunique()} drugs"
    )
    return resp_df


def process_drug_smiles(
    smiles_filepath: str,
    drug_ids: Optional[List[str]] = None,
) -> pd.DataFrame:
    """Process drug SMILES strings with RDKit validation.

    Args:
        smiles_filepath: Path to CSV with drug_id and SMILES columns.
        drug_ids: Optional list of drug IDs to filter.

    Returns:
        DataFrame with validated SMILES and molecular properties.
    """
    logger.info(f"Processing drug SMILES from: {smiles_filepath}")
    drug_df = pd.read_csv(smiles_filepath)

    # Standardize column names
    if "SMILES" in drug_df.columns:
        drug_df = drug_df.rename(columns={"SMILES": "smiles"})
    if "DRUG_ID" in drug_df.columns:
        drug_df = drug_df.rename(columns={"DRUG_ID": "drug_id"})

    if drug_ids is not None:
        drug_df = drug_df[drug_df["drug_id"].isin(drug_ids)]

    # Validate and canonicalize SMILES
    valid_smiles = []
    mol_weights = []
    logp_values = []
    num_atoms_list = []

    for _, row in drug_df.iterrows():
        mol = Chem.MolFromSmiles(row["smiles"])
        if mol is not None:
            canonical = Chem.MolToSmiles(mol, canonical=True)
            valid_smiles.append(canonical)
            mol_weights.append(Descriptors.MolWt(mol))
            logp_values.append(Descriptors.MolLogP(mol))
            num_atoms_list.append(mol.GetNumHeavyAtoms())
        else:
            valid_smiles.append(None)
            mol_weights.append(None)
            logp_values.append(None)
            num_atoms_list.append(None)
            logger.warning(f"Invalid SMILES for drug {row['drug_id']}: {row['smiles']}")

    drug_df["canonical_smiles"] = valid_smiles
    drug_df["mol_weight"] = mol_weights
    drug_df["logp"] = logp_values
    drug_df["num_heavy_atoms"] = num_atoms_list

    # Remove invalid molecules
    drug_df = drug_df.dropna(subset=["canonical_smiles"])

    logger.info(f"Valid drugs: {len(drug_df)} / {len(valid_smiles)}")
    return drug_df


def compute_morgan_fingerprints(
    smiles_list: List[str],
    radius: int = 2,
    n_bits: int = 2048,
) -> np.ndarray:
    """Compute Morgan fingerprints for a list of SMILES.

    Args:
        smiles_list: List of canonical SMILES strings.
        radius: Morgan fingerprint radius (default: 2).
        n_bits: Number of bits (default: 2048).

    Returns:
        Numpy array of shape (N, n_bits) with fingerprint vectors.
    """
    fingerprints = []
    for smiles in smiles_list:
        mol = Chem.MolFromSmiles(smiles)
        if mol is not None:
            fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
            fingerprints.append(np.array(fp))
        else:
            fingerprints.append(np.zeros(n_bits))
    return np.array(fingerprints)


def compute_tanimoto_matrix(fingerprints: np.ndarray) -> np.ndarray:
    """Compute pairwise Tanimoto similarity matrix from fingerprints.

    Args:
        fingerprints: Binary fingerprint matrix (N, D).

    Returns:
        Tanimoto similarity matrix (N, N).
    """
    # Tanimoto = intersection / union = (A & B) / (A | B)
    intersection = fingerprints @ fingerprints.T
    row_sums = fingerprints.sum(axis=1, keepdims=True)
    union = row_sums + row_sums.T - intersection
    tanimoto = intersection / (union + 1e-8)
    return tanimoto


def create_data_splits(
    response_df: pd.DataFrame,
    test_size: float = 0.2,
    val_size: float = 0.1,
    cold_drug_ratio: float = 0.1,
    cold_cell_ratio: float = 0.1,
    seed: int = 42,
) -> Dict[str, pd.DataFrame]:
    """Create train/val/test splits with cold-start subsets.

    Args:
        response_df: Drug response DataFrame.
        test_size: Fraction for test set.
        val_size: Fraction for validation set (from train).
        cold_drug_ratio: Fraction of drugs held out for cold-drug test.
        cold_cell_ratio: Fraction of cell lines held out for cold-cell test.
        seed: Random seed for reproducibility.

    Returns:
        Dictionary with 'train', 'val', 'test', 'test_cold_drug',
        'test_cold_cell', 'test_cold_both' DataFrames.
    """
    np.random.seed(seed)

    all_drugs = response_df["drug_id"].unique()
    all_cells = response_df["cell_line"].unique()

    # Hold out drugs and cell lines for cold-start evaluation
    n_cold_drugs = max(1, int(len(all_drugs) * cold_drug_ratio))
    n_cold_cells = max(1, int(len(all_cells) * cold_cell_ratio))

    cold_drugs = np.random.choice(all_drugs, n_cold_drugs, replace=False)
    cold_cells = np.random.choice(all_cells, n_cold_cells, replace=False)

    # Cold-start test sets
    mask_cold_drug = response_df["drug_id"].isin(cold_drugs)
    mask_cold_cell = response_df["cell_line"].isin(cold_cells)

    test_cold_drug = response_df[mask_cold_drug & ~mask_cold_cell].copy()
    test_cold_cell = response_df[~mask_cold_drug & mask_cold_cell].copy()
    test_cold_both = response_df[mask_cold_drug & mask_cold_cell].copy()

    # Remaining data for standard splits
    warm_data = response_df[~mask_cold_drug & ~mask_cold_cell].copy()

    train_val, test = train_test_split(
        warm_data, test_size=test_size, random_state=seed
    )
    adjusted_val_size = val_size / (1 - test_size)
    train, val = train_test_split(
        train_val, test_size=adjusted_val_size, random_state=seed
    )

    splits = {
        "train": train.reset_index(drop=True),
        "val": val.reset_index(drop=True),
        "test": test.reset_index(drop=True),
        "test_cold_drug": test_cold_drug.reset_index(drop=True),
        "test_cold_cell": test_cold_cell.reset_index(drop=True),
        "test_cold_both": test_cold_both.reset_index(drop=True),
    }

    for name, df in splits.items():
        logger.info(f"Split {name}: {len(df)} samples")

    return splits


def preprocess_gdsc(
    expression_path: str,
    response_path: str,
    smiles_path: str,
    output_dir: str,
    max_genes: int = 2048,
    seed: int = 42,
) -> None:
    """Full GDSC preprocessing pipeline.

    Args:
        expression_path: Path to raw gene expression CSV.
        response_path: Path to raw IC50 CSV.
        smiles_path: Path to drug SMILES CSV.
        output_dir: Directory to save processed files.
        max_genes: Maximum number of genes to retain.
        seed: Random seed.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Process gene expression
    expr_df = load_gene_expression(expression_path, max_genes=max_genes)
    expr_df.to_csv(output_dir / "gene_expression.csv")
    logger.info(f"Saved expression to {output_dir / 'gene_expression.csv'}")

    # Save gene list
    gene_list = expr_df.columns.tolist()
    with open(output_dir / "gene_list.txt", "w") as f:
        f.write("\n".join(gene_list))

    # 2. Process drug response
    resp_df = load_drug_response(response_path)

    # Filter to cell lines present in expression data
    common_cells = set(expr_df.index) & set(resp_df["cell_line"])
    resp_df = resp_df[resp_df["cell_line"].isin(common_cells)]
    logger.info(f"Cell lines with both expression and response: {len(common_cells)}")

    # 3. Process drug SMILES
    drug_ids = resp_df["drug_id"].unique().tolist()
    drug_df = process_drug_smiles(smiles_path, drug_ids=drug_ids)
    drug_df.to_csv(output_dir / "drug_info.csv", index=False)

    # Compute fingerprints and similarity matrix
    fps = compute_morgan_fingerprints(drug_df["canonical_smiles"].tolist())
    np.save(output_dir / "drug_fingerprints.npy", fps)

    tanimoto = compute_tanimoto_matrix(fps)
    np.save(output_dir / "drug_tanimoto_similarity.npy", tanimoto)

    # Filter response to valid drugs
    valid_drug_ids = set(drug_df["drug_id"])
    resp_df = resp_df[resp_df["drug_id"].isin(valid_drug_ids)]

    # 4. Create data splits
    splits = create_data_splits(resp_df, seed=seed)
    for name, df in splits.items():
        df.to_csv(output_dir / f"split_{name}.csv", index=False)

    # Save summary statistics
    summary = {
        "n_cell_lines": len(common_cells),
        "n_drugs": len(valid_drug_ids),
        "n_genes": len(gene_list),
        "n_total_records": len(resp_df),
        "splits": {name: len(df) for name, df in splits.items()},
    }
    pd.Series(summary).to_json(output_dir / "data_summary.json")

    logger.info("Preprocessing complete!")
    logger.info(f"Summary: {summary}")


def preprocess_drug_smiles(smiles_path: str, output_dir: str) -> None:
    """Standalone drug SMILES preprocessing.

    Args:
        smiles_path: Path to drug SMILES CSV.
        output_dir: Output directory.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    drug_df = process_drug_smiles(smiles_path)
    drug_df.to_csv(output_dir / "drug_info.csv", index=False)

    fps = compute_morgan_fingerprints(drug_df["canonical_smiles"].tolist())
    np.save(output_dir / "drug_fingerprints.npy", fps)

    logger.info(f"Processed {len(drug_df)} drugs, saved to {output_dir}")


def main() -> None:
    """CLI entry point for data preprocessing."""
    parser = argparse.ArgumentParser(
        description="Preprocess data for GenoDrug-Agent"
    )
    parser.add_argument(
        "--expression_path",
        type=str,
        required=True,
        help="Path to raw gene expression CSV",
    )
    parser.add_argument(
        "--response_path",
        type=str,
        required=True,
        help="Path to raw drug response (IC50) CSV",
    )
    parser.add_argument(
        "--smiles_path",
        type=str,
        required=True,
        help="Path to drug SMILES CSV",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="./data/processed",
        help="Output directory for processed data",
    )
    parser.add_argument("--max_genes", type=int, default=2048)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    preprocess_gdsc(
        expression_path=args.expression_path,
        response_path=args.response_path,
        smiles_path=args.smiles_path,
        output_dir=args.output_dir,
        max_genes=args.max_genes,
        seed=args.seed,
    )


if __name__ == "__main__":
    main()
