"""GraphDRP baseline implementation.

Reimplementation of GraphDRP (Nguyen et al., Bioinformatics 2022) for
drug response prediction using graph neural networks for drug encoding.
"""

from typing import Any, Dict, List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class GINConvLayer(nn.Module):
    """Graph Isomorphism Network (GIN) convolution layer.

    Simplified version operating on fingerprint features.

    Args:
        in_dim: Input dimension.
        out_dim: Output dimension.
        eps: Learnable epsilon parameter.
    """

    def __init__(self, in_dim: int, out_dim: int, eps: float = 0.0) -> None:
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, out_dim),
            nn.BatchNorm1d(out_dim),
            nn.ReLU(),
            nn.Linear(out_dim, out_dim),
        )
        self.eps = nn.Parameter(torch.tensor(eps))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass.

        Args:
            x: Input features (B, in_dim).

        Returns:
            Output features (B, out_dim).
        """
        return self.mlp((1 + self.eps) * x)


class GraphDRP(nn.Module):
    """GraphDRP: Graph-based Drug Response Prediction model.

    Uses GIN layers for drug encoding and 1D CNN for genomic encoding.

    Args:
        gene_input_dim: Number of genomic features.
        drug_input_dim: Drug fingerprint dimension.
        gene_hidden_dim: Hidden dimension for genomic encoder.
        drug_hidden_dim: Hidden dimension for drug encoder.
        num_gin_layers: Number of GIN layers for drug encoder.
        fusion_hidden_dim: Fusion layer hidden dimension.
        dropout: Dropout rate.
    """

    def __init__(
        self,
        gene_input_dim: int = 735,
        drug_input_dim: int = 2048,
        gene_hidden_dim: int = 256,
        drug_hidden_dim: int = 128,
        num_gin_layers: int = 5,
        fusion_hidden_dim: int = 256,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()

        # Genomic encoder: 1D CNN
        self.gene_conv1 = nn.Conv1d(1, 32, kernel_size=7, padding=3)
        self.gene_bn1 = nn.BatchNorm1d(32)
        self.gene_conv2 = nn.Conv1d(32, 64, kernel_size=5, padding=2)
        self.gene_bn2 = nn.BatchNorm1d(64)
        self.gene_conv3 = nn.Conv1d(64, gene_hidden_dim, kernel_size=3, padding=1)
        self.gene_bn3 = nn.BatchNorm1d(gene_hidden_dim)
        self.gene_pool = nn.AdaptiveAvgPool1d(1)
        self.gene_dropout = nn.Dropout(dropout)

        # Drug encoder: stacked GIN layers on fingerprints
        gin_layers: List[nn.Module] = []
        in_dim = drug_input_dim
        for i in range(num_gin_layers):
            out_dim = drug_hidden_dim
            gin_layers.append(GINConvLayer(in_dim, out_dim))
            in_dim = out_dim
        self.gin_layers = nn.ModuleList(gin_layers)
        self.drug_dropout = nn.Dropout(dropout)

        # Fusion
        fusion_in = gene_hidden_dim + drug_hidden_dim
        self.fusion = nn.Sequential(
            nn.Linear(fusion_in, fusion_hidden_dim),
            nn.BatchNorm1d(fusion_hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(fusion_hidden_dim, fusion_hidden_dim // 2),
            nn.BatchNorm1d(fusion_hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        self.output_layer = nn.Linear(fusion_hidden_dim // 2, 1)
        self.loss_fn = nn.MSELoss()

    def encode_genes(self, gene_expression: torch.Tensor) -> torch.Tensor:
        """Encode genomic features with 1D CNN.

        Args:
            gene_expression: (B, N_genes).

        Returns:
            Gene embeddings (B, gene_hidden_dim).
        """
        x = gene_expression.unsqueeze(1)  # (B, 1, N_genes)
        x = F.relu(self.gene_bn1(self.gene_conv1(x)))
        x = F.max_pool1d(x, 2)
        x = F.relu(self.gene_bn2(self.gene_conv2(x)))
        x = F.max_pool1d(x, 2)
        x = F.relu(self.gene_bn3(self.gene_conv3(x)))
        x = self.gene_pool(x).squeeze(-1)
        x = self.gene_dropout(x)
        return x

    def encode_drugs(self, drug_fingerprint: torch.Tensor) -> torch.Tensor:
        """Encode drug features with GIN layers.

        Args:
            drug_fingerprint: (B, fp_dim).

        Returns:
            Drug embeddings (B, drug_hidden_dim).
        """
        x = drug_fingerprint
        for gin_layer in self.gin_layers:
            x = gin_layer(x)
            x = F.relu(x)
        x = self.drug_dropout(x)
        return x

    def forward(
        self,
        gene_expression: torch.Tensor,
        drug_fingerprint: torch.Tensor,
        ic50: Optional[torch.Tensor] = None,
        **kwargs: Any,
    ) -> Dict[str, torch.Tensor]:
        """Forward pass.

        Args:
            gene_expression: Gene expression features (B, gene_input_dim).
            drug_fingerprint: Drug fingerprint (B, drug_input_dim).
            ic50: Ground truth IC50 (B,). Optional.

        Returns:
            Dict with 'ic50_pred' and optionally 'loss'.
        """
        h_gene = self.encode_genes(gene_expression)
        h_drug = self.encode_drugs(drug_fingerprint)

        h_fused = torch.cat([h_gene, h_drug], dim=-1)
        h_fused = self.fusion(h_fused)

        ic50_pred = self.output_layer(h_fused).squeeze(-1)

        outputs = {"ic50_pred": ic50_pred}

        if ic50 is not None:
            loss = self.loss_fn(ic50_pred, ic50)
            outputs["loss"] = loss

        return outputs
