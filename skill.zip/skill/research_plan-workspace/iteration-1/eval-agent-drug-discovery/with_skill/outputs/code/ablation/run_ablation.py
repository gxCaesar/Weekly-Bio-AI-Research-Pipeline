"""Ablation study orchestrator for GenoDrug-Agent.

Runs all ablation experiments defined in the configs/ablation_*.yaml files
and collects results into a summary table.
"""

import argparse
import json
import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Dict, List

logger = logging.getLogger(__name__)

# Define ablation experiments
ABLATION_EXPERIMENTS = {
    "full_model": {
        "config": "configs/default.yaml",
        "description": "Full GenoDrug-Agent model (all components)",
    },
    "no_contrastive": {
        "config": "configs/ablation_no_contrastive.yaml",
        "description": "Remove contrastive loss (A2)",
    },
    "no_hardneg": {
        "config": "configs/ablation_no_hardneg.yaml",
        "description": "Remove hard negative mining (A3)",
    },
    "fixed_temperature": {
        "config": "configs/default.yaml",
        "description": "Fixed temperature tau=0.07 (A4)",
        "override": {"training.temperature_learnable": False},
    },
    "no_geneformer": {
        "config": "configs/default.yaml",
        "description": "Replace Geneformer with random init (A1)",
        "override": {"model.genomic_encoder.name": "mlp"},
    },
    "fingerprint_only": {
        "config": "configs/default.yaml",
        "description": "Replace Uni-Mol with Morgan fingerprint MLP (A5)",
        "override": {"model.drug_encoder.name": "fingerprint"},
    },
    "no_agent": {
        "config": "configs/default.yaml",
        "description": "Disable Agent framework (A6)",
        "override": {"agent.enabled": False},
    },
    "no_uncertainty": {
        "config": "configs/default.yaml",
        "description": "Disable MC Dropout uncertainty (A7)",
        "override": {"agent.num_mc_dropout": 0},
    },
}


def run_experiment(
    name: str,
    config_path: str,
    output_dir: str,
    description: str = "",
) -> Dict:
    """Run a single ablation experiment.

    Args:
        name: Experiment name.
        config_path: Path to YAML config file.
        output_dir: Output directory for this experiment.
        description: Experiment description.

    Returns:
        Dictionary with experiment results.
    """
    logger.info(f"\n{'=' * 60}")
    logger.info(f"Running ablation: {name}")
    logger.info(f"Description: {description}")
    logger.info(f"Config: {config_path}")
    logger.info(f"Output: {output_dir}")
    logger.info(f"{'=' * 60}")

    cmd = [
        sys.executable,
        "main.py",
        "--config", config_path,
        "--mode", "train_eval",
        "--output_dir", output_dir,
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=7200,  # 2 hour timeout per experiment
        )

        if result.returncode != 0:
            logger.error(f"Experiment {name} failed: {result.stderr}")
            return {
                "name": name,
                "status": "failed",
                "error": result.stderr[:500],
            }

    except subprocess.TimeoutExpired:
        logger.error(f"Experiment {name} timed out")
        return {"name": name, "status": "timeout"}

    # Load results
    eval_path = os.path.join(output_dir, "eval_test.json")
    if os.path.exists(eval_path):
        with open(eval_path) as f:
            eval_results = json.load(f)
        return {
            "name": name,
            "description": description,
            "status": "success",
            "metrics": eval_results.get("metrics", {}),
        }
    else:
        return {
            "name": name,
            "status": "completed_no_eval",
        }


def run_all_ablations(base_output_dir: str = "./outputs/ablations") -> None:
    """Run all ablation experiments and generate summary.

    Args:
        base_output_dir: Base directory for ablation outputs.
    """
    base_dir = Path(base_output_dir)
    base_dir.mkdir(parents=True, exist_ok=True)

    all_results = []

    for name, exp_config in ABLATION_EXPERIMENTS.items():
        output_dir = str(base_dir / name)
        result = run_experiment(
            name=name,
            config_path=exp_config["config"],
            output_dir=output_dir,
            description=exp_config.get("description", ""),
        )
        all_results.append(result)

    # Generate summary table
    print_summary_table(all_results)

    # Save results
    summary_path = base_dir / "ablation_summary.json"
    with open(summary_path, "w") as f:
        json.dump(all_results, f, indent=2)
    logger.info(f"Ablation summary saved to: {summary_path}")


def print_summary_table(results: List[Dict]) -> None:
    """Print a formatted summary table of ablation results.

    Args:
        results: List of experiment result dictionaries.
    """
    header = (
        f"{'Experiment':<25} {'Status':<10} "
        f"{'PCC':>8} {'RMSE':>8} {'Spearman':>10} {'AUROC':>8}"
    )

    print("\n" + "=" * 80)
    print("ABLATION STUDY SUMMARY")
    print("=" * 80)
    print(header)
    print("-" * 80)

    for r in results:
        if r["status"] == "success":
            m = r.get("metrics", {})
            row = (
                f"{r['name']:<25} {r['status']:<10} "
                f"{m.get('pcc', 0):>8.4f} "
                f"{m.get('rmse', 0):>8.4f} "
                f"{m.get('spearman', 0):>10.4f} "
                f"{m.get('auroc', 0):>8.4f}"
            )
        else:
            row = f"{r['name']:<25} {r['status']:<10}"
        print(row)

    print("=" * 80)


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Run ablation studies for GenoDrug-Agent"
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="./outputs/ablations",
        help="Base output directory",
    )
    parser.add_argument(
        "--experiment",
        type=str,
        default=None,
        choices=list(ABLATION_EXPERIMENTS.keys()),
        help="Run a specific experiment (default: all)",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    if args.experiment:
        exp = ABLATION_EXPERIMENTS[args.experiment]
        output_dir = os.path.join(args.output_dir, args.experiment)
        run_experiment(
            name=args.experiment,
            config_path=exp["config"],
            output_dir=output_dir,
            description=exp.get("description", ""),
        )
    else:
        run_all_ablations(args.output_dir)


if __name__ == "__main__":
    main()
