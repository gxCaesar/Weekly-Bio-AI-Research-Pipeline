"""DeepCDR baseline implementation.

Reimplementation of DeepCDR (Li et al., Bioinformatics 2020) for
cancer drug response prediction using multi-omics data.
"""

from typing import Any, Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class DeepCDR(nn.Module):
    """DeepCDR: Cancer Drug Response prediction model.

    Uses CNN for drug molecular features and MLP for genomic features,
    with a fusion layer for IC50 prediction.

    Args:
        gene_input_dim: Number of genomic features (genes).
        drug_input_dim: Drug fingerprint dimension.
        gene_hidden_dims: Hidden dimensions for genomic MLP.
        drug_hidden_dims: Hidden dimensions for drug MLP.
        fusion_hidden_dim: Fusion layer hidden dimension.
        dropout: Dropout rate.
    """

    def __init__(
        self,
        gene_input_dim: int = 735,
        drug_input_dim: int = 2048,
        gene_hidden_dims: tuple = (512, 256),
        drug_hidden_dims: tuple = (512, 256),
        fusion_hidden_dim: int = 256,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()

        # Genomic feature encoder (MLP)
        gene_layers = []
        in_dim = gene_input_dim
        for h_dim in gene_hidden_dims:
            gene_layers.extend([
                nn.Linear(in_dim, h_dim),
                nn.BatchNorm1d(h_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
            ])
            in_dim = h_dim
        self.gene_encoder = nn.Sequential(*gene_layers)
        gene_out_dim = gene_hidden_dims[-1]

        # Drug feature encoder (MLP on fingerprints)
        drug_layers = []
        in_dim = drug_input_dim
        for h_dim in drug_hidden_dims:
            drug_layers.extend([
                nn.Linear(in_dim, h_dim),
                nn.BatchNorm1d(h_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
            ])
            in_dim = h_dim
        self.drug_encoder = nn.Sequential(*drug_layers)
        drug_out_dim = drug_hidden_dims[-1]

        # Fusion layers
        fusion_input_dim = gene_out_dim + drug_out_dim
        self.fusion = nn.Sequential(
            nn.Linear(fusion_input_dim, fusion_hidden_dim),
            nn.BatchNorm1d(fusion_hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(fusion_hidden_dim, fusion_hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        # Prediction head
        self.output_layer = nn.Linear(fusion_hidden_dim // 2, 1)

        # Loss
        self.loss_fn = nn.MSELoss()

    def forward(
        self,
        gene_expression: torch.Tensor,
        drug_fingerprint: torch.Tensor,
        ic50: Optional[torch.Tensor] = None,
        **kwargs: Any,
    ) -> Dict[str, torch.Tensor]:
        """Forward pass.

        Args:
            gene_expression: Gene expression features (B, gene_input_dim).
            drug_fingerprint: Drug fingerprint (B, drug_input_dim).
            ic50: Ground truth IC50 values (B,). Optional.

        Returns:
            Dictionary with 'ic50_pred' and optionally 'loss'.
        """
        h_gene = self.gene_encoder(gene_expression)
        h_drug = self.drug_encoder(drug_fingerprint)

        h_fused = torch.cat([h_gene, h_drug], dim=-1)
        h_fused = self.fusion(h_fused)

        ic50_pred = self.output_layer(h_fused).squeeze(-1)

        outputs = {"ic50_pred": ic50_pred}

        if ic50 is not None:
            loss = self.loss_fn(ic50_pred, ic50)
            outputs["loss"] = loss

        return outputs
