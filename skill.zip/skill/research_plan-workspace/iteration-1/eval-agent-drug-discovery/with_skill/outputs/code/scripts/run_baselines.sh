#!/bin/bash
# Run all baseline experiments
set -e

echo "=============================================="
echo "Running Baseline Experiments"
echo "=============================================="

# DeepCDR
echo "[1/2] Training DeepCDR..."
python main.py \
    --config configs/baseline_deepcdr.yaml \
    --mode train_eval \
    --output_dir outputs/baseline_deepcdr

# GraphDRP
echo "[2/2] Training GraphDRP..."
python main.py \
    --config configs/baseline_graphdrp.yaml \
    --mode train_eval \
    --output_dir outputs/baseline_graphdrp

echo "=============================================="
echo "All baselines complete!"
echo "=============================================="

# Print summary
echo ""
echo "Baseline Results Summary:"
echo "========================="
for dir in outputs/baseline_*/; do
    name=$(basename "$dir")
    eval_file="$dir/eval_test.json"
    if [ -f "$eval_file" ]; then
        echo "$name: $(cat "$eval_file" | python -c 'import sys,json; d=json.load(sys.stdin); m=d.get("metrics",{}); print(f"PCC={m.get(\"pcc\",0):.4f} RMSE={m.get(\"rmse\",0):.4f}")')"
    else
        echo "$name: No evaluation results found"
    fi
done
