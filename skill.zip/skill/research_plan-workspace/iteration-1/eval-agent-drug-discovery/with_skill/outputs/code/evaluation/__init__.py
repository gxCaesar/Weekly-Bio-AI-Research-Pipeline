"""Evaluation module for GenoDrug-Agent.

Provides metric computation, evaluation pipelines, and visualization tools.
"""

from evaluation.metrics import compute_all_metrics
from evaluation.evaluate import Evaluator
from evaluation.visualize import plot_results

__all__ = ["compute_all_metrics", "Evaluator", "plot_results"]
