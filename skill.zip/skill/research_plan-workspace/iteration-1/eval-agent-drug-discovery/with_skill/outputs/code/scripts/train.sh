#!/bin/bash
# Train GenoDrug-Agent or baseline model
set -e

CONFIG=${1:-configs/default.yaml}
OUTPUT_DIR=${2:-outputs/default}
NUM_GPUS=${3:-1}

echo "Training with config: $CONFIG"
echo "Output directory: $OUTPUT_DIR"
echo "Number of GPUs: $NUM_GPUS"

mkdir -p "$OUTPUT_DIR"

if [ "$NUM_GPUS" -gt 1 ]; then
    echo "Using DistributedDataParallel with $NUM_GPUS GPUs"
    torchrun --nproc_per_node="$NUM_GPUS" main.py \
        --config "$CONFIG" \
        --mode train_eval \
        --output_dir "$OUTPUT_DIR"
else
    python main.py \
        --config "$CONFIG" \
        --mode train_eval \
        --output_dir "$OUTPUT_DIR"
fi

echo "Training complete. Results saved to: $OUTPUT_DIR"
