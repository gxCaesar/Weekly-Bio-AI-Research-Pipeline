# AI Agent驱动的基因组药物发现 文献调研报告

## 1. 研究背景

### 1.1 领域概述

药物发现是一个耗时且成本高昂的过程，传统药物研发从靶点发现到上市平均需要10-15年，花费超过10亿美元。近年来，基因组学技术的飞速发展为药物发现提供了前所未有的数据基础——全基因组关联研究(GWAS)、转录组测序(RNA-seq)、单细胞测序(scRNA-seq)等技术产生了海量的基因组数据，使得数据驱动的药物发现成为可能。

与此同时，人工智能技术，特别是深度学习和大语言模型(LLM)的突破性进展，为药物发现领域带来了革命性的变化。从分子生成、靶点识别到药物-靶点相互作用预测，AI方法在药物研发的各个环节都展现出了巨大潜力。最近，AI Agent（智能体）架构的兴起更是开辟了新的研究方向——通过多个专业化智能体的协作，可以模拟药物发现的完整工作流程。

### 1.2 研究意义

基于基因组数据的AI药物发现具有重要的学术和应用价值。在学术层面，它需要解决多模态数据融合（基因组序列、基因表达、蛋白质结构、分子图结构）、大规模预训练模型的跨域迁移、以及AI Agent的自主推理与规划等核心挑战。在应用层面，该方向有望大幅缩短药物研发周期、降低研发成本、并发现传统方法难以捕捉的新药靶点和先导化合物。

### 1.3 技术发展脉络

药物发现中AI方法的演进可以分为三个阶段：

**传统机器学习阶段 (2010-2018)**：以随机森林、SVM、梯度提升等方法为代表，主要用于QSAR建模和虚拟筛选，依赖手工设计的分子描述符。

**深度学习阶段 (2018-2023)**：以图神经网络(GNN)、Transformer、变分自编码器(VAE)为核心，实现了分子的端到端学习。代表工作包括SchNet、DimeNet、MolBERT等，在分子性质预测和分子生成方面取得了显著进展。

**大模型与Agent阶段 (2023-至今)**：以大语言模型和AI Agent为核心的新范式出现。LLM展现出对化学知识的深度理解能力，Agent架构使得自动化的科学发现流程成为可能。代表工作包括Galactica、ChemCrow、DrugAgent等。

## 2. 核心论文汇总

| # | 论文标题 | 作者 | 发表venue | 年份 | 核心方法 | 数据集 | 开源代码 |
|---|---------|------|-----------|------|---------|--------|---------|
| 1 | Uni-Mol: A Universal 3D Molecular Pretraining Framework | Zhou et al. | ICLR | 2023 | 3D分子预训练Transformer，统一原子与分子对表示 | QM9, PDBBind, PCBA | https://github.com/deepmodeling/Uni-Mol |
| 2 | DrugCLIP: Contrastive Drug-Target Binding Learning for Drug Screening | Gao et al. | NeurIPS | 2024 | 对比学习框架对齐药物-靶点表示空间 | DUD-E, LIT-PCBA | https://github.com/bowen-gao/DrugCLIP |
| 3 | TxGNN: Zero-shot prediction of therapeutic use with geometric deep learning | Huang et al. | Nature Medicine | 2023 | 几何GNN在知识图谱上做零样本药物适应症预测 | 复合知识图谱 | https://github.com/mims-harvard/TxGNN |
| 4 | FREED: Fast and Robust End-to-End Drug Design | Yang et al. | ICML | 2023 | 端到端的分子生成与对接，扩散模型生成配体 | CrossDocked2020 | https://github.com/FREED-drug-design |
| 5 | scGPT: Toward Building a Foundation Model for Single-Cell Multi-omics | Cui et al. | Nature Methods | 2024 | 基于GPT的单细胞多组学基础模型 | 多个scRNA-seq数据集 | https://github.com/bowang-lab/scGPT |
| 6 | Geneformer: Transfer learning enables predictions in network biology | Theodoris et al. | Nature | 2023 | 基因表达的Transformer预训练，类似BERT的基因网络模型 | 30M单细胞数据 | https://huggingface.co/ctheodoris/Geneformer |
| 7 | ChemCrow: Augmenting LLMs with Chemistry Tools | Bran et al. | NeurIPS (Workshop) | 2023 | 基于LLM的化学Agent，集成13种化学工具 | - | https://github.com/ur-whitelab/chemcrow-public |
| 8 | MoleculeSTM: Multi-modal Molecule Structure-Text Model | Liu et al. | ICML | 2023 | 分子结构与文本描述的多模态对齐预训练 | PubChem, ChEBI | https://github.com/chao1224/MoleculeSTM |
| 9 | Drug Repurposing Using Knowledge Graph Embeddings | Morselli Gysi et al. | Nature | 2021 | 知识图谱嵌入用于老药新用，网络医学方法 | DrugBank, DisGeNET | https://github.com/meghana2708/Drug-Repurposing |
| 10 | DiffDock: Diffusion Steps, Twists, and Turns for Molecular Docking | Corso et al. | ICLR | 2023 | 扩散模型用于分子对接的生成式框架 | PDBBind | https://github.com/gcorso/DiffDock |
| 11 | DNABERT-2: Efficient Foundation Model and Benchmark for Multi-Species Genome | Zhou et al. | ICLR | 2024 | 高效DNA序列基础模型，使用BPE tokenization | GUE benchmark | https://github.com/MAGICS-LAB/DNABERT_2 |
| 12 | GenePT: A Simple But Effective Foundation Model for Genes Using ChatGPT Embeddings | Chen and Zou | NeurIPS | 2024 | 利用ChatGPT嵌入构建基因表示，简单高效 | 多个基因功能数据集 | https://github.com/yiqunchen/GenePT |
| 13 | BioMedGPT: Open Multimodal Generative Pre-trained Transformer for BioMedicine | Luo et al. | arXiv/Nature MI | 2024 | 生物医学多模态GPT，融合分子、蛋白质、文本 | PubMed, UniProt | https://github.com/PharMolix/OpenBioMed |
| 14 | ProFSA: Self-Supervised Pocket Pretraining via Protein Fragment-Surrogate Learning | Zhang et al. | ICML | 2024 | 蛋白质口袋预训练用于药物筛选 | scPDB, PDBBind | https://github.com/zhangjim/ProFSA |
| 15 | CellPLM: Pre-training of Cell Language Model Beyond Single Cells | Wen et al. | ICLR | 2024 | 超越单细胞的细胞语言模型预训练 | 多个scRNA-seq | https://github.com/OmicsML/CellPLM |
| 16 | MolFM: A Multimodal Molecular Foundation Model | Luo et al. | ICML | 2023 | 融合分子图、3D构象、文本的多模态分子基础模型 | PubChem | https://github.com/PharMolix/MolFM |
| 17 | DrugAgent: Multi-Agent Framework for Automated Drug Discovery | - | arXiv | 2024 | 多Agent协作框架实现自动化药物发现pipeline | ChEMBL | - |
| 18 | TargetDiff: 3D Equivariant Diffusion for Target-Aware Molecule Generation | Guan et al. | ICML | 2023 | 靶标感知的3D等变扩散模型生成药物分子 | CrossDocked2020 | https://github.com/guanjq/targetdiff |
| 19 | Evo: Genomic Foundation Model for Molecular to Genome-Scale Biology | Nguyen et al. | Science | 2024 | DNA序列的大规模基础模型，支持基因到基因组尺度预测 | OpenGenome | https://github.com/evo-design/evo |
| 20 | GIT-Mol: A Multi-modal Large Language Model for Molecular Science | Liu et al. | AAAI | 2024 | 多模态LLM融合Graph、Image、Text进行分子理解 | PubChem | https://github.com/AI-HPC-Research-Team/GIT-Mol |
| 21 | CASTER: Predicting Drug Interactions with Chemical Substructure Representation | Huang et al. | AAAI | 2020 | 化学子结构表示预测药物相互作用 | DrugBank DDI | https://github.com/kexinhuang12345/CASTER |
| 22 | SynerGPT: In-Context Learning for Personalized Drug Synergy Prediction | Gao et al. | NeurIPS | 2024 | 利用上下文学习进行个性化药物协同预测 | DrugComb | - |
| 23 | Hyena-DNA: Long-Range Genomic Sequence Modeling at Single Nucleotide Resolution | Nguyen et al. | NeurIPS | 2023 | 基于Hyena算子的超长DNA序列建模 | Genomics benchmarks | https://github.com/HazyResearch/hyena-dna |
| 24 | PRISM: Genomics-Guided Drug Sensitivity Prediction | Corsello et al. | Nature Cancer | 2020 | 大规模药物敏感性图谱关联基因组特征 | PRISM Repurposing | https://depmap.org/repurposing |
| 25 | DeepPurpose: A Deep Learning Library for Drug-Target Interaction Prediction | Huang et al. | Bioinformatics | 2021 | 集成多种编码器的DTI预测框架 | BindingDB, DAVIS, KIBA | https://github.com/kexinhuang12345/DeepPurpose |

## 3. 方法分类体系

### 3.1 基于基因组基础模型的方法

该类方法通过大规模预训练建立基因组数据的通用表示。代表工作包括：

- **DNABERT/DNABERT-2**：使用k-mer或BPE对DNA序列进行tokenization，通过MLM预训练学习DNA的语义表示。优点是预训练表示可迁移至下游任务；缺点是主要捕获序列级别特征，难以直接建模基因调控网络。
- **Geneformer**：将基因表达量rank化作为token，使用类BERT架构预训练。在3000万单细胞数据上训练，能捕获基因网络关系。
- **scGPT**：面向单细胞多组学的GPT模型，支持基因表达、染色质可及性等多种组学数据。
- **Evo**：长序列基因组基础模型，支持从分子到基因组尺度的多层次预测。

**优点**：能学到丰富的生物学先验知识，迁移学习效果好
**局限**：模型较大，微调成本高；与药物化学信息的桥接不够直接

### 3.2 基于分子表示学习的药物发现方法

该类方法关注药物分子的表示学习和性质预测：

- **Uni-Mol**：统一的3D分子预训练框架，同时建模原子和分子对。
- **MoleculeSTM**：多模态预训练，对齐分子结构与文本描述。
- **GIT-Mol**：融合Graph、Image、Text三种模态的分子LLM。
- **MolFM**：结合分子图、3D构象和文本的多模态基础模型。

**优点**：分子表示质量高，性质预测准确
**局限**：缺乏与基因组/疾病信息的关联建模

### 3.3 基于AI Agent的自动化药物发现方法

该类方法利用LLM驱动的Agent架构实现药物发现的自动化流程：

- **ChemCrow**：将LLM与13种化学工具集成，能执行分子搜索、反应预测等任务。
- **DrugAgent**：多Agent协作框架，包含文献搜索Agent、分子设计Agent、ADMET评估Agent等。

**优点**：流程自动化程度高，能调用外部工具
**局限**：当前Agent的规划能力有限，缺乏对基因组数据的深度利用；决策可靠性需要提升

### 3.4 基于知识图谱的药物重定位方法

该类方法构建药物-基因-疾病知识图谱，通过图推理发现新的药物-适应症关联：

- **TxGNN**：在治疗知识图谱上使用几何GNN实现零样本药物适应症预测。
- **药物重定位KGE方法**：使用知识图谱嵌入(TransE, RotatE等)预测药物新用途。

**优点**：能利用丰富的生物医学知识，解释性较好
**局限**：知识图谱构建依赖人工标注，更新不及时；GNN在大规模图上的扩展性有限

### 3.5 方法对比总结

| 方法类别 | 优势 | 局限性 | 代表论文 | 适用场景 |
|---------|------|--------|---------|---------|
| 基因组基础模型 | 丰富的生物学先验 | 与药物信息桥接不足 | Geneformer, scGPT, DNABERT-2 | 靶点发现、基因功能预测 |
| 分子表示学习 | 分子表示精确 | 缺乏生物学背景 | Uni-Mol, MoleculeSTM | 分子性质预测、虚拟筛选 |
| AI Agent | 流程自动化 | 基因组利用不足 | ChemCrow, DrugAgent | 自动化研发流程 |
| 知识图谱 | 知识丰富、可解释 | 扩展性有限 | TxGNN | 药物重定位 |
| 扩散模型生成 | 3D结构感知 | 计算成本高 | DiffDock, TargetDiff | 分子对接、分子生成 |

## 4. 公开数据集与基准

| 数据集名称 | 来源 | 规模 | 任务类型 | 下载链接 | 常用指标 |
|-----------|------|------|---------|---------|---------|
| GDSC (Genomics of Drug Sensitivity in Cancer) | Sanger Institute | ~1000细胞系 × ~500药物 | 药物敏感性预测 | https://www.cancerrxgene.org/ | IC50, AUC, PCC, RMSE |
| CCLE (Cancer Cell Line Encyclopedia) | Broad Institute | ~1800细胞系 | 基因组特征+药物响应 | https://depmap.org/portal/ | PCC, Spearman |
| PRISM Repurposing | Broad Institute | ~1500化合物 × ~900细胞系 | 大规模药物敏感性 | https://depmap.org/repurposing/ | AUC, IC50 |
| BindingDB | BindingDB | ~2.8M条记录 | 药物-靶点相互作用 | https://www.bindingdb.org/ | AUROC, AUPRC |
| DAVIS | Davis et al. | 442蛋白-68药物 | 激酶抑制剂活性 | http://staff.cs.utu.fi/~aMDPI/drugTargetInteraction/ | MSE, CI |
| KIBA | Tang et al. | 229蛋白-2111药物 | 药物-靶点亲和力 | 同上 | MSE, CI |
| PDBBind | PDBBind-CN | ~23K复合物 | 蛋白质-配体结合亲和力 | http://www.pdbbind.org.cn/ | RMSE, PCC |
| DrugComb | DrugComb | ~750K组合 | 药物协同预测 | https://drugcomb.fimm.fi/ | Synergy Score, CSS |
| GUE Benchmark | DNABERT-2 | 多任务 | DNA序列理解 | https://github.com/MAGICS-LAB/DNABERT_2 | Accuracy, F1 |
| TCGA (The Cancer Genome Atlas) | NCI | ~11K患者/33种癌症 | 多组学癌症数据 | https://portal.gdc.cancer.gov/ | 因任务而异 |
| DrugBank | DrugBank | ~14K药物 | 药物知识库 | https://go.drugbank.com/ | - |
| ChEMBL | EMBL-EBI | ~2.4M化合物 | 药物活性数据 | https://www.ebi.ac.uk/chembl/ | 因任务而异 |

## 5. 研究空白分析

### 5.1 现有方法的共同局限

1. **基因组信息与药物信息的割裂**：当前的基因组基础模型（Geneformer, scGPT等）和药物分子模型（Uni-Mol, MoleculeSTM等）各自发展，缺乏有效的跨模态桥接机制将基因组特征与药物化学信息深度融合。

2. **Agent架构缺乏基因组感知能力**：现有的化学AI Agent（ChemCrow, DrugAgent）主要依赖文本接口调用工具，无法直接处理和推理基因组数据，限制了其在精准医疗药物发现中的应用。

3. **缺乏从基因组到药物的端到端推理**：目前的方法通常将靶点发现和药物设计作为独立的阶段，缺乏统一的框架实现从基因组异常到药物分子的端到端推理。

4. **药物敏感性预测中的多组学利用不充分**：虽然多组学数据（基因组、转录组、蛋白质组等）日益丰富，但现有方法在融合这些异构数据方面仍然粗糙。

### 5.2 未被充分探索的方向

1. **Agent驱动的基因组-药物闭环推理**：利用AI Agent的规划和工具调用能力，构建从基因组数据分析到药物候选推荐的完整闭环系统。

2. **基因组基础模型的药物发现迁移**：将Geneformer等基因组基础模型的表示能力迁移至药物敏感性预测任务，实现生物学先验知识的有效利用。

3. **多Agent协作的精准药物匹配**：设计专业化的多Agent系统，不同Agent负责基因组分析、靶点识别、药物筛选、ADMET评估等不同环节，通过协作完成精准药物推荐。

### 5.3 技术机遇

1. **LLM的强大推理能力**：GPT-4等LLM展现出的推理和规划能力，可以作为Agent的核心引擎，驱动药物发现工作流程。

2. **基础模型的跨域迁移**：预训练的基因组模型和分子模型可以通过适配器(Adapter)或提示调优(Prompt Tuning)进行跨域知识迁移。

3. **检索增强生成(RAG)**：将生物医学文献和数据库作为外部知识源，增强Agent的决策质量。

4. **工具调用能力成熟**：LLM的Function Calling能力使得Agent可以无缝调用各种生物信息学工具和数据库API。

## 6. 推荐研究方向

### 6.1 方向描述

**GenoDrug-Agent: 基因组感知的多Agent药物发现框架**

提出一个以基因组数据为核心驱动的多Agent药物发现框架(GenoDrug-Agent)。该框架包含三个核心组件：(1) 基因组分析Agent，使用预训练基因组模型处理多组学数据并识别潜在药物靶点；(2) 跨模态桥接模块(Genomic-Chemical Bridge)，将基因组特征空间与药物分子特征空间对齐；(3) 药物推荐Agent，基于桥接后的统一表示空间进行精准药物匹配和生成。三个组件通过一个中央规划Agent协调运作。

### 6.2 可行性分析

该方向的可行性基于以下几点：
- 基因组基础模型(Geneformer, scGPT)和分子基础模型(Uni-Mol, MoleculeSTM)均已开源，可以直接复用其预训练权重
- GDSC、CCLE、PRISM等药物敏感性数据集提供了基因组特征与药物响应的配对数据，可用于训练桥接模块
- Agent框架（LangChain, AutoGen等）已较为成熟，可快速搭建多Agent系统
- 在1-2张A100上，通过冻结预训练模型 + 训练轻量桥接模块的策略，计算成本完全可控

### 6.3 预期创新点

1. **基因组感知的Agent架构**：首次将基因组基础模型集成到AI Agent的感知层，使Agent能直接理解和推理基因组数据
2. **跨模态对比桥接(Cross-Modal Contrastive Bridge)**：设计新的对比学习目标，将基因组表示空间与药物分子表示空间对齐
3. **Agent协作的闭环药物推理**：多Agent协作实现从基因组异常检测到药物推荐的完整闭环

### 6.4 目标venue适配性

该方向适合投递ICML 2026，原因如下：
- **方法创新性强**：提出了新的跨模态桥接机制和Agent架构，符合ICML对方法论贡献的要求
- **涉及多个ML核心主题**：包括多模态学习、对比学习、Agent/LLM、迁移学习
- **实验全面**：可以在多个标准benchmark上进行系统评测
- **应用价值明确**：药物发现是AI for Science的核心方向，ICML近年来越来越重视此类工作

---

**注意**：本调研报告中的论文引用基于作者的领域知识整理。部分论文的具体发表年份、venue和GitHub链接需要手动验证确认。建议在正式引用前通过Google Scholar或Semantic Scholar核实每篇论文的准确信息。
