# GenoDrug-Agent: 基因组感知的多Agent药物发现框架 研究方案

## 1. 研究问题与动机

### 1.1 问题定义

本研究旨在解决以下核心问题：**如何构建一个基因组数据驱动的AI Agent系统，实现从基因组异常模式到药物候选分子的端到端自动推理？**

具体而言，给定患者或细胞系的多组学数据（基因表达谱、突变信息、拷贝数变异等），系统需要自动完成：(1) 识别关键致病基因和药物靶点；(2) 将基因组特征映射到药物化学空间；(3) 推荐或生成匹配的候选药物分子；(4) 评估药物的ADMET性质和安全性。

### 1.2 研究动机

当前AI药物发现面临的关键瓶颈在于**基因组信息与药物化学信息的割裂**：

- 基因组基础模型（如Geneformer、scGPT）能够很好地理解基因表达模式和基因网络关系，但无法直接用于药物推荐
- 分子基础模型（如Uni-Mol、MoleculeSTM）在药物性质预测上表现优异，但缺乏对患者基因组背景的感知
- 现有AI Agent（如ChemCrow）依赖文本接口，无法直接处理高维基因组数据，限制了精准药物发现的能力

这种割裂导致目前的计算药物发现流程仍然高度碎片化，需要人工在各个阶段间传递信息和做出判断。

### 1.3 目标

1. 提出GenoDrug-Agent框架，实现基因组数据到药物推荐的自动化闭环
2. 设计跨模态对比桥接模块(Cross-Modal Contrastive Bridge, CMCB)，对齐基因组表示空间与药物分子表示空间
3. 在GDSC、PRISM等标准药物敏感性预测基准上，超越现有SOTA方法5%+
4. 在端到端药物推荐任务上，展示Agent框架相比于非Agent方法的优势

## 2. 创新点

### 创新点1: 基因组感知的Agent架构 (Genome-Aware Agent Architecture)
- **描述**: 提出首个将预训练基因组基础模型（Geneformer）集成为Agent感知层的药物发现框架。不同于ChemCrow等仅使用文本接口的Agent，我们的Genomic Analysis Agent能直接处理基因表达矩阵，通过Geneformer提取生物学有意义的基因嵌入，并将其转化为Agent可理解的结构化状态表示。
- **解决的问题**: 现有Agent无法直接处理高维基因组数据，只能依赖预处理后的文本描述，丢失了大量信息。
- **与现有工作的区别**: ChemCrow和DrugAgent使用文本API调用生物信息学工具；我们将基因组基础模型深度集成到Agent感知层，实现端到端的基因组理解。
- **技术依据**: 基于Geneformer (Theodoris et al., Nature 2023)的预训练表示能力，以及ReAct (Yao et al., ICLR 2023)的Agent推理框架。

### 创新点2: 跨模态对比桥接模块 (Cross-Modal Contrastive Bridge, CMCB)
- **描述**: 设计一个轻量级的跨模态桥接模块，通过对比学习将基因组表示空间和药物分子表示空间对齐到统一的语义空间。该模块以细胞系的基因组特征为锚点，以该细胞系对某药物的IC50值为监督信号，学习基因组-药物的对应关系。引入硬负样本挖掘(Hard Negative Mining)策略和药物结构感知的温度自适应机制(Structure-aware Temperature Scaling)。
- **解决的问题**: 基因组表示和药物分子表示处于完全不同的特征空间，无法直接计算相似度或进行匹配。
- **与现有工作的区别**: DrugCLIP对齐的是药物分子与蛋白质口袋；我们对齐的是基因组表达特征与药物分子，这在粒度和信息含量上完全不同。CMCB还引入了药敏感度感知的对比目标，不仅学习"哪些配对"，还学习"配对的强度"。
- **技术依据**: 基于CLIP (Radford et al., ICML 2021)和DrugCLIP (Gao et al., NeurIPS 2024)的对比学习范式。

### 创新点3: 多Agent协作的闭环药物推理 (Multi-Agent Collaborative Drug Reasoning)
- **描述**: 设计四个专业化Agent的协作机制：(1) Genomic Analyst Agent负责基因组数据分析和靶点识别；(2) Bridge Agent负责跨模态映射；(3) Drug Recommender Agent负责在统一空间中检索和推荐药物；(4) Safety Evaluator Agent负责ADMET评估和安全性检查。四个Agent通过一个中央Planner Agent的调度进行协作，Planner Agent维护一个共享的推理状态(Reasoning State)，记录每一步的分析结论和不确定度。
- **解决的问题**: 药物发现涉及多个专业领域的知识，单一模型或Agent难以覆盖所有环节。
- **与现有工作的区别**: 与DrugAgent相比，我们的Agent系统(1)具有基因组感知能力，(2)使用学习到的跨模态桥接而非启发式规则，(3)引入不确定度估计指导Agent决策。
- **技术依据**: 基于AutoGen (Wu et al., 2024)的多Agent对话框架和ReAct推理策略。

## 3. 方法概述

### 3.1 整体框架

GenoDrug-Agent是一个多Agent协作的药物发现系统。整体流程：

1. 输入：细胞系/患者的多组学数据（基因表达谱为主，可选地包含突变、CNV等信息）
2. Genomic Analyst Agent使用预训练的Geneformer提取基因嵌入，识别差异表达基因和潜在靶点
3. Bridge Agent通过CMCB模块将基因组特征映射到药物化学空间
4. Drug Recommender Agent在统一表示空间中检索最佳候选药物
5. Safety Evaluator Agent评估候选药物的ADMET性质
6. Planner Agent汇总所有信息，输出最终的药物推荐报告

### 3.2 模型架构

#### ASCII架构图

```
                              ┌─────────────────────────────────┐
                              │        Planner Agent            │
                              │   (中央调度 + 推理状态管理)       │
                              └───┬───────┬───────┬───────┬─────┘
                                  │       │       │       │
                    ┌─────────────┘       │       │       └──────────────┐
                    v                     v       v                      v
         ┌──────────────────┐  ┌──────────────┐  ┌──────────────────┐  ┌────────────────┐
         │ Genomic Analyst  │  │ Bridge Agent │  │Drug Recommender  │  │Safety Evaluator│
         │     Agent        │  │              │  │     Agent        │  │    Agent       │
         └────────┬─────────┘  └──────┬───────┘  └────────┬─────────┘  └───────┬────────┘
                  │                   │                    │                    │
                  v                   v                    v                    v
         ┌──────────────────┐  ┌──────────────┐  ┌──────────────────┐  ┌────────────────┐
         │   Geneformer     │  │    CMCB      │  │   Uni-Mol        │  │  ADMET Tools   │
         │  (预训练冻结)     │  │ (可训练桥接)  │  │  (预训练冻结)     │  │  (外部API)     │
         └────────┬─────────┘  └──────┬───────┘  └────────┬─────────┘  └───────┬────────┘
                  │                   │                    │                    │
    ┌─────────────┘                   │                    │                    │
    v                                 v                    v                    v
┌─────────┐              ┌────────────────┐         ┌──────────┐        ┌───────────┐
│Gene Expr│              │Unified Semantic│         │Drug      │        │ADMET      │
│ Matrix  │              │    Space       │         │Database  │        │Prediction │
└─────────┘              └────────────────┘         └──────────┘        └───────────┘
```

#### 架构详细说明

**Genomic Analyst Agent**
- 输入：基因表达矩阵 X ∈ R^(N_genes × 1)（单个样本）或 X ∈ R^(N_cells × N_genes)（scRNA-seq）
- 处理：使用预训练Geneformer将基因按表达量排序编码为token序列，提取[CLS] token作为样本级嵌入 h_g ∈ R^256
- 工具：差异分析工具、基因集富集分析(GSEA)工具、通路分析工具
- 输出：基因组嵌入 h_g、差异基因列表、富集通路

**Cross-Modal Contrastive Bridge (CMCB)**
- 输入：基因组嵌入 h_g ∈ R^256 和药物分子嵌入 h_d ∈ R^512
- 基因组投影器：两层MLP，256 → 512 → 512，LayerNorm + GELU
- 药物投影器：两层MLP，512 → 512 → 512，LayerNorm + GELU
- 对比目标：InfoNCE loss with Structure-aware Temperature Scaling
- 输出：对齐后的基因组向量 z_g ∈ R^512 和药物向量 z_d ∈ R^512

**Drug Recommender Agent**
- 输入：对齐后的基因组向量 z_g
- 药物数据库：预计算所有候选药物的 z_d（使用Uni-Mol + 药物投影器）
- 检索策略：Cosine similarity + 药敏度预测回归头
- 输出：Top-K候选药物列表及预测的药敏度

**Safety Evaluator Agent**
- 输入：候选药物SMILES
- 工具：RDKit属性计算、SwissADME API、pkCSM预测
- 评估维度：Lipinski规则、溶解度、代谢稳定性、毒性预测
- 输出：ADMET报告和安全性评分

### 3.3 训练策略

**阶段一：预训练模型加载（不训练）**
- 加载Geneformer预训练权重，冻结所有参数
- 加载Uni-Mol预训练权重，冻结所有参数

**阶段二：CMCB桥接模块训练**
- 训练数据：GDSC数据集中的细胞系基因表达-药物IC50配对
- 损失函数：L = L_contrastive + λ * L_regression
  - L_contrastive: InfoNCE对比损失，以药物-细胞系配对的IC50为软标签
  - L_regression: 预测IC50的回归损失(MSE)
- 优化器：AdamW, lr=1e-4, weight_decay=0.01
- 训练：100 epochs, batch_size=128, warmup 10%

**阶段三：端到端微调（可选）**
- 解冻Geneformer最后2层和Uni-Mol最后2层
- 使用更小学习率(1e-5)进行端到端微调
- 训练：20 epochs

### 3.4 关键技术细节

**Structure-aware Temperature Scaling**

标准InfoNCE使用固定温度τ，我们根据药物的化学结构相似性自适应调整温度：

```
τ_ij = τ_base * (1 + α * sim_struct(d_i, d_j))
```

其中 sim_struct 是基于Tanimoto指纹的结构相似性，α是可学习参数。这使得结构相似的药物对需要更精细的区分。

**Hard Negative Mining**

在每个mini-batch内，对于每个基因组锚点，选择与其匹配药物化学结构最相似但生物活性不同的药物作为难负样本：

```
Neg_hard(g_i, d_i) = {d_j | sim_struct(d_i, d_j) > θ 且 |IC50_i - IC50_j| > δ}
```

**不确定度估计**

使用MC Dropout在推理时进行多次前向传播（T=10次），估计预测不确定度：

```
uncertainty(g, d) = Var([f_t(g, d) for t in 1..T])
```

不确定度高的预测将被标记，由Planner Agent决定是否需要额外验证。

## 4. 数据集

| 数据集 | 来源 | 规模 | 用途 | 下载方式 | 预处理方法 |
|-------|------|------|------|---------|-----------|
| GDSC v2 | Sanger Institute | 805细胞系 × 198药物 | 主训练集（药物敏感性预测） | https://www.cancerrxgene.org/downloads | 基因表达：log2(TPM+1)标准化；IC50：log变换 |
| CCLE | Broad/DepMap | 1406细胞系 | 基因组特征补充 | https://depmap.org/portal/download/ | 与GDSC细胞系匹配后merge |
| PRISM | Broad/DepMap | 1448化合物 × 930细胞系 | 独立测试集 | https://depmap.org/repurposing/ | 同GDSC预处理流程 |
| DrugBank 5.0 | DrugBank | ~14K药物 | 药物SMILES和属性 | https://go.drugbank.com/releases/ | 提取approved药物的SMILES |
| PubChem | NIH/NCBI | ~110M化合物 | 药物指纹计算 | PubChemPy API | 计算Morgan fingerprint |

### 4.1 数据预处理流程

1. **基因表达数据**：下载GDSC的RMA标准化表达矩阵 → 选择与Geneformer vocabulary匹配的基因 → 按表达量排序生成token序列 → 截断至最大长度2048
2. **药物分子数据**：从DrugBank获取SMILES → RDKit标准化 → 生成3D构象（使用RDKit ETKDG） → 输入Uni-Mol获取分子嵌入
3. **标签数据**：GDSC IC50值 → log变换 → Z-score标准化 → 二值化（以中位数为阈值，用于分类任务）

### 4.2 数据划分

- 训练集/验证集/测试集 = 70%/10%/20%
- **冷启动测试**：划分留出一部分测试集，其中的细胞系或药物在训练集中未出现
  - Cold-Drug：测试药物在训练中未见
  - Cold-Cell：测试细胞系在训练中未见
  - Cold-Both：两者都未见

## 5. 基线方法

| 基线方法 | 论文 | 年份 | 开源代码链接 | 关键指标 |
|---------|------|------|-------------|---------|
| DeepCDR | Li et al., Bioinformatics | 2020 | https://github.com/kimmo1019/DeepCDR | PCC: 0.90+ on GDSC |
| GraphDRP | Nguyen et al., Bioinformatics | 2022 | https://github.com/hauldhut/GraphDRP | PCC, RMSE on GDSC |
| TGSA | Zhu et al., AAAI | 2022 | https://github.com/violet-sto/TGSA | PCC, RMSE on GDSC/CCLE |
| DrugCell | Kuenzi et al., Cancer Cell | 2020 | https://github.com/idekerlab/DrugCell | PCC, AUROC on GDSC |
| DeepPurpose | Huang et al., Bioinformatics | 2021 | https://github.com/kexinhuang12345/DeepPurpose | MSE, CI on DAVIS/KIBA |
| HiDRA | Jin et al., NeurIPS | 2021 | https://github.com/GIST-CSBL/HiDRA | PCC on GDSC |
| MOFFIT | Baseline (MLP) | - | 自行实现 | 基础MLP作为下限 |

### 各基线简述

- **DeepCDR**: 使用CNN处理药物分子图+基因组特征，融合后预测IC50
- **GraphDRP**: 使用GNN对药物分子图编码，与基因组特征融合预测
- **TGSA**: 组织引导的注意力机制，利用基因-基因交互图
- **DrugCell**: 将基因本体(GO)结构编码为可解释的神经网络
- **DeepPurpose**: 灵活的DTI预测框架，支持多种编码器组合
- **HiDRA**: 层次化药物响应注意力网络

## 6. 评估指标

| 指标名称 | 数学定义 | 评估维度 | 备注 |
|---------|---------|---------|------|
| PCC (Pearson Correlation) | corr(y_pred, y_true) | 回归预测质量 | 主要指标 |
| RMSE | sqrt(mean((y_pred - y_true)^2)) | 回归预测精度 | 越低越好 |
| Spearman Correlation | rank_corr(y_pred, y_true) | 排序一致性 | 对异常值鲁棒 |
| AUROC | ROC曲线下面积 | 二分类性能 | 敏感/耐药分类 |
| AUPRC | PR曲线下面积 | 不平衡分类性能 | 关注敏感药物 |
| Hit Rate@K | 前K推荐中有效药物比例 | 药物推荐质量 | K=10,20,50 |
| Cold-start PCC | 冷启动场景下的PCC | 泛化能力 | 关键差异化指标 |

## 7. 消融实验设计

| 实验编号 | 消融对象 | 具体做法 | 验证目的 |
|---------|---------|---------|---------|
| A1 | Geneformer预训练 | 用随机初始化的Transformer替换Geneformer | 验证基因组预训练的贡献 |
| A2 | CMCB对比学习 | 移除对比损失，仅保留回归损失 | 验证跨模态对齐的必要性 |
| A3 | Hard Negative Mining | 使用随机负样本替换 | 验证难负样本策略的效果 |
| A4 | Structure-aware Temperature | 使用固定温度τ=0.07 | 验证自适应温度的贡献 |
| A5 | Uni-Mol预训练 | 用Morgan指纹+MLP替换Uni-Mol | 验证3D分子预训练的贡献 |
| A6 | Agent协作机制 | 移除Agent框架，直接使用单模型端到端预测 | 验证Agent架构的优势 |
| A7 | 不确定度估计 | 移除MC Dropout | 验证不确定度引导的价值 |
| A8 | 端到端微调 | 仅训练CMCB，不解冻预训练模型 | 验证微调预训练模型的增益 |

## 8. 计算资源评估

### 8.1 GPU显存估算

- Geneformer参数量: ~30M parameters (冻结) → 推理时约2GB显存
- Uni-Mol参数量: ~50M parameters (冻结) → 推理时约3GB显存
- CMCB桥接模块: ~5M parameters (可训练) → 梯度约0.5GB
- 基因组嵌入缓存: 805细胞系 × 256维 ≈ 0.8MB
- 药物嵌入缓存: 198药物 × 512维 ≈ 0.4MB
- 对比学习batch: 128对 × (512+512)维 → 约1GB
- **峰值显存估计**: ~15GB (阶段二, 仅训练CMCB)
- **峰值显存估计**: ~40GB (阶段三, 端到端微调) 

两阶段均可在单张A100 80GB上运行。

### 8.2 训练时间估算

- 预训练模型推理（一次性）: ~2小时（提取所有嵌入）
- CMCB训练: 100 epochs × ~5 min/epoch ≈ 8.3小时 (1x A100)
- 端到端微调: 20 epochs × ~30 min/epoch ≈ 10小时 (1x A100)
- 基线复现: ~5小时/个 × 6个 = ~30小时
- 消融实验: ~5小时/个 × 8个 = ~40小时
- **总计**: ~90小时 ≈ 4天 (1x A100) 或 ~2天 (2x A100 with DDP)

### 8.3 推理时间估算

- 单个样本的完整Agent推理pipeline: ~5秒
- 批量评估全部测试集: ~30分钟

## 9. 基于的论文和开源代码

| 参考论文 | 使用方式 | GitHub链接 | 许可证 |
|---------|---------|-----------|--------|
| Geneformer (Theodoris et al., Nature 2023) | 基因组编码器，加载预训练权重 | https://huggingface.co/ctheodoris/Geneformer | Apache-2.0 |
| Uni-Mol (Zhou et al., ICLR 2023) | 分子编码器，加载预训练权重 | https://github.com/deepmodeling/Uni-Mol | MIT |
| CLIP (Radford et al., ICML 2021) | 对比学习框架参考实现 | https://github.com/openai/CLIP | MIT |
| DeepCDR (Li et al., 2020) | 基线方法代码 | https://github.com/kimmo1019/DeepCDR | MIT |
| DeepPurpose (Huang et al., 2021) | DTI基线方法 | https://github.com/kexinhuang12345/DeepPurpose | BSD-3 |

### 9.1 代码复用计划

- **从Geneformer复用**: 基因表达tokenizer、预训练模型加载代码
- **从Uni-Mol复用**: 分子3D构象生成、预训练模型加载和推理代码
- **从CLIP复用**: InfoNCE损失函数实现、温度参数管理
- **自行开发**: CMCB模块、Structure-aware Temperature Scaling、Agent框架集成、训练pipeline、评估pipeline

## 10. 风险评估与备选方案

| 风险 | 可能性 | 影响 | 备选方案 |
|------|--------|------|---------|
| Geneformer表示与药物空间对齐困难 | 中 | 高 | 增加桥接模块深度；使用更大的训练集(CCLE+GDSC) |
| 冷启动场景性能不佳 | 中 | 中 | 引入元学习(MAML)策略；增加预训练数据多样性 |
| Agent推理延迟过高 | 低 | 中 | 使用嵌入缓存减少预训练模型推理次数；简化Agent对话轮数 |
| GDSC数据量不足以训练CMCB | 中 | 高 | 合并GDSC+PRISM+CCLE；使用数据增强（基因dropout、药物指纹扰动） |
| 计算资源不足(超出80GB) | 低 | 高 | 使用gradient checkpointing；减小batch size并增加梯度累积 |
| 基线复现困难 | 低 | 低 | 使用官方提供的预训练权重；联系原作者 |

## 11. 时间规划

| 阶段 | 任务 | 时间 | 产出 |
|------|------|------|------|
| 第1-2周 | 环境搭建 + 数据下载预处理 + Geneformer/Uni-Mol加载测试 | 2周 | 数据就绪，预训练模型可用 |
| 第3-4周 | CMCB模块实现 + 基线方法复现 (DeepCDR, GraphDRP, TGSA) | 2周 | 核心模型代码完成，基线结果就绪 |
| 第5-6周 | CMCB训练 + 端到端微调 + Agent框架集成 + 主实验 | 2周 | 主要实验结果 |
| 第7-8周 | 消融实验 + 结果分析可视化 + 论文撰写 | 2周 | 完整论文初稿 |
