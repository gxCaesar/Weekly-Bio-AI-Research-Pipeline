#!/usr/bin/env python3
"""Generate GenoDrugAgent presentation using python-pptx."""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
import os

# Colors
NAVY = RGBColor(0x1E, 0x27, 0x61)
DEEP_BLUE = RGBColor(0x06, 0x5A, 0x82)
TEAL = RGBColor(0x1C, 0x72, 0x93)
ICE = RGBColor(0xCA, 0xDC, 0xFC)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
OFF_WHITE = RGBColor(0xF0, 0xF4, 0xF8)
DARK_TEXT = RGBColor(0x1A, 0x1A, 0x2E)
ACCENT = RGBColor(0x00, 0xA8, 0x96)
ACCENT_DARK = RGBColor(0x02, 0x80, 0x90)
CORAL = RGBColor(0xF9, 0x61, 0x67)
GOLD = RGBColor(0xF9, 0xC8, 0x46)
GRAY = RGBColor(0x6B, 0x72, 0x80)
LIGHT_GRAY = RGBColor(0x9C, 0xA3, 0xAF)

TITLE_FONT = "Georgia"
BODY_FONT = "Calibri"

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

def add_colored_bg(slide, color):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color

def add_rect(slide, left, top, width, height, fill_color, line_color=None, line_width=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    if line_color:
        shape.line.color.rgb = line_color
        shape.line.width = Pt(line_width or 1)
    else:
        shape.line.fill.background()
    return shape

def add_rounded_rect(slide, left, top, width, height, fill_color, line_color=None, line_width=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    if line_color:
        shape.line.color.rgb = line_color
        shape.line.width = Pt(line_width or 1)
    else:
        shape.line.fill.background()
    return shape

def add_oval(slide, left, top, width, height, fill_color):
    shape = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(left), Inches(top), Inches(width), Inches(height))
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    shape.line.fill.background()
    return shape

def add_text_box(slide, left, top, width, height, text, font_size=14, font_name=BODY_FONT,
                 color=DARK_TEXT, bold=False, italic=False, align=PP_ALIGN.LEFT, valign=MSO_ANCHOR.TOP,
                 line_spacing=None):
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.name = font_name
    p.font.color.rgb = color
    p.font.bold = bold
    p.font.italic = italic
    p.alignment = align
    tf.paragraphs[0].space_before = Pt(0)
    tf.paragraphs[0].space_after = Pt(0)
    if line_spacing:
        p.line_spacing = Pt(line_spacing)
    return txBox

def add_multiline_text(slide, left, top, width, height, lines, font_size=14, font_name=BODY_FONT,
                       color=DARK_TEXT, bold=False, align=PP_ALIGN.LEFT, line_spacing=None):
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True
    for i, line in enumerate(lines):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = line
        p.font.size = Pt(font_size)
        p.font.name = font_name
        p.font.color.rgb = color
        p.font.bold = bold
        p.alignment = align
        if line_spacing:
            p.line_spacing = Pt(line_spacing)
    return txBox

# =====================================================================
# SLIDE 1 - TITLE
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank layout
add_colored_bg(slide, NAVY)
add_rect(slide, 0, 0, 13.333, 0.15, ACCENT)

add_text_box(slide, 1.0, 1.5, 11.0, 1.2, "GenoDrugAgent", 48, TITLE_FONT, WHITE, bold=True)
add_multiline_text(slide, 1.0, 2.8, 10.0, 1.2,
    ["AI Agent-Driven Drug Discovery from Genomic Data",
     "with Learned Multi-Step Planning"],
    22, BODY_FONT, ICE, line_spacing=30)

add_rect(slide, 1.0, 4.2, 3.0, 0.06, ACCENT)
add_text_box(slide, 1.0, 4.5, 4.0, 0.6, "ICML 2026", 20, BODY_FONT, GOLD, bold=True)
add_text_box(slide, 1.0, 5.3, 8.0, 0.5, "Research Team  |  University X  |  Institute Y", 14, BODY_FONT, LIGHT_GRAY)

# Decorative circles
for x, y, sz in [(10.5, 2.0, 0.3), (11.2, 2.8, 0.45), (10.8, 3.6, 0.35), (11.5, 4.2, 0.5), (10.3, 4.8, 0.3)]:
    s = add_oval(slide, x, y, sz, sz, TEAL)
    s.fill.fore_color.rgb = TEAL

# =====================================================================
# SLIDE 2 - PROBLEM
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, OFF_WHITE)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "The Drug Discovery Challenge", 36, TITLE_FONT, NAVY, bold=True)

# Stat cards
stats = [
    (0.8, "10+", "Years", "Average development\ntimeline per drug"),
    (4.8, "$2B+", "Cost", "Average cost per\napproved compound"),
    (8.8, "90%", "Failure", "Clinical trial\nfailure rate"),
]
for x, num, unit, desc in stats:
    add_rounded_rect(slide, x, 1.6, 3.5, 2.2, WHITE)
    add_text_box(slide, x + 0.3, 1.8, 2.9, 0.8, num, 44, TITLE_FONT, CORAL, bold=True)
    add_text_box(slide, x + 0.3, 2.6, 2.9, 0.35, unit, 14, BODY_FONT, GRAY, bold=True)
    add_multiline_text(slide, x + 0.3, 2.95, 2.9, 0.7, desc.split("\n"), 13, BODY_FONT, DARK_TEXT)

# Problem bullets
problems = [
    "Genomics and chemistry tools operate in isolation -- biological context lost at boundaries",
    "No feedback loops -- downstream failures never inform upstream decisions",
    "Manual orchestration required -- human experts must bridge disconnected AI tools",
]
for i, text in enumerate(problems):
    y_pos = 4.2 + i * 0.65
    add_oval(slide, 1.0, y_pos, 0.35, 0.35, CORAL)
    add_text_box(slide, 1.02, y_pos - 0.02, 0.35, 0.38, "\u2716", 13, BODY_FONT, WHITE, align=PP_ALIGN.CENTER)
    add_text_box(slide, 1.55, y_pos, 10.5, 0.4, text, 15, BODY_FONT, DARK_TEXT)

# =====================================================================
# SLIDE 3 - KEY INSIGHT
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, NAVY)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "Key Insight", 36, TITLE_FONT, WHITE, bold=True)

add_rounded_rect(slide, 1.5, 1.8, 10.33, 2.0, DEEP_BLUE, ACCENT, 2)
add_multiline_text(slide, 2.0, 1.95, 9.33, 1.7,
    ["Unify genomic understanding and molecular design",
     "in a single AI agent that learns to plan",
     "across the full drug discovery pipeline."],
    24, TITLE_FONT, WHITE, align=PP_ALIGN.CENTER, line_spacing=36)

pillars = [
    ("Genomic Grounding", "Disease biology drives\nmolecular design", ACCENT),
    ("Learned Planning", "MCTS optimizes decisions\nacross the full pipeline", TEAL),
    ("Closed-Loop Learning", "Agent reflects and improves\nfrom trajectory outcomes", ACCENT_DARK),
]
for i, (title, desc, color) in enumerate(pillars):
    px = 1.2 + i * 4.0
    add_rounded_rect(slide, px, 4.3, 3.5, 2.2, color, line_color=color, line_width=1.5)
    add_text_box(slide, px + 0.2, 4.5, 3.1, 0.6, title, 18, TITLE_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)
    add_multiline_text(slide, px + 0.2, 5.2, 3.1, 1.0, desc.split("\n"), 14, BODY_FONT, ICE, align=PP_ALIGN.CENTER)

# =====================================================================
# SLIDE 4 - ARCHITECTURE
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, OFF_WHITE)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "System Architecture", 36, TITLE_FONT, NAVY, bold=True)

layers = [
    (1.5, "Meta-Controller", "LLM-Based Orchestrator", "Decomposes goals, selects modules, performs strategic reasoning", NAVY),
    (2.8, "Genomic Perception", "scGPT + ESM-2 + GWAS", "Encodes gene expression, protein structure, genetic variants", DEEP_BLUE),
    (4.1, "Molecular Design", "Conditional Generation", "Generates and evaluates drug candidates conditioned on genomic context", TEAL),
    (5.4, "Planning Engine", "MCTS + Value Network", "Optimizes multi-step decisions with learned value function and reflection", ACCENT_DARK),
]
for y, title, subtitle, desc, color in layers:
    add_rounded_rect(slide, 1.0, y, 11.33, 1.1, WHITE)
    add_rect(slide, 1.0, y, 0.15, 1.1, color)
    add_text_box(slide, 1.5, y + 0.08, 3.5, 0.45, title, 18, TITLE_FONT, NAVY, bold=True)
    tag = add_rounded_rect(slide, 5.3, y + 0.15, 2.8, 0.35, color)
    tag.fill.fore_color.rgb = color
    add_text_box(slide, 5.35, y + 0.13, 2.7, 0.38, subtitle, 11, BODY_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)
    add_text_box(slide, 1.5, y + 0.58, 10.5, 0.45, desc, 14, BODY_FONT, GRAY)

# Arrows
for ay in [2.6, 3.9, 5.2]:
    add_text_box(slide, 6.3, ay, 0.5, 0.3, "\u25BC", 16, BODY_FONT, ACCENT, align=PP_ALIGN.CENTER)

# =====================================================================
# SLIDE 5 - GCC
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, OFF_WHITE)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "Genomic Context Conditioning (GCC)", 34, TITLE_FONT, NAVY, bold=True)

inputs_data = [
    (0.8, "Gene Expression", "scGPT", "Disease-specific\nexpression profiles", "G"),
    (5.0, "Protein Structure", "ESM-2", "Target protein\nresidue embeddings", "P"),
    (9.2, "GWAS Variants", "MLP Encoder", "Genetic association\nsignals & effects", "V"),
]
for x, title, model, desc, letter in inputs_data:
    add_rounded_rect(slide, x, 1.6, 3.6, 2.2, WHITE)
    add_oval(slide, x + 1.3, 1.75, 0.9, 0.9, ACCENT)
    add_text_box(slide, x + 1.3, 1.77, 0.9, 0.88, letter, 28, TITLE_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)
    add_text_box(slide, x + 0.2, 2.75, 3.2, 0.4, title, 16, TITLE_FONT, NAVY, bold=True, align=PP_ALIGN.CENTER)
    add_text_box(slide, x + 0.8, 3.1, 2.0, 0.3, model, 11, BODY_FONT, ACCENT, bold=True, align=PP_ALIGN.CENTER)
    add_multiline_text(slide, x + 0.2, 3.4, 3.2, 0.4, desc.split("\n"), 12, BODY_FONT, GRAY, align=PP_ALIGN.CENTER)

for ax in [2.5, 6.7, 10.9]:
    add_text_box(slide, ax, 3.85, 0.5, 0.35, "\u25BC", 18, BODY_FONT, ACCENT, align=PP_ALIGN.CENTER)

add_rounded_rect(slide, 2.5, 4.3, 8.33, 1.0, NAVY)
add_text_box(slide, 2.7, 4.4, 7.93, 0.8, "Cross-Attention Fusion:  c_geno = Pool( CrossAttn( G, [P ; V] ) )", 16, "Consolas", ICE, align=PP_ALIGN.CENTER)

add_text_box(slide, 6.3, 5.35, 0.5, 0.35, "\u25BC", 18, BODY_FONT, ACCENT, align=PP_ALIGN.CENTER)

add_rounded_rect(slide, 3.5, 5.8, 6.33, 0.9, TEAL)
add_text_box(slide, 3.7, 5.85, 5.93, 0.8, "Conditional Molecular Generator  p(m | c_geno)", 16, BODY_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)

# =====================================================================
# SLIDE 6 - MCTS
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, OFF_WHITE)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "MCTS-Based Multi-Step Planning", 34, TITLE_FONT, NAVY, bold=True)

# Left: MDP
add_rounded_rect(slide, 0.8, 1.5, 5.6, 5.2, WHITE)
add_text_box(slide, 1.1, 1.6, 5.0, 0.5, "Drug Discovery as MDP", 20, TITLE_FONT, NAVY, bold=True)

mdp_items = [
    ("State S", "Knowledge state: targets,\nmolecules, evaluations"),
    ("Actions A", "analyze_genomics, identify_target,\ngenerate, optimize, evaluate, reflect"),
    ("Reward R", "0.3*affinity + 0.2*ADMET\n+ 0.2*genomic + 0.15*novelty + 0.15*synth"),
    ("Discount", "\u03B3 = 0.99 for long-horizon\noptimization"),
]
for i, (label, desc) in enumerate(mdp_items):
    iy = 2.25 + i * 1.1
    tag = add_rounded_rect(slide, 1.2, iy, 1.4, 0.35, ACCENT)
    add_text_box(slide, 1.22, iy - 0.01, 1.36, 0.36, label, 11, BODY_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)
    add_multiline_text(slide, 2.8, iy, 3.3, 0.8, desc.split("\n"), 12, BODY_FONT, DARK_TEXT)

# Right: MCTS
add_rounded_rect(slide, 6.9, 1.5, 5.6, 3.0, NAVY)
add_text_box(slide, 7.2, 1.6, 5.0, 0.5, "MCTS Algorithm", 20, TITLE_FONT, WHITE, bold=True)
mcts_steps = [
    "1. Select: UCB1 with learned values",
    "2. Expand: Policy network proposes",
    "3. Simulate: Rollout heuristic policy",
    "4. Reflect: LLM analyzes trajectory",
    "5. Backpropagate: Update tree stats",
]
add_multiline_text(slide, 7.4, 2.2, 4.8, 2.1, mcts_steps, 13, "Consolas", ICE, line_spacing=22)

add_rounded_rect(slide, 6.9, 4.8, 5.6, 0.8, DEEP_BLUE)
add_text_box(slide, 7.1, 4.85, 5.2, 0.7, "UCB(s,a) = Q(s,a) + c\u00B7\u03C0(a|s)\u00B7\u221A(ln N(s)/(1+N(s,a)))", 13, "Consolas", GOLD, align=PP_ALIGN.CENTER)

add_rounded_rect(slide, 6.9, 5.8, 5.6, 0.9, WHITE, ACCENT, 1.5)
add_multiline_text(slide, 7.1, 5.85, 5.2, 0.8,
    ["Reflection-Augmented Learning", "Episodic memory stores verbal feedback for future planning"],
    13, BODY_FONT, DARK_TEXT, align=PP_ALIGN.CENTER)

# =====================================================================
# SLIDE 7 - BENCHMARK
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, OFF_WHITE)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "GenoDrugBench: Evaluation Benchmark", 34, TITLE_FONT, NAVY, bold=True)

diseases = [
    ("T2D", "Type 2\nDiabetes", "5 targets", "Easy", ACCENT),
    ("IBD", "Inflammatory\nBowel Disease", "5 targets", "Medium", TEAL),
    ("NSCLC", "Non-Small Cell\nLung Cancer", "6 targets", "Medium", DEEP_BLUE),
    ("AD", "Alzheimer's\nDisease", "6 targets", "Hard", CORAL),
    ("RA", "Rheumatoid\nArthritis", "6 targets", "Medium", ACCENT_DARK),
]
for i, (abbr, name, targets, diff, color) in enumerate(diseases):
    dx = 0.6 + i * 2.5
    add_rounded_rect(slide, dx, 1.6, 2.2, 2.8, WHITE)
    # Colored header
    add_rounded_rect(slide, dx, 1.6, 2.2, 1.0, color)
    add_rect(slide, dx, 2.3, 2.2, 0.3, color)
    add_text_box(slide, dx, 1.7, 2.2, 0.8, abbr, 28, TITLE_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)
    add_multiline_text(slide, dx + 0.15, 2.7, 1.9, 0.7, name.split("\n"), 12, BODY_FONT, DARK_TEXT, align=PP_ALIGN.CENTER)
    add_text_box(slide, dx + 0.15, 3.4, 1.9, 0.3, targets, 12, BODY_FONT, GRAY, align=PP_ALIGN.CENTER)
    diff_color = ACCENT if diff == "Easy" else CORAL if diff == "Hard" else GOLD
    add_rounded_rect(slide, dx + 0.5, 3.75, 1.2, 0.35, diff_color)
    add_text_box(slide, dx + 0.52, 3.73, 1.16, 0.38, diff, 11, BODY_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)

add_text_box(slide, 0.8, 4.8, 5.0, 0.5, "Evaluation Dimensions", 20, TITLE_FONT, NAVY, bold=True)

eval_metrics = [
    (0.8, 5.4, "1", "Target Quality", "Precision, recall, F1 vs. known targets"),
    (0.8, 6.1, "2", "Molecular Quality", "Binding affinity, QED, SA score, validity"),
    (6.8, 5.4, "3", "Genomic Consistency", "Alignment with disease expression"),
    (6.8, 6.1, "4", "Efficiency", "Agent steps, wall-clock time, LLM calls"),
]
for mx, my, num, title, desc in eval_metrics:
    add_oval(slide, mx, my, 0.3, 0.3, ACCENT)
    add_text_box(slide, mx + 0.02, my - 0.02, 0.26, 0.33, num, 12, BODY_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)
    add_text_box(slide, mx + 0.45, my, 2.0, 0.3, title, 14, BODY_FONT, NAVY, bold=True)
    add_text_box(slide, mx + 2.5, my, 3.5, 0.3, desc, 13, BODY_FONT, GRAY)

# =====================================================================
# SLIDE 8 - MAIN RESULTS
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, OFF_WHITE)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "Main Results", 36, TITLE_FONT, NAVY, bold=True)
add_text_box(slide, 0.8, 1.05, 11.5, 0.4, "Averaged over 5 disease benchmark tasks", 14, BODY_FONT, GRAY, italic=True)

# Build table manually with shapes
headers = ["Method", "pIC50 \u2191", "QED \u2191", "Gen.Con. \u2191", "Valid% \u2191", "Steps \u2193"]
col_widths = [2.5, 1.7, 1.7, 1.7, 1.7, 1.7]
data_rows = [
    ["Pipeline", "6.2", "0.61", "0.32", "94.1", "--"],
    ["REINVENT", "7.1", "0.58", "0.28", "96.3", "--"],
    ["ChemCrow", "5.8", "0.55", "0.35", "88.7", "24"],
    ["DrugAgent", "6.5", "0.59", "0.41", "91.2", "31"],
    ["GenoDrugAgent", "7.8", "0.67", "0.62", "93.5", "18"],
]

table_x = 0.8
table_y = 1.6
row_h = 0.45

# Header row
cx = table_x
for j, h in enumerate(headers):
    add_rounded_rect(slide, cx, table_y, col_widths[j], row_h, NAVY)
    align = PP_ALIGN.LEFT if j == 0 else PP_ALIGN.CENTER
    add_text_box(slide, cx + 0.1, table_y + 0.02, col_widths[j] - 0.2, row_h - 0.04, h, 13, BODY_FONT, WHITE, bold=True, align=align)
    cx += col_widths[j]

# Data rows
for i, row in enumerate(data_rows):
    ry = table_y + (i + 1) * row_h
    is_best = (i == len(data_rows) - 1)
    bg_color = RGBColor(0xE8, 0xF5, 0xF0) if is_best else WHITE
    text_color = ACCENT if is_best else DARK_TEXT
    cx = table_x
    for j, val in enumerate(row):
        add_rect(slide, cx, ry, col_widths[j], row_h, bg_color)
        align = PP_ALIGN.LEFT if j == 0 else PP_ALIGN.CENTER
        add_text_box(slide, cx + 0.1, ry + 0.02, col_widths[j] - 0.2, row_h - 0.04, val, 13 if not is_best else 14, BODY_FONT, text_color, bold=is_best, align=align)
        cx += col_widths[j]

# Highlight cards
highlights = [
    (0.8, "+23%", "Higher binding\naffinity vs. best baseline", ACCENT),
    (4.0, "+31%", "Better genomic\nconsistency", TEAL),
    (7.2, "-40%", "Fewer computational\nsteps needed", DEEP_BLUE),
    (10.4, "5x", "Predicted potency\nimprovement", CORAL),
]
for x, num, desc, color in highlights:
    add_rounded_rect(slide, x, 5.0, 2.7, 1.5, WHITE)
    add_text_box(slide, x + 0.2, 5.1, 2.3, 0.65, num, 36, TITLE_FONT, color, bold=True, align=PP_ALIGN.CENTER)
    add_multiline_text(slide, x + 0.2, 5.8, 2.3, 0.55, desc.split("\n"), 12, BODY_FONT, GRAY, align=PP_ALIGN.CENTER)

# =====================================================================
# SLIDE 9 - ABLATION
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, OFF_WHITE)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "Ablation Study", 36, TITLE_FONT, NAVY, bold=True)
add_text_box(slide, 0.8, 1.05, 11.5, 0.4, "Impact of each component on overall performance", 14, BODY_FONT, GRAY, italic=True)

ablations = [
    ("w/o GCC", "Remove Genomic Context", "-45%", "Genomic Consistency", "Consistency drops from 0.62 to 0.34.\nConfirms GCC is essential for\nbiologically grounded generation.", CORAL),
    ("w/o MCTS", "Replace with greedy selection", "+39%", "More Steps Needed", "Agent needs 25 steps vs 18.\nLearned planning significantly\nimproves efficiency.", GOLD),
    ("w/o Reflection", "Remove episodic memory", "Modest", "Consistent Improvement", "Affinity drops from 7.8 to 7.4.\nReflection provides steady gains\nacross all metrics.", TEAL),
]

for i, (title, subtitle, stat, stat_label, detail, color) in enumerate(ablations):
    ax = 0.8 + i * 4.1
    add_rounded_rect(slide, ax, 1.7, 3.7, 5.0, WHITE)
    # Colored header
    add_rounded_rect(slide, ax, 1.7, 3.7, 1.1, color)
    add_rect(slide, ax, 2.5, 3.7, 0.3, color)
    add_text_box(slide, ax + 0.2, 1.8, 3.3, 0.5, title, 22, TITLE_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)
    add_text_box(slide, ax + 0.2, 2.25, 3.3, 0.35, subtitle, 11, BODY_FONT, WHITE, align=PP_ALIGN.CENTER)
    add_text_box(slide, ax + 0.2, 3.1, 3.3, 1.0, stat, 48, TITLE_FONT, color, bold=True, align=PP_ALIGN.CENTER)
    add_text_box(slide, ax + 0.2, 4.05, 3.3, 0.4, stat_label, 13, BODY_FONT, GRAY, bold=True, align=PP_ALIGN.CENTER)
    add_multiline_text(slide, ax + 0.3, 4.6, 3.1, 1.8, detail.split("\n"), 13, BODY_FONT, DARK_TEXT, line_spacing=20)

# =====================================================================
# SLIDE 10 - CASE STUDY
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, OFF_WHITE)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "Case Study: Type 2 Diabetes", 34, TITLE_FONT, NAVY, bold=True)

steps_data = [
    ("1", "Genomic Analysis", "Analyzed T2D GWAS loci and gene expression from pancreatic islet cells"),
    ("2", "Target Identification", "GLP-1R ranked as top target -- validates known biology of GLP-1 agonists"),
    ("3", "Molecular Generation", "Generated 100 candidates with structural similarity to known GLP-1R modulators"),
    ("4", "Reflection & Optimization", "Agent prioritized selectivity over raw potency after early off-target predictions"),
    ("5", "Final Candidates", "Top 5 molecules show novel scaffolds with pIC50 > 8.0 and clean ADMET profiles"),
]

for i, (num, title, desc) in enumerate(steps_data):
    sy = 1.6 + i * 1.1
    add_oval(slide, 1.0, sy, 0.6, 0.6, ACCENT)
    add_text_box(slide, 1.02, sy, 0.56, 0.58, num, 20, TITLE_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)
    if i < len(steps_data) - 1:
        add_rect(slide, 1.27, sy + 0.6, 0.06, 0.5, TEAL)
    add_rounded_rect(slide, 2.0, sy, 10.5, 0.8, WHITE)
    add_text_box(slide, 2.3, sy + 0.05, 3.0, 0.35, title, 16, TITLE_FONT, NAVY, bold=True)
    add_text_box(slide, 2.3, sy + 0.4, 9.8, 0.35, desc, 13, BODY_FONT, GRAY)

# =====================================================================
# SLIDE 11 - KEY CONTRIBUTIONS
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, NAVY)
add_rect(slide, 0, 0, 13.333, 0.08, ACCENT)
add_text_box(slide, 0.8, 0.4, 11.5, 0.8, "Key Contributions", 36, TITLE_FONT, WHITE, bold=True)

contributions = [
    ("01", "Unified Agent Framework", "First system bridging genomic foundation models and molecular design in a single agent"),
    ("02", "Genomic Context Conditioning", "Novel cross-attention mechanism fusing scGPT, ESM-2, and GWAS for conditional generation"),
    ("03", "MCTS Planning for Drug Discovery", "Learned multi-step planning that optimizes across the full discovery pipeline"),
    ("04", "GenoDrugBench Benchmark", "Standardized evaluation across 5 therapeutic areas with comprehensive metrics"),
    ("05", "Open-Source Framework", "Fully reproducible codebase with modular architecture for community extension"),
]

for i, (num, title, desc) in enumerate(contributions):
    cy = 1.5 + i * 1.1
    add_text_box(slide, 0.8, cy, 0.8, 0.8, num, 28, TITLE_FONT, ACCENT, bold=True, align=PP_ALIGN.CENTER)
    add_rect(slide, 1.8, cy + 0.1, 0.04, 0.6, TEAL)
    add_text_box(slide, 2.2, cy, 10.0, 0.4, title, 18, TITLE_FONT, WHITE, bold=True)
    add_text_box(slide, 2.2, cy + 0.42, 10.0, 0.4, desc, 14, BODY_FONT, ICE)

# =====================================================================
# SLIDE 12 - THANK YOU
# =====================================================================
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_colored_bg(slide, NAVY)
add_rect(slide, 0, 0, 13.333, 0.15, ACCENT)
add_text_box(slide, 1.0, 1.5, 11.33, 1.2, "Thank You", 52, TITLE_FONT, WHITE, bold=True, align=PP_ALIGN.CENTER)
add_text_box(slide, 1.0, 2.8, 11.33, 0.7, "Questions & Discussion", 24, BODY_FONT, ICE, align=PP_ALIGN.CENTER)
add_rect(slide, 5.5, 3.8, 2.33, 0.06, ACCENT)

add_rounded_rect(slide, 3.5, 4.3, 6.33, 2.0, DEEP_BLUE)
add_multiline_text(slide, 3.8, 4.5, 5.73, 1.6,
    ["author1@university.edu",
     "github.com/anonymous/genodrugagent",
     "",
     "Code, data, and benchmarks available at project repository"],
    14, BODY_FONT, ICE, align=PP_ALIGN.CENTER, line_spacing=24)

# Decorative circles
for x, y, sz in [(1.5, 5.5, 0.3), (2.0, 6.0, 0.4), (11.0, 5.3, 0.35), (11.5, 6.0, 0.45), (1.0, 6.3, 0.25)]:
    add_oval(slide, x, y, sz, sz, TEAL)

# Save
output_path = "/Users/cgxmac/Desktop/skill/research_plan-workspace/iteration-1/eval-agent-drug-discovery/without_skill/outputs/presentation/GenoDrugAgent_Presentation.pptx"
os.makedirs(os.path.dirname(output_path), exist_ok=True)
prs.save(output_path)
print(f"Presentation saved to {output_path}")
