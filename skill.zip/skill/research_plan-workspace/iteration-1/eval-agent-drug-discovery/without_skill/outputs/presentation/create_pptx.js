const PptxGenJS = require("pptxgenjs");

const pptx = new PptxGenJS();
pptx.layout = "LAYOUT_WIDE";

// Color palette - Ocean/Science theme
const COLORS = {
  navy: "1E2761",
  deepBlue: "065A82",
  teal: "1C7293",
  ice: "CADCFC",
  white: "FFFFFF",
  offWhite: "F0F4F8",
  darkText: "1A1A2E",
  lightText: "E8EDF2",
  accent: "00A896",
  accentDark: "028090",
  coral: "F96167",
  gold: "F9C846",
  gray: "6B7280",
  lightGray: "9CA3AF",
};

// Font choices
const TITLE_FONT = "Georgia";
const BODY_FONT = "Calibri";

// =====================================================================
// SLIDE 1 - TITLE
// =====================================================================
let slide1 = pptx.addSlide();
slide1.background = { color: COLORS.navy };

// Decorative top bar
slide1.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.15,
  fill: { color: COLORS.accent },
});

// Main title
slide1.addText("GenoDrugAgent", {
  x: 1.0, y: 1.5, w: 11.33, h: 1.2,
  fontSize: 48, fontFace: TITLE_FONT, color: COLORS.white,
  bold: true, align: "left",
});

slide1.addText("AI Agent-Driven Drug Discovery from Genomic Data\nwith Learned Multi-Step Planning", {
  x: 1.0, y: 2.8, w: 10.0, h: 1.2,
  fontSize: 22, fontFace: BODY_FONT, color: COLORS.ice,
  align: "left", lineSpacingMultiple: 1.3,
});

// Decorative line
slide1.addShape(pptx.shapes.RECTANGLE, {
  x: 1.0, y: 4.2, w: 3.0, h: 0.06,
  fill: { color: COLORS.accent },
});

slide1.addText("ICML 2026", {
  x: 1.0, y: 4.6, w: 4.0, h: 0.6,
  fontSize: 20, fontFace: BODY_FONT, color: COLORS.gold,
  bold: true, align: "left",
});

slide1.addText("Research Team  |  University X  |  Institute Y", {
  x: 1.0, y: 5.4, w: 8.0, h: 0.5,
  fontSize: 14, fontFace: BODY_FONT, color: COLORS.lightGray,
  align: "left",
});

// DNA helix icon circles (decorative)
const circlePositions = [
  { x: 10.5, y: 2.0 }, { x: 11.2, y: 2.8 }, { x: 10.8, y: 3.6 },
  { x: 11.5, y: 4.2 }, { x: 10.3, y: 4.8 },
];
circlePositions.forEach((pos, i) => {
  const size = 0.3 + (i % 3) * 0.15;
  slide1.addShape(pptx.shapes.OVAL, {
    x: pos.x, y: pos.y, w: size, h: size,
    fill: { color: COLORS.accent, transparency: 60 + i * 5 },
    line: { color: COLORS.teal, width: 1.5 },
  });
});

// =====================================================================
// SLIDE 2 - PROBLEM
// =====================================================================
let slide2 = pptx.addSlide();
slide2.background = { color: COLORS.offWhite };

slide2.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide2.addText("The Drug Discovery Challenge", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 36, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

// Big stat cards - row 1
const statCards = [
  { x: 0.8, y: 1.6, num: "10+", unit: "Years", desc: "Average development\ntimeline per drug" },
  { x: 4.8, y: 1.6, num: "$2B+", unit: "Cost", desc: "Average cost per\napproved compound" },
  { x: 8.8, y: 1.6, num: "90%", unit: "Failure", desc: "Clinical trial\nfailure rate" },
];

statCards.forEach((card) => {
  slide2.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: card.x, y: card.y, w: 3.5, h: 2.2,
    fill: { color: COLORS.white },
    shadow: { type: "outer", blur: 6, offset: 2, color: "C0C0C0", opacity: 0.3 },
    rectRadius: 0.15,
  });
  slide2.addText(card.num, {
    x: card.x + 0.3, y: card.y + 0.2, w: 2.9, h: 0.9,
    fontSize: 44, fontFace: TITLE_FONT, color: COLORS.coral,
    bold: true, align: "left", margin: 0,
  });
  slide2.addText(card.unit, {
    x: card.x + 0.3, y: card.y + 1.0, w: 2.9, h: 0.4,
    fontSize: 14, fontFace: BODY_FONT, color: COLORS.gray,
    bold: true, align: "left", margin: 0,
  });
  slide2.addText(card.desc, {
    x: card.x + 0.3, y: card.y + 1.35, w: 2.9, h: 0.7,
    fontSize: 13, fontFace: BODY_FONT, color: COLORS.darkText,
    align: "left", lineSpacingMultiple: 1.2, margin: 0,
  });
});

// Problem bullets below
const problems = [
  { icon: "\u2716", text: "Genomics and chemistry tools operate in isolation -- biological context lost at stage boundaries" },
  { icon: "\u2716", text: "No feedback loops -- downstream failures never inform upstream decisions" },
  { icon: "\u2716", text: "Manual orchestration required -- human experts must bridge disconnected AI tools" },
];

problems.forEach((p, i) => {
  slide2.addShape(pptx.shapes.OVAL, {
    x: 1.0, y: 4.15 + i * 0.65, w: 0.35, h: 0.35,
    fill: { color: COLORS.coral },
  });
  slide2.addText(p.icon, {
    x: 1.0, y: 4.13 + i * 0.65, w: 0.35, h: 0.38,
    fontSize: 14, fontFace: BODY_FONT, color: COLORS.white,
    align: "center", valign: "middle",
  });
  slide2.addText(p.text, {
    x: 1.55, y: 4.15 + i * 0.65, w: 10.5, h: 0.4,
    fontSize: 15, fontFace: BODY_FONT, color: COLORS.darkText,
    align: "left", valign: "middle",
  });
});

// =====================================================================
// SLIDE 3 - KEY INSIGHT
// =====================================================================
let slide3 = pptx.addSlide();
slide3.background = { color: COLORS.navy };

slide3.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide3.addText("Key Insight", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 36, fontFace: TITLE_FONT, color: COLORS.white,
  bold: true, align: "left",
});

// Central insight box
slide3.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
  x: 1.5, y: 1.8, w: 10.33, h: 2.0,
  fill: { color: COLORS.deepBlue },
  line: { color: COLORS.accent, width: 2 },
  rectRadius: 0.15,
});

slide3.addText("Unify genomic understanding and molecular design\nin a single AI agent that learns to plan\nacross the full drug discovery pipeline.", {
  x: 2.0, y: 1.9, w: 9.33, h: 1.8,
  fontSize: 24, fontFace: TITLE_FONT, color: COLORS.white,
  align: "center", valign: "middle", italic: true, lineSpacingMultiple: 1.4,
});

// Three pillars
const pillars = [
  { title: "Genomic Grounding", desc: "Disease biology drives\nmolecular design", color: COLORS.accent },
  { title: "Learned Planning", desc: "MCTS optimizes decisions\nacross the full pipeline", color: COLORS.teal },
  { title: "Closed-Loop Learning", desc: "Agent reflects and improves\nfrom trajectory outcomes", color: COLORS.accentDark },
];

pillars.forEach((p, i) => {
  const px = 1.2 + i * 4.0;
  slide3.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: px, y: 4.3, w: 3.5, h: 2.2,
    fill: { color: p.color, transparency: 20 },
    line: { color: p.color, width: 1.5 },
    rectRadius: 0.12,
  });
  slide3.addText(p.title, {
    x: px + 0.2, y: 4.5, w: 3.1, h: 0.6,
    fontSize: 18, fontFace: TITLE_FONT, color: COLORS.white,
    bold: true, align: "center",
  });
  slide3.addText(p.desc, {
    x: px + 0.2, y: 5.2, w: 3.1, h: 1.0,
    fontSize: 14, fontFace: BODY_FONT, color: COLORS.ice,
    align: "center", lineSpacingMultiple: 1.3,
  });
});

// =====================================================================
// SLIDE 4 - ARCHITECTURE OVERVIEW
// =====================================================================
let slide4 = pptx.addSlide();
slide4.background = { color: COLORS.offWhite };

slide4.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide4.addText("System Architecture", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 36, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

// Four architecture layers as stacked cards
const layers = [
  { y: 1.5, title: "Meta-Controller", subtitle: "LLM-Based Orchestrator", desc: "Decomposes goals into sub-tasks, selects modules, performs strategic reasoning", color: COLORS.navy, icon: "\uD83E\uDDE0" },
  { y: 2.8, title: "Genomic Perception", subtitle: "scGPT + ESM-2 + GWAS", desc: "Encodes gene expression, protein structure, and genetic variants into unified context", color: COLORS.deepBlue, icon: "\uD83E\uDDEC" },
  { y: 4.1, title: "Molecular Design", subtitle: "Conditional Generation", desc: "Generates and evaluates drug candidates conditioned on genomic context vector", color: COLORS.teal, icon: "\u2697\uFE0F" },
  { y: 5.4, title: "Planning Engine", subtitle: "MCTS + Value Network", desc: "Optimizes multi-step decisions with learned value function and reflection", color: COLORS.accentDark, icon: "\uD83C\uDFAF" },
];

layers.forEach((layer) => {
  // Main card
  slide4.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: 1.0, y: layer.y, w: 11.33, h: 1.1,
    fill: { color: COLORS.white },
    shadow: { type: "outer", blur: 4, offset: 2, color: "C0C0C0", opacity: 0.25 },
    rectRadius: 0.1,
  });

  // Color accent bar on left
  slide4.addShape(pptx.shapes.RECTANGLE, {
    x: 1.0, y: layer.y, w: 0.15, h: 1.1,
    fill: { color: layer.color },
  });

  // Title
  slide4.addText(layer.title, {
    x: 1.5, y: layer.y + 0.08, w: 3.5, h: 0.45,
    fontSize: 18, fontFace: TITLE_FONT, color: COLORS.navy,
    bold: true, align: "left", margin: 0,
  });

  // Subtitle tag
  slide4.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: 5.3, y: layer.y + 0.15, w: 2.8, h: 0.35,
    fill: { color: layer.color, transparency: 85 },
    rectRadius: 0.05,
  });
  slide4.addText(layer.subtitle, {
    x: 5.3, y: layer.y + 0.12, w: 2.8, h: 0.4,
    fontSize: 12, fontFace: BODY_FONT, color: layer.color,
    bold: true, align: "center", margin: 0,
  });

  // Description
  slide4.addText(layer.desc, {
    x: 1.5, y: layer.y + 0.55, w: 10.5, h: 0.45,
    fontSize: 14, fontFace: BODY_FONT, color: COLORS.gray,
    align: "left", margin: 0,
  });
});

// Arrows between layers
[2.6, 3.9, 5.2].forEach((y) => {
  slide4.addText("\u25BC", {
    x: 6.3, y: y, w: 0.5, h: 0.3,
    fontSize: 16, color: COLORS.accent, align: "center",
  });
});

// =====================================================================
// SLIDE 5 - GENOMIC CONTEXT CONDITIONING
// =====================================================================
let slide5 = pptx.addSlide();
slide5.background = { color: COLORS.offWhite };

slide5.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide5.addText("Genomic Context Conditioning (GCC)", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 34, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

// Three input boxes
const inputs = [
  { x: 0.8, title: "Gene Expression", model: "scGPT", desc: "Disease-specific\nexpression profiles", emoji: "G" },
  { x: 5.0, title: "Protein Structure", model: "ESM-2", desc: "Target protein\nresidue embeddings", emoji: "P" },
  { x: 9.2, title: "GWAS Variants", model: "MLP Encoder", desc: "Genetic association\nsignals & effect sizes", emoji: "V" },
];

inputs.forEach((inp) => {
  slide5.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: inp.x, y: 1.6, w: 3.6, h: 2.2,
    fill: { color: COLORS.white },
    shadow: { type: "outer", blur: 4, offset: 2, color: "C0C0C0", opacity: 0.25 },
    rectRadius: 0.12,
  });

  // Icon circle
  slide5.addShape(pptx.shapes.OVAL, {
    x: inp.x + 1.3, y: 1.75, w: 0.9, h: 0.9,
    fill: { color: COLORS.accent },
  });
  slide5.addText(inp.emoji, {
    x: inp.x + 1.3, y: 1.75, w: 0.9, h: 0.9,
    fontSize: 28, fontFace: TITLE_FONT, color: COLORS.white,
    bold: true, align: "center", valign: "middle",
  });

  slide5.addText(inp.title, {
    x: inp.x + 0.2, y: 2.75, w: 3.2, h: 0.4,
    fontSize: 16, fontFace: TITLE_FONT, color: COLORS.navy,
    bold: true, align: "center", margin: 0,
  });
  slide5.addText(inp.model, {
    x: inp.x + 0.8, y: 3.1, w: 2.0, h: 0.3,
    fontSize: 11, fontFace: BODY_FONT, color: COLORS.accent,
    bold: true, align: "center",
  });
  slide5.addText(inp.desc, {
    x: inp.x + 0.2, y: 3.35, w: 3.2, h: 0.45,
    fontSize: 12, fontFace: BODY_FONT, color: COLORS.gray,
    align: "center", lineSpacingMultiple: 1.2,
  });
});

// Arrows down
[2.5, 6.7, 10.9].forEach((ax) => {
  slide5.addText("\u25BC", {
    x: ax, y: 3.85, w: 0.5, h: 0.35,
    fontSize: 18, color: COLORS.accent, align: "center",
  });
});

// Cross-attention fusion box
slide5.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
  x: 2.5, y: 4.3, w: 8.33, h: 1.0,
  fill: { color: COLORS.navy },
  rectRadius: 0.1,
});
slide5.addText("Cross-Attention Fusion:  c_geno = Pool( CrossAttn( G, [P ; V] ) )", {
  x: 2.7, y: 4.35, w: 7.93, h: 0.9,
  fontSize: 17, fontFace: "Consolas", color: COLORS.ice,
  align: "center", valign: "middle",
});

// Arrow down to generator
slide5.addText("\u25BC", {
  x: 6.3, y: 5.35, w: 0.5, h: 0.35,
  fontSize: 18, color: COLORS.accent, align: "center",
});

// Molecular generator box
slide5.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
  x: 3.5, y: 5.8, w: 6.33, h: 0.9,
  fill: { color: COLORS.teal },
  rectRadius: 0.1,
});
slide5.addText("Conditional Molecular Generator  p(m | c_geno)", {
  x: 3.7, y: 5.8, w: 5.93, h: 0.9,
  fontSize: 16, fontFace: BODY_FONT, color: COLORS.white,
  bold: true, align: "center", valign: "middle",
});

// =====================================================================
// SLIDE 6 - MCTS PLANNING
// =====================================================================
let slide6 = pptx.addSlide();
slide6.background = { color: COLORS.offWhite };

slide6.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide6.addText("MCTS-Based Multi-Step Planning", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 34, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

// Left side: MDP formulation
slide6.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
  x: 0.8, y: 1.5, w: 5.6, h: 5.2,
  fill: { color: COLORS.white },
  shadow: { type: "outer", blur: 4, offset: 2, color: "C0C0C0", opacity: 0.25 },
  rectRadius: 0.12,
});

slide6.addText("Drug Discovery as MDP", {
  x: 1.1, y: 1.6, w: 5.0, h: 0.5,
  fontSize: 20, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

const mdpItems = [
  { label: "State S", desc: "Knowledge state: targets, molecules, evaluations" },
  { label: "Actions A", desc: "analyze_genomics, identify_target, generate_molecule,\noptimize, evaluate_admet, assess_binding, reflect" },
  { label: "Reward R", desc: "R = 0.3*affinity + 0.2*ADMET + 0.2*genomic\n     + 0.15*novelty + 0.15*synthesizability" },
  { label: "Discount", desc: "\u03B3 = 0.99 for long-horizon optimization" },
];

mdpItems.forEach((item, i) => {
  const iy = 2.25 + i * 1.1;
  slide6.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: 1.2, y: iy, w: 1.4, h: 0.35,
    fill: { color: COLORS.accent, transparency: 85 },
    rectRadius: 0.05,
  });
  slide6.addText(item.label, {
    x: 1.2, y: iy - 0.02, w: 1.4, h: 0.38,
    fontSize: 11, fontFace: BODY_FONT, color: COLORS.accentDark,
    bold: true, align: "center", margin: 0,
  });
  slide6.addText(item.desc, {
    x: 2.8, y: iy, w: 3.3, h: 0.8,
    fontSize: 12, fontFace: BODY_FONT, color: COLORS.darkText,
    align: "left", lineSpacingMultiple: 1.2, margin: 0,
  });
});

// Right side: MCTS algorithm
slide6.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
  x: 6.9, y: 1.5, w: 5.6, h: 3.0,
  fill: { color: COLORS.navy },
  rectRadius: 0.12,
});

slide6.addText("MCTS Algorithm", {
  x: 7.2, y: 1.6, w: 5.0, h: 0.5,
  fontSize: 20, fontFace: TITLE_FONT, color: COLORS.white,
  bold: true, align: "left",
});

const mctsSteps = [
  "1. Select: UCB1 with learned value estimates",
  "2. Expand: Policy network proposes actions",
  "3. Simulate: Rollout with heuristic policy",
  "4. Reflect: LLM analyzes trajectory (every 5th)",
  "5. Backpropagate: Update tree statistics",
];

slide6.addText(mctsSteps.join("\n"), {
  x: 7.4, y: 2.2, w: 4.8, h: 2.1,
  fontSize: 13, fontFace: "Consolas", color: COLORS.ice,
  lineSpacingMultiple: 1.5, align: "left",
});

// UCB formula box
slide6.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
  x: 6.9, y: 4.8, w: 5.6, h: 0.8,
  fill: { color: COLORS.deepBlue },
  rectRadius: 0.1,
});
slide6.addText("UCB(s,a) = Q(s,a) + c * \u03C0(a|s) * sqrt(ln N(s) / (1+N(s,a)))", {
  x: 7.1, y: 4.8, w: 5.2, h: 0.8,
  fontSize: 13, fontFace: "Consolas", color: COLORS.gold,
  align: "center", valign: "middle",
});

// Reflection box
slide6.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
  x: 6.9, y: 5.8, w: 5.6, h: 0.9,
  fill: { color: COLORS.white },
  line: { color: COLORS.accent, width: 1.5 },
  rectRadius: 0.1,
});
slide6.addText("Reflection-Augmented Learning\nEpisodic memory stores verbal feedback for future planning", {
  x: 7.1, y: 5.85, w: 5.2, h: 0.8,
  fontSize: 13, fontFace: BODY_FONT, color: COLORS.darkText,
  align: "center", lineSpacingMultiple: 1.3,
});

// =====================================================================
// SLIDE 7 - GENODRUGBENCH
// =====================================================================
let slide7 = pptx.addSlide();
slide7.background = { color: COLORS.offWhite };

slide7.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide7.addText("GenoDrugBench: Evaluation Benchmark", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 34, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

// Disease cards
const diseases = [
  { abbr: "T2D", name: "Type 2\nDiabetes", targets: "5", diff: "Easy", color: COLORS.accent },
  { abbr: "IBD", name: "Inflammatory\nBowel Disease", targets: "5", diff: "Medium", color: COLORS.teal },
  { abbr: "NSCLC", name: "Non-Small Cell\nLung Cancer", targets: "6", diff: "Medium", color: COLORS.deepBlue },
  { abbr: "AD", name: "Alzheimer's\nDisease", targets: "6", diff: "Hard", color: COLORS.coral },
  { abbr: "RA", name: "Rheumatoid\nArthritis", targets: "6", diff: "Medium", color: COLORS.accentDark },
];

diseases.forEach((d, i) => {
  const dx = 0.6 + i * 2.5;
  slide7.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: dx, y: 1.6, w: 2.2, h: 2.8,
    fill: { color: COLORS.white },
    shadow: { type: "outer", blur: 4, offset: 2, color: "C0C0C0", opacity: 0.25 },
    rectRadius: 0.12,
  });

  // Colored top
  slide7.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: dx, y: 1.6, w: 2.2, h: 1.0,
    fill: { color: d.color },
    rectRadius: 0.12,
  });
  // Bottom cover to square off bottom of colored top
  slide7.addShape(pptx.shapes.RECTANGLE, {
    x: dx, y: 2.3, w: 2.2, h: 0.3,
    fill: { color: d.color },
  });

  slide7.addText(d.abbr, {
    x: dx, y: 1.7, w: 2.2, h: 0.8,
    fontSize: 28, fontFace: TITLE_FONT, color: COLORS.white,
    bold: true, align: "center", valign: "middle",
  });

  slide7.addText(d.name, {
    x: dx + 0.15, y: 2.7, w: 1.9, h: 0.7,
    fontSize: 12, fontFace: BODY_FONT, color: COLORS.darkText,
    align: "center", lineSpacingMultiple: 1.2,
  });

  slide7.addText(`${d.targets} targets`, {
    x: dx + 0.15, y: 3.4, w: 1.9, h: 0.3,
    fontSize: 12, fontFace: BODY_FONT, color: COLORS.gray,
    align: "center",
  });

  // Difficulty badge
  const diffColor = d.diff === "Easy" ? COLORS.accent : d.diff === "Hard" ? COLORS.coral : COLORS.gold;
  slide7.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: dx + 0.5, y: 3.75, w: 1.2, h: 0.35,
    fill: { color: diffColor, transparency: 80 },
    rectRadius: 0.05,
  });
  slide7.addText(d.diff, {
    x: dx + 0.5, y: 3.73, w: 1.2, h: 0.38,
    fontSize: 11, fontFace: BODY_FONT, color: diffColor,
    bold: true, align: "center", margin: 0,
  });
});

// Metrics section
slide7.addText("Evaluation Dimensions", {
  x: 0.8, y: 4.8, w: 5.0, h: 0.5,
  fontSize: 20, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

const metrics = [
  { title: "Target Quality", desc: "Precision, recall, F1 vs. known targets" },
  { title: "Molecular Quality", desc: "Binding affinity, QED, SA score, validity" },
  { title: "Genomic Consistency", desc: "Alignment with disease expression signatures" },
  { title: "Efficiency", desc: "Agent steps, wall-clock time, LLM calls" },
];

metrics.forEach((m, i) => {
  const mx = (i < 2) ? 0.8 : 6.8;
  const my = (i % 2 === 0) ? 5.4 : 6.1;

  slide7.addShape(pptx.shapes.OVAL, {
    x: mx, y: my, w: 0.3, h: 0.3,
    fill: { color: COLORS.accent },
  });
  slide7.addText(`${i + 1}`, {
    x: mx, y: my - 0.02, w: 0.3, h: 0.33,
    fontSize: 12, fontFace: BODY_FONT, color: COLORS.white,
    bold: true, align: "center", margin: 0,
  });
  slide7.addText(m.title, {
    x: mx + 0.45, y: my, w: 2.0, h: 0.3,
    fontSize: 14, fontFace: BODY_FONT, color: COLORS.navy,
    bold: true, align: "left", margin: 0,
  });
  slide7.addText(m.desc, {
    x: mx + 2.5, y: my, w: 3.5, h: 0.3,
    fontSize: 13, fontFace: BODY_FONT, color: COLORS.gray,
    align: "left", margin: 0,
  });
});

// =====================================================================
// SLIDE 8 - MAIN RESULTS
// =====================================================================
let slide8 = pptx.addSlide();
slide8.background = { color: COLORS.offWhite };

slide8.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide8.addText("Main Results", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 36, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

slide8.addText("Averaged over 5 disease benchmark tasks", {
  x: 0.8, y: 1.05, w: 11.5, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, color: COLORS.gray, italic: true,
  align: "left",
});

// Results table
const tableRows = [
  [
    { text: "Method", options: { bold: true, color: COLORS.white, fill: { color: COLORS.navy }, fontSize: 14, fontFace: BODY_FONT, align: "left" } },
    { text: "pIC50 \u2191", options: { bold: true, color: COLORS.white, fill: { color: COLORS.navy }, fontSize: 14, fontFace: BODY_FONT, align: "center" } },
    { text: "QED \u2191", options: { bold: true, color: COLORS.white, fill: { color: COLORS.navy }, fontSize: 14, fontFace: BODY_FONT, align: "center" } },
    { text: "Gen.Con. \u2191", options: { bold: true, color: COLORS.white, fill: { color: COLORS.navy }, fontSize: 14, fontFace: BODY_FONT, align: "center" } },
    { text: "Valid% \u2191", options: { bold: true, color: COLORS.white, fill: { color: COLORS.navy }, fontSize: 14, fontFace: BODY_FONT, align: "center" } },
    { text: "Steps \u2193", options: { bold: true, color: COLORS.white, fill: { color: COLORS.navy }, fontSize: 14, fontFace: BODY_FONT, align: "center" } },
  ],
  [
    { text: "Pipeline", options: { fontSize: 13, fontFace: BODY_FONT, align: "left" } },
    { text: "6.2", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "0.61", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "0.32", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "94.1", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "--", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
  ],
  [
    { text: "REINVENT", options: { fontSize: 13, fontFace: BODY_FONT, align: "left" } },
    { text: "7.1", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "0.58", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "0.28", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "96.3", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "--", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
  ],
  [
    { text: "ChemCrow", options: { fontSize: 13, fontFace: BODY_FONT, align: "left" } },
    { text: "5.8", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "0.55", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "0.35", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "88.7", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "24", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
  ],
  [
    { text: "DrugAgent", options: { fontSize: 13, fontFace: BODY_FONT, align: "left" } },
    { text: "6.5", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "0.59", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "0.41", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "91.2", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
    { text: "31", options: { fontSize: 13, fontFace: BODY_FONT, align: "center" } },
  ],
  [
    { text: "GenoDrugAgent", options: { bold: true, fontSize: 14, fontFace: BODY_FONT, color: COLORS.accent, align: "left" } },
    { text: "7.8", options: { bold: true, fontSize: 14, fontFace: BODY_FONT, color: COLORS.accent, align: "center" } },
    { text: "0.67", options: { bold: true, fontSize: 14, fontFace: BODY_FONT, color: COLORS.accent, align: "center" } },
    { text: "0.62", options: { bold: true, fontSize: 14, fontFace: BODY_FONT, color: COLORS.accent, align: "center" } },
    { text: "93.5", options: { bold: true, fontSize: 14, fontFace: BODY_FONT, color: COLORS.accent, align: "center" } },
    { text: "18", options: { bold: true, fontSize: 14, fontFace: BODY_FONT, color: COLORS.accent, align: "center" } },
  ],
];

slide8.addTable(tableRows, {
  x: 0.8, y: 1.6, w: 11.73,
  border: { type: "solid", pt: 0.5, color: "DDDDDD" },
  colW: [2.5, 1.8, 1.8, 1.8, 1.8, 1.8],
  rowH: [0.5, 0.45, 0.45, 0.45, 0.45, 0.55],
  autoPage: false,
});

// Highlight stats
const highlights = [
  { x: 0.8, num: "+23%", desc: "Higher binding\naffinity vs. best baseline", color: COLORS.accent },
  { x: 4.0, num: "+31%", desc: "Better genomic\nconsistency", color: COLORS.teal },
  { x: 7.2, num: "-40%", desc: "Fewer computational\nsteps needed", color: COLORS.deepBlue },
  { x: 10.4, num: "5x", desc: "Predicted potency\nimprovement", color: COLORS.coral },
];

highlights.forEach((h) => {
  slide8.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: h.x, y: 5.2, w: 2.7, h: 1.4,
    fill: { color: COLORS.white },
    shadow: { type: "outer", blur: 4, offset: 2, color: "C0C0C0", opacity: 0.25 },
    rectRadius: 0.1,
  });
  slide8.addText(h.num, {
    x: h.x + 0.2, y: 5.3, w: 2.3, h: 0.65,
    fontSize: 36, fontFace: TITLE_FONT, color: h.color,
    bold: true, align: "center",
  });
  slide8.addText(h.desc, {
    x: h.x + 0.2, y: 5.95, w: 2.3, h: 0.55,
    fontSize: 12, fontFace: BODY_FONT, color: COLORS.gray,
    align: "center", lineSpacingMultiple: 1.2,
  });
});

// =====================================================================
// SLIDE 9 - ABLATION STUDY
// =====================================================================
let slide9 = pptx.addSlide();
slide9.background = { color: COLORS.offWhite };

slide9.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide9.addText("Ablation Study", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 36, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

slide9.addText("Impact of each component on overall performance", {
  x: 0.8, y: 1.05, w: 11.5, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, color: COLORS.gray, italic: true,
  align: "left",
});

// Three ablation cards
const ablations = [
  {
    title: "w/o GCC",
    subtitle: "Remove Genomic Context Conditioning",
    stat: "-45%",
    statLabel: "Genomic Consistency",
    detail: "Consistency drops from 0.62 to 0.34.\nConfirms GCC is essential for biologically grounded generation.",
    color: COLORS.coral,
  },
  {
    title: "w/o MCTS",
    subtitle: "Replace MCTS with greedy selection",
    stat: "+39%",
    statLabel: "More Steps Needed",
    detail: "Agent needs 25 steps instead of 18.\nLearned planning significantly improves efficiency.",
    color: COLORS.gold,
  },
  {
    title: "w/o Reflection",
    subtitle: "Remove episodic memory",
    stat: "Modest",
    statLabel: "Consistent Improvement",
    detail: "Affinity drops from 7.8 to 7.4.\nReflection provides steady gains across all metrics.",
    color: COLORS.teal,
  },
];

ablations.forEach((ab, i) => {
  const ax = 0.8 + i * 4.1;
  slide9.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: ax, y: 1.7, w: 3.7, h: 5.0,
    fill: { color: COLORS.white },
    shadow: { type: "outer", blur: 4, offset: 2, color: "C0C0C0", opacity: 0.25 },
    rectRadius: 0.12,
  });

  // Colored header
  slide9.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: ax, y: 1.7, w: 3.7, h: 1.1,
    fill: { color: ab.color },
    rectRadius: 0.12,
  });
  slide9.addShape(pptx.shapes.RECTANGLE, {
    x: ax, y: 2.5, w: 3.7, h: 0.3,
    fill: { color: ab.color },
  });

  slide9.addText(ab.title, {
    x: ax + 0.2, y: 1.8, w: 3.3, h: 0.5,
    fontSize: 22, fontFace: TITLE_FONT, color: COLORS.white,
    bold: true, align: "center",
  });
  slide9.addText(ab.subtitle, {
    x: ax + 0.2, y: 2.25, w: 3.3, h: 0.35,
    fontSize: 11, fontFace: BODY_FONT, color: COLORS.white,
    align: "center", transparency: 20,
  });

  // Big stat
  slide9.addText(ab.stat, {
    x: ax + 0.2, y: 3.1, w: 3.3, h: 1.0,
    fontSize: 48, fontFace: TITLE_FONT, color: ab.color,
    bold: true, align: "center",
  });
  slide9.addText(ab.statLabel, {
    x: ax + 0.2, y: 4.05, w: 3.3, h: 0.4,
    fontSize: 13, fontFace: BODY_FONT, color: COLORS.gray,
    bold: true, align: "center",
  });

  // Detail
  slide9.addText(ab.detail, {
    x: ax + 0.3, y: 4.6, w: 3.1, h: 1.8,
    fontSize: 13, fontFace: BODY_FONT, color: COLORS.darkText,
    align: "left", lineSpacingMultiple: 1.4,
  });
});

// =====================================================================
// SLIDE 10 - CASE STUDY T2D
// =====================================================================
let slide10 = pptx.addSlide();
slide10.background = { color: COLORS.offWhite };

slide10.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide10.addText("Case Study: Type 2 Diabetes", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 34, fontFace: TITLE_FONT, color: COLORS.navy,
  bold: true, align: "left",
});

// Timeline / process flow
const steps = [
  { num: "1", title: "Genomic Analysis", desc: "Analyzed T2D GWAS loci and gene expression profiles from pancreatic islet cells", y: 1.6 },
  { num: "2", title: "Target Identification", desc: "GLP-1R ranked as top target -- validates known biology of GLP-1 receptor agonists", y: 2.7 },
  { num: "3", title: "Molecular Generation", desc: "Generated 100 candidates with structural similarity to known GLP-1R modulators", y: 3.8 },
  { num: "4", title: "Reflection & Optimization", desc: "Agent learned to prioritize selectivity over raw potency after early off-target predictions", y: 4.9 },
  { num: "5", title: "Final Candidates", desc: "Top 5 molecules show novel scaffolds with pIC50 > 8.0 and clean ADMET profiles", y: 6.0 },
];

steps.forEach((step) => {
  // Number circle
  slide10.addShape(pptx.shapes.OVAL, {
    x: 1.0, y: step.y, w: 0.6, h: 0.6,
    fill: { color: COLORS.accent },
  });
  slide10.addText(step.num, {
    x: 1.0, y: step.y - 0.02, w: 0.6, h: 0.63,
    fontSize: 20, fontFace: TITLE_FONT, color: COLORS.white,
    bold: true, align: "center", valign: "middle",
  });

  // Connector line (except last)
  if (step.num !== "5") {
    slide10.addShape(pptx.shapes.RECTANGLE, {
      x: 1.27, y: step.y + 0.6, w: 0.06, h: 0.5,
      fill: { color: COLORS.accent, transparency: 50 },
    });
  }

  // Content card
  slide10.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: 2.0, y: step.y, w: 10.5, h: 0.8,
    fill: { color: COLORS.white },
    shadow: { type: "outer", blur: 3, offset: 1, color: "C0C0C0", opacity: 0.2 },
    rectRadius: 0.08,
  });

  slide10.addText(step.title, {
    x: 2.3, y: step.y + 0.05, w: 3.0, h: 0.35,
    fontSize: 16, fontFace: TITLE_FONT, color: COLORS.navy,
    bold: true, align: "left", margin: 0,
  });
  slide10.addText(step.desc, {
    x: 2.3, y: step.y + 0.4, w: 9.8, h: 0.35,
    fontSize: 13, fontFace: BODY_FONT, color: COLORS.gray,
    align: "left", margin: 0,
  });
});

// =====================================================================
// SLIDE 11 - KEY CONTRIBUTIONS
// =====================================================================
let slide11 = pptx.addSlide();
slide11.background = { color: COLORS.navy };

slide11.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.08,
  fill: { color: COLORS.accent },
});

slide11.addText("Key Contributions", {
  x: 0.8, y: 0.4, w: 11.5, h: 0.8,
  fontSize: 36, fontFace: TITLE_FONT, color: COLORS.white,
  bold: true, align: "left",
});

const contributions = [
  { num: "01", title: "Unified Agent Framework", desc: "First system bridging genomic foundation models and molecular design in a single agent" },
  { num: "02", title: "Genomic Context Conditioning", desc: "Novel cross-attention mechanism fusing scGPT, ESM-2, and GWAS for conditional generation" },
  { num: "03", title: "MCTS Planning for Drug Discovery", desc: "Learned multi-step planning that optimizes across the full discovery pipeline" },
  { num: "04", title: "GenoDrugBench Benchmark", desc: "Standardized evaluation across 5 therapeutic areas with comprehensive metrics" },
  { num: "05", title: "Open-Source Framework", desc: "Fully reproducible codebase with modular architecture for community extension" },
];

contributions.forEach((c, i) => {
  const cy = 1.5 + i * 1.1;

  // Number
  slide11.addText(c.num, {
    x: 0.8, y: cy, w: 0.8, h: 0.8,
    fontSize: 28, fontFace: TITLE_FONT, color: COLORS.accent,
    bold: true, align: "center", valign: "middle",
  });

  // Vertical separator
  slide11.addShape(pptx.shapes.RECTANGLE, {
    x: 1.8, y: cy + 0.1, w: 0.04, h: 0.6,
    fill: { color: COLORS.accent, transparency: 50 },
  });

  // Title and description
  slide11.addText(c.title, {
    x: 2.2, y: cy, w: 10.0, h: 0.4,
    fontSize: 18, fontFace: TITLE_FONT, color: COLORS.white,
    bold: true, align: "left", margin: 0,
  });
  slide11.addText(c.desc, {
    x: 2.2, y: cy + 0.4, w: 10.0, h: 0.4,
    fontSize: 14, fontFace: BODY_FONT, color: COLORS.ice,
    align: "left", margin: 0,
  });
});

// =====================================================================
// SLIDE 12 - THANK YOU
// =====================================================================
let slide12 = pptx.addSlide();
slide12.background = { color: COLORS.navy };

slide12.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.15,
  fill: { color: COLORS.accent },
});

slide12.addText("Thank You", {
  x: 1.0, y: 1.5, w: 11.33, h: 1.2,
  fontSize: 52, fontFace: TITLE_FONT, color: COLORS.white,
  bold: true, align: "center",
});

slide12.addText("Questions & Discussion", {
  x: 1.0, y: 2.8, w: 11.33, h: 0.7,
  fontSize: 24, fontFace: BODY_FONT, color: COLORS.ice,
  align: "center",
});

// Decorative line
slide12.addShape(pptx.shapes.RECTANGLE, {
  x: 5.5, y: 3.8, w: 2.33, h: 0.06,
  fill: { color: COLORS.accent },
});

// Contact info
slide12.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
  x: 3.5, y: 4.3, w: 6.33, h: 2.0,
  fill: { color: COLORS.deepBlue },
  rectRadius: 0.12,
});

slide12.addText([
  { text: "author1@university.edu\n", options: { fontSize: 16, color: COLORS.ice } },
  { text: "github.com/anonymous/genodrugagent\n\n", options: { fontSize: 14, color: COLORS.accent } },
  { text: "Code, data, and benchmarks available at project repository", options: { fontSize: 12, color: COLORS.lightGray } },
], {
  x: 3.8, y: 4.5, w: 5.73, h: 1.6,
  fontFace: BODY_FONT, align: "center", valign: "middle",
  lineSpacingMultiple: 1.4,
});

// Decorative circles
const endCircles = [
  { x: 1.5, y: 5.5 }, { x: 2.0, y: 6.0 }, { x: 11.0, y: 5.3 },
  { x: 11.5, y: 6.0 }, { x: 1.0, y: 6.3 },
];
endCircles.forEach((pos, i) => {
  const size = 0.2 + (i % 3) * 0.1;
  slide12.addShape(pptx.shapes.OVAL, {
    x: pos.x, y: pos.y, w: size, h: size,
    fill: { color: COLORS.accent, transparency: 60 + i * 5 },
    line: { color: COLORS.teal, width: 1 },
  });
});

// Write file
const outputPath = "/Users/cgxmac/Desktop/skill/research_plan-workspace/iteration-1/eval-agent-drug-discovery/without_skill/outputs/presentation/GenoDrugAgent_Presentation.pptx";
pptx.writeFile({ fileName: outputPath })
  .then(() => console.log(`Presentation saved to ${outputPath}`))
  .catch((err) => console.error("Error:", err));
