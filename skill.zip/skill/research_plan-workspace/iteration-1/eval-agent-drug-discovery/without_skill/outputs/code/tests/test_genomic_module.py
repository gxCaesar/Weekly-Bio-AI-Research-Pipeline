"""Tests for the Genomic Perception Module."""

import pytest
import torch

from genodrugagent.genomic_module import (
    GeneExpressionEncoder,
    GenomicContextFusion,
    GenomicPerceptionModule,
    GWASEncoder,
    ProteinEncoder,
)


@pytest.fixture
def d_model():
    return 128  # Small for fast testing


@pytest.fixture
def batch_size():
    return 4


@pytest.fixture
def n_genes():
    return 100


class TestGeneExpressionEncoder:
    def test_output_shape(self, d_model, batch_size, n_genes):
        encoder = GeneExpressionEncoder(n_genes=n_genes, d_model=d_model, n_layers=2)
        gene_ids = torch.randint(0, n_genes, (batch_size, n_genes))
        expression_values = torch.randn(batch_size, n_genes)

        output = encoder(gene_ids, expression_values)
        assert output.shape == (batch_size, n_genes, d_model)

    def test_with_mask(self, d_model, batch_size, n_genes):
        encoder = GeneExpressionEncoder(n_genes=n_genes, d_model=d_model, n_layers=2)
        gene_ids = torch.randint(0, n_genes, (batch_size, n_genes))
        expression_values = torch.randn(batch_size, n_genes)
        mask = torch.ones(batch_size, n_genes)
        mask[:, n_genes // 2:] = 0

        output = encoder(gene_ids, expression_values, mask)
        assert output.shape == (batch_size, n_genes, d_model)


class TestProteinEncoder:
    def test_output_shape(self, d_model, batch_size):
        encoder = ProteinEncoder(d_model=d_model)
        seq_len = 50
        tokens = torch.randint(0, 20, (batch_size, seq_len))

        output = encoder(tokens)
        assert output.shape == (batch_size, seq_len, d_model)

    def test_encode_sequence(self, d_model):
        encoder = ProteinEncoder(d_model=d_model)
        embedding = encoder.encode_sequence("MKFLILLFNILCLFPVLAAR")
        assert embedding.shape == (20, d_model)


class TestGWASEncoder:
    def test_output_shape(self, d_model, batch_size):
        encoder = GWASEncoder(n_features=64, d_model=d_model)
        variants = torch.randn(batch_size, 10, 64)
        output = encoder(variants)
        assert output.shape == (batch_size, 10, d_model)


class TestGenomicContextFusion:
    def test_output_shape(self, d_model, batch_size, n_genes):
        fusion = GenomicContextFusion(d_model=d_model, n_fusion_layers=2)
        gene_emb = torch.randn(batch_size, n_genes, d_model)
        prot_emb = torch.randn(batch_size, 50, d_model)

        context = fusion(gene_emb, prot_emb)
        assert context.shape == (batch_size, d_model)

    def test_with_gwas(self, d_model, batch_size, n_genes):
        fusion = GenomicContextFusion(d_model=d_model, n_fusion_layers=2)
        gene_emb = torch.randn(batch_size, n_genes, d_model)
        prot_emb = torch.randn(batch_size, 50, d_model)
        gwas_emb = torch.randn(batch_size, 10, d_model)

        context = fusion(gene_emb, prot_emb, gwas_emb)
        assert context.shape == (batch_size, d_model)


class TestGenomicPerceptionModule:
    def test_forward(self, d_model, batch_size, n_genes):
        module = GenomicPerceptionModule(
            n_genes=n_genes, d_model=d_model, n_heads=4
        )
        gene_ids = torch.randint(0, n_genes, (batch_size, n_genes))
        expr = torch.randn(batch_size, n_genes)
        prot = torch.randint(0, 20, (batch_size, 30))

        context = module(gene_ids, expr, prot)
        assert context.shape == (batch_size, d_model)

    def test_build_context(self, d_model, n_genes):
        module = GenomicPerceptionModule(
            n_genes=n_genes, d_model=d_model, n_heads=4
        )
        gene_ids = torch.arange(n_genes)
        expr = torch.randn(n_genes)
        targets = {"EGFR": "MRPSGTAGAALLALLAALCPASRALEEKKVC"}

        ctx = module.build_context("test_disease", gene_ids, expr, targets)
        assert ctx.disease_id == "test_disease"
        assert ctx.context_vector is not None
        assert ctx.context_vector.shape == (d_model,)
        assert "EGFR" in ctx.target_protein_embeddings
