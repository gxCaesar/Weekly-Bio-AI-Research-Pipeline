#!/usr/bin/env python3
"""
Training script for GenoDrugAgent.

Implements the full training loop:
1. Collect trajectories using MCTS self-play
2. Train value and policy networks from trajectory data
3. Periodically evaluate on benchmark tasks
"""

import argparse
import json
import logging
import time
from pathlib import Path

import torch
import torch.nn.functional as F

# Add parent to path for imports
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from genodrugagent.agent import AgentConfig, GenoDrugAgent
from genodrugagent.benchmark import BenchmarkEvaluator, create_benchmark_suite
from genodrugagent.planning_engine import (
    DiscoveryState,
    PlannerTrainer,
    PolicyNetwork,
    RewardFunction,
    Reflector,
    ValueNetwork,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger(__name__)


def collect_trajectories(
    agent: GenoDrugAgent,
    tasks: list,
    n_trajectories: int = 10,
) -> list[dict]:
    """Collect trajectories by running the agent on benchmark tasks."""
    trajectories = []

    for i in range(n_trajectories):
        task = tasks[i % len(tasks)]
        logger.info(f"Collecting trajectory {i+1}/{n_trajectories} on {task.disease_name}")

        trajectory = agent.run(
            disease_id=task.disease_id,
            disease_description=task.disease_description,
            gene_ids=task.gene_ids,
            expression_values=task.expression_values,
            target_sequences=task.target_sequences,
            gwas_features=task.gwas_features,
        )

        trajectories.append({
            "task_id": task.task_id,
            "trajectory": trajectory,
            "steps": trajectory.steps,
            "reward": trajectory.total_reward,
        })

    return trajectories


def extract_training_data(
    trajectories: list[dict],
    d_model: int = 512,
) -> tuple[list[DiscoveryState], torch.Tensor, torch.Tensor]:
    """Extract states, values, and policies from collected trajectories."""
    states = []
    values = []
    policies = []

    for traj_data in trajectories:
        steps = traj_data["steps"]
        total_reward = traj_data["reward"]

        for i, step in enumerate(steps):
            state = DiscoveryState(
                disease_id=traj_data["task_id"],
                step_count=step.get("step", i),
                total_reward=step.get("cumulative_reward", 0),
            )
            states.append(state)

            # Compute discounted return from this step
            remaining_reward = total_reward - step.get("cumulative_reward", 0)
            discount = 0.99 ** (len(steps) - i)
            values.append(step.get("reward", 0) + discount * remaining_reward)

            # Action taken (as class index) -- simplified
            policies.append(0)  # Placeholder

    if not states:
        return [], torch.tensor([]), torch.tensor([])

    return states, torch.tensor(values, dtype=torch.float32), torch.tensor(policies, dtype=torch.long)


def evaluate_agent(
    agent: GenoDrugAgent,
    tasks: list,
) -> dict:
    """Run evaluation on benchmark tasks."""
    evaluator = BenchmarkEvaluator()

    for task in tasks:
        trajectory = agent.run(
            disease_id=task.disease_id,
            disease_description=task.disease_description,
            gene_ids=task.gene_ids,
            expression_values=task.expression_values,
            target_sequences=task.target_sequences,
            gwas_features=task.gwas_features,
        )
        evaluator.evaluate_trajectory(task, trajectory)

    return evaluator.summary()


def main():
    parser = argparse.ArgumentParser(description="Train GenoDrugAgent")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--trajectories-per-epoch", type=int, default=5)
    parser.add_argument("--d-model", type=int, default=256)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--mcts-sims", type=int, default=20)
    parser.add_argument("--max-steps", type=int, default=15)
    parser.add_argument("--eval-interval", type=int, default=10)
    parser.add_argument("--checkpoint-dir", type=str, default="./checkpoints")
    parser.add_argument("--log-dir", type=str, default="./logs/training")
    args = parser.parse_args()

    # Setup
    checkpoint_dir = Path(args.checkpoint_dir)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    log_dir = Path(args.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    # Initialize agent
    config = AgentConfig(
        d_model=args.d_model,
        mcts_simulations=args.mcts_sims,
        max_steps=args.max_steps,
        n_molecules_per_round=20,  # Small for training speed
        log_dir=str(log_dir),
        save_trajectories=False,
    )
    agent = GenoDrugAgent(config)

    # Initialize trainer
    trainer = PlannerTrainer(
        agent.value_network,
        agent.policy_network,
        lr=args.lr,
    )

    # Load benchmark tasks
    tasks = create_benchmark_suite()
    logger.info(f"Loaded {len(tasks)} benchmark tasks")

    # Training loop
    training_history = []
    best_eval_score = -float("inf")

    for epoch in range(1, args.epochs + 1):
        epoch_start = time.time()
        logger.info(f"\n{'='*60}")
        logger.info(f"Epoch {epoch}/{args.epochs}")
        logger.info(f"{'='*60}")

        # 1. Collect trajectories
        trajectories = collect_trajectories(
            agent, tasks, n_trajectories=args.trajectories_per_epoch,
        )
        avg_reward = sum(t["reward"] for t in trajectories) / len(trajectories)
        logger.info(f"Average trajectory reward: {avg_reward:.4f}")

        # 2. Extract training data
        states, values, policies = extract_training_data(trajectories, args.d_model)

        if len(states) > 0:
            # 3. Train networks
            losses = trainer.train_step(states, values, policies)
            logger.info(f"Losses: {losses}")
        else:
            losses = {"total_loss": 0, "value_loss": 0, "policy_loss": 0}

        epoch_time = time.time() - epoch_start

        # Record history
        training_history.append({
            "epoch": epoch,
            "avg_reward": avg_reward,
            "losses": losses,
            "epoch_time": epoch_time,
        })

        # 4. Periodic evaluation
        if epoch % args.eval_interval == 0:
            logger.info("Running evaluation...")
            eval_results = evaluate_agent(agent, tasks[:2])  # Evaluate on subset
            logger.info(f"Evaluation results: {eval_results}")

            overall = eval_results.get("overall_score_mean", 0)
            if overall > best_eval_score:
                best_eval_score = overall
                agent.save_checkpoint(str(checkpoint_dir / "best_model.pt"))
                logger.info(f"New best model saved (score={overall:.4f})")

        # Checkpoint
        if epoch % 20 == 0:
            agent.save_checkpoint(str(checkpoint_dir / f"checkpoint_epoch_{epoch}.pt"))

    # Save training history
    with open(log_dir / "training_history.json", "w") as f:
        json.dump(training_history, f, indent=2, default=str)

    logger.info(f"\nTraining completed. Best eval score: {best_eval_score:.4f}")
    logger.info(f"Checkpoints saved to {checkpoint_dir}")


if __name__ == "__main__":
    main()
