"""
GenoDrugBench: Benchmark for evaluating agent-driven
genomics-to-drug discovery pipelines.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np
import torch

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Benchmark tasks
# ---------------------------------------------------------------------------

@dataclass
class BenchmarkTask:
    """A single benchmark task for evaluating drug discovery agents."""

    task_id: str
    disease_id: str
    disease_name: str
    disease_description: str

    # Known targets (for evaluation)
    known_targets: list[str] = field(default_factory=list)
    target_sequences: dict[str, str] = field(default_factory=dict)

    # Known drugs (for evaluation)
    known_drugs: list[str] = field(default_factory=list)  # SMILES
    known_drug_affinities: dict[str, float] = field(default_factory=dict)

    # Gene expression data
    n_genes: int = 1000
    gene_ids: Optional[torch.Tensor] = None
    expression_values: Optional[torch.Tensor] = None

    # GWAS data
    gwas_features: Optional[torch.Tensor] = None

    # Difficulty
    difficulty: str = "medium"  # easy, medium, hard

    def generate_synthetic_data(self) -> None:
        """Generate synthetic data for development and testing."""
        self.gene_ids = torch.arange(self.n_genes)
        self.expression_values = torch.randn(self.n_genes)

        # Synthetic GWAS features
        n_variants = 50
        self.gwas_features = torch.randn(n_variants, 64)

        # Synthetic target sequences
        amino_acids = "ACDEFGHIKLMNPQRSTVWY"
        for target in self.known_targets:
            if target not in self.target_sequences:
                seq_len = np.random.randint(100, 500)
                self.target_sequences[target] = "".join(
                    np.random.choice(list(amino_acids), seq_len)
                )


# ---------------------------------------------------------------------------
# Evaluation metrics
# ---------------------------------------------------------------------------

@dataclass
class EvaluationResult:
    """Results of evaluating an agent on a benchmark task."""

    task_id: str
    agent_name: str

    # Target identification metrics
    target_precision: float = 0.0
    target_recall: float = 0.0
    target_f1: float = 0.0

    # Molecular quality metrics
    avg_qed: float = 0.0
    avg_sa_score: float = 0.0
    avg_affinity: float = 0.0
    best_affinity: float = 0.0
    fraction_valid: float = 0.0
    fraction_unique: float = 0.0
    fraction_novel: float = 0.0
    internal_diversity: float = 0.0

    # ADMET metrics
    fraction_admet_pass: float = 0.0
    avg_bioavailability: float = 0.0

    # Genomic consistency
    avg_genomic_consistency: float = 0.0

    # Efficiency metrics
    n_steps: int = 0
    wall_time_seconds: float = 0.0
    n_llm_calls: int = 0

    # Overall scores
    target_score: float = 0.0
    molecular_score: float = 0.0
    efficiency_score: float = 0.0
    overall_score: float = 0.0

    def compute_overall(self) -> None:
        """Compute aggregate scores."""
        self.target_score = self.target_f1
        self.molecular_score = (
            0.3 * min(self.best_affinity / 10.0, 1.0)
            + 0.2 * self.avg_qed
            + 0.15 * self.fraction_valid
            + 0.15 * self.fraction_admet_pass
            + 0.1 * self.internal_diversity
            + 0.1 * self.avg_genomic_consistency
        )
        # Efficiency: reward faster completion (normalized)
        max_steps = 50
        self.efficiency_score = max(0, 1.0 - self.n_steps / max_steps)
        self.overall_score = (
            0.3 * self.target_score
            + 0.5 * self.molecular_score
            + 0.2 * self.efficiency_score
        )

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


class BenchmarkEvaluator:
    """Evaluates agent performance on benchmark tasks."""

    def __init__(self):
        self.results: list[EvaluationResult] = []

    def evaluate_trajectory(
        self,
        task: BenchmarkTask,
        trajectory: Any,
        agent_name: str = "GenoDrugAgent",
    ) -> EvaluationResult:
        """Evaluate an agent trajectory against ground truth."""
        result = EvaluationResult(task_id=task.task_id, agent_name=agent_name)

        # Target identification evaluation
        if hasattr(trajectory, "steps"):
            identified = set()
            for step in trajectory.steps:
                # Extract identified targets from step records
                pass
            if task.known_targets:
                true_set = set(task.known_targets)
                if identified:
                    result.target_precision = len(identified & true_set) / len(identified)
                    result.target_recall = len(identified & true_set) / len(true_set)
                    if result.target_precision + result.target_recall > 0:
                        result.target_f1 = (
                            2 * result.target_precision * result.target_recall
                            / (result.target_precision + result.target_recall)
                        )

        # Molecular quality evaluation
        candidates = getattr(trajectory, "final_candidates", [])
        if candidates:
            affinities = [c.get("predicted_affinity", 0) for c in candidates]
            qeds = [c.get("qed_score", 0) for c in candidates]
            sa_scores = [c.get("sa_score", 0) for c in candidates]
            gc_scores = [c.get("genomic_consistency_score", 0) for c in candidates]

            result.avg_affinity = np.mean(affinities) if affinities else 0
            result.best_affinity = max(affinities) if affinities else 0
            result.avg_qed = np.mean(qeds) if qeds else 0
            result.avg_sa_score = np.mean(sa_scores) if sa_scores else 0
            result.avg_genomic_consistency = np.mean(gc_scores) if gc_scores else 0

            # Validity, uniqueness, novelty
            smiles_list = [c.get("smiles", "") for c in candidates]
            valid_smiles = [s for s in smiles_list if s and len(s) >= 3]
            result.fraction_valid = len(valid_smiles) / max(len(smiles_list), 1)
            unique_smiles = set(valid_smiles)
            result.fraction_unique = len(unique_smiles) / max(len(valid_smiles), 1)

            # Novelty (not in known drugs)
            if task.known_drugs:
                known_set = set(task.known_drugs)
                novel = [s for s in unique_smiles if s not in known_set]
                result.fraction_novel = len(novel) / max(len(unique_smiles), 1)
            else:
                result.fraction_novel = 1.0

            # Internal diversity (placeholder - would use Tanimoto in production)
            result.internal_diversity = min(len(unique_smiles) / 10.0, 1.0)

        # Efficiency
        result.n_steps = getattr(trajectory, "n_steps", 0)
        result.wall_time_seconds = getattr(trajectory, "wall_time_seconds", 0)

        # Compute overall
        result.compute_overall()
        self.results.append(result)

        return result

    def summary(self) -> dict[str, float]:
        """Compute summary statistics across all evaluated tasks."""
        if not self.results:
            return {}

        metrics = [
            "target_score", "molecular_score", "efficiency_score", "overall_score",
            "avg_qed", "best_affinity", "avg_genomic_consistency",
        ]
        summary = {}
        for metric in metrics:
            values = [getattr(r, metric, 0) for r in self.results]
            summary[f"{metric}_mean"] = np.mean(values)
            summary[f"{metric}_std"] = np.std(values)

        return summary

    def save_results(self, path: str) -> None:
        """Save all evaluation results."""
        with open(path, "w") as f:
            json.dump(
                {
                    "results": [r.to_dict() for r in self.results],
                    "summary": self.summary(),
                },
                f, indent=2, default=str,
            )


# ---------------------------------------------------------------------------
# Pre-defined benchmark tasks
# ---------------------------------------------------------------------------

def create_benchmark_suite() -> list[BenchmarkTask]:
    """Create the standard GenoDrugBench benchmark suite."""

    tasks = []

    # Task 1: Type 2 Diabetes
    t2d = BenchmarkTask(
        task_id="T2D_001",
        disease_id="EFO_0001360",
        disease_name="Type 2 Diabetes Mellitus",
        disease_description=(
            "A chronic metabolic disorder characterized by insulin resistance "
            "and relative insulin deficiency, leading to hyperglycemia."
        ),
        known_targets=["GLP1R", "SGLT2", "DPP4", "PPARG", "GCK"],
        known_drugs=[
            "OC(=O)[C@@H]1CCCN1/N=C/c1cc(F)ccc1O",  # sitagliptin-like
            "OC(=O)c1ccc(NC(=O)c2ccccc2)cc1",  # example scaffold
        ],
        difficulty="easy",
    )
    t2d.generate_synthetic_data()
    tasks.append(t2d)

    # Task 2: Inflammatory Bowel Disease
    ibd = BenchmarkTask(
        task_id="IBD_001",
        disease_id="EFO_0003767",
        disease_name="Inflammatory Bowel Disease",
        disease_description=(
            "A group of inflammatory conditions of the colon and small intestine, "
            "including Crohn's disease and ulcerative colitis."
        ),
        known_targets=["TNF", "IL23A", "JAK2", "INTEGRIN_A4", "S1PR1"],
        difficulty="medium",
    )
    ibd.generate_synthetic_data()
    tasks.append(ibd)

    # Task 3: Non-Small Cell Lung Cancer
    nsclc = BenchmarkTask(
        task_id="NSCLC_001",
        disease_id="EFO_0003060",
        disease_name="Non-Small Cell Lung Cancer",
        disease_description=(
            "The most common type of lung cancer, including adenocarcinoma, "
            "squamous cell carcinoma, and large cell carcinoma."
        ),
        known_targets=["EGFR", "ALK", "KRAS", "MET", "ROS1", "BRAF"],
        known_drugs=[
            "C=CC(=O)Nc1cc(Nc2nccc(-c3cn(C)c4ccccc34)n2)c(OC)cc1N(C)CCN(C)C",  # osimertinib-like
        ],
        difficulty="medium",
    )
    nsclc.generate_synthetic_data()
    tasks.append(nsclc)

    # Task 4: Alzheimer's Disease (hard - complex genetics)
    ad = BenchmarkTask(
        task_id="AD_001",
        disease_id="EFO_0000249",
        disease_name="Alzheimer's Disease",
        disease_description=(
            "A progressive neurodegenerative disorder characterized by cognitive decline, "
            "amyloid plaques, and neurofibrillary tangles."
        ),
        known_targets=["APP", "BACE1", "TREM2", "APOE", "MAPT", "GSK3B"],
        difficulty="hard",
    )
    ad.generate_synthetic_data()
    tasks.append(ad)

    # Task 5: Rheumatoid Arthritis
    ra = BenchmarkTask(
        task_id="RA_001",
        disease_id="EFO_0000685",
        disease_name="Rheumatoid Arthritis",
        disease_description=(
            "A chronic autoimmune disorder primarily affecting joints, "
            "causing inflammation and progressive joint destruction."
        ),
        known_targets=["TNF", "IL6R", "JAK1", "JAK3", "BTK", "CD20"],
        difficulty="medium",
    )
    ra.generate_synthetic_data()
    tasks.append(ra)

    return tasks
