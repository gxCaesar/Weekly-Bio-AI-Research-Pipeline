"""
Genomic Perception Module for GenoDrugAgent.

This module integrates genomic foundation models (scGPT, ESM-2) to extract
disease-relevant biological context for conditioning molecular generation.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


@dataclass
class GenomicContext:
    """Container for genomic context information."""

    disease_id: str
    gene_expression_embedding: torch.Tensor  # (n_genes, d_model)
    target_protein_embeddings: dict[str, torch.Tensor]  # gene_name -> (seq_len, d_model)
    gwas_variant_features: Optional[torch.Tensor] = None  # (n_variants, d_variant)
    context_vector: Optional[torch.Tensor] = None  # (d_context,) fused representation
    target_scores: dict[str, float] = field(default_factory=dict)


class GeneExpressionEncoder(nn.Module):
    """Encodes gene expression profiles using a pre-trained or fine-tuned model.

    In production, this wraps scGPT. For development, we use a transformer
    encoder that operates on gene expression vectors.
    """

    def __init__(
        self,
        n_genes: int = 20000,
        d_model: int = 512,
        n_heads: int = 8,
        n_layers: int = 6,
        dropout: float = 0.1,
        use_pretrained: bool = False,
        pretrained_model_name: str = "scgpt",
    ):
        super().__init__()
        self.n_genes = n_genes
        self.d_model = d_model
        self.use_pretrained = use_pretrained

        if use_pretrained:
            # Load pre-trained scGPT model
            logger.info(f"Loading pre-trained {pretrained_model_name} model...")
            self._load_pretrained(pretrained_model_name)
        else:
            # Lightweight encoder for development/testing
            self.gene_embedding = nn.Embedding(n_genes, d_model)
            self.expression_proj = nn.Linear(1, d_model)
            self.combine = nn.Linear(2 * d_model, d_model)

            encoder_layer = nn.TransformerEncoderLayer(
                d_model=d_model,
                nhead=n_heads,
                dim_feedforward=d_model * 4,
                dropout=dropout,
                batch_first=True,
            )
            self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
            self.output_proj = nn.Linear(d_model, d_model)

    def _load_pretrained(self, model_name: str) -> None:
        """Load a pre-trained genomic foundation model."""
        # Placeholder for loading scGPT or Geneformer weights
        # In practice: self.model = scGPT.from_pretrained(model_name)
        logger.warning(
            f"Pre-trained model {model_name} not available. "
            "Using randomly initialized weights for development."
        )
        self.model = nn.Sequential(
            nn.Linear(self.d_model, self.d_model),
            nn.GELU(),
            nn.Linear(self.d_model, self.d_model),
        )

    def forward(
        self,
        gene_ids: torch.Tensor,
        expression_values: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Encode gene expression profile.

        Args:
            gene_ids: (batch, n_genes) gene index identifiers
            expression_values: (batch, n_genes) expression values
            mask: (batch, n_genes) attention mask

        Returns:
            (batch, n_genes, d_model) gene-level embeddings
        """
        gene_emb = self.gene_embedding(gene_ids)  # (B, G, D)
        expr_emb = self.expression_proj(expression_values.unsqueeze(-1))  # (B, G, D)
        combined = self.combine(torch.cat([gene_emb, expr_emb], dim=-1))  # (B, G, D)

        if mask is not None:
            # Convert to transformer mask format (True = ignore)
            src_key_padding_mask = ~mask.bool()
        else:
            src_key_padding_mask = None

        encoded = self.transformer(combined, src_key_padding_mask=src_key_padding_mask)
        return self.output_proj(encoded)


class ProteinEncoder(nn.Module):
    """Encodes protein sequences using ESM-2 or a lightweight substitute."""

    def __init__(
        self,
        d_model: int = 512,
        esm_model_name: str = "esm2_t33_650M_UR50D",
        use_pretrained: bool = False,
    ):
        super().__init__()
        self.d_model = d_model
        self.use_pretrained = use_pretrained

        if use_pretrained:
            logger.info(f"Loading ESM-2 model: {esm_model_name}")
            self._load_esm(esm_model_name)
        else:
            # Lightweight protein encoder for development
            self.aa_embedding = nn.Embedding(25, d_model)  # 20 AA + special tokens
            encoder_layer = nn.TransformerEncoderLayer(
                d_model=d_model,
                nhead=8,
                dim_feedforward=d_model * 4,
                dropout=0.1,
                batch_first=True,
            )
            self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=4)
            self.output_proj = nn.Linear(d_model, d_model)

    def _load_esm(self, model_name: str) -> None:
        """Load pre-trained ESM-2 model."""
        try:
            import esm

            self.esm_model, self.alphabet = esm.pretrained.load_model_and_alphabet(model_name)
            self.batch_converter = self.alphabet.get_batch_converter()
            # Project ESM hidden dim to our d_model
            esm_dim = self.esm_model.embed_dim
            self.proj = nn.Linear(esm_dim, self.d_model)
        except ImportError:
            logger.warning("ESM not installed. Using lightweight encoder.")
            self.use_pretrained = False
            self.__init__(d_model=self.d_model, use_pretrained=False)

    def forward(
        self,
        tokens: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Encode protein sequence.

        Args:
            tokens: (batch, seq_len) amino acid token indices
            mask: (batch, seq_len) attention mask

        Returns:
            (batch, seq_len, d_model) residue-level embeddings
        """
        emb = self.aa_embedding(tokens)
        if mask is not None:
            src_key_padding_mask = ~mask.bool()
        else:
            src_key_padding_mask = None
        encoded = self.transformer(emb, src_key_padding_mask=src_key_padding_mask)
        return self.output_proj(encoded)

    def encode_sequence(self, sequence: str) -> torch.Tensor:
        """Encode a single protein sequence string."""
        # Simple tokenization: map AA letters to indices
        aa_to_idx = {aa: i for i, aa in enumerate("ACDEFGHIKLMNPQRSTVWY")}
        tokens = [aa_to_idx.get(aa, 20) for aa in sequence.upper()]
        tokens_tensor = torch.tensor([tokens], dtype=torch.long)
        with torch.no_grad():
            return self(tokens_tensor).squeeze(0)  # (seq_len, d_model)


class GWASEncoder(nn.Module):
    """Encodes GWAS variant information."""

    def __init__(self, n_features: int = 64, d_model: int = 512):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(n_features, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
        )

    def forward(self, variant_features: torch.Tensor) -> torch.Tensor:
        """
        Encode GWAS variant features.

        Args:
            variant_features: (batch, n_variants, n_features)
                Features include: p-value, effect size, MAF, LD score,
                functional annotation scores, etc.

        Returns:
            (batch, n_variants, d_model) variant embeddings
        """
        return self.encoder(variant_features)


class GenomicContextFusion(nn.Module):
    """
    Fuses gene expression, protein, and GWAS embeddings into a unified
    genomic context vector using cross-attention.

    This is the core of the Genomic Context Conditioning (GCC) mechanism.
    """

    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        n_fusion_layers: int = 3,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.d_model = d_model

        # Cross-attention: gene expression attends to protein + GWAS
        self.cross_attention_layers = nn.ModuleList([
            nn.MultiheadAttention(
                embed_dim=d_model,
                num_heads=n_heads,
                dropout=dropout,
                batch_first=True,
            )
            for _ in range(n_fusion_layers)
        ])

        self.layer_norms = nn.ModuleList([
            nn.LayerNorm(d_model) for _ in range(n_fusion_layers * 2)
        ])

        self.ffn_layers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(d_model, d_model * 4),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(d_model * 4, d_model),
                nn.Dropout(dropout),
            )
            for _ in range(n_fusion_layers)
        ])

        # Final projection to context vector
        self.context_pool = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.Tanh(),
        )

    def forward(
        self,
        gene_embeddings: torch.Tensor,
        protein_embeddings: torch.Tensor,
        gwas_embeddings: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Fuse multi-modal genomic embeddings.

        Args:
            gene_embeddings: (batch, n_genes, d_model)
            protein_embeddings: (batch, n_residues, d_model)
            gwas_embeddings: (batch, n_variants, d_model) or None

        Returns:
            (batch, d_model) fused genomic context vector
        """
        # Concatenate protein and GWAS as key/value
        if gwas_embeddings is not None:
            kv = torch.cat([protein_embeddings, gwas_embeddings], dim=1)
        else:
            kv = protein_embeddings

        query = gene_embeddings
        for i, (attn, ffn) in enumerate(
            zip(self.cross_attention_layers, self.ffn_layers)
        ):
            # Cross-attention
            residual = query
            query = self.layer_norms[2 * i](query)
            attn_out, _ = attn(query, kv, kv)
            query = residual + attn_out

            # Feed-forward
            residual = query
            query = self.layer_norms[2 * i + 1](query)
            query = residual + ffn(query)

        # Pool to a single context vector (mean pooling)
        pooled = query.mean(dim=1)  # (batch, d_model)
        return self.context_pool(pooled)


class GenomicPerceptionModule(nn.Module):
    """
    Complete Genomic Perception Module integrating all genomic encoders
    and the context fusion mechanism.
    """

    def __init__(
        self,
        n_genes: int = 20000,
        d_model: int = 512,
        n_heads: int = 8,
        use_pretrained: bool = False,
    ):
        super().__init__()
        self.gene_encoder = GeneExpressionEncoder(
            n_genes=n_genes, d_model=d_model, use_pretrained=use_pretrained
        )
        self.protein_encoder = ProteinEncoder(
            d_model=d_model, use_pretrained=use_pretrained
        )
        self.gwas_encoder = GWASEncoder(d_model=d_model)
        self.fusion = GenomicContextFusion(d_model=d_model, n_heads=n_heads)
        self.d_model = d_model

    def forward(
        self,
        gene_ids: torch.Tensor,
        expression_values: torch.Tensor,
        protein_tokens: torch.Tensor,
        gwas_features: Optional[torch.Tensor] = None,
        gene_mask: Optional[torch.Tensor] = None,
        protein_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Process genomic inputs and produce a fused context vector.

        Returns:
            (batch, d_model) genomic context vector for molecular conditioning
        """
        gene_emb = self.gene_encoder(gene_ids, expression_values, gene_mask)
        protein_emb = self.protein_encoder(protein_tokens, protein_mask)

        gwas_emb = None
        if gwas_features is not None:
            gwas_emb = self.gwas_encoder(gwas_features)

        context = self.fusion(gene_emb, protein_emb, gwas_emb)
        return context

    def build_context(
        self,
        disease_id: str,
        gene_ids: torch.Tensor,
        expression_values: torch.Tensor,
        target_sequences: dict[str, str],
        gwas_features: Optional[torch.Tensor] = None,
    ) -> GenomicContext:
        """
        Build a complete GenomicContext object for a disease.

        This is the main entry point used by the agent.
        """
        self.eval()
        with torch.no_grad():
            # Encode gene expression
            gene_emb = self.gene_encoder(
                gene_ids.unsqueeze(0),
                expression_values.unsqueeze(0),
            )

            # Encode each target protein
            target_embeddings = {}
            for gene_name, sequence in target_sequences.items():
                target_embeddings[gene_name] = self.protein_encoder.encode_sequence(sequence)

            # Use first target for fusion (in practice, iterate or batch)
            if target_embeddings:
                first_target = next(iter(target_embeddings.values()))
                protein_emb = first_target.unsqueeze(0)
            else:
                protein_emb = torch.zeros(1, 1, self.d_model)

            gwas_emb = None
            if gwas_features is not None:
                gwas_emb = self.gwas_encoder(gwas_features.unsqueeze(0))

            context_vector = self.fusion(gene_emb, protein_emb, gwas_emb)

        return GenomicContext(
            disease_id=disease_id,
            gene_expression_embedding=gene_emb.squeeze(0),
            target_protein_embeddings=target_embeddings,
            gwas_variant_features=gwas_features,
            context_vector=context_vector.squeeze(0),
        )
