"""GenoDrugAgent: AI Agent Framework for Genomics-Informed Drug Discovery."""

__version__ = "0.1.0"
