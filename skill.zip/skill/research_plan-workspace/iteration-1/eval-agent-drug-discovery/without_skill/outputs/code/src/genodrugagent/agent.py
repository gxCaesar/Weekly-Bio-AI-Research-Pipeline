"""
GenoDrugAgent: Main agent orchestration module.

The meta-controller that coordinates genomic perception, molecular design,
and planning into a unified drug discovery agent.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import torch

from .genomic_module import GenomicContext, GenomicPerceptionModule
from .molecular_module import MolecularDesignModule, MoleculeCandidate
from .planning_engine import (
    Action,
    ActionType,
    DiscoveryState,
    MCTSPlanner,
    PolicyNetwork,
    RewardFunction,
    Reflector,
    ValueNetwork,
)

logger = logging.getLogger(__name__)


@dataclass
class AgentConfig:
    """Configuration for GenoDrugAgent."""

    # Model dimensions
    d_model: int = 512
    n_genes: int = 20000
    use_pretrained: bool = False

    # Planning parameters
    mcts_simulations: int = 100
    exploration_weight: float = 1.414
    max_steps: int = 50
    discount: float = 0.99

    # Generation parameters
    n_molecules_per_round: int = 100
    temperature: float = 0.8
    top_k: int = 50

    # Optimization parameters
    n_optimization_rounds: int = 5
    optimization_temperature: float = 0.6

    # Reward weights
    affinity_weight: float = 0.30
    admet_weight: float = 0.20
    genomic_weight: float = 0.20
    novelty_weight: float = 0.15
    synth_weight: float = 0.15

    # LLM settings
    use_llm_reflection: bool = False
    llm_model: str = "claude-3-opus-20240229"

    # Logging
    log_dir: str = "./logs"
    save_trajectories: bool = True

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


@dataclass
class TrajectoryRecord:
    """Record of a complete agent trajectory."""

    disease_id: str
    steps: list[dict[str, Any]] = field(default_factory=list)
    final_candidates: list[dict[str, Any]] = field(default_factory=list)
    total_reward: float = 0.0
    n_steps: int = 0
    wall_time_seconds: float = 0.0
    reflections: list[str] = field(default_factory=list)

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump({
                "disease_id": self.disease_id,
                "steps": self.steps,
                "final_candidates": self.final_candidates,
                "total_reward": self.total_reward,
                "n_steps": self.n_steps,
                "wall_time_seconds": self.wall_time_seconds,
                "reflections": self.reflections,
            }, f, indent=2, default=str)


class GenoDrugAgent:
    """
    Main agent class that orchestrates the entire drug discovery process.

    The agent follows a perception-planning-action loop:
    1. Perceive: Use genomic modules to understand disease biology
    2. Plan: Use MCTS to determine the best action sequence
    3. Act: Execute the selected action using appropriate modules
    4. Reflect: Analyze outcomes and update strategy
    """

    def __init__(self, config: AgentConfig):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Initialize modules
        self.genomic_module = GenomicPerceptionModule(
            n_genes=config.n_genes,
            d_model=config.d_model,
            use_pretrained=config.use_pretrained,
        ).to(self.device)

        self.molecular_module = MolecularDesignModule(
            d_model=config.d_model,
        ).to(self.device)

        # Initialize planning components
        self.value_network = ValueNetwork(d_model=config.d_model).to(self.device)
        self.policy_network = PolicyNetwork(d_model=config.d_model).to(self.device)
        self.reward_function = RewardFunction(
            alpha=config.affinity_weight,
            beta=config.admet_weight,
            gamma=config.genomic_weight,
            delta=config.novelty_weight,
            epsilon=config.synth_weight,
        )
        self.reflector = Reflector(
            use_llm=config.use_llm_reflection,
        )
        self.planner = MCTSPlanner(
            value_network=self.value_network,
            policy_network=self.policy_network,
            reward_function=self.reward_function,
            reflector=self.reflector,
            n_simulations=config.mcts_simulations,
            exploration_weight=config.exploration_weight,
            max_depth=config.max_steps,
            discount=config.discount,
        )

        # State
        self.state: Optional[DiscoveryState] = None
        self.trajectory: Optional[TrajectoryRecord] = None
        self.genomic_context: Optional[GenomicContext] = None

        logger.info(f"GenoDrugAgent initialized on {self.device}")
        logger.info(f"Config: {config.to_dict()}")

    def run(
        self,
        disease_id: str,
        disease_description: str = "",
        gene_ids: Optional[torch.Tensor] = None,
        expression_values: Optional[torch.Tensor] = None,
        target_sequences: Optional[dict[str, str]] = None,
        gwas_features: Optional[torch.Tensor] = None,
    ) -> TrajectoryRecord:
        """
        Run the full drug discovery agent for a given disease.

        Args:
            disease_id: Identifier for the target disease
            disease_description: Natural language description
            gene_ids: Gene index tensor for expression encoding
            expression_values: Gene expression values
            target_sequences: Dictionary of target gene names to protein sequences
            gwas_features: GWAS variant features

        Returns:
            TrajectoryRecord with the full agent trajectory and results
        """
        start_time = time.time()
        logger.info(f"Starting drug discovery for disease: {disease_id}")

        # Initialize state
        self.state = DiscoveryState(
            disease_id=disease_id,
            disease_description=disease_description,
        )
        self.trajectory = TrajectoryRecord(disease_id=disease_id)

        # Store input data for use during execution
        self._input_data = {
            "gene_ids": gene_ids,
            "expression_values": expression_values,
            "target_sequences": target_sequences or {},
            "gwas_features": gwas_features,
        }

        # Main agent loop
        for step in range(self.config.max_steps):
            self.state.step_count = step
            logger.info(f"\n{'='*60}")
            logger.info(f"Step {step + 1}/{self.config.max_steps}")
            logger.info(f"{'='*60}")

            # Plan: Use MCTS to select action
            action = self.planner.search(self.state)
            logger.info(f"Selected action: {action}")

            # Act: Execute the action
            reward = self._execute_action(action)
            self.state.total_reward += reward
            self.state.action_history.append(action)

            # Record step
            step_record = {
                "step": step,
                "action": str(action),
                "reward": reward,
                "cumulative_reward": self.state.total_reward,
                "n_targets": len(self.state.identified_targets),
                "n_molecules": len(self.state.generated_molecules),
                "best_score": max(
                    (m.get("overall_score", 0) for m in self.state.generated_molecules),
                    default=0,
                ),
            }
            self.trajectory.steps.append(step_record)
            logger.info(f"Reward: {reward:.4f}, Cumulative: {self.state.total_reward:.4f}")

            # Check termination
            if action.action_type == ActionType.TERMINATE:
                logger.info("Agent chose to terminate.")
                break

        # Finalize
        self.trajectory.n_steps = self.state.step_count + 1
        self.trajectory.total_reward = self.state.total_reward
        self.trajectory.wall_time_seconds = time.time() - start_time
        self.trajectory.reflections = [
            m["reflection"] for m in self.reflector.memory
        ]

        # Compile final candidates
        all_molecules = self.state.generated_molecules + self.state.optimized_molecules
        all_molecules.sort(key=lambda m: m.get("overall_score", 0), reverse=True)
        self.trajectory.final_candidates = all_molecules[:10]

        logger.info(f"\nDrug discovery completed in {self.trajectory.wall_time_seconds:.1f}s")
        logger.info(f"Total steps: {self.trajectory.n_steps}")
        logger.info(f"Total reward: {self.trajectory.total_reward:.4f}")
        logger.info(f"Final candidates: {len(self.trajectory.final_candidates)}")

        # Save trajectory
        if self.config.save_trajectories:
            log_dir = Path(self.config.log_dir)
            log_dir.mkdir(parents=True, exist_ok=True)
            traj_path = log_dir / f"trajectory_{disease_id}_{int(time.time())}.json"
            self.trajectory.save(str(traj_path))
            logger.info(f"Trajectory saved to {traj_path}")

        return self.trajectory

    def _execute_action(self, action: Action) -> float:
        """Execute an action and return the immediate reward."""
        try:
            if action.action_type == ActionType.ANALYZE_GENOMICS:
                return self._action_analyze_genomics()
            elif action.action_type == ActionType.IDENTIFY_TARGET:
                return self._action_identify_target()
            elif action.action_type == ActionType.GENERATE_MOLECULE:
                return self._action_generate_molecule()
            elif action.action_type == ActionType.OPTIMIZE_MOLECULE:
                return self._action_optimize_molecule()
            elif action.action_type == ActionType.EVALUATE_ADMET:
                return self._action_evaluate_admet()
            elif action.action_type == ActionType.ASSESS_BINDING:
                return self._action_assess_binding()
            elif action.action_type == ActionType.REFLECT:
                return self._action_reflect()
            elif action.action_type == ActionType.TERMINATE:
                return self._action_terminate()
            else:
                logger.warning(f"Unknown action type: {action.action_type}")
                return 0.0
        except Exception as e:
            logger.error(f"Action execution failed: {e}")
            return -0.1  # Penalty for failure

    def _action_analyze_genomics(self) -> float:
        """Analyze genomic data and build context."""
        logger.info("Analyzing genomic data...")

        gene_ids = self._input_data.get("gene_ids")
        expression_values = self._input_data.get("expression_values")
        target_sequences = self._input_data.get("target_sequences", {})
        gwas_features = self._input_data.get("gwas_features")

        if gene_ids is None:
            # Generate synthetic data for development
            n_genes = min(self.config.n_genes, 1000)  # Use fewer for speed
            gene_ids = torch.arange(n_genes)
            expression_values = torch.randn(n_genes)
            logger.info("Using synthetic genomic data for development")

        self.genomic_context = self.genomic_module.build_context(
            disease_id=self.state.disease_id,
            gene_ids=gene_ids.to(self.device),
            expression_values=expression_values.to(self.device),
            target_sequences=target_sequences,
            gwas_features=gwas_features.to(self.device) if gwas_features is not None else None,
        )

        self.state.genomic_context = self.genomic_context.context_vector
        logger.info("Genomic context built successfully")
        return 0.2

    def _action_identify_target(self) -> float:
        """Identify and prioritize drug targets."""
        logger.info("Identifying drug targets...")

        if self.genomic_context is None:
            logger.warning("No genomic context available. Run analyze_genomics first.")
            return -0.05

        # In production, this would use the genomic context to rank targets
        # For development, generate synthetic target data
        targets = []
        target_sequences = self._input_data.get("target_sequences", {})

        if target_sequences:
            for gene_name, seq in target_sequences.items():
                targets.append({
                    "gene_name": gene_name,
                    "druggability_score": float(torch.rand(1).item()),
                    "genetic_evidence": float(torch.rand(1).item()),
                    "expression_specificity": float(torch.rand(1).item()),
                    "sequence_length": len(seq),
                })
        else:
            # Synthetic targets
            for i in range(5):
                targets.append({
                    "gene_name": f"TARGET_{i}",
                    "druggability_score": float(torch.rand(1).item()),
                    "genetic_evidence": float(torch.rand(1).item()),
                    "expression_specificity": float(torch.rand(1).item()),
                })

        targets.sort(key=lambda t: t["druggability_score"], reverse=True)
        self.state.identified_targets = targets
        self.state.selected_target = targets[0]["gene_name"]

        logger.info(f"Identified {len(targets)} targets. Selected: {self.state.selected_target}")
        return 0.3 * targets[0]["druggability_score"]

    def _action_generate_molecule(self) -> float:
        """Generate molecules conditioned on genomic context."""
        logger.info("Generating molecules...")

        if self.state.genomic_context is None:
            return -0.05

        context = self.state.genomic_context.to(self.device)
        disease_expr = context  # Simplified; in practice, separate embeddings

        # Get target protein embedding
        if self.genomic_context and self.genomic_context.target_protein_embeddings:
            target_name = self.state.selected_target
            if target_name in self.genomic_context.target_protein_embeddings:
                prot_emb = self.genomic_context.target_protein_embeddings[target_name]
            else:
                prot_emb = next(iter(self.genomic_context.target_protein_embeddings.values()))
        else:
            prot_emb = torch.randn(50, self.config.d_model).to(self.device)

        candidates = self.molecular_module.generate_and_evaluate(
            genomic_context=context,
            disease_expression=disease_expr,
            target_protein_embedding=prot_emb.to(self.device),
            n_samples=self.config.n_molecules_per_round,
            temperature=self.config.temperature,
        )

        # Store as dicts
        for cand in candidates:
            self.state.generated_molecules.append(cand.to_dict())

        if candidates:
            best = candidates[0]
            logger.info(
                f"Generated {len(candidates)} valid molecules. "
                f"Best score: {best.overall_score:.4f}, SMILES: {best.smiles[:50]}"
            )
            return 0.3 * best.overall_score
        else:
            logger.warning("No valid molecules generated")
            return -0.05

    def _action_optimize_molecule(self) -> float:
        """Optimize the best generated molecules."""
        logger.info("Optimizing molecules...")

        if not self.state.generated_molecules:
            return -0.05

        # Select top candidates for optimization
        sorted_mols = sorted(
            self.state.generated_molecules,
            key=lambda m: m.get("overall_score", 0),
            reverse=True,
        )
        top_mols = sorted_mols[:5]

        # Re-generate with lower temperature conditioned on best molecules
        # In production, this would use scaffold-constrained generation
        if self.state.genomic_context is not None:
            context = self.state.genomic_context.to(self.device)
            optimized_smiles = self.molecular_module.generator.generate(
                context,
                temperature=self.config.optimization_temperature,
                n_samples=self.config.n_molecules_per_round // 2,
            )

            for smiles in optimized_smiles:
                if smiles and len(smiles) >= 3:
                    props = self.molecular_module.property_predictor.predict_smiles(smiles)
                    self.state.optimized_molecules.append({
                        "smiles": smiles,
                        "overall_score": sum(props.values()) / len(props),
                        **props,
                    })

        if self.state.optimized_molecules:
            best_opt = max(
                self.state.optimized_molecules,
                key=lambda m: m.get("overall_score", 0),
            )
            best_gen = max(
                self.state.generated_molecules,
                key=lambda m: m.get("overall_score", 0),
            )
            improvement = (
                best_opt.get("overall_score", 0) - best_gen.get("overall_score", 0)
            )
            logger.info(f"Optimization improvement: {improvement:+.4f}")
            return max(0, improvement * 0.5)

        return 0.0

    def _action_evaluate_admet(self) -> float:
        """Evaluate ADMET properties of candidates."""
        logger.info("Evaluating ADMET properties...")

        all_mols = self.state.generated_molecules + self.state.optimized_molecules
        if not all_mols:
            return -0.05

        n_passed = 0
        for mol in all_mols[:20]:  # Evaluate top 20
            smiles = mol.get("smiles", "")
            if not smiles:
                continue

            props = self.molecular_module.property_predictor.predict_smiles(smiles)
            self.state.admet_results[smiles] = props

            # Simple pass/fail criteria
            passes = (
                props.get("CYP3A4_inhibition", 1.0) < 0.5
                and props.get("hERG_liability", 1.0) < 0.5
                and props.get("Bioavailability", 0.0) > 0.3
            )
            if passes:
                n_passed += 1

        logger.info(f"ADMET: {n_passed}/{min(len(all_mols), 20)} candidates passed")
        return 0.1 * (n_passed / max(min(len(all_mols), 20), 1))

    def _action_assess_binding(self) -> float:
        """Assess binding affinity of top candidates."""
        logger.info("Assessing binding affinity...")

        all_mols = self.state.generated_molecules + self.state.optimized_molecules
        if not all_mols:
            return -0.05

        # Sort by overall score and assess top candidates
        sorted_mols = sorted(
            all_mols, key=lambda m: m.get("overall_score", 0), reverse=True
        )

        best_affinity = 0.0
        for mol in sorted_mols[:10]:
            smiles = mol.get("smiles", "")
            if not smiles:
                continue

            # In production, this would use docking or ML-predicted binding
            affinity = mol.get("predicted_affinity", 0.0)
            self.state.binding_results[smiles] = affinity
            best_affinity = max(best_affinity, affinity)

        logger.info(f"Best predicted binding affinity: pIC50 = {best_affinity:.2f}")
        return 0.2 * min(best_affinity / 10.0, 1.0)

    def _action_reflect(self) -> float:
        """Perform strategic reflection."""
        reflection = self.reflector.reflect(self.state)
        self.state.reflections.append(reflection)
        logger.info(f"Reflection: {reflection}")
        return 0.05

    def _action_terminate(self) -> float:
        """Terminate and select best candidate."""
        all_mols = self.state.generated_molecules + self.state.optimized_molecules
        if all_mols:
            best = max(all_mols, key=lambda m: m.get("overall_score", 0))
            self.state.best_molecule = best
            logger.info(f"Selected best candidate: {best.get('smiles', 'N/A')[:50]}")
            return best.get("overall_score", 0) * 0.5
        return 0.0

    def save_checkpoint(self, path: str) -> None:
        """Save agent model weights."""
        checkpoint = {
            "config": self.config.to_dict(),
            "genomic_module": self.genomic_module.state_dict(),
            "molecular_module": self.molecular_module.state_dict(),
            "value_network": self.value_network.state_dict(),
            "policy_network": self.policy_network.state_dict(),
        }
        torch.save(checkpoint, path)
        logger.info(f"Checkpoint saved to {path}")

    @classmethod
    def load_checkpoint(cls, path: str) -> GenoDrugAgent:
        """Load agent from checkpoint."""
        checkpoint = torch.load(path, map_location="cpu")
        config = AgentConfig(**checkpoint["config"])
        agent = cls(config)
        agent.genomic_module.load_state_dict(checkpoint["genomic_module"])
        agent.molecular_module.load_state_dict(checkpoint["molecular_module"])
        agent.value_network.load_state_dict(checkpoint["value_network"])
        agent.policy_network.load_state_dict(checkpoint["policy_network"])
        logger.info(f"Agent loaded from {path}")
        return agent
