"""
Molecular Design Module for GenoDrugAgent.

Handles compound generation conditioned on genomic context,
property prediction, and molecular optimization.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class MoleculeCandidate:
    """A generated or optimized molecule with predicted properties."""

    smiles: str
    embedding: Optional[torch.Tensor] = None
    predicted_affinity: float = 0.0  # pIC50
    qed_score: float = 0.0
    sa_score: float = 0.0
    logp: float = 0.0
    molecular_weight: float = 0.0
    lipinski_violations: int = 0
    tanimoto_to_known: float = 0.0
    genomic_consistency_score: float = 0.0
    overall_score: float = 0.0

    def to_dict(self) -> dict:
        return {
            "smiles": self.smiles,
            "predicted_affinity": self.predicted_affinity,
            "qed_score": self.qed_score,
            "sa_score": self.sa_score,
            "logp": self.logp,
            "molecular_weight": self.molecular_weight,
            "lipinski_violations": self.lipinski_violations,
            "genomic_consistency_score": self.genomic_consistency_score,
            "overall_score": self.overall_score,
        }


# ---------------------------------------------------------------------------
# Molecular encoder / decoder
# ---------------------------------------------------------------------------

class MolecularEncoder(nn.Module):
    """Transformer encoder for SMILES strings."""

    VOCAB = (
        " " + "CNOS" + "cnos" + "=#()" + "[]" + "+-" + "1234567890" + "@/\\." + "FClBrIP" + "rlp"
    )

    def __init__(self, d_model: int = 512, n_heads: int = 8, n_layers: int = 6,
                 max_len: int = 256, dropout: float = 0.1):
        super().__init__()
        self.d_model = d_model
        self.max_len = max_len
        self.vocab_size = len(self.VOCAB) + 3  # PAD, BOS, EOS

        self.token_emb = nn.Embedding(self.vocab_size, d_model, padding_idx=0)
        self.pos_emb = nn.Embedding(max_len, d_model)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads,
            dim_feedforward=d_model * 4, dropout=dropout, batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.output_proj = nn.Linear(d_model, d_model)

    def tokenize(self, smiles: str) -> torch.Tensor:
        char_to_idx = {c: i + 3 for i, c in enumerate(self.VOCAB)}
        tokens = [1]  # BOS
        for c in smiles[:self.max_len - 2]:
            tokens.append(char_to_idx.get(c, 0))
        tokens.append(2)  # EOS
        while len(tokens) < self.max_len:
            tokens.append(0)  # PAD
        return torch.tensor(tokens, dtype=torch.long)

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        B, L = tokens.shape
        positions = torch.arange(L, device=tokens.device).unsqueeze(0).expand(B, -1)
        x = self.token_emb(tokens) + self.pos_emb(positions)
        mask = tokens == 0
        encoded = self.transformer(x, src_key_padding_mask=mask)
        return self.output_proj(encoded)

    def encode_smiles(self, smiles: str) -> torch.Tensor:
        tokens = self.tokenize(smiles).unsqueeze(0)
        with torch.no_grad():
            encoded = self(tokens)
        return encoded.mean(dim=1).squeeze(0)


class ConditionalMolecularGenerator(nn.Module):
    """
    Autoregressive molecular generator conditioned on genomic context.

    Generates SMILES token-by-token, using the genomic context vector as a
    cross-attention key to bias generation toward disease-relevant chemistry.
    """

    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        n_layers: int = 8,
        max_len: int = 256,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.d_model = d_model
        self.max_len = max_len
        vocab = MolecularEncoder.VOCAB
        self.vocab_size = len(vocab) + 3  # PAD, BOS, EOS

        self.token_emb = nn.Embedding(self.vocab_size, d_model, padding_idx=0)
        self.pos_emb = nn.Embedding(max_len, d_model)

        # Decoder layers with cross-attention to genomic context
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model, nhead=n_heads,
            dim_feedforward=d_model * 4, dropout=dropout, batch_first=True,
        )
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=n_layers)

        # Genomic context projection (from context vector to sequence of KV)
        self.context_proj = nn.Sequential(
            nn.Linear(d_model, d_model * 4),
            nn.GELU(),
            nn.Linear(d_model * 4, d_model * 8),  # 8 virtual tokens
        )
        self.n_context_tokens = 8

        self.output_head = nn.Linear(d_model, self.vocab_size)

    def _prepare_context_memory(self, genomic_context: torch.Tensor) -> torch.Tensor:
        """Convert context vector into a sequence of virtual tokens for cross-attention."""
        B = genomic_context.size(0)
        memory = self.context_proj(genomic_context)  # (B, d_model * n_ctx)
        memory = memory.view(B, self.n_context_tokens, self.d_model)
        return memory

    def _causal_mask(self, size: int, device: torch.device) -> torch.Tensor:
        mask = torch.triu(torch.ones(size, size, device=device), diagonal=1)
        return mask.bool()

    def forward(
        self,
        tokens: torch.Tensor,
        genomic_context: torch.Tensor,
    ) -> torch.Tensor:
        """
        Forward pass for teacher-forced training.

        Args:
            tokens: (batch, seq_len) input SMILES tokens
            genomic_context: (batch, d_model) genomic context vector

        Returns:
            (batch, seq_len, vocab_size) logits
        """
        B, L = tokens.shape
        positions = torch.arange(L, device=tokens.device).unsqueeze(0).expand(B, -1)
        x = self.token_emb(tokens) + self.pos_emb(positions)

        memory = self._prepare_context_memory(genomic_context)
        tgt_mask = self._causal_mask(L, tokens.device)

        decoded = self.decoder(x, memory, tgt_mask=tgt_mask)
        return self.output_head(decoded)

    @torch.no_grad()
    def generate(
        self,
        genomic_context: torch.Tensor,
        temperature: float = 1.0,
        top_k: int = 50,
        max_length: int = 128,
        n_samples: int = 1,
    ) -> list[str]:
        """
        Generate SMILES strings conditioned on genomic context.

        Args:
            genomic_context: (d_model,) or (1, d_model) context vector
            temperature: sampling temperature
            top_k: top-k filtering
            max_length: maximum sequence length
            n_samples: number of molecules to generate

        Returns:
            List of SMILES strings
        """
        self.eval()
        if genomic_context.dim() == 1:
            genomic_context = genomic_context.unsqueeze(0)
        genomic_context = genomic_context.expand(n_samples, -1)

        device = genomic_context.device
        memory = self._prepare_context_memory(genomic_context)

        # Start with BOS token
        generated = torch.ones(n_samples, 1, dtype=torch.long, device=device)  # BOS=1
        idx_to_char = {i + 3: c for i, c in enumerate(MolecularEncoder.VOCAB)}
        idx_to_char[2] = ""  # EOS

        for step in range(max_length - 1):
            positions = torch.arange(
                generated.size(1), device=device
            ).unsqueeze(0).expand(n_samples, -1)
            x = self.token_emb(generated) + self.pos_emb(positions)
            tgt_mask = self._causal_mask(generated.size(1), device)

            decoded = self.decoder(x, memory, tgt_mask=tgt_mask)
            logits = self.output_head(decoded[:, -1, :]) / temperature

            # Top-k filtering
            if top_k > 0:
                values, _ = torch.topk(logits, top_k)
                min_val = values[:, -1].unsqueeze(-1)
                logits = torch.where(logits < min_val, torch.full_like(logits, -1e9), logits)

            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, 1)
            generated = torch.cat([generated, next_token], dim=1)

            # Check if all sequences have generated EOS
            if (next_token == 2).all():
                break

        # Decode tokens to SMILES
        smiles_list = []
        for i in range(n_samples):
            tokens_i = generated[i].tolist()
            smiles = ""
            for t in tokens_i[1:]:  # skip BOS
                if t == 2:  # EOS
                    break
                smiles += idx_to_char.get(t, "")
            smiles_list.append(smiles)

        return smiles_list


# ---------------------------------------------------------------------------
# Property predictors
# ---------------------------------------------------------------------------

class PropertyPredictor(nn.Module):
    """Multi-task property predictor for ADMET and drug-likeness."""

    PROPERTY_NAMES = [
        "pIC50", "QED", "SA_Score", "LogP", "Solubility",
        "CYP3A4_inhibition", "hERG_liability", "Bioavailability",
    ]

    def __init__(self, d_model: int = 512, n_properties: int = 8):
        super().__init__()
        self.encoder = MolecularEncoder(d_model=d_model, n_layers=4)

        self.shared = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Dropout(0.1),
        )

        self.heads = nn.ModuleList([
            nn.Sequential(
                nn.Linear(d_model, d_model // 2),
                nn.GELU(),
                nn.Linear(d_model // 2, 1),
            )
            for _ in range(n_properties)
        ])

    def forward(self, tokens: torch.Tensor) -> dict[str, torch.Tensor]:
        encoded = self.encoder(tokens)
        pooled = encoded.mean(dim=1)  # (B, D)
        shared_repr = self.shared(pooled)

        predictions = {}
        for name, head in zip(self.PROPERTY_NAMES, self.heads):
            predictions[name] = head(shared_repr).squeeze(-1)
        return predictions

    def predict_smiles(self, smiles: str) -> dict[str, float]:
        tokens = self.encoder.tokenize(smiles).unsqueeze(0)
        with torch.no_grad():
            preds = self(tokens)
        return {k: v.item() for k, v in preds.items()}


class BindingAffinityPredictor(nn.Module):
    """Predicts binding affinity between molecule and target protein."""

    def __init__(self, d_model: int = 512, n_heads: int = 8):
        super().__init__()
        self.mol_encoder = MolecularEncoder(d_model=d_model, n_layers=4)
        self.protein_proj = nn.Linear(d_model, d_model)

        # Bilinear attention (inspired by DrugBAN)
        self.bilinear = nn.Bilinear(d_model, d_model, d_model)
        self.attention = nn.MultiheadAttention(d_model, n_heads, batch_first=True)

        self.predictor = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, 1),
        )

    def forward(
        self,
        mol_tokens: torch.Tensor,
        protein_embedding: torch.Tensor,
    ) -> torch.Tensor:
        """
        Predict binding affinity.

        Args:
            mol_tokens: (batch, mol_len) SMILES tokens
            protein_embedding: (batch, prot_len, d_model) protein embeddings

        Returns:
            (batch,) predicted pIC50 values
        """
        mol_emb = self.mol_encoder(mol_tokens)  # (B, M, D)
        prot_emb = self.protein_proj(protein_embedding)  # (B, P, D)

        # Bilinear attention between mol and protein
        mol_pooled = mol_emb.mean(dim=1)  # (B, D)
        prot_pooled = prot_emb.mean(dim=1)  # (B, D)
        interaction = self.bilinear(mol_pooled, prot_pooled)  # (B, D)

        return self.predictor(interaction).squeeze(-1)


# ---------------------------------------------------------------------------
# Genomic consistency scorer
# ---------------------------------------------------------------------------

class GenomicConsistencyScorer(nn.Module):
    """
    Scores how consistent a molecule's predicted effects are with
    the disease gene expression signature.

    Uses the Connectivity Map concept: a good drug should reverse
    the disease gene expression pattern.
    """

    def __init__(self, d_model: int = 512):
        super().__init__()
        self.mol_to_expression = nn.Sequential(
            nn.Linear(d_model, d_model * 2),
            nn.GELU(),
            nn.Linear(d_model * 2, d_model),
        )
        self.scorer = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.GELU(),
            nn.Linear(d_model, 1),
            nn.Sigmoid(),
        )

    def forward(
        self,
        mol_embedding: torch.Tensor,
        disease_expression_embedding: torch.Tensor,
    ) -> torch.Tensor:
        """
        Score genomic consistency.

        Args:
            mol_embedding: (batch, d_model)
            disease_expression_embedding: (batch, d_model)

        Returns:
            (batch,) consistency scores in [0, 1]
        """
        predicted_effect = self.mol_to_expression(mol_embedding)
        combined = torch.cat([predicted_effect, disease_expression_embedding], dim=-1)
        return self.scorer(combined).squeeze(-1)


# ---------------------------------------------------------------------------
# Molecular Design Module (orchestrator)
# ---------------------------------------------------------------------------

class MolecularDesignModule(nn.Module):
    """
    Complete Molecular Design Module orchestrating generation,
    property prediction, and scoring.
    """

    def __init__(self, d_model: int = 512):
        super().__init__()
        self.generator = ConditionalMolecularGenerator(d_model=d_model)
        self.property_predictor = PropertyPredictor(d_model=d_model)
        self.binding_predictor = BindingAffinityPredictor(d_model=d_model)
        self.consistency_scorer = GenomicConsistencyScorer(d_model=d_model)
        self.mol_encoder = MolecularEncoder(d_model=d_model)

    def generate_and_evaluate(
        self,
        genomic_context: torch.Tensor,
        disease_expression: torch.Tensor,
        target_protein_embedding: torch.Tensor,
        n_samples: int = 100,
        temperature: float = 0.8,
    ) -> list[MoleculeCandidate]:
        """
        Generate molecules and evaluate them comprehensively.

        Args:
            genomic_context: (d_model,) genomic context vector
            disease_expression: (d_model,) disease expression embedding
            target_protein_embedding: (prot_len, d_model) target protein
            n_samples: number of molecules to generate
            temperature: sampling temperature

        Returns:
            Sorted list of MoleculeCandidate objects (best first)
        """
        # Generate SMILES
        smiles_list = self.generator.generate(
            genomic_context, temperature=temperature, n_samples=n_samples,
        )

        candidates = []
        for smiles in smiles_list:
            if not smiles or len(smiles) < 3:
                continue

            try:
                # Predict properties
                props = self.property_predictor.predict_smiles(smiles)

                # Encode molecule
                mol_emb = self.mol_encoder.encode_smiles(smiles)

                # Predict binding affinity
                mol_tokens = self.mol_encoder.tokenize(smiles).unsqueeze(0)
                prot_emb = target_protein_embedding.unsqueeze(0)
                affinity = self.binding_predictor(mol_tokens, prot_emb).item()

                # Genomic consistency
                consistency = self.consistency_scorer(
                    mol_emb.unsqueeze(0),
                    disease_expression.unsqueeze(0),
                ).item()

                # Compute overall score
                overall = (
                    0.3 * min(affinity / 10.0, 1.0)
                    + 0.2 * props.get("QED", 0.5)
                    + 0.15 * (1.0 - props.get("SA_Score", 0.5) / 10.0)
                    + 0.15 * consistency
                    + 0.1 * (1.0 - abs(props.get("LogP", 3.0) - 3.0) / 5.0)
                    + 0.1 * props.get("Bioavailability", 0.5)
                )

                candidates.append(MoleculeCandidate(
                    smiles=smiles,
                    embedding=mol_emb,
                    predicted_affinity=affinity,
                    qed_score=props.get("QED", 0.0),
                    sa_score=props.get("SA_Score", 0.0),
                    logp=props.get("LogP", 0.0),
                    genomic_consistency_score=consistency,
                    overall_score=overall,
                ))

            except Exception as e:
                logger.debug(f"Failed to evaluate {smiles}: {e}")
                continue

        # Sort by overall score (descending)
        candidates.sort(key=lambda x: x.overall_score, reverse=True)
        return candidates
