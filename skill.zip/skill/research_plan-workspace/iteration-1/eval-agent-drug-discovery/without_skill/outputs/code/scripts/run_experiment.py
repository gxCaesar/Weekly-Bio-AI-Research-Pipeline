#!/usr/bin/env python3
"""
Run a complete experiment: agent execution + evaluation + reporting.
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from genodrugagent.agent import AgentConfig, GenoDrugAgent
from genodrugagent.benchmark import BenchmarkEvaluator, create_benchmark_suite

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def run_ablation_study(tasks, output_dir: Path):
    """Run ablation experiments comparing different agent configurations."""
    configs = {
        "full": AgentConfig(d_model=256, mcts_simulations=50, max_steps=20),
        "no_mcts": AgentConfig(d_model=256, mcts_simulations=1, max_steps=20),
        "no_genomic": AgentConfig(d_model=256, mcts_simulations=50, max_steps=20),
        "small_model": AgentConfig(d_model=128, mcts_simulations=50, max_steps=20),
    }

    all_results = {}
    for config_name, config in configs.items():
        logger.info(f"\nRunning ablation: {config_name}")
        config.log_dir = str(output_dir / config_name)
        config.save_trajectories = True

        agent = GenoDrugAgent(config)
        evaluator = BenchmarkEvaluator()

        for task in tasks:
            trajectory = agent.run(
                disease_id=task.disease_id,
                disease_description=task.disease_description,
                gene_ids=task.gene_ids,
                expression_values=task.expression_values,
                target_sequences=task.target_sequences,
                gwas_features=task.gwas_features if config_name != "no_genomic" else None,
            )
            evaluator.evaluate_trajectory(task, trajectory, agent_name=config_name)

        all_results[config_name] = evaluator.summary()
        logger.info(f"{config_name} results: {evaluator.summary()}")

    # Save comparison
    with open(output_dir / "ablation_results.json", "w") as f:
        json.dump(all_results, f, indent=2, default=str)

    return all_results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["single", "benchmark", "ablation"], default="benchmark")
    parser.add_argument("--task-id", default="T2D_001")
    parser.add_argument("--output-dir", default="./results")
    parser.add_argument("--d-model", type=int, default=256)
    parser.add_argument("--mcts-sims", type=int, default=50)
    parser.add_argument("--max-steps", type=int, default=20)
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    tasks = create_benchmark_suite()

    if args.mode == "single":
        task = next((t for t in tasks if t.task_id == args.task_id), tasks[0])
        config = AgentConfig(
            d_model=args.d_model, mcts_simulations=args.mcts_sims,
            max_steps=args.max_steps, log_dir=str(output_dir),
        )
        agent = GenoDrugAgent(config)
        trajectory = agent.run(
            disease_id=task.disease_id,
            disease_description=task.disease_description,
            gene_ids=task.gene_ids,
            expression_values=task.expression_values,
            target_sequences=task.target_sequences,
            gwas_features=task.gwas_features,
        )
        trajectory.save(str(output_dir / f"trajectory_{task.task_id}.json"))
        print(f"Results saved to {output_dir}")

    elif args.mode == "benchmark":
        config = AgentConfig(
            d_model=args.d_model, mcts_simulations=args.mcts_sims,
            max_steps=args.max_steps, log_dir=str(output_dir),
        )
        agent = GenoDrugAgent(config)
        evaluator = BenchmarkEvaluator()

        for task in tasks:
            logger.info(f"Running: {task.disease_name}")
            trajectory = agent.run(
                disease_id=task.disease_id,
                disease_description=task.disease_description,
                gene_ids=task.gene_ids,
                expression_values=task.expression_values,
                target_sequences=task.target_sequences,
                gwas_features=task.gwas_features,
            )
            evaluator.evaluate_trajectory(task, trajectory)

        evaluator.save_results(str(output_dir / "benchmark_results.json"))
        summary = evaluator.summary()
        print("\nBenchmark Summary:")
        for k, v in summary.items():
            print(f"  {k}: {v:.4f}")

    elif args.mode == "ablation":
        results = run_ablation_study(tasks, output_dir)
        print("\nAblation Study Results:")
        for config_name, summary in results.items():
            print(f"\n  {config_name}:")
            for k, v in summary.items():
                print(f"    {k}: {v:.4f}")


if __name__ == "__main__":
    main()
