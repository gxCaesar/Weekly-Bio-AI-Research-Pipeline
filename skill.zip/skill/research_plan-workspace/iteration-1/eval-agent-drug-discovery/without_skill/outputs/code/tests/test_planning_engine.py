"""Tests for the Planning Engine."""

import pytest
import torch

from genodrugagent.planning_engine import (
    Action,
    ActionType,
    DiscoveryState,
    MCTSNode,
    MCTSPlanner,
    PlannerTrainer,
    PolicyNetwork,
    Reflector,
    RewardFunction,
    ValueNetwork,
)


@pytest.fixture
def d_model():
    return 128


@pytest.fixture
def state():
    return DiscoveryState(
        disease_id="test_disease",
        disease_description="Test disease for unit testing",
    )


class TestDiscoveryState:
    def test_feature_vector(self, state, d_model):
        features = state.get_feature_vector(d_model=d_model)
        assert features.shape == (d_model,)

    def test_feature_vector_with_data(self, d_model):
        state = DiscoveryState(
            disease_id="test",
            genomic_context=torch.randn(d_model),
            identified_targets=[{"gene_name": "EGFR", "druggability_score": 0.8}],
            selected_target="EGFR",
            generated_molecules=[{"smiles": "CCO", "overall_score": 0.6}],
            step_count=5,
            total_reward=1.5,
        )
        features = state.get_feature_vector(d_model=d_model)
        assert features.shape == (d_model,)


class TestValueNetwork:
    def test_forward(self, d_model):
        net = ValueNetwork(d_model=d_model)
        x = torch.randn(4, d_model)
        out = net(x)
        assert out.shape == (4, 1)

    def test_estimate_value(self, d_model, state):
        net = ValueNetwork(d_model=d_model)
        value = net.estimate_value(state)
        assert isinstance(value, float)


class TestPolicyNetwork:
    def test_forward(self, d_model):
        net = PolicyNetwork(d_model=d_model)
        x = torch.randn(4, d_model)
        probs = net(x)
        assert probs.shape == (4, 8)
        assert torch.allclose(probs.sum(dim=-1), torch.ones(4), atol=1e-5)

    def test_action_priors(self, d_model, state):
        net = PolicyNetwork(d_model=d_model)
        priors = net.get_action_priors(state)
        assert isinstance(priors, dict)
        assert len(priors) == len(ActionType)
        total = sum(priors.values())
        assert abs(total - 1.0) < 1e-4


class TestRewardFunction:
    def test_identify_target_reward(self, state):
        rf = RewardFunction()
        state.identified_targets = [
            {"gene_name": "EGFR", "druggability_score": 0.9, "genetic_evidence": 0.8}
        ]
        action = Action(ActionType.IDENTIFY_TARGET)
        reward = rf.compute(state, action)
        assert reward > 0

    def test_reflect_reward(self, state):
        rf = RewardFunction()
        action = Action(ActionType.REFLECT)
        reward = rf.compute(state, action)
        assert reward == 0.05


class TestReflector:
    def test_heuristic_reflect_empty_state(self, state):
        reflector = Reflector()
        reflection = reflector.reflect(state)
        assert isinstance(reflection, str)
        assert len(reflection) > 0

    def test_memory_accumulates(self, state):
        reflector = Reflector()
        reflector.reflect(state)
        reflector.reflect(state)
        assert len(reflector.memory) == 2

    def test_get_relevant_memories(self, state):
        reflector = Reflector()
        for _ in range(10):
            reflector.reflect(state)
        memories = reflector.get_relevant_memories(state, k=3)
        assert len(memories) == 3


class TestMCTSNode:
    def test_ucb_unvisited(self, state):
        node = MCTSNode(state=state)
        assert node.ucb_score() == float("inf")

    def test_ucb_visited(self, state):
        parent = MCTSNode(state=state)
        parent.visit_count = 10

        child = MCTSNode(state=state, parent=parent)
        child.visit_count = 3
        child.total_value = 1.5
        child.prior = 0.5

        score = child.ucb_score()
        assert isinstance(score, float)
        assert score > 0

    def test_best_child(self, state):
        parent = MCTSNode(state=state)
        parent.visit_count = 10

        for i in range(3):
            child = MCTSNode(state=state, parent=parent)
            child.visit_count = i + 1
            child.total_value = (i + 1) * 0.5
            child.prior = 1.0 / 3
            parent.children.append(child)

        best = parent.best_child()
        assert best is not None


class TestMCTSPlanner:
    def test_get_valid_actions_initial(self, state, d_model):
        planner = MCTSPlanner(
            value_network=ValueNetwork(d_model=d_model),
            policy_network=PolicyNetwork(d_model=d_model),
            reward_function=RewardFunction(),
            reflector=Reflector(),
            n_simulations=5,
        )
        actions = planner.get_valid_actions(state)
        assert len(actions) > 0

    def test_search(self, state, d_model):
        planner = MCTSPlanner(
            value_network=ValueNetwork(d_model=d_model),
            policy_network=PolicyNetwork(d_model=d_model),
            reward_function=RewardFunction(),
            reflector=Reflector(),
            n_simulations=10,
        )
        action = planner.search(state)
        assert isinstance(action, Action)
        assert isinstance(action.action_type, ActionType)


class TestPlannerTrainer:
    def test_train_step(self, d_model):
        value_net = ValueNetwork(d_model=d_model)
        policy_net = PolicyNetwork(d_model=d_model)
        trainer = PlannerTrainer(value_net, policy_net)

        states = [DiscoveryState(disease_id=f"d{i}") for i in range(4)]
        target_values = torch.randn(4)
        target_policies = torch.randint(0, 8, (4,))

        losses = trainer.train_step(states, target_values, target_policies)
        assert "total_loss" in losses
        assert "value_loss" in losses
        assert "policy_loss" in losses
        assert all(v > 0 for v in losses.values())
