"""
Planning Engine for GenoDrugAgent.

Implements Monte Carlo Tree Search (MCTS) with learned value functions
and LLM-based reflection for multi-step drug discovery planning.
"""

from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

import numpy as np
import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Action space
# ---------------------------------------------------------------------------

class ActionType(Enum):
    """Possible agent actions in the drug discovery MDP."""
    ANALYZE_GENOMICS = "analyze_genomics"
    IDENTIFY_TARGET = "identify_target"
    GENERATE_MOLECULE = "generate_molecule"
    OPTIMIZE_MOLECULE = "optimize_molecule"
    EVALUATE_ADMET = "evaluate_admet"
    ASSESS_BINDING = "assess_binding"
    REFLECT = "reflect"
    TERMINATE = "terminate"


@dataclass
class Action:
    """An action in the drug discovery MDP."""
    action_type: ActionType
    parameters: dict[str, Any] = field(default_factory=dict)
    description: str = ""

    def __repr__(self) -> str:
        return f"Action({self.action_type.value}, {self.description})"


# ---------------------------------------------------------------------------
# State representation
# ---------------------------------------------------------------------------

@dataclass
class DiscoveryState:
    """State in the drug discovery MDP."""

    # Disease information
    disease_id: str = ""
    disease_description: str = ""

    # Genomic analysis results
    genomic_context: Optional[torch.Tensor] = None
    identified_targets: list[dict[str, Any]] = field(default_factory=list)
    selected_target: Optional[str] = None

    # Molecular candidates
    generated_molecules: list[dict[str, Any]] = field(default_factory=list)
    optimized_molecules: list[dict[str, Any]] = field(default_factory=list)
    best_molecule: Optional[dict[str, Any]] = None

    # Evaluation results
    admet_results: dict[str, dict] = field(default_factory=dict)
    binding_results: dict[str, float] = field(default_factory=dict)

    # Agent memory
    reflections: list[str] = field(default_factory=list)
    action_history: list[Action] = field(default_factory=list)
    step_count: int = 0
    total_reward: float = 0.0

    def get_feature_vector(self, d_model: int = 512) -> torch.Tensor:
        """Convert state to a fixed-size feature vector for the value network."""
        features = []

        # Genomic context (or zeros)
        if self.genomic_context is not None:
            features.append(self.genomic_context)
        else:
            features.append(torch.zeros(d_model))

        # Target information
        n_targets = len(self.identified_targets)
        target_features = torch.tensor([
            n_targets / 10.0,
            1.0 if self.selected_target else 0.0,
        ])
        features.append(target_features)

        # Molecule information
        n_mols = len(self.generated_molecules)
        best_score = max(
            (m.get("overall_score", 0) for m in self.generated_molecules), default=0
        )
        mol_features = torch.tensor([
            n_mols / 100.0,
            best_score,
            len(self.optimized_molecules) / 50.0,
        ])
        features.append(mol_features)

        # Step information
        step_features = torch.tensor([
            self.step_count / 50.0,
            self.total_reward,
        ])
        features.append(step_features)

        # Concatenate and project to fixed size
        concat = torch.cat([f.float().flatten() for f in features])
        # Pad or truncate to d_model
        if concat.size(0) < d_model:
            concat = F.pad(concat, (0, d_model - concat.size(0)))
        else:
            concat = concat[:d_model]
        return concat


import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Value network
# ---------------------------------------------------------------------------

class ValueNetwork(nn.Module):
    """Learned value function for MCTS node evaluation."""

    def __init__(self, d_model: int = 512):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model // 2),
            nn.GELU(),
            nn.LayerNorm(d_model // 2),
            nn.Linear(d_model // 2, 1),
        )

    def forward(self, state_features: torch.Tensor) -> torch.Tensor:
        return self.network(state_features)

    def estimate_value(self, state: DiscoveryState) -> float:
        features = state.get_feature_vector()
        with torch.no_grad():
            return self(features.unsqueeze(0)).item()


# ---------------------------------------------------------------------------
# Policy network
# ---------------------------------------------------------------------------

class PolicyNetwork(nn.Module):
    """Policy network for action selection prior probabilities."""

    def __init__(self, d_model: int = 512, n_actions: int = 8):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, n_actions),
        )

    def forward(self, state_features: torch.Tensor) -> torch.Tensor:
        return F.softmax(self.network(state_features), dim=-1)

    def get_action_priors(self, state: DiscoveryState) -> dict[ActionType, float]:
        features = state.get_feature_vector()
        with torch.no_grad():
            probs = self(features.unsqueeze(0)).squeeze(0)
        return {action: probs[i].item() for i, action in enumerate(ActionType)}


# ---------------------------------------------------------------------------
# MCTS Node
# ---------------------------------------------------------------------------

class MCTSNode:
    """A node in the MCTS tree."""

    def __init__(
        self,
        state: DiscoveryState,
        action: Optional[Action] = None,
        parent: Optional[MCTSNode] = None,
    ):
        self.state = state
        self.action = action
        self.parent = parent
        self.children: list[MCTSNode] = []
        self.visit_count: int = 0
        self.total_value: float = 0.0
        self.prior: float = 0.0
        self.is_terminal: bool = False

    @property
    def mean_value(self) -> float:
        if self.visit_count == 0:
            return 0.0
        return self.total_value / self.visit_count

    def ucb_score(self, exploration_weight: float = 1.414) -> float:
        """Upper Confidence Bound score for node selection."""
        if self.visit_count == 0:
            return float("inf")
        parent_visits = self.parent.visit_count if self.parent else 1
        exploitation = self.mean_value
        exploration = exploration_weight * self.prior * math.sqrt(
            math.log(parent_visits) / self.visit_count
        )
        return exploitation + exploration

    def best_child(self, exploration_weight: float = 1.414) -> MCTSNode:
        return max(self.children, key=lambda c: c.ucb_score(exploration_weight))

    def best_action_child(self) -> MCTSNode:
        """Select the most visited child (for final action selection)."""
        return max(self.children, key=lambda c: c.visit_count)


# ---------------------------------------------------------------------------
# Reward computation
# ---------------------------------------------------------------------------

class RewardFunction:
    """Multi-objective reward computation."""

    def __init__(
        self,
        alpha: float = 0.30,  # affinity weight
        beta: float = 0.20,   # ADMET weight
        gamma: float = 0.20,  # genomic consistency weight
        delta: float = 0.15,  # novelty weight
        epsilon: float = 0.15,  # synthesizability weight
    ):
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.delta = delta
        self.epsilon = epsilon

    def compute(self, state: DiscoveryState, action: Action) -> float:
        """Compute reward for a state-action pair."""
        reward = 0.0

        if action.action_type == ActionType.IDENTIFY_TARGET:
            # Reward for identifying high-quality targets
            if state.identified_targets:
                best_target = max(
                    state.identified_targets,
                    key=lambda t: t.get("druggability_score", 0),
                )
                reward += 0.3 * best_target.get("druggability_score", 0)
                reward += 0.2 * best_target.get("genetic_evidence", 0)

        elif action.action_type == ActionType.GENERATE_MOLECULE:
            if state.generated_molecules:
                best_mol = max(
                    state.generated_molecules,
                    key=lambda m: m.get("overall_score", 0),
                )
                reward += self.alpha * best_mol.get("predicted_affinity", 0) / 10.0
                reward += self.gamma * best_mol.get("genomic_consistency_score", 0)

        elif action.action_type == ActionType.OPTIMIZE_MOLECULE:
            if state.optimized_molecules and state.generated_molecules:
                best_opt = max(
                    state.optimized_molecules,
                    key=lambda m: m.get("overall_score", 0),
                )
                best_gen = max(
                    state.generated_molecules,
                    key=lambda m: m.get("overall_score", 0),
                )
                improvement = (
                    best_opt.get("overall_score", 0)
                    - best_gen.get("overall_score", 0)
                )
                reward += max(0, improvement)

        elif action.action_type == ActionType.EVALUATE_ADMET:
            if state.admet_results:
                # Reward for passing ADMET filters
                for mol_id, results in state.admet_results.items():
                    passed = sum(1 for v in results.values() if v > 0.5)
                    reward += self.beta * passed / len(results)

        elif action.action_type == ActionType.REFLECT:
            # Small reward for reflection (encourages strategic thinking)
            reward += 0.05

        elif action.action_type == ActionType.TERMINATE:
            # Final reward based on overall state quality
            if state.best_molecule:
                reward += state.best_molecule.get("overall_score", 0)

        return reward


# ---------------------------------------------------------------------------
# Reflector
# ---------------------------------------------------------------------------

class Reflector:
    """
    LLM-based reflection module that analyzes trajectories and
    generates verbal feedback for episodic memory.
    """

    def __init__(self, use_llm: bool = False, llm_client: Any = None):
        self.use_llm = use_llm
        self.llm_client = llm_client
        self.memory: list[dict[str, Any]] = []

    def reflect(self, state: DiscoveryState) -> str:
        """Generate a reflection on the current trajectory."""
        if self.use_llm and self.llm_client:
            return self._llm_reflect(state)
        return self._heuristic_reflect(state)

    def _heuristic_reflect(self, state: DiscoveryState) -> str:
        """Rule-based reflection for development/testing."""
        reflections = []

        if not state.identified_targets:
            reflections.append(
                "No targets identified yet. Should prioritize genomic analysis."
            )
        elif not state.selected_target:
            reflections.append(
                f"Found {len(state.identified_targets)} targets but none selected. "
                "Should evaluate druggability and select the most promising one."
            )

        if state.generated_molecules:
            best = max(state.generated_molecules, key=lambda m: m.get("overall_score", 0))
            if best.get("overall_score", 0) < 0.5:
                reflections.append(
                    f"Best molecule score is {best.get('overall_score', 0):.2f}, "
                    "which is below threshold. Consider adjusting generation parameters "
                    "or trying a different target."
                )
            if best.get("genomic_consistency_score", 0) < 0.3:
                reflections.append(
                    "Generated molecules show low genomic consistency. "
                    "The genomic context conditioning may need stronger weighting."
                )

        if state.step_count > 30 and not state.best_molecule:
            reflections.append(
                "Many steps taken without identifying a strong candidate. "
                "Consider terminating and re-starting with different parameters."
            )

        if not reflections:
            reflections.append("Current trajectory is progressing well.")

        reflection = " ".join(reflections)
        self.memory.append({
            "step": state.step_count,
            "reflection": reflection,
            "best_score": max(
                (m.get("overall_score", 0) for m in state.generated_molecules),
                default=0,
            ),
        })
        return reflection

    def _llm_reflect(self, state: DiscoveryState) -> str:
        """LLM-based reflection using API call."""
        prompt = f"""You are an expert drug discovery scientist analyzing an AI agent's progress.

Current state:
- Disease: {state.disease_id}
- Targets identified: {len(state.identified_targets)}
- Selected target: {state.selected_target}
- Molecules generated: {len(state.generated_molecules)}
- Molecules optimized: {len(state.optimized_molecules)}
- Steps taken: {state.step_count}
- Total reward: {state.total_reward:.3f}

Recent actions: {[str(a) for a in state.action_history[-5:]]}

Provide a brief reflection (2-3 sentences) analyzing:
1. What is going well or poorly?
2. What should the agent do next?
3. Are there any strategic pivots needed?
"""
        try:
            # This would use the actual LLM API
            response = self.llm_client.generate(prompt)
            self.memory.append({
                "step": state.step_count,
                "reflection": response,
            })
            return response
        except Exception as e:
            logger.warning(f"LLM reflection failed: {e}")
            return self._heuristic_reflect(state)

    def get_relevant_memories(self, state: DiscoveryState, k: int = 5) -> list[str]:
        """Retrieve most relevant past reflections."""
        if not self.memory:
            return []
        # Return most recent k reflections
        recent = self.memory[-k:]
        return [m["reflection"] for m in recent]


# ---------------------------------------------------------------------------
# MCTS Planner
# ---------------------------------------------------------------------------

class MCTSPlanner:
    """
    Monte Carlo Tree Search planner for drug discovery.

    Combines a learned value network, a policy network, and
    LLM-based reflection for multi-step planning.
    """

    def __init__(
        self,
        value_network: ValueNetwork,
        policy_network: PolicyNetwork,
        reward_function: RewardFunction,
        reflector: Reflector,
        n_simulations: int = 100,
        exploration_weight: float = 1.414,
        max_depth: int = 20,
        discount: float = 0.99,
    ):
        self.value_network = value_network
        self.policy_network = policy_network
        self.reward_function = reward_function
        self.reflector = reflector
        self.n_simulations = n_simulations
        self.exploration_weight = exploration_weight
        self.max_depth = max_depth
        self.discount = discount

    def get_valid_actions(self, state: DiscoveryState) -> list[Action]:
        """Determine valid actions given current state."""
        actions = []

        if not state.genomic_context is not None and not state.identified_targets:
            actions.append(Action(
                ActionType.ANALYZE_GENOMICS,
                {"disease_id": state.disease_id},
                "Analyze genomic data for disease",
            ))

        if state.genomic_context is not None and not state.selected_target:
            actions.append(Action(
                ActionType.IDENTIFY_TARGET,
                {},
                "Identify and prioritize drug targets",
            ))

        if state.selected_target:
            actions.append(Action(
                ActionType.GENERATE_MOLECULE,
                {"target": state.selected_target, "n_samples": 50},
                f"Generate molecules for target {state.selected_target}",
            ))

        if state.generated_molecules:
            actions.append(Action(
                ActionType.OPTIMIZE_MOLECULE,
                {},
                "Optimize best generated molecules",
            ))
            actions.append(Action(
                ActionType.EVALUATE_ADMET,
                {},
                "Evaluate ADMET properties",
            ))
            actions.append(Action(
                ActionType.ASSESS_BINDING,
                {},
                "Assess binding affinity",
            ))

        if state.step_count > 0:
            actions.append(Action(
                ActionType.REFLECT,
                {},
                "Reflect on progress and strategy",
            ))

        if state.best_molecule or state.step_count > self.max_depth:
            actions.append(Action(
                ActionType.TERMINATE,
                {},
                "Terminate and return best candidate",
            ))

        if not actions:
            actions.append(Action(
                ActionType.ANALYZE_GENOMICS,
                {"disease_id": state.disease_id},
                "Start with genomic analysis",
            ))

        return actions

    def search(self, root_state: DiscoveryState) -> Action:
        """
        Run MCTS from the given state and return the best action.

        Args:
            root_state: Current state of the drug discovery process

        Returns:
            Best action to take
        """
        root = MCTSNode(state=root_state)

        # Set prior probabilities from policy network
        action_priors = self.policy_network.get_action_priors(root_state)
        valid_actions = self.get_valid_actions(root_state)

        for action in valid_actions:
            child = MCTSNode(state=root_state, action=action, parent=root)
            child.prior = action_priors.get(action.action_type, 1.0 / len(valid_actions))
            root.children.append(child)

        # Run simulations
        for sim in range(self.n_simulations):
            node = root

            # Selection: traverse tree using UCB
            while node.children and not node.is_terminal:
                node = node.best_child(self.exploration_weight)

            # Expansion: if not visited, expand
            if node.visit_count == 0 and not node.is_terminal:
                # Use value network for leaf evaluation
                value = self.value_network.estimate_value(node.state)
            else:
                # Simulate: rollout with heuristic policy
                value = self._simulate(node.state)

            # Backpropagate
            while node is not None:
                node.visit_count += 1
                node.total_value += value
                value *= self.discount
                node = node.parent

        # Reflection after search
        if root_state.step_count % 5 == 0:
            reflection = self.reflector.reflect(root_state)
            logger.info(f"Agent reflection: {reflection}")

        # Select best action (most visited child)
        best_child = root.best_action_child()
        logger.info(
            f"MCTS selected: {best_child.action} "
            f"(visits: {best_child.visit_count}, value: {best_child.mean_value:.3f})"
        )
        return best_child.action

    def _simulate(self, state: DiscoveryState, max_steps: int = 10) -> float:
        """Rollout simulation using a fast heuristic policy."""
        cumulative_reward = 0.0
        discount = 1.0

        simulated_state = DiscoveryState(
            disease_id=state.disease_id,
            genomic_context=state.genomic_context,
            identified_targets=list(state.identified_targets),
            selected_target=state.selected_target,
            generated_molecules=list(state.generated_molecules),
            step_count=state.step_count,
        )

        for _ in range(max_steps):
            valid_actions = self.get_valid_actions(simulated_state)
            if not valid_actions:
                break

            # Heuristic: choose action with highest prior
            action_priors = self.policy_network.get_action_priors(simulated_state)
            best_action = max(
                valid_actions,
                key=lambda a: action_priors.get(a.action_type, 0),
            )

            reward = self.reward_function.compute(simulated_state, best_action)
            cumulative_reward += discount * reward
            discount *= self.discount

            # Simple state transition simulation
            simulated_state.step_count += 1
            simulated_state.action_history.append(best_action)

            if best_action.action_type == ActionType.TERMINATE:
                break

        # Terminal value estimation
        terminal_value = self.value_network.estimate_value(simulated_state)
        cumulative_reward += discount * terminal_value

        return cumulative_reward


# ---------------------------------------------------------------------------
# Training utilities
# ---------------------------------------------------------------------------

class PlannerTrainer:
    """Training loop for value and policy networks."""

    def __init__(
        self,
        value_network: ValueNetwork,
        policy_network: PolicyNetwork,
        lr: float = 1e-4,
        value_loss_weight: float = 1.0,
        policy_loss_weight: float = 1.0,
    ):
        self.value_network = value_network
        self.policy_network = policy_network
        self.optimizer = torch.optim.AdamW(
            list(value_network.parameters()) + list(policy_network.parameters()),
            lr=lr,
            weight_decay=1e-5,
        )
        self.value_loss_weight = value_loss_weight
        self.policy_loss_weight = policy_loss_weight

    def train_step(
        self,
        states: list[DiscoveryState],
        target_values: torch.Tensor,
        target_policies: torch.Tensor,
    ) -> dict[str, float]:
        """Single training step on a batch of MCTS trajectories."""
        self.optimizer.zero_grad()

        # Stack state features
        state_features = torch.stack([s.get_feature_vector() for s in states])

        # Value loss
        predicted_values = self.value_network(state_features).squeeze(-1)
        value_loss = F.mse_loss(predicted_values, target_values)

        # Policy loss (cross-entropy with MCTS visit counts as targets)
        predicted_policy = self.policy_network(state_features)
        policy_loss = F.cross_entropy(predicted_policy, target_policies)

        # Combined loss
        total_loss = (
            self.value_loss_weight * value_loss
            + self.policy_loss_weight * policy_loss
        )

        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(
            list(self.value_network.parameters())
            + list(self.policy_network.parameters()),
            max_norm=1.0,
        )
        self.optimizer.step()

        return {
            "total_loss": total_loss.item(),
            "value_loss": value_loss.item(),
            "policy_loss": policy_loss.item(),
        }
