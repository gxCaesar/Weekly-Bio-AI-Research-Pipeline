"""Command-line interface for GenoDrugAgent."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import torch


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def cmd_run(args: argparse.Namespace) -> None:
    """Run the agent on a disease."""
    from .agent import AgentConfig, GenoDrugAgent
    from .benchmark import create_benchmark_suite

    config = AgentConfig(
        d_model=args.d_model,
        mcts_simulations=args.mcts_sims,
        max_steps=args.max_steps,
        n_molecules_per_round=args.n_molecules,
        temperature=args.temperature,
        log_dir=args.log_dir,
        use_pretrained=args.use_pretrained,
    )

    agent = GenoDrugAgent(config)

    # Find the task
    tasks = create_benchmark_suite()
    task = None
    for t in tasks:
        if t.task_id == args.task_id or t.disease_name.lower().startswith(
            args.task_id.lower()
        ):
            task = t
            break

    if task is None:
        print(f"Task '{args.task_id}' not found. Available tasks:")
        for t in tasks:
            print(f"  {t.task_id}: {t.disease_name}")
        sys.exit(1)

    print(f"Running GenoDrugAgent on: {task.disease_name}")
    trajectory = agent.run(
        disease_id=task.disease_id,
        disease_description=task.disease_description,
        gene_ids=task.gene_ids,
        expression_values=task.expression_values,
        target_sequences=task.target_sequences,
        gwas_features=task.gwas_features,
    )

    print(f"\nCompleted in {trajectory.wall_time_seconds:.1f}s, "
          f"{trajectory.n_steps} steps, "
          f"reward={trajectory.total_reward:.4f}")
    print(f"Top candidates: {len(trajectory.final_candidates)}")
    for i, cand in enumerate(trajectory.final_candidates[:5]):
        print(f"  {i+1}. {cand.get('smiles', 'N/A')[:60]} "
              f"(score={cand.get('overall_score', 0):.4f})")


def cmd_benchmark(args: argparse.Namespace) -> None:
    """Run the full benchmark suite."""
    from .agent import AgentConfig, GenoDrugAgent
    from .benchmark import BenchmarkEvaluator, create_benchmark_suite

    config = AgentConfig(
        d_model=args.d_model,
        mcts_simulations=args.mcts_sims,
        max_steps=args.max_steps,
        log_dir=args.log_dir,
    )

    agent = GenoDrugAgent(config)
    evaluator = BenchmarkEvaluator()
    tasks = create_benchmark_suite()

    print(f"Running benchmark with {len(tasks)} tasks...")
    for task in tasks:
        print(f"\n{'='*60}")
        print(f"Task: {task.disease_name} ({task.task_id})")
        print(f"{'='*60}")

        trajectory = agent.run(
            disease_id=task.disease_id,
            disease_description=task.disease_description,
            gene_ids=task.gene_ids,
            expression_values=task.expression_values,
            target_sequences=task.target_sequences,
            gwas_features=task.gwas_features,
        )

        result = evaluator.evaluate_trajectory(task, trajectory)
        print(f"  Overall score: {result.overall_score:.4f}")
        print(f"  Target score: {result.target_score:.4f}")
        print(f"  Molecular score: {result.molecular_score:.4f}")

    # Summary
    summary = evaluator.summary()
    print(f"\n{'='*60}")
    print("BENCHMARK SUMMARY")
    print(f"{'='*60}")
    for key, value in summary.items():
        print(f"  {key}: {value:.4f}")

    # Save results
    output_path = Path(args.log_dir) / "benchmark_results.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    evaluator.save_results(str(output_path))
    print(f"\nResults saved to {output_path}")


def cmd_train(args: argparse.Namespace) -> None:
    """Train the planning networks using collected trajectories."""
    print("Training mode - collecting trajectories and training value/policy networks")
    print("This is a placeholder for the full training loop.")
    print("See scripts/train.py for the complete training pipeline.")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="GenoDrugAgent: AI Agent for Genomics-Informed Drug Discovery"
    )
    parser.add_argument(
        "--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"]
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Run command
    run_parser = subparsers.add_parser("run", help="Run agent on a disease")
    run_parser.add_argument("task_id", help="Task ID or disease name prefix")
    run_parser.add_argument("--d-model", type=int, default=256)
    run_parser.add_argument("--mcts-sims", type=int, default=50)
    run_parser.add_argument("--max-steps", type=int, default=20)
    run_parser.add_argument("--n-molecules", type=int, default=50)
    run_parser.add_argument("--temperature", type=float, default=0.8)
    run_parser.add_argument("--log-dir", default="./logs")
    run_parser.add_argument("--use-pretrained", action="store_true")

    # Benchmark command
    bench_parser = subparsers.add_parser("benchmark", help="Run full benchmark")
    bench_parser.add_argument("--d-model", type=int, default=256)
    bench_parser.add_argument("--mcts-sims", type=int, default=50)
    bench_parser.add_argument("--max-steps", type=int, default=20)
    bench_parser.add_argument("--log-dir", default="./logs")

    # Train command
    train_parser = subparsers.add_parser("train", help="Train planning networks")
    train_parser.add_argument("--epochs", type=int, default=100)
    train_parser.add_argument("--lr", type=float, default=1e-4)

    args = parser.parse_args()
    setup_logging(args.log_level)

    if args.command == "run":
        cmd_run(args)
    elif args.command == "benchmark":
        cmd_benchmark(args)
    elif args.command == "train":
        cmd_train(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
