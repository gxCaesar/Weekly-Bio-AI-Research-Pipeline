"""Tests for the Molecular Design Module."""

import pytest
import torch

from genodrugagent.molecular_module import (
    BindingAffinityPredictor,
    ConditionalMolecularGenerator,
    GenomicConsistencyScorer,
    MolecularDesignModule,
    MolecularEncoder,
    PropertyPredictor,
)


@pytest.fixture
def d_model():
    return 128


@pytest.fixture
def batch_size():
    return 4


class TestMolecularEncoder:
    def test_tokenize(self):
        encoder = MolecularEncoder(d_model=64, n_layers=2)
        tokens = encoder.tokenize("CCO")
        assert tokens.shape == (256,)
        assert tokens[0] == 1  # BOS

    def test_encode(self, d_model, batch_size):
        encoder = MolecularEncoder(d_model=d_model, n_layers=2)
        tokens = torch.stack([encoder.tokenize("CCO")] * batch_size)
        output = encoder(tokens)
        assert output.shape == (batch_size, 256, d_model)

    def test_encode_smiles(self, d_model):
        encoder = MolecularEncoder(d_model=d_model, n_layers=2)
        emb = encoder.encode_smiles("c1ccccc1")
        assert emb.shape == (d_model,)


class TestConditionalMolecularGenerator:
    def test_forward(self, d_model, batch_size):
        gen = ConditionalMolecularGenerator(d_model=d_model, n_layers=2)
        tokens = torch.randint(0, gen.vocab_size, (batch_size, 64))
        context = torch.randn(batch_size, d_model)

        logits = gen(tokens, context)
        assert logits.shape == (batch_size, 64, gen.vocab_size)

    def test_generate(self, d_model):
        gen = ConditionalMolecularGenerator(d_model=d_model, n_layers=2)
        context = torch.randn(d_model)

        smiles = gen.generate(context, n_samples=5, max_length=32)
        assert isinstance(smiles, list)
        assert len(smiles) == 5
        for s in smiles:
            assert isinstance(s, str)


class TestPropertyPredictor:
    def test_predict(self, d_model, batch_size):
        predictor = PropertyPredictor(d_model=d_model)
        tokens = torch.randint(0, 50, (batch_size, 256))
        preds = predictor(tokens)
        assert isinstance(preds, dict)
        assert "pIC50" in preds
        assert preds["pIC50"].shape == (batch_size,)

    def test_predict_smiles(self, d_model):
        predictor = PropertyPredictor(d_model=d_model)
        preds = predictor.predict_smiles("CCO")
        assert isinstance(preds, dict)
        assert "QED" in preds
        assert isinstance(preds["QED"], float)


class TestBindingAffinityPredictor:
    def test_predict(self, d_model, batch_size):
        predictor = BindingAffinityPredictor(d_model=d_model)
        mol_tokens = torch.randint(0, 50, (batch_size, 256))
        prot_emb = torch.randn(batch_size, 30, d_model)

        affinity = predictor(mol_tokens, prot_emb)
        assert affinity.shape == (batch_size,)


class TestGenomicConsistencyScorer:
    def test_score(self, d_model, batch_size):
        scorer = GenomicConsistencyScorer(d_model=d_model)
        mol_emb = torch.randn(batch_size, d_model)
        disease_emb = torch.randn(batch_size, d_model)

        scores = scorer(mol_emb, disease_emb)
        assert scores.shape == (batch_size,)
        assert (scores >= 0).all() and (scores <= 1).all()


class TestMolecularDesignModule:
    def test_init(self, d_model):
        module = MolecularDesignModule(d_model=d_model)
        assert module.generator is not None
        assert module.property_predictor is not None
        assert module.binding_predictor is not None

    def test_generate_and_evaluate(self, d_model):
        module = MolecularDesignModule(d_model=d_model)
        context = torch.randn(d_model)
        disease_expr = torch.randn(d_model)
        prot_emb = torch.randn(30, d_model)

        candidates = module.generate_and_evaluate(
            context, disease_expr, prot_emb,
            n_samples=10, temperature=1.0,
        )
        assert isinstance(candidates, list)
        # May generate some valid candidates
        for cand in candidates:
            assert hasattr(cand, "smiles")
            assert hasattr(cand, "overall_score")
