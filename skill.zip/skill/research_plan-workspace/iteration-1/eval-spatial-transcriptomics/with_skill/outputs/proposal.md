# SpaFormers: 空间感知转录组基础模型 研究方案

## 1. 研究问题与动机

### 1.1 问题定义

**核心问题**：如何设计一个专门针对空间转录组学（Spatial Transcriptomics, ST）数据的基础模型，使其能够在大规模ST数据上通过自监督预训练学习到同时编码基因表达模式和空间组织结构的通用表征，并通过微调高效适配多种下游分析任务（空间域识别、基因表达插补、细胞类型解卷积、空间变异基因检测等）？

**形式化定义**：给定空间转录组学数据集 $\mathcal{D} = \{(x_i, s_i)\}_{i=1}^{N}$，其中 $x_i \in \mathbb{R}^{G}$ 为第 $i$ 个spot/cell的基因表达向量（$G$为基因数），$s_i \in \mathbb{R}^{2}$ 为其空间坐标。目标是学习一个编码器 $f_\theta: (x_i, s_i, \mathcal{N}_i) \rightarrow z_i \in \mathbb{R}^{d}$，其中 $\mathcal{N}_i$ 为spot $i$ 的空间邻域，使得学到的表征 $z_i$ 能够同时反映基因表达特征和空间微环境信息。

### 1.2 研究动机

**现有方法的关键局限**：

1. **单细胞基础模型的空间盲点**：scGPT、Geneformer等模型在scRNA-seq数据上预训练，将每个细胞视为独立的"句子"来建模，完全忽略了空间上下文信息。当将其应用于ST数据时，空间信息只能作为微调阶段的辅助特征，无法在预训练阶段被充分学习。

2. **专用ST方法的泛化困境**：SpaGCN、STAGATE等方法虽然直接建模空间关系，但它们是从头训练的（train from scratch），每个任务和数据集都需要独立训练，缺乏跨任务的知识迁移能力。

3. **跨平台差异的挑战**：Visium（spot级，~55μm分辨率）、MERFISH（单细胞级，亚微米分辨率）、Stereo-seq（纳米级分辨率）等平台的数据特征差异巨大。现有方法缺乏处理这种异质性的统一框架。

### 1.3 目标

1. 构建首个真正空间感知的转录组基础模型，在预训练阶段即深度整合空间位置信息
2. 在至少5个标准ST分析任务上达到或超越当前最优专用方法
3. 展示跨平台（Visium→MERFISH）和跨物种（Human→Mouse）的零样本或少样本迁移能力
4. 模型规模控制在300M参数以内，确保在单块A100 80GB上可训练

## 2. 创新点

### 创新点1: 层次化空间位置编码（Hierarchical Spatial Positional Encoding, HSPE）

- **描述**: 设计一种新的位置编码方案，将旋转位置编码（RoPE）从1D推广到2D空间坐标，并结合可学习的多尺度空间哈希嵌入。具体地，(1)使用2D-RoPE编码精确的空间坐标，保持平移等变性；(2)使用多分辨率空间哈希网格（灵感来自Instant-NGP）对空间位置进行层次化离散编码，捕获不同尺度的空间模式；(3)通过门控融合机制将两种编码自适应地组合。
- **解决的问题**: 现有方法（如CellPLM的简单2D正弦位置编码）无法同时捕获局部空间精度和全局组织层次结构。HSPE使模型能够在不同空间尺度上进行推理。
- **与现有工作的区别**: CellPLM使用固定的2D正弦位置编码，无法适应不同分辨率的数据；scGPT完全没有空间位置编码。HSPE通过多尺度设计和可学习组件来自适应不同平台和分辨率。
- **技术依据**: RoPE (Su et al., 2021) 在NLP中的成功；Instant-NGP (Muller et al., 2022) 中多分辨率哈希编码在3D表征学习中的有效性；Vision Transformer中2D位置编码的研究。

### 创新点2: 空间感知掩码预训练策略（Spatially-Aware Masked Pre-training, SAMP）

- **描述**: 设计三种互补的自监督预训练任务：(1) **空间条件基因预测（Spatial-Conditioned Gene Prediction, SCGP）**：随机掩码一个spot的部分基因，利用其空间邻居的信息来预测被掩码的基因表达值，迫使模型学习空间自相关模式；(2) **空间上下文对比学习（Spatial Context Contrastive Learning, SCCL）**：构造正样本对（空间邻近的spots共享相似的微环境）和负样本对（空间远离的spots），学习空间一致的表征；(3) **跨分辨率一致性（Cross-Resolution Consistency, CRC）**：对同一区域的数据在不同粒度下（如16个spots的聚合 vs 单个spot）计算表征，要求两者在嵌入空间中一致。
- **解决的问题**: scGPT等现有模型的预训练目标（如masked gene expression prediction）完全不考虑空间上下文，导致学到的表征缺乏空间感知能力。
- **与现有工作的区别**: scGPT使用独立的masked gene prediction；Geneformer使用rank-value encoding的masked language modeling；CellPLM尝试了cell-level的masked auto-encoding但未充分利用空间邻域结构。SAMP首次将空间邻域信息系统性地融入预训练目标。
- **技术依据**: BERT的masked language modeling; MAE (He et al., 2022) 的masked auto-encoding; SimCLR/MoCo的对比学习框架。

### 创新点3: 多尺度空间注意力（Multi-Scale Spatial Attention, MSSA）

- **描述**: 在标准Transformer的self-attention基础上，设计一种分层的空间注意力机制：(1) **局部窗口注意力**：每个spot只与其空间邻域内的K个最近邻进行attention计算（类似Swin Transformer的窗口机制），复杂度为O(NK)；(2) **全局稀疏注意力**：通过空间聚类选择空间代表性tokens（cluster centroids），进行全局attention以捕获长程空间依赖；(3) **跨尺度信息传递**：在不同空间尺度之间设计信息交换机制，实现细粒度和粗粒度信息的融合。最终复杂度为O(N(K+M))，其中M为全局代表点数量，远小于标准attention的O(N^2)。
- **解决的问题**: 标准Transformer的O(N^2)注意力在大规模ST数据（N>100K）上不可行；简单的图注意力（如STAGATE的GAT）只考虑固定邻域，无法捕获多尺度空间模式。
- **与现有工作的区别**: STAGATE使用固定邻域的GAT；GraphST使用标准GCN；现有基础模型使用标准full attention。MSSA首次在ST基础模型中引入分层、高效的空间注意力设计。
- **技术依据**: Swin Transformer (Liu et al., 2021) 的窗口注意力; Performer (Choromanski et al., 2020) 的线性注意力; Graphormer (Ying et al., 2021) 的图结构位置编码。

## 3. 方法概述

### 3.1 整体框架

SpaFormers采用预训练-微调的两阶段框架：

**预训练阶段**：在大规模ST数据集（来自多个平台、多个物种、多种组织类型）上进行自监督预训练。输入为每个样本的基因表达矩阵和空间坐标。通过SAMP策略中的三种预训练任务共同优化模型参数。

**微调阶段**：针对具体的下游任务（空间域识别、基因插补、细胞解卷积等），添加任务特定的head（如分类head、回归head），在目标数据集上进行有监督或自监督微调。

### 3.2 模型架构

#### ASCII架构图
```
                            SpaFormers Architecture
                            =====================

Input Layer:
┌─────────────┐   ┌─────────────┐
│ Gene Expr   │   │  Spatial    │
│ x_i ∈ R^G   │   │  Coords    │
│             │   │  s_i ∈ R^2  │
└──────┬──────┘   └──────┬──────┘
       │                 │
       ▼                 ▼
┌──────────────┐  ┌──────────────────────┐
│ Gene Token   │  │ Hierarchical Spatial │
│ Embedding    │  │ Positional Encoding  │
│ (Adaptive    │  │ (HSPE)               │
│  Binning +   │  │ ┌────────┐ ┌──────┐ │
│  Linear)     │  │ │2D-RoPE │+│ Hash │ │
│              │  │ │        │ │ Grid │ │
└──────┬───────┘  │ └────────┘ └──────┘ │
       │          └──────────┬───────────┘
       │                     │
       ▼                     ▼
┌──────────────────────────────────────────┐
│          Input Fusion Layer              │
│    h_i = GeneEmb(x_i) + HSPE(s_i)       │
└─────────────────┬────────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│     Multi-Scale Spatial Attention        │
│     Transformer Blocks (×L layers)       │
│  ┌────────────────────────────────────┐  │
│  │  Local Window Attention (K-NN)    │  │
│  │  ┌──────────┐  ┌──────────────┐   │  │
│  │  │ Q,K,V    │→ │Spatial-Masked│   │  │
│  │  │ Projections│ │  Attention   │   │  │
│  │  └──────────┘  └──────────────┘   │  │
│  ├────────────────────────────────────┤  │
│  │  Global Sparse Attention          │  │
│  │  ┌──────────┐  ┌──────────────┐   │  │
│  │  │Centroid  │→ │ Cross-Scale  │   │  │
│  │  │Selection │  │  Attention   │   │  │
│  │  └──────────┘  └──────────────┘   │  │
│  ├────────────────────────────────────┤  │
│  │  FFN + LayerNorm + Residual       │  │
│  └────────────────────────────────────┘  │
└─────────────────┬────────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│         Pre-training Heads               │
│  ┌──────────┐ ┌────────┐ ┌───────────┐  │
│  │  SCGP    │ │ SCCL   │ │   CRC     │  │
│  │  Head    │ │ Head   │ │   Head    │  │
│  │(Gene Pred)│ │(Contra)│ │(Consist.) │  │
│  └──────────┘ └────────┘ └───────────┘  │
└──────────────────────────────────────────┘
                  │
        (Fine-tuning: replace with)
                  ▼
┌──────────────────────────────────────────┐
│         Task-Specific Heads              │
│  ┌──────────┐ ┌────────┐ ┌───────────┐  │
│  │ Domain   │ │ Gene   │ │Cell Type  │  │
│  │ Classif. │ │ Impute │ │Deconvolve │  │
│  └──────────┘ └────────┘ └───────────┘  │
└──────────────────────────────────────────┘
```

#### 架构详细说明

**1. 基因表达嵌入（Gene Token Embedding）**
- 输入：原始基因表达向量 $x_i \in \mathbb{R}^G$
- 首先进行自适应分箱（adaptive binning）：将连续的表达值离散化为B个bin（B=64），保留表达排名信息
- 然后通过可学习的嵌入层将每个bin映射为d维向量
- 高变异基因（HVG）选择：取top-2000 HVG作为输入token序列
- 输出：$E_{\text{gene}} \in \mathbb{R}^{G' \times d}$，其中G'=2000

**2. 层次化空间位置编码（HSPE）**
- 输入：空间坐标 $s_i = (x, y) \in \mathbb{R}^2$
- 2D-RoPE分支：将RoPE从1D序列扩展到2D空间，对x和y坐标分别应用旋转矩阵
- 多分辨率哈希分支：在L个分辨率级别（如16, 32, 64, 128, 256, 512）上构建空间哈希网格，每个级别输出F维特征
- 门控融合：$\text{HSPE}(s_i) = \sigma(W_g[p_{\text{RoPE}}; p_{\text{Hash}}]) \odot p_{\text{RoPE}} + (1 - \sigma(\cdot)) \odot p_{\text{Hash}}$
- 输出：$P_{\text{spatial}} \in \mathbb{R}^d$

**3. 多尺度空间注意力（MSSA）Transformer**
- L=12层Transformer blocks
- 每个block包含：
  - 局部窗口注意力：基于空间K-NN图（K=20），每个spot只与K个空间最近邻计算attention
  - 全局稀疏注意力：通过K-Means将N个spots聚类为M个簇（M=256），使用cluster centroids作为全局token
  - 跨尺度信息传递：局部→全局通过cross-attention汇聚，全局→局部通过广播更新
- 隐藏维度：d=768，注意力头数：H=12
- FFN维度：4d=3072
- 使用Pre-Norm（LayerNorm before attention）

**4. 预训练头**
- SCGP Head: 线性投影 + Softmax，预测被掩码基因的bin类别
- SCCL Head: 投影到128维空间 + InfoNCE loss
- CRC Head: 线性投影 + MSE loss

### 3.3 训练策略

**预训练阶段**：
- 优化器：AdamW (β1=0.9, β2=0.98, weight_decay=0.05)
- 学习率调度：Cosine annealing with linear warmup (warmup 5% steps)
- 峰值学习率：1e-4
- 批次大小：有效批次大小512（单卡batch_size=32 × gradient_accumulation=16）
- 总训练步数：100K steps
- 混合精度训练：BFloat16
- 掩码比例：30%的基因token
- 损失权重：$\mathcal{L} = \mathcal{L}_{\text{SCGP}} + 0.5 \mathcal{L}_{\text{SCCL}} + 0.3 \mathcal{L}_{\text{CRC}}$

**微调阶段**：
- 学习率：1e-5到5e-5（任务相关）
- 训练轮数：20-50 epochs
- 批次大小：64
- 策略：全参数微调（小数据集可用LoRA，r=16）

### 3.4 关键技术细节

**空间K-NN图构建算法**：
```
输入: 空间坐标矩阵 S ∈ R^{N×2}, 邻居数 K
输出: 邻接矩阵 A ∈ {0,1}^{N×N}
1. 使用KD-Tree对S进行索引构建
2. 对每个spot i, 查询K个最近邻
3. 构建对称邻接矩阵: A[i,j] = A[j,i] = 1 if j ∈ KNN(i)
4. 可选: 基于距离进行边权重加权
```

**自适应分箱策略**：
```
输入: 基因表达值 x ∈ R
输出: bin索引 b ∈ {0, 1, ..., B-1}
1. 对非零值取log1p: x' = log(1+x)
2. 使用quantile-based binning将x'映射到B个等频bin
3. bin=0保留给零值（dropout事件）
4. 在预训练数据上计算全局bin边界
```

**总损失函数**：
$$\mathcal{L}_{\text{total}} = \mathcal{L}_{\text{SCGP}} + \lambda_1 \mathcal{L}_{\text{SCCL}} + \lambda_2 \mathcal{L}_{\text{CRC}}$$

其中 $\lambda_1 = 0.5$, $\lambda_2 = 0.3$。

## 4. 数据集

| 数据集 | 来源 | 规模 | 用途 | 下载方式 | 预处理方法 |
|-------|------|------|------|---------|-----------|
| CELLxGENE Census (Human) | CZI | ~50M cells (scRNA-seq) | 预训练初始化 | `cellxgene_census` API | 标准scanpy流程 |
| 10x Visium DLPFC | SpatialLIBD | 12 slices, ~47K spots | 空间域识别基准 | spatialLIBD R包 | QC + HVG selection |
| 10x Visium Breast Cancer | 10x Genomics | 2 slices, ~7K spots | 肿瘤微环境分析 | 10x Genomics网站 | QC + HVG selection |
| MERFISH Mouse Brain | Allen Institute | ~1M cells, 500 genes | 大规模ST基准 | Allen Brain Map Portal | Normalization + filtering |
| Stereo-seq Mouse Embryo | BGI | ~100K+ bins | 跨平台泛化测试 | STOMICS DB | Spatial binning + QC |
| 10x Xenium Human Lung | 10x Genomics | ~100K cells | 跨平台验证 | 10x Genomics网站 | Standard QC |
| Mouse Brain (Allen) | Allen Institute | Multiple sections | 预训练数据 | Allen Brain Map | Standard preprocessing |

### 4.1 数据预处理流程

1. **质量控制（QC）**：
   - 过滤低质量spots（总UMI数<200或>50000）
   - 过滤低表达基因（在<10个spots中表达）
   - 过滤线粒体基因比例>25%的spots
   
2. **归一化**：
   - 库大小归一化（library size normalization to 10,000 per cell）
   - Log1p变换
   
3. **高变异基因选择**：
   - 使用scanpy.pp.highly_variable_genes选取top 2000 HVGs
   - 保留所有平台共有的marker基因
   
4. **空间坐标标准化**：
   - 将空间坐标缩放至[0, 1]范围
   - 对不同平台的分辨率进行归一化

### 4.2 数据划分

- 预训练数据：使用所有可用ST数据（不区分训练/测试）
- 下游任务数据划分：
  - DLPFC：按切片划分（10:1:1 = train:val:test，使用leave-one-slice-out交叉验证）
  - 其他数据集：80:10:10随机划分（固定随机种子）

## 5. 基线方法

| 基线方法 | 论文 | 年份 | 开源代码链接 | 关键指标 |
|---------|------|------|-------------|---------|
| scGPT | Cui et al., Nature Methods | 2024 | https://github.com/bowang-lab/scGPT | 预训练基础模型对比 |
| Geneformer | Theodoris et al., Nature | 2023 | https://huggingface.co/ctheodoris/Geneformer | 预训练基础模型对比 |
| CellPLM | Wen et al., ICLR | 2024 | https://github.com/OmicsML/CellPLM | 最接近的空间感知基础模型 |
| STAGATE | Dong & Zhang, Nature Comms | 2022 | https://github.com/QIFEIDKN/STAGATE | 空间域识别基线 |
| GraphST | Long et al., Nature Comms | 2023 | https://github.com/JinmiaoChenLab/GraphST | 空间域识别+整合基线 |
| SpaGCN | Hu et al., Nature Methods | 2021 | https://github.com/jianhuupenn/SpaGCN | 经典空间域识别方法 |
| BANKSY | Singhal et al., Nature Genetics | 2024 | https://github.com/prabhakarlab/Banksy | 最新空间聚类方法 |
| Cell2Location | Kleshchevnikov et al., Nat Biotech | 2022 | https://github.com/BayraktarLab/cell2location | 空间解卷积基线 |

### 各基线简述

- **scGPT**: 在33M单细胞数据上预训练的生成式Transformer，使用masked gene expression prediction作为预训练任务。无空间位置编码。
- **Geneformer**: 使用rank-value encoding将基因表达转化为有序token序列，在30M单细胞上预训练。无空间信息。
- **CellPLM**: 首个尝试整合空间信息的单细胞预训练模型，使用2D正弦位置编码。预训练规模较小。
- **STAGATE**: 基于图注意力自编码器的空间域识别方法，使用自适应图构建策略。
- **GraphST**: 基于图自监督对比学习的空间转录组分析方法，支持空间域识别和数据整合。
- **SpaGCN**: 经典的图卷积网络方法，整合基因表达、空间位置和组织学图像。
- **BANKSY**: 通过空间邻域特征增强的聚类方法，无需深度学习。
- **Cell2Location**: 贝叶斯模型用于空间解卷积，将spot级数据分解为细胞类型比例。

## 6. 评估指标

| 指标名称 | 数学定义 | 评估维度 | 备注 |
|---------|---------|---------|------|
| Adjusted Rand Index (ARI) | $\text{ARI} = \frac{\text{RI} - E[\text{RI}]}{\max(\text{RI}) - E[\text{RI}]}$ | 空间域识别 | 主要指标，越高越好 |
| Normalized Mutual Information (NMI) | $\text{NMI} = \frac{2 \cdot I(Y; \hat{Y})}{H(Y) + H(\hat{Y})}$ | 空间域识别 | 辅助指标 |
| Accuracy (ACC) | $\text{ACC} = \frac{\text{正确预测数}}{N}$ | 细胞类型注释 | 使用Hungarian matching |
| Macro F1 | $F1 = 2 \cdot \frac{P \cdot R}{P + R}$, 各类别取平均 | 细胞类型注释 | 处理类别不平衡 |
| Pearson Correlation (PCC) | $r = \frac{\sum(x-\bar{x})(y-\bar{y})}{\sqrt{\sum(x-\bar{x})^2\sum(y-\bar{y})^2}}$ | 基因表达插补 | 与ground truth的相关性 |
| Mean Squared Error (MSE) | $\text{MSE} = \frac{1}{n}\sum(y - \hat{y})^2$ | 基因表达插补 | 预测精度 |
| CHAOS Score | 空间平滑度度量 | 空间域识别 | 越低越好 |
| Silhouette Score | $s = \frac{b - a}{\max(a, b)}$ | 表征质量 | 聚类质量评估 |

## 7. 消融实验设计

| 实验编号 | 消融对象 | 具体做法 | 验证目的 |
|---------|---------|---------|---------|
| A1 | HSPE → 标准2D正弦位置编码 | 替换HSPE为CellPLM使用的固定2D sinusoidal PE | 验证层次化空间位置编码的贡献 |
| A2 | HSPE → 无位置编码 | 完全移除空间位置编码 | 验证空间信息对模型性能的必要性 |
| A3 | MSSA → 标准full attention | 将多尺度空间注意力替换为标准Transformer self-attention | 验证MSSA的效率和性能优势 |
| A4 | MSSA → 仅局部注意力 | 移除全局稀疏注意力，只保留局部窗口注意力 | 验证全局空间信息的价值 |
| A5 | SAMP → 仅SCGP | 只使用空间条件基因预测，移除SCCL和CRC任务 | 验证多任务预训练的重要性 |
| A6 | SAMP → 仅标准MLM | 使用与scGPT相同的非空间masked prediction | 验证空间感知预训练目标的关键性 |
| A7 | 预训练 → 从头训练 | 不进行预训练，直接在下游任务上从头训练 | 验证预训练的价值 |
| A8 | Gene embedding → 简单线性层 | 将自适应分箱嵌入替换为直接线性映射 | 验证自适应分箱策略的效果 |

## 8. 计算资源评估

### 8.1 GPU显存估算

- 模型参数量: ~300M parameters
  - Gene Token Embedding: 2000×768 = ~1.5M
  - HSPE: ~5M (hash tables + projection layers)
  - 12-layer MSSA Transformer: ~280M (12 × [768×768×4 (QKV+O) + 768×3072×2 (FFN)])
  - Task Heads: ~10M
- 模型FP16占用: ~600MB
- 单样本显存（含中间激活，batch_size=32）:
  - 前向传播: ~8GB
  - 反向传播（梯度）: ~16GB
  - 优化器状态（AdamW FP32）: ~2.4GB
- 总峰值显存: ~30GB (without gradient checkpointing)
- 启用gradient checkpointing: ~20GB
- **结论: 在单块A100 80GB上有充足余量**

### 8.2 训练时间估算

**预训练**：
- 预训练数据量: ~2M spatial spots/cells (来自多个数据集)
- 单epoch时间: ~2 hours (on 1x A100, batch_size=32, gradient_accumulation=16)
- 总训练步数: 100K steps ≈ ~50 epochs
- 总预训练时间: ~100 hours ≈ 4-5 days (1x A100)
- 使用2x A100 DDP: ~50-60 hours ≈ 2-3 days

**微调（per task）**：
- DLPFC空间域识别: ~30 min (20 epochs, ~47K spots)
- 细胞类型注释: ~1 hour (50 epochs, 依数据集大小)
- 基因表达插补: ~2 hours (50 epochs)

### 8.3 推理时间估算

- 单张DLPFC slice (~4K spots): <10 seconds
- 大规模MERFISH (~100K cells): ~30 seconds
- 批量评估（所有任务+所有数据集）: ~2-3 hours

## 9. 基于的论文和开源代码

| 参考论文 | 使用方式 | GitHub链接 | 许可证 |
|---------|---------|-----------|--------|
| scGPT (Cui et al., 2024) | 参考基因token化策略和预训练框架设计 | https://github.com/bowang-lab/scGPT | BSD |
| CellPLM (Wen et al., 2024) | 参考空间位置编码的基本设计和cell-level预训练范式 | https://github.com/OmicsML/CellPLM | MIT |
| Flash Attention (Dao et al., 2022) | 直接使用高效attention实现 | https://github.com/Dao-AILab/flash-attention | BSD |
| Swin Transformer (Liu et al., 2021) | 参考窗口注意力设计 | https://github.com/microsoft/Swin-Transformer | MIT |
| scanpy (Wolf et al., 2018) | 数据预处理和基因选择 | https://github.com/scverse/scanpy | BSD |
| anndata (Virshup et al., 2024) | 数据存储格式 | https://github.com/scverse/anndata | BSD |

### 9.1 代码复用计划

**从scGPT复用**：
- 基因表达分箱（binning）策略的实现
- Masked gene prediction的损失函数实现
- 基本的训练循环和checkpointing逻辑

**从CellPLM复用**：
- 2D位置编码的基础实现（我们在此基础上扩展为HSPE）
- 数据加载器中对空间坐标的处理逻辑

**需要自行实现**：
- 层次化空间位置编码（HSPE）
- 多尺度空间注意力（MSSA）
- 空间感知预训练任务（SAMP的三个子任务）
- 多分辨率哈希空间嵌入
- 跨尺度信息传递机制
- 所有下游任务的微调head和评估流程

## 10. 风险评估与备选方案

| 风险 | 可能性 | 影响 | 备选方案 |
|------|--------|------|---------|
| 预训练数据不足（ST数据量远少于scRNA-seq） | 中 | 高 | 方案B1: 使用scRNA-seq预训练初始化，ST数据做领域适应；方案B2: 使用数据增强（空间旋转、平移、基因dropout） |
| MSSA在超大规模数据上仍然过慢 | 低 | 中 | 方案B3: 使用FlashAttention + 更激进的稀疏化策略；方案B4: 减少全局attention的频率（每隔3层做一次） |
| 跨平台泛化效果不佳 | 中 | 中 | 方案B5: 对每个平台进行轻量级领域适应微调（adapter层）；方案B6: 在预训练中增加平台特征标记 |
| 预训练收敛困难 | 低 | 高 | 方案B7: 使用更小的模型（150M参数）；方案B8: 采用渐进式训练（先训练SCGP，再加入SCCL和CRC） |
| 空间域识别不超过BANKSY等方法 | 中 | 中 | 方案B9: 增加图正则化约束；方案B10: 在微调时使用邻域投票后处理 |
| A100 80GB显存不够（大batch场景） | 低 | 中 | 已有gradient checkpointing和gradient accumulation作为缓解措施 |

## 11. 时间规划

| 阶段 | 任务 | 时间 | 产出 |
|------|------|------|------|
| 第1周 | 环境搭建 + 数据下载预处理 | 1周 | 预处理好的数据、运行环境 |
| 第2周 | 模型架构实现（HSPE + MSSA + Gene Embedding） | 1周 | 可运行的模型代码 |
| 第3周 | 预训练任务实现（SAMP） + 预训练启动 | 1周 | 预训练开始 |
| 第4周 | 预训练完成 + 初步评估 + 调参 | 1周 | 预训练checkpoint |
| 第5周 | 下游任务微调（空间域识别、基因插补、细胞注释） | 1周 | 下游任务结果 |
| 第6周 | 基线复现 + 对比实验 | 1周 | 完整对比表格 |
| 第7周 | 消融实验 + 可视化分析 | 1周 | 消融表格、分析图表 |
| 第8周 | 论文撰写 + 整理 | 1周 | 完整论文草稿 |
