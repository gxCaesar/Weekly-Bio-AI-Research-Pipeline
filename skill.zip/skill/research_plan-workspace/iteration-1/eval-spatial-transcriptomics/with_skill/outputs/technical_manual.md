# SpaFormers 技术手册

## 1. 环境配置

### 1.1 系统要求

- **操作系统**: Linux (Ubuntu 20.04/22.04 推荐)
- **GPU**: NVIDIA A100 80GB x 1-2 (必须)
- **CUDA**: 11.8 或 12.1
- **Python**: 3.10+
- **RAM**: 64GB+ (数据预处理阶段需要较大内存)
- **磁盘空间**: 50GB+ (数据+模型checkpoint)

### 1.2 安装步骤

```bash
# 1. 创建conda环境
conda create -n spaformers python=3.10 -y
conda activate spaformers

# 2. 安装PyTorch (CUDA 11.8)
pip install torch==2.1.2 torchvision==0.16.2 torchaudio==2.1.2 --index-url https://download.pytorch.org/whl/cu118

# 如果使用CUDA 12.1:
# pip install torch==2.1.2 torchvision==0.16.2 torchaudio==2.1.2 --index-url https://download.pytorch.org/whl/cu121

# 3. 安装Flash Attention (可选，提升训练速度)
pip install flash-attn --no-build-isolation

# 4. 安装项目依赖
cd code/
pip install -r requirements.txt

# 5. 安装scanpy生态
pip install scanpy anndata squidpy

# 6. 安装wandb (可选，用于训练监控)
pip install wandb
wandb login  # 输入你的API key
```

### 1.3 验证安装

```bash
# 验证PyTorch和CUDA
python -c "
import torch
print(f'PyTorch version: {torch.__version__}')
print(f'CUDA available: {torch.cuda.is_available()}')
if torch.cuda.is_available():
    print(f'CUDA version: {torch.version.cuda}')
    print(f'GPU: {torch.cuda.get_device_name(0)}')
    print(f'GPU memory: {torch.cuda.get_device_properties(0).total_mem / 1e9:.1f} GB')
"

# 验证关键依赖
python -c "
import scanpy as sc
import anndata as ad
import sklearn
import yaml
print('All dependencies OK')
"

# 验证项目代码可导入
python -c "
from models.model import SpaFormers, SpaFormersForPretraining
from data.dataset import SpatialTranscriptomicsDataset
from evaluation.metrics import compute_metrics
print('Project modules OK')
"
```

## 2. 数据准备

### 2.1 下载数据

```bash
# 下载DLPFC数据集 (主要基准数据)
python data/download.py --dataset dlpfc --output_dir data/raw/

# 下载MERFISH数据 (跨平台测试)
python data/download.py --dataset merfish_mouse_brain --output_dir data/raw/

# 查看所有可用数据集
python data/download.py --dataset list
```

**如果自动下载失败**，请手动下载：

| 数据集 | 下载地址 | 放置位置 |
|--------|---------|---------|
| DLPFC | http://spatial.libd.org/spatialLIBD/ | `data/raw/dlpfc/` |
| MERFISH | https://alleninstitute.org/ | `data/raw/merfish_mouse_brain/` |

下载后确保文件格式为 `.h5ad`，每个slice/sample一个文件。

### 2.2 数据预处理

```bash
# 预处理DLPFC (Visium平台)
python data/preprocess.py \
    --input_dir data/raw/dlpfc \
    --output_dir data/processed/dlpfc \
    --config configs/default.yaml \
    --platform visium

# 预处理MERFISH
python data/preprocess.py \
    --input_dir data/raw/merfish_mouse_brain \
    --output_dir data/processed/merfish_mouse_brain \
    --config configs/default.yaml \
    --platform merfish
```

### 2.3 验证数据

预处理完成后，检查以下文件和内容：

```bash
# 查看预处理后的文件
ls -la data/processed/dlpfc/

# 期望输出: 12个.h5ad文件 (每个切片一个)
# 151507.h5ad  (~5-10MB)
# 151508.h5ad  (~5-10MB)
# ...
# 151676.h5ad  (~5-10MB)
```

```python
# 验证数据质量
import anndata as ad
adata = ad.read_h5ad("data/processed/dlpfc/151507.h5ad")
print(f"Spots: {adata.n_obs}")          # 期望: 3000-5000
print(f"Genes: {adata.n_vars}")          # 期望: 2000+ (HVG后)
print(f"Layers: {list(adata.layers.keys())}")  # 期望: ['counts', 'normalized', 'binned']
print(f"Obsm: {list(adata.obsm.keys())}")      # 期望: ['spatial_normalized', 'spatial_neighbors', ...]
```

## 3. 运行基线实验

### 3.1 基线1: STAGATE

```bash
python main.py \
    --config configs/baseline_stagate.yaml \
    --mode finetune \
    --task spatial_domain \
    --output_dir outputs/baselines/stagate

# 预期训练时间: ~30分钟 (1x A100)
# 预期ARI结果范围: 0.40-0.55
```

### 3.2 基线2: GraphST

```bash
python main.py \
    --config configs/baseline_graphst.yaml \
    --mode finetune \
    --task spatial_domain \
    --output_dir outputs/baselines/graphst

# 预期训练时间: ~1小时 (1x A100)
# 预期ARI结果范围: 0.45-0.60
```

### 3.3 基线3: scGPT (无空间编码)

```bash
python main.py \
    --config configs/baseline_scgpt.yaml \
    --mode train_eval \
    --task spatial_domain \
    --output_dir outputs/baselines/scgpt

# 预期训练时间: ~3-4小时 (含预训练，1x A100)
# 预期ARI结果范围: 0.35-0.50
```

### 3.4 一键运行所有基线

```bash
bash scripts/run_baselines.sh outputs/baselines spatial_domain
```

## 4. 训练我们的模型

### 4.1 完整流程（预训练 + 微调 + 评估）

```bash
# 推荐方式：一键执行全流程
python main.py \
    --config configs/default.yaml \
    --mode train_eval \
    --task spatial_domain \
    --output_dir outputs/main

# 预期总时间: ~5-6天 (预训练4-5天 + 微调1天，1x A100)
```

### 4.2 分步执行

```bash
# 步骤1: 仅预训练
python main.py \
    --config configs/default.yaml \
    --mode pretrain \
    --output_dir outputs/pretrain

# 步骤2: 仅微调 (使用预训练checkpoint)
python main.py \
    --config configs/default.yaml \
    --mode finetune \
    --task spatial_domain \
    --checkpoint outputs/pretrain/best_model.pt \
    --output_dir outputs/finetune_spatial_domain

# 步骤3: 仅评估
python main.py \
    --config configs/default.yaml \
    --mode eval \
    --task spatial_domain \
    --checkpoint outputs/finetune_spatial_domain/best_model.pt \
    --output_dir outputs/eval
```

### 4.3 多GPU训练

```bash
# 使用2块GPU进行预训练 (DDP)
torchrun --nproc_per_node=2 main.py \
    --config configs/default.yaml \
    --mode pretrain \
    --output_dir outputs/pretrain_2gpu
```

### 4.4 训练监控

**使用wandb**：
- 打开浏览器访问 https://wandb.ai
- 在 `spaformers` 项目下查看训练曲线
- 关注指标: `train/loss`, `train/loss_scgp`, `train/loss_sccl`, `train/loss_crc`

**查看日志文件**：
```bash
tail -f outputs/main/train.log
```

**预期训练行为**：
- 预训练loss应在前1000步快速下降，然后缓慢收敛
- SCGP loss: 从~4.0下降到~1.5
- SCCL loss: 从~3.0下降到~1.0
- CRC loss: 从~0.5下降到~0.1

### 4.5 断点续训

如果训练中断，可以从最后的checkpoint恢复：

```bash
python main.py \
    --config configs/default.yaml \
    --mode pretrain \
    --checkpoint outputs/pretrain/last.pt \
    --output_dir outputs/pretrain
```

## 5. 评估

### 5.1 运行评估

```bash
# 在DLPFC测试集上评估
bash scripts/eval.sh \
    outputs/finetune_spatial_domain/best_model.pt \
    configs/default.yaml \
    spatial_domain \
    outputs/eval_dlpfc
```

### 5.2 查看结果

结果保存在 `outputs/eval_dlpfc/eval_results_spatial_domain.json`：

```json
{
    "task": "spatial_domain",
    "metrics": {
        "ari": 0.XXX,
        "nmi": 0.XXX,
        "accuracy": 0.XXX,
        "f1_macro": 0.XXX,
        "silhouette": 0.XXX,
        "chaos": 0.XXX
    },
    "n_samples": XXXX
}
```

### 5.3 预期结果范围

| 指标 | DLPFC期望范围 | 说明 |
|------|-------------|------|
| ARI | 0.55-0.70 | 主要指标 |
| NMI | 0.60-0.75 | 辅助聚类指标 |
| Accuracy | 0.60-0.75 | Hungarian matching后的准确率 |
| F1 (macro) | 0.55-0.70 | 类别加权F1 |
| Silhouette | 0.15-0.35 | 嵌入质量 |
| CHAOS | 0.05-0.15 | 越低越好（空间平滑度） |

## 6. 消融实验

### 6.1 运行所有消融

```bash
bash scripts/run_ablation.sh outputs/ablation spatial_domain
```

### 6.2 运行特定消融

```bash
# 只运行特定消融实验
python ablation/run_ablation.py \
    --output_dir outputs/ablation \
    --task spatial_domain \
    --experiments full_model no_hspe_sinusoidal no_mssa_full_attn
```

### 6.3 消融实验说明

| 编号 | 实验名 | 消融内容 | 验证目的 |
|------|--------|---------|---------|
| A1 | `no_hspe_sinusoidal` | HSPE替换为2D正弦PE | HSPE层次化编码的价值 |
| A2 | `no_hspe_none` | 完全移除空间PE | 空间信息的必要性 |
| A3 | `no_mssa_full_attn` | MSSA替换为标准attention | MSSA的效率和效果 |
| A4 | `no_global_attn` | 仅保留局部attention | 全局空间信息的价值 |
| A5 | `only_scgp` | 仅SCGP预训练 | 多任务预训练的重要性 |
| A6 | `standard_mlm` | 标准MLM（无空间感知） | 空间感知预训练的关键性 |
| A7 | `no_pretrain` | 从头训练 | 预训练的价值 |
| A8 | `no_adaptive_binning` | 简单线性嵌入 | 自适应分箱的效果 |

消融结果将汇总在 `outputs/ablation/ablation_results.json` 和 `outputs/ablation/ablation_chart.png`。

## 7. 常见问题

### 7.1 OOM (显存不足)

**症状**: `CUDA out of memory`

**解决方案（按优先级）**:

1. 减小batch_size:
   ```yaml
   # configs/default.yaml
   pretraining:
     batch_size: 16  # 从32减到16
     gradient_accumulation_steps: 32  # 相应增大以保持有效批次大小
   ```

2. 开启gradient checkpointing:
   ```yaml
   pretraining:
     gradient_checkpointing: true
   ```

3. 减小模型规模:
   ```yaml
   model:
     num_layers: 8   # 从12减到8
     hidden_dim: 512  # 从768减到512
   ```

4. 减小max_spots:
   ```yaml
   model:
     max_spots: 4096  # 从8192减到4096
   ```

### 7.2 训练loss不下降

**可能原因和解决方案**:

1. **学习率太高/太低**: 尝试 1e-5 到 1e-3 范围
2. **数据预处理问题**: 运行验证脚本检查数据
3. **梯度爆炸**: 减小 max_grad_norm (默认1.0)
4. **warmup不足**: 增加 warmup_ratio (默认0.05)

### 7.3 CUDA版本不匹配

```bash
# 方法1: 重新安装匹配的PyTorch
pip install torch==2.1.2 --index-url https://download.pytorch.org/whl/cu118

# 方法2: 通过conda安装
conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia
```

### 7.4 数据下载失败

- 确保网络连接正常
- 如果使用代理，设置环境变量:
  ```bash
  export http_proxy=http://your-proxy:port
  export https_proxy=http://your-proxy:port
  ```
- 手动从数据集网站下载 h5ad 文件到 `data/raw/` 对应目录

### 7.5 wandb初始化失败

```bash
# 方法1: 离线模式
export WANDB_MODE=offline

# 方法2: 完全禁用wandb
# 在config.yaml中设置:
# logging:
#   wandb_project: null
```

### 7.6 多GPU训练不收敛

- 确保所有GPU显存一致
- 检查 `NCCL` 版本兼容性
- 尝试减小学习率（多GPU通常需要调整）

## 8. 预期结果格式

### 8.1 需要产出的表格

**Table 1: 空间域识别主结果**

| Method | ARI | NMI | ACC | F1 |
|--------|-----|-----|-----|-----|
| SpaGCN | XX.X | XX.X | XX.X | XX.X |
| STAGATE | XX.X | XX.X | XX.X | XX.X |
| GraphST | XX.X | XX.X | XX.X | XX.X |
| scGPT | XX.X | XX.X | XX.X | XX.X |
| **SpaFormers (Ours)** | **XX.X** | **XX.X** | **XX.X** | **XX.X** |

**Table 2: 消融实验结果**

| Configuration | ARI | NMI | Delta ARI |
|--------------|-----|-----|-----------|
| Full model | XX.X | XX.X | - |
| w/o HSPE (sin2D) | XX.X | XX.X | -X.X |
| w/o HSPE (none) | XX.X | XX.X | -X.X |
| w/o MSSA | XX.X | XX.X | -X.X |
| w/o global attn | XX.X | XX.X | -X.X |
| Only SCGP | XX.X | XX.X | -X.X |
| Standard MLM | XX.X | XX.X | -X.X |
| No pre-training | XX.X | XX.X | -X.X |

### 8.2 需要产出的图表

1. **空间域识别可视化**: ground truth vs predicted 的空间散点图
2. **t-SNE嵌入图**: 模型学习到的嵌入在2D空间中的分布
3. **消融实验柱状图**: 各消融配置的ARI对比
4. **训练曲线**: loss随epoch的变化

所有图表将自动保存在 `outputs/` 对应目录下。
