"""
Data preprocessing pipeline for SpaFormers.
Handles QC, normalization, HVG selection, and spatial coordinate processing.
"""

import logging
from pathlib import Path
from typing import Optional, Tuple, List

import numpy as np
import pandas as pd
import scanpy as sc
import anndata as ad
from scipy.sparse import issparse

logger = logging.getLogger(__name__)


def quality_control(
    adata: ad.AnnData,
    min_counts: int = 200,
    max_counts: int = 50000,
    max_mito_pct: float = 25.0,
    min_genes: int = 100,
) -> ad.AnnData:
    """
    Perform quality control filtering on spatial transcriptomics data.

    Args:
        adata: AnnData object with raw counts
        min_counts: Minimum total UMI counts per spot
        max_counts: Maximum total UMI counts per spot
        max_mito_pct: Maximum mitochondrial gene percentage
        min_genes: Minimum number of genes expressed per spot

    Returns:
        Filtered AnnData object
    """
    n_before = adata.n_obs
    logger.info(f"QC: Starting with {n_before} spots/cells")

    # Calculate QC metrics
    adata.var["mt"] = adata.var_names.str.startswith(("MT-", "mt-"))
    sc.pp.calculate_qc_metrics(
        adata, qc_vars=["mt"], percent_top=None, log1p=False, inplace=True
    )

    # Apply filters
    sc.pp.filter_cells(adata, min_counts=min_counts)
    sc.pp.filter_cells(adata, max_counts=max_counts)
    sc.pp.filter_cells(adata, min_genes=min_genes)

    if "pct_counts_mt" in adata.obs.columns:
        adata = adata[adata.obs["pct_counts_mt"] < max_mito_pct].copy()

    # Filter genes
    sc.pp.filter_genes(adata, min_cells=10)

    n_after = adata.n_obs
    logger.info(f"QC: {n_before} -> {n_after} spots/cells ({n_before - n_after} removed)")
    logger.info(f"QC: {adata.n_vars} genes remaining")

    return adata


def normalize_data(
    adata: ad.AnnData,
    target_sum: float = 10000.0,
) -> ad.AnnData:
    """
    Normalize gene expression data.

    Args:
        adata: QC-filtered AnnData object
        target_sum: Target library size for normalization

    Returns:
        Normalized AnnData object with raw counts stored in adata.layers["counts"]
    """
    # Store raw counts
    adata.layers["counts"] = adata.X.copy()

    # Library size normalization
    sc.pp.normalize_total(adata, target_sum=target_sum)

    # Log1p transformation
    sc.pp.log1p(adata)

    # Store normalized data
    adata.layers["normalized"] = adata.X.copy()

    logger.info(f"Normalization: target_sum={target_sum}, log1p applied")

    return adata


def select_hvg(
    adata: ad.AnnData,
    n_top_genes: int = 2000,
    method: str = "seurat_v3",
    batch_key: Optional[str] = None,
) -> ad.AnnData:
    """
    Select highly variable genes.

    Args:
        adata: Normalized AnnData object
        n_top_genes: Number of top HVGs to select
        method: HVG selection method ('seurat_v3' or 'cell_ranger')
        batch_key: Key for batch information (for batch-aware HVG selection)

    Returns:
        AnnData with HVG annotation in adata.var['highly_variable']
    """
    if method == "seurat_v3":
        # Seurat v3 uses raw counts
        if "counts" in adata.layers:
            adata_raw = adata.copy()
            adata_raw.X = adata_raw.layers["counts"]
            sc.pp.highly_variable_genes(
                adata_raw,
                n_top_genes=n_top_genes,
                flavor="seurat_v3",
                batch_key=batch_key,
            )
            adata.var["highly_variable"] = adata_raw.var["highly_variable"]
        else:
            sc.pp.highly_variable_genes(
                adata,
                n_top_genes=n_top_genes,
                flavor="seurat_v3",
                batch_key=batch_key,
            )
    else:
        sc.pp.highly_variable_genes(
            adata,
            n_top_genes=n_top_genes,
            flavor=method,
            batch_key=batch_key,
        )

    n_hvg = adata.var["highly_variable"].sum()
    logger.info(f"HVG selection: {n_hvg} genes selected using {method}")

    return adata


def normalize_spatial_coords(
    adata: ad.AnnData,
    coord_key: str = "spatial",
    scale: float = 1.0,
) -> ad.AnnData:
    """
    Normalize spatial coordinates to [0, 1] range.

    Args:
        adata: AnnData with spatial coordinates
        coord_key: Key for spatial coordinates in adata.obsm
        scale: Additional scaling factor

    Returns:
        AnnData with normalized spatial coordinates
    """
    if coord_key in adata.obsm:
        coords = adata.obsm[coord_key].copy()
    elif "spatial" in adata.obsm:
        coords = adata.obsm["spatial"].copy()
    elif "X_spatial" in adata.obsm:
        coords = adata.obsm["X_spatial"].copy()
    else:
        # Try to extract from obs columns
        if "x_coord" in adata.obs and "y_coord" in adata.obs:
            coords = adata.obs[["x_coord", "y_coord"]].values.copy()
        elif "array_row" in adata.obs and "array_col" in adata.obs:
            coords = adata.obs[["array_row", "array_col"]].values.astype(float).copy()
        else:
            raise ValueError(
                "No spatial coordinates found. Expected key in obsm: 'spatial' "
                "or columns in obs: 'x_coord', 'y_coord'"
            )

    # Ensure float type
    coords = coords.astype(np.float32)

    # Normalize to [0, 1]
    coord_min = coords.min(axis=0)
    coord_max = coords.max(axis=0)
    coord_range = coord_max - coord_min
    coord_range[coord_range == 0] = 1.0  # Avoid division by zero

    coords_normalized = (coords - coord_min) / coord_range * scale

    adata.obsm["spatial_normalized"] = coords_normalized
    adata.obsm["spatial_raw"] = adata.obsm.get(coord_key, coords).copy()

    logger.info(
        f"Spatial coords normalized: range [{coord_min}] to [{coord_max}] -> [0, {scale}]"
    )

    return adata


def build_spatial_graph(
    adata: ad.AnnData,
    n_neighbors: int = 20,
    coord_key: str = "spatial_normalized",
) -> ad.AnnData:
    """
    Build spatial K-NN graph for MSSA local attention.

    Args:
        adata: AnnData with spatial coordinates
        n_neighbors: Number of nearest neighbors
        coord_key: Key for spatial coordinates in adata.obsm

    Returns:
        AnnData with spatial graph in adata.obsp['spatial_connectivities']
    """
    from sklearn.neighbors import NearestNeighbors

    coords = adata.obsm[coord_key]

    nn = NearestNeighbors(n_neighbors=n_neighbors, metric="euclidean", n_jobs=-1)
    nn.fit(coords)
    distances, indices = nn.kneighbors(coords)

    # Store as sparse adjacency matrix
    from scipy.sparse import lil_matrix

    n_spots = adata.n_obs
    adj = lil_matrix((n_spots, n_spots), dtype=np.float32)

    for i in range(n_spots):
        for j_idx in range(n_neighbors):
            j = indices[i, j_idx]
            d = distances[i, j_idx]
            adj[i, j] = 1.0
            adj[j, i] = 1.0  # Symmetric

    adata.obsp["spatial_connectivities"] = adj.tocsr()

    # Store neighbor indices for efficient local attention
    adata.obsm["spatial_neighbors"] = indices.astype(np.int64)
    adata.obsm["spatial_distances"] = distances.astype(np.float32)

    logger.info(
        f"Spatial graph: {n_spots} nodes, K={n_neighbors}, "
        f"mean distance={distances[:, 1:].mean():.4f}"
    )

    return adata


def compute_adaptive_bins(
    adata: ad.AnnData,
    n_bins: int = 64,
    layer: str = "normalized",
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute adaptive binning boundaries using quantile-based approach.

    Args:
        adata: AnnData with normalized expression
        n_bins: Number of expression bins (bin 0 reserved for zero/dropout)
        layer: Which layer to use for computing bins

    Returns:
        bin_edges: Array of bin boundaries shape (n_bins + 1,)
        binned_data: Binned expression matrix shape (n_obs, n_vars)
    """
    if layer in adata.layers:
        X = adata.layers[layer]
    else:
        X = adata.X

    if issparse(X):
        X = X.toarray()

    # Separate zero and non-zero values
    nonzero_mask = X > 0
    nonzero_vals = X[nonzero_mask]

    if len(nonzero_vals) == 0:
        logger.warning("No non-zero values found")
        return np.zeros(n_bins + 1), np.zeros_like(X, dtype=np.int64)

    # Compute quantile-based bin edges for non-zero values
    quantiles = np.linspace(0, 100, n_bins)
    bin_edges = np.percentile(nonzero_vals, quantiles)
    bin_edges = np.unique(bin_edges)

    # Bin the data: 0 = zero/dropout, 1 to n_bins = expression levels
    binned = np.zeros_like(X, dtype=np.int64)
    for i in range(X.shape[1]):
        col = X[:, i]
        nz_mask = col > 0
        if nz_mask.any():
            binned[nz_mask, i] = np.digitize(col[nz_mask], bin_edges)

    # Clip to valid range
    binned = np.clip(binned, 0, n_bins - 1)

    logger.info(
        f"Adaptive binning: {n_bins} bins, "
        f"non-zero ratio: {nonzero_mask.mean():.3f}"
    )

    return bin_edges, binned


def preprocess_visium(
    input_path: str,
    output_path: str,
    config: dict,
) -> ad.AnnData:
    """
    Full preprocessing pipeline for 10x Visium data.

    Args:
        input_path: Path to input h5ad file or spaceranger output directory
        output_path: Path to save processed h5ad file
        config: Configuration dictionary with preprocessing parameters

    Returns:
        Processed AnnData object
    """
    logger.info(f"Processing Visium data: {input_path}")

    # Load data
    input_path = Path(input_path)
    if input_path.suffix == ".h5ad":
        adata = sc.read_h5ad(str(input_path))
    elif (input_path / "outs").exists():
        adata = sc.read_visium(str(input_path / "outs"))
    else:
        adata = sc.read_visium(str(input_path))

    # Ensure gene names are unique
    adata.var_names_make_unique()

    # QC
    data_cfg = config.get("data", {})
    adata = quality_control(
        adata,
        min_counts=data_cfg.get("min_counts", 200),
        max_counts=data_cfg.get("max_counts", 50000),
        max_mito_pct=data_cfg.get("max_mito_pct", 25.0),
    )

    # Normalize
    adata = normalize_data(
        adata,
        target_sum=data_cfg.get("normalize_total", 10000),
    )

    # Select HVGs
    adata = select_hvg(
        adata,
        n_top_genes=config.get("model", {}).get("num_genes", 2000),
        method=data_cfg.get("hvg_method", "seurat_v3"),
    )

    # Normalize spatial coordinates
    adata = normalize_spatial_coords(
        adata,
        scale=data_cfg.get("spatial_coord_scale", 1.0),
    )

    # Build spatial graph
    adata = build_spatial_graph(
        adata,
        n_neighbors=config.get("model", {}).get("mssa", {}).get("local_k", 20),
    )

    # Compute adaptive bins
    n_bins = config.get("model", {}).get("num_bins", 64)
    bin_edges, binned_data = compute_adaptive_bins(adata, n_bins=n_bins)
    adata.layers["binned"] = binned_data
    adata.uns["bin_edges"] = bin_edges

    # Save
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    adata.write_h5ad(str(output_path))

    logger.info(
        f"Saved processed data: {output_path} "
        f"({adata.n_obs} spots, {adata.n_vars} genes)"
    )

    return adata


def preprocess_merfish(
    input_path: str,
    output_path: str,
    config: dict,
) -> ad.AnnData:
    """Full preprocessing pipeline for MERFISH data."""
    logger.info(f"Processing MERFISH data: {input_path}")

    adata = sc.read_h5ad(str(input_path))
    adata.var_names_make_unique()

    data_cfg = config.get("data", {})

    # MERFISH-specific QC (fewer genes, so adjust thresholds)
    adata = quality_control(
        adata,
        min_counts=data_cfg.get("min_counts", 50),
        max_counts=data_cfg.get("max_counts", 10000),
        max_mito_pct=data_cfg.get("max_mito_pct", 50.0),
        min_genes=10,
    )

    adata = normalize_data(adata, target_sum=data_cfg.get("normalize_total", 10000))

    # For MERFISH, use all genes (typically ~500)
    n_genes = min(config.get("model", {}).get("num_genes", 2000), adata.n_vars)
    adata = select_hvg(adata, n_top_genes=n_genes)

    adata = normalize_spatial_coords(adata, scale=data_cfg.get("spatial_coord_scale", 1.0))
    adata = build_spatial_graph(
        adata,
        n_neighbors=config.get("model", {}).get("mssa", {}).get("local_k", 20),
    )

    n_bins = config.get("model", {}).get("num_bins", 64)
    bin_edges, binned_data = compute_adaptive_bins(adata, n_bins=n_bins)
    adata.layers["binned"] = binned_data
    adata.uns["bin_edges"] = bin_edges

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    adata.write_h5ad(str(output_path))

    logger.info(f"Saved: {output_path} ({adata.n_obs} cells, {adata.n_vars} genes)")
    return adata


def preprocess_stereoseq(
    input_path: str,
    output_path: str,
    config: dict,
) -> ad.AnnData:
    """Full preprocessing pipeline for Stereo-seq data."""
    logger.info(f"Processing Stereo-seq data: {input_path}")

    adata = sc.read_h5ad(str(input_path))
    adata.var_names_make_unique()

    data_cfg = config.get("data", {})

    adata = quality_control(
        adata,
        min_counts=data_cfg.get("min_counts", 200),
        max_counts=data_cfg.get("max_counts", 50000),
        max_mito_pct=data_cfg.get("max_mito_pct", 25.0),
    )

    adata = normalize_data(adata, target_sum=data_cfg.get("normalize_total", 10000))
    adata = select_hvg(
        adata,
        n_top_genes=config.get("model", {}).get("num_genes", 2000),
    )

    adata = normalize_spatial_coords(adata, scale=data_cfg.get("spatial_coord_scale", 1.0))
    adata = build_spatial_graph(
        adata,
        n_neighbors=config.get("model", {}).get("mssa", {}).get("local_k", 20),
    )

    n_bins = config.get("model", {}).get("num_bins", 64)
    bin_edges, binned_data = compute_adaptive_bins(adata, n_bins=n_bins)
    adata.layers["binned"] = binned_data
    adata.uns["bin_edges"] = bin_edges

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    adata.write_h5ad(str(output_path))

    logger.info(f"Saved: {output_path} ({adata.n_obs} bins, {adata.n_vars} genes)")
    return adata


if __name__ == "__main__":
    import argparse
    import yaml

    parser = argparse.ArgumentParser(description="Preprocess ST data")
    parser.add_argument("--input_dir", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--config", type=str, default="configs/default.yaml")
    parser.add_argument(
        "--platform",
        type=str,
        choices=["visium", "merfish", "stereoseq"],
        default="visium",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)

    with open(args.config) as f:
        config = yaml.safe_load(f)

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    preprocess_fn = {
        "visium": preprocess_visium,
        "merfish": preprocess_merfish,
        "stereoseq": preprocess_stereoseq,
    }[args.platform]

    h5ad_files = list(input_dir.glob("*.h5ad"))
    logger.info(f"Found {len(h5ad_files)} h5ad files in {input_dir}")

    for h5ad_file in h5ad_files:
        out_path = output_dir / h5ad_file.name
        preprocess_fn(str(h5ad_file), str(out_path), config)
