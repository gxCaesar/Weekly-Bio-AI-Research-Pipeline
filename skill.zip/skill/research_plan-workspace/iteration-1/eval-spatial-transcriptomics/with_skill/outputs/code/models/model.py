"""
SpaFormers: Spatial-Aware Transcriptomic Foundation Model.
Main model architectures for pre-training and fine-tuning.
"""

import logging
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.modules import (
    HierarchicalSpatialPE,
    GeneTokenEmbedding,
    SpaFormersBlock,
    Sinusoidal2DPE,
    StandardAttention,
)

logger = logging.getLogger(__name__)


class SpaFormers(nn.Module):
    """
    Core SpaFormers encoder model.
    Encodes spatial transcriptomics data into contextualized spot representations
    using HSPE and MSSA.
    """

    def __init__(self, config: dict):
        """
        Args:
            config: Model configuration dictionary
        """
        super().__init__()
        self.config = config
        model_cfg = config.get("model", config)

        self.hidden_dim = model_cfg.get("hidden_dim", 768)
        self.num_layers = model_cfg.get("num_layers", 12)
        self.num_heads = model_cfg.get("num_heads", 12)
        self.ffn_dim = model_cfg.get("ffn_dim", 3072)
        self.dropout = model_cfg.get("dropout", 0.1)
        self.num_genes = model_cfg.get("num_genes", 2000)
        self.num_bins = model_cfg.get("num_bins", 64)

        hspe_config = model_cfg.get("hspe", {})
        mssa_config = model_cfg.get("mssa", {})

        use_hspe = hspe_config.get("enabled", True) if isinstance(hspe_config, dict) else True
        use_mssa = mssa_config.get("enabled", True) if isinstance(mssa_config, dict) else True

        # Gene expression embedding
        self.gene_embedding = GeneTokenEmbedding(
            num_genes=self.num_genes,
            num_bins=self.num_bins,
            hidden_dim=self.hidden_dim,
            dropout=self.dropout,
        )

        # Spatial positional encoding
        self.use_hspe = use_hspe
        if use_hspe:
            use_sin2d = hspe_config.get("use_sinusoidal_2d", False)
            if use_sin2d:
                self.spatial_pe = Sinusoidal2DPE(self.hidden_dim)
                self.hspe = None
            else:
                self.hspe = HierarchicalSpatialPE(model_cfg)
                self.spatial_pe = None
        else:
            self.hspe = None
            self.spatial_pe = None

        # Transformer blocks
        self.use_mssa = use_mssa
        local_k = mssa_config.get("local_k", 20) if isinstance(mssa_config, dict) else 20
        num_global = mssa_config.get("num_global_tokens", 256) if isinstance(mssa_config, dict) else 256
        global_every = mssa_config.get("global_every_n_layers", 1) if isinstance(mssa_config, dict) else 1
        self.global_every_n_layers = global_every

        self.layers = nn.ModuleList()
        for i in range(self.num_layers):
            if use_mssa:
                block = SpaFormersBlock(
                    hidden_dim=self.hidden_dim,
                    num_heads=self.num_heads,
                    ffn_dim=self.ffn_dim,
                    dropout=self.dropout,
                    attention_dropout=model_cfg.get("attention_dropout", 0.1),
                    local_k=local_k,
                    num_global_tokens=num_global,
                    use_rope=use_hspe,
                )
            else:
                block = SpaFormersBlock(
                    hidden_dim=self.hidden_dim,
                    num_heads=self.num_heads,
                    ffn_dim=self.ffn_dim,
                    dropout=self.dropout,
                    attention_dropout=model_cfg.get("attention_dropout", 0.1),
                    local_k=local_k,
                    num_global_tokens=num_global,
                    use_rope=False,
                )
            self.layers.append(block)

        # Final layer norm
        self.final_norm = nn.LayerNorm(self.hidden_dim)

        # Initialize weights
        self.apply(self._init_weights)

        # Log model size
        n_params = sum(p.numel() for p in self.parameters())
        logger.info(f"SpaFormers initialized: {n_params / 1e6:.1f}M parameters")

    def _init_weights(self, module: nn.Module) -> None:
        """Initialize weights using truncated normal distribution."""
        if isinstance(module, nn.Linear):
            nn.init.trunc_normal_(module.weight, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.LayerNorm):
            nn.init.ones_(module.weight)
            nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.trunc_normal_(module.weight, std=0.02)

    def forward(
        self,
        expression: torch.Tensor,
        spatial_coords: torch.Tensor,
        neighbor_indices: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Encode spatial transcriptomics data.

        Args:
            expression: Gene expression values (batch, n_spots, n_genes) or (batch, n_genes)
            spatial_coords: Spatial coordinates (batch, n_spots, 2) or (batch, 2)
            neighbor_indices: K-NN indices (batch, n_spots, K) or (batch, K)
            attention_mask: Valid spot mask (batch, n_spots) or None

        Returns:
            Contextualized spot embeddings (batch, n_spots, hidden_dim)
        """
        # Handle 2D inputs (single spot per sample) by adding spot dimension
        squeeze_output = False
        if expression.dim() == 2:
            expression = expression.unsqueeze(1)
            spatial_coords = spatial_coords.unsqueeze(1)
            neighbor_indices = neighbor_indices.unsqueeze(1)
            squeeze_output = True

        # Gene expression embedding
        x = self.gene_embedding(expression)  # (batch, n_spots, hidden_dim)

        # Spatial positional encoding
        rope_params = None
        if self.hspe is not None:
            spatial_embed, rope_params = self.hspe(spatial_coords)
            x = x + spatial_embed
        elif self.spatial_pe is not None:
            spatial_embed = self.spatial_pe(spatial_coords)
            x = x + spatial_embed

        # Transformer layers
        for i, layer in enumerate(self.layers):
            use_global = (i % self.global_every_n_layers == 0) if self.use_mssa else False
            x = layer(
                x,
                neighbor_indices,
                attention_mask=attention_mask,
                rope_params=rope_params,
                use_global=use_global,
            )

        x = self.final_norm(x)

        if squeeze_output:
            x = x.squeeze(1)

        return x


class SpaFormersForPretraining(nn.Module):
    """
    SpaFormers with pre-training heads (SCGP, SCCL, CRC).
    """

    def __init__(self, config: dict):
        super().__init__()
        self.config = config
        model_cfg = config.get("model", config)

        self.encoder = SpaFormers(config)

        hidden_dim = model_cfg.get("hidden_dim", 768)
        num_bins = model_cfg.get("num_bins", 64)
        num_genes = model_cfg.get("num_genes", 2000)

        # SCGP prediction head: predict masked gene expression bins
        self.scgp_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, num_genes * (num_bins + 1)),
        )
        self.num_genes = num_genes
        self.num_bins = num_bins

    def forward(
        self,
        expression: torch.Tensor,
        spatial_coords: torch.Tensor,
        neighbor_indices: torch.Tensor,
        gene_mask: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass for pre-training.

        Args:
            expression: Gene expression (batch, n_spots, n_genes)
            spatial_coords: Spatial coordinates (batch, n_spots, 2)
            neighbor_indices: K-NN indices (batch, n_spots, K)
            gene_mask: Boolean mask for masked genes (batch, n_genes)
            attention_mask: Valid spot mask (batch, n_spots)

        Returns:
            Dictionary with:
                - features: Encoder output (batch, n_spots, hidden_dim)
                - scgp_predictions: Bin predictions (batch, n_spots, n_genes, num_bins+1)
        """
        # Save original expression for targets
        original_expression = expression.clone()

        # Apply gene masking: zero out masked genes in input
        if gene_mask is not None:
            mask_expanded = gene_mask.unsqueeze(1).expand_as(expression)
            expression = expression.masked_fill(mask_expanded, 0)

        # Encode
        features = self.encoder(
            expression, spatial_coords, neighbor_indices, attention_mask
        )

        # SCGP predictions
        scgp_logits = self.scgp_head(features)
        batch_size = features.shape[0]
        n_spots = features.shape[1] if features.dim() == 3 else 1

        if features.dim() == 3:
            scgp_logits = scgp_logits.view(
                batch_size, n_spots, self.num_genes, self.num_bins + 1
            )
        else:
            scgp_logits = scgp_logits.view(
                batch_size, self.num_genes, self.num_bins + 1
            )

        return {
            "features": features,
            "scgp_predictions": scgp_logits,
            "targets": original_expression,
        }


class SpaFormersForFineTuning(nn.Module):
    """
    SpaFormers with task-specific fine-tuning heads.
    Supports: spatial_domain, gene_imputation, cell_annotation, cell_deconvolution.
    """

    def __init__(self, config: dict, task: str = "spatial_domain"):
        """
        Args:
            config: Configuration dictionary
            task: Task name
        """
        super().__init__()
        self.config = config
        self.task = task
        model_cfg = config.get("model", config)

        self.encoder = SpaFormers(config)

        hidden_dim = model_cfg.get("hidden_dim", 768)
        task_cfg = config.get("tasks", {}).get(task, {})
        head_type = task_cfg.get("head_type", "mlp")
        head_hidden = task_cfg.get("head_hidden_dim", 256)

        if task == "spatial_domain":
            num_classes = task_cfg.get("num_classes", 7)
            if head_type == "mlp":
                self.head = nn.Sequential(
                    nn.Linear(hidden_dim, head_hidden),
                    nn.GELU(),
                    nn.Dropout(0.1),
                    nn.Linear(head_hidden, num_classes),
                )
            else:
                self.head = nn.Linear(hidden_dim, num_classes)

        elif task == "cell_annotation":
            num_classes = task_cfg.get("num_classes", 20)
            if head_type == "mlp":
                self.head = nn.Sequential(
                    nn.Linear(hidden_dim, head_hidden),
                    nn.GELU(),
                    nn.Dropout(0.1),
                    nn.Linear(head_hidden, num_classes),
                )
            else:
                self.head = nn.Linear(hidden_dim, num_classes)

        elif task == "gene_imputation":
            num_genes = model_cfg.get("num_genes", 2000)
            self.head = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, num_genes),
            )

        elif task == "cell_deconvolution":
            num_cell_types = task_cfg.get("num_cell_types", 10)
            self.head = nn.Sequential(
                nn.Linear(hidden_dim, head_hidden),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(head_hidden, num_cell_types),
                nn.Softmax(dim=-1),
            )

        else:
            raise ValueError(f"Unknown task: {task}")

        self.loss_fn = self._get_loss_fn(task)

    def _get_loss_fn(self, task: str) -> nn.Module:
        """Get appropriate loss function for the task."""
        if task in ("spatial_domain", "cell_annotation"):
            return nn.CrossEntropyLoss(ignore_index=-1)
        elif task == "gene_imputation":
            return nn.MSELoss()
        elif task == "cell_deconvolution":
            return nn.KLDivLoss(reduction="batchmean")
        else:
            return nn.MSELoss()

    def load_pretrained(self, checkpoint_path: str) -> None:
        """
        Load pre-trained encoder weights.

        Args:
            checkpoint_path: Path to pre-training checkpoint
        """
        checkpoint = torch.load(checkpoint_path, map_location="cpu")

        if "model_state_dict" in checkpoint:
            state_dict = checkpoint["model_state_dict"]
        elif "state_dict" in checkpoint:
            state_dict = checkpoint["state_dict"]
        else:
            state_dict = checkpoint

        # Extract encoder weights (remove 'encoder.' prefix if present)
        encoder_state = {}
        for k, v in state_dict.items():
            if k.startswith("encoder."):
                encoder_state[k[len("encoder."):]] = v
            elif not k.startswith("scgp_head."):
                encoder_state[k] = v

        missing, unexpected = self.encoder.load_state_dict(encoder_state, strict=False)
        if missing:
            logger.warning(f"Missing keys when loading pre-trained: {missing}")
        if unexpected:
            logger.warning(f"Unexpected keys when loading pre-trained: {unexpected}")

        logger.info(f"Loaded pre-trained weights from {checkpoint_path}")

    def forward(
        self,
        expression: torch.Tensor,
        spatial_coords: torch.Tensor,
        neighbor_indices: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        proportions: Optional[torch.Tensor] = None,
        counts: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass for fine-tuning.

        Args:
            expression: Gene expression (batch, n_genes) or (batch, n_spots, n_genes)
            spatial_coords: Spatial coordinates
            neighbor_indices: K-NN indices
            attention_mask: Valid spot mask
            labels: Ground truth labels (for spatial_domain, cell_annotation)
            proportions: Ground truth cell type proportions (for deconvolution)
            counts: Raw counts (for gene_imputation)

        Returns:
            Dictionary with predictions and optional loss
        """
        features = self.encoder(
            expression, spatial_coords, neighbor_indices, attention_mask
        )

        logits = self.head(features)

        output = {"features": features, "logits": logits}

        # Compute loss if targets provided
        if self.task in ("spatial_domain", "cell_annotation") and labels is not None:
            loss = self.loss_fn(logits.view(-1, logits.shape[-1]), labels.view(-1))
            output["loss"] = loss
            output["predictions"] = logits.argmax(dim=-1)

        elif self.task == "gene_imputation" and counts is not None:
            loss = self.loss_fn(logits, counts)
            output["loss"] = loss
            output["predictions"] = logits

        elif self.task == "cell_deconvolution" and proportions is not None:
            log_predictions = torch.log(logits + 1e-8)
            loss = self.loss_fn(log_predictions, proportions)
            output["loss"] = loss
            output["predictions"] = logits

        return output
