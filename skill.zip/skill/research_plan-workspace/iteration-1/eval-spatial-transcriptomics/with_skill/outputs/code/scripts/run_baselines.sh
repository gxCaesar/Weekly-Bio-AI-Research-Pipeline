#!/bin/bash
# Run all baseline methods
set -e

OUTPUT_DIR=${1:-outputs/baselines}
TASK=${2:-spatial_domain}

echo "Running baseline experiments"
echo "  Output: $OUTPUT_DIR"
echo "  Task: $TASK"

mkdir -p "$OUTPUT_DIR"

# Baseline 1: STAGATE
echo ""
echo ">>> Baseline: STAGATE"
python main.py \
    --config configs/baseline_stagate.yaml \
    --mode finetune \
    --task "$TASK" \
    --output_dir "$OUTPUT_DIR/stagate" \
    2>&1 | tee "$OUTPUT_DIR/stagate/train.log"

# Baseline 2: GraphST
echo ""
echo ">>> Baseline: GraphST"
python main.py \
    --config configs/baseline_graphst.yaml \
    --mode finetune \
    --task "$TASK" \
    --output_dir "$OUTPUT_DIR/graphst" \
    2>&1 | tee "$OUTPUT_DIR/graphst/train.log"

# Baseline 3: scGPT (without spatial encoding)
echo ""
echo ">>> Baseline: scGPT (no spatial PE)"
python main.py \
    --config configs/baseline_scgpt.yaml \
    --mode train_eval \
    --task "$TASK" \
    --output_dir "$OUTPUT_DIR/scgpt" \
    2>&1 | tee "$OUTPUT_DIR/scgpt/train.log"

echo ""
echo "All baselines complete. Results in $OUTPUT_DIR"

# Collect results
echo ""
echo "Baseline Results Summary:"
echo "========================="
for baseline in stagate graphst scgpt; do
    result_file="$OUTPUT_DIR/$baseline/training_results.json"
    if [ -f "$result_file" ]; then
        echo "$baseline:"
        cat "$result_file"
        echo ""
    fi
done
