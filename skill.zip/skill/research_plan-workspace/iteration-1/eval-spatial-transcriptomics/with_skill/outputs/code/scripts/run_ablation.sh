#!/bin/bash
# Run all ablation studies
set -e

OUTPUT_DIR=${1:-outputs/ablation}
TASK=${2:-spatial_domain}

echo "Running ablation studies"
echo "  Output: $OUTPUT_DIR"
echo "  Task: $TASK"

mkdir -p "$OUTPUT_DIR"

python ablation/run_ablation.py \
    --output_dir "$OUTPUT_DIR" \
    --task "$TASK" \
    2>&1 | tee "$OUTPUT_DIR/ablation.log"

echo ""
echo "Ablation studies complete. Results in $OUTPUT_DIR"
echo "Combined results: $OUTPUT_DIR/ablation_results.json"
