# SpaFormers: Spatial-Aware Transcriptomic Foundation Model

A foundation model for spatial transcriptomics data analysis that integrates gene expression and spatial location information through hierarchical spatial positional encoding (HSPE) and multi-scale spatial attention (MSSA).

## Project Structure

```
code/
├── configs/           # YAML configuration files
├── data/              # Data loading, preprocessing, and dataset classes
├── models/            # Model architecture (SpaFormers, HSPE, MSSA)
├── baselines/         # Baseline methods (STAGATE, GraphST)
├── training/          # Training loop, optimizer, callbacks
├── evaluation/        # Metrics, evaluation pipeline, visualization
├── scripts/           # Shell scripts for running experiments
├── ablation/          # Ablation study orchestrator
├── main.py            # Main entry point
├── requirements.txt   # Python dependencies
└── README.md          # This file
```

## Quick Start

### 1. Environment Setup

```bash
conda create -n spaformers python=3.10 -y
conda activate spaformers
pip install -r requirements.txt
```

### 2. Download Data

```bash
python data/download.py --dataset dlpfc --output_dir data/raw/
```

### 3. Preprocess

```bash
python data/preprocess.py \
    --input_dir data/raw/dlpfc \
    --output_dir data/processed/dlpfc \
    --config configs/default.yaml \
    --platform visium
```

### 4. Train (Pre-train + Fine-tune + Evaluate)

```bash
python main.py \
    --config configs/default.yaml \
    --mode train_eval \
    --task spatial_domain \
    --output_dir outputs/main
```

### 5. Run Everything

```bash
bash scripts/run_all.sh configs/default.yaml outputs/full_run 1 spatial_domain
```

## Key Components

- **HSPE**: Combines 2D-RoPE with multi-resolution hash encoding for spatial position encoding
- **MSSA**: Local K-NN attention + global sparse attention for multi-scale spatial modeling
- **SAMP**: Three complementary pre-training objectives (SCGP, SCCL, CRC)

## Hardware Requirements

- GPU: NVIDIA A100 80GB (1-2 cards)
- RAM: 64GB+
- Storage: 50GB for data and checkpoints

## Citation

If you use this code, please cite our paper (forthcoming).
