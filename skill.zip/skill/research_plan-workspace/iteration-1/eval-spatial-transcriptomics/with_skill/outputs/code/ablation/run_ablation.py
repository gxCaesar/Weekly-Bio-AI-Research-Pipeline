"""
Ablation study orchestrator for SpaFormers.
Runs all ablation experiments and collects results.
"""

import argparse
import json
import logging
import subprocess
import sys
from pathlib import Path
from typing import Dict, List

import yaml

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Ablation experiment definitions
ABLATION_EXPERIMENTS = {
    "full_model": {
        "config": "configs/default.yaml",
        "description": "Full SpaFormers (all components)",
    },
    "no_hspe_sinusoidal": {
        "config": "configs/ablation_no_hspe.yaml",
        "description": "A1: Replace HSPE with 2D sinusoidal PE",
    },
    "no_hspe_none": {
        "config": "configs/default.yaml",
        "override": {"model": {"hspe": {"enabled": False}}},
        "description": "A2: No spatial positional encoding",
    },
    "no_mssa_full_attn": {
        "config": "configs/ablation_no_mssa.yaml",
        "description": "A3: Replace MSSA with standard full attention",
    },
    "no_global_attn": {
        "config": "configs/default.yaml",
        "override": {"model": {"mssa": {"num_global_tokens": 0}}},
        "description": "A4: Only local attention (no global)",
    },
    "only_scgp": {
        "config": "configs/ablation_no_sccl.yaml",
        "description": "A5: Only SCGP pre-training (no SCCL, no CRC)",
    },
    "standard_mlm": {
        "config": "configs/default.yaml",
        "override": {
            "pretraining": {
                "scgp_weight": 1.0,
                "sccl_weight": 0.0,
                "crc_weight": 0.0,
            },
            "model": {"hspe": {"enabled": False}},
        },
        "description": "A6: Standard masked prediction (no spatial awareness)",
    },
    "no_pretrain": {
        "config": "configs/default.yaml",
        "override": {"pretraining": {"enabled": False}},
        "description": "A7: Train from scratch (no pre-training)",
    },
    "no_adaptive_binning": {
        "config": "configs/default.yaml",
        "override": {"model": {"num_bins": 0}},
        "description": "A8: Simple linear embedding (no adaptive binning)",
    },
}


def run_single_ablation(
    experiment_name: str,
    experiment_config: dict,
    base_output_dir: str,
    task: str = "spatial_domain",
    pretrain_checkpoint: str = None,
) -> Dict[str, float]:
    """
    Run a single ablation experiment.

    Args:
        experiment_name: Name of the experiment
        experiment_config: Experiment configuration
        base_output_dir: Base output directory
        task: Downstream task
        pretrain_checkpoint: Optional pre-trained checkpoint path

    Returns:
        Dictionary of metrics
    """
    logger.info(f"\n{'='*60}")
    logger.info(f"Ablation: {experiment_name}")
    logger.info(f"Description: {experiment_config['description']}")
    logger.info(f"{'='*60}")

    output_dir = Path(base_output_dir) / experiment_name
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load and potentially override config
    config_path = experiment_config["config"]
    with open(config_path) as f:
        config = yaml.safe_load(f)

    if "override" in experiment_config:
        config = _deep_merge(config, experiment_config["override"])

    # Save experiment config
    exp_config_path = output_dir / "config.yaml"
    with open(exp_config_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False)

    # Run experiment via subprocess
    cmd = [
        sys.executable, "main.py",
        "--config", str(exp_config_path),
        "--mode", "train_eval" if config.get("pretraining", {}).get("enabled", True) else "finetune",
        "--task", task,
        "--output_dir", str(output_dir),
    ]

    if pretrain_checkpoint and not config.get("pretraining", {}).get("enabled", True):
        cmd.extend(["--checkpoint", pretrain_checkpoint])

    logger.info(f"Running: {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=3600 * 24,  # 24h timeout
        )

        if result.returncode != 0:
            logger.error(f"Experiment {experiment_name} failed:")
            logger.error(result.stderr)
            return {"error": 1.0}

    except subprocess.TimeoutExpired:
        logger.error(f"Experiment {experiment_name} timed out")
        return {"error": 1.0}

    # Load results
    results_file = output_dir / f"eval_{task}" / f"eval_results_{task}.json"
    if results_file.exists():
        with open(results_file) as f:
            results = json.load(f)
        return results.get("metrics", {})
    else:
        # Try training results
        results_file = output_dir / "training_results.json"
        if results_file.exists():
            with open(results_file) as f:
                return json.load(f)

    logger.warning(f"No results found for {experiment_name}")
    return {}


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def run_all_ablations(
    output_dir: str,
    task: str = "spatial_domain",
    experiments: List[str] = None,
) -> Dict[str, Dict[str, float]]:
    """
    Run all ablation experiments and collect results.

    Args:
        output_dir: Base output directory
        task: Downstream task
        experiments: Optional list of specific experiments to run

    Returns:
        Dictionary of experiment_name -> metrics
    """
    if experiments is None:
        experiments = list(ABLATION_EXPERIMENTS.keys())

    all_results = {}
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    for exp_name in experiments:
        if exp_name not in ABLATION_EXPERIMENTS:
            logger.warning(f"Unknown experiment: {exp_name}, skipping")
            continue

        exp_config = ABLATION_EXPERIMENTS[exp_name]
        results = run_single_ablation(
            experiment_name=exp_name,
            experiment_config=exp_config,
            base_output_dir=str(output_dir),
            task=task,
        )
        all_results[exp_name] = results

    # Save combined results
    combined_path = output_dir / "ablation_results.json"
    with open(combined_path, "w") as f:
        json.dump(all_results, f, indent=2)

    # Print results table
    logger.info("\n" + "=" * 80)
    logger.info("ABLATION STUDY RESULTS")
    logger.info("=" * 80)
    logger.info(f"{'Experiment':<30} {'ARI':>8} {'NMI':>8} {'ACC':>8} {'F1':>8}")
    logger.info("-" * 80)
    for exp_name, metrics in all_results.items():
        ari = metrics.get("ari", 0)
        nmi = metrics.get("nmi", 0)
        acc = metrics.get("accuracy", 0)
        f1 = metrics.get("f1_macro", 0)
        logger.info(f"{exp_name:<30} {ari:8.4f} {nmi:8.4f} {acc:8.4f} {f1:8.4f}")

    # Generate visualization
    try:
        from evaluation.visualize import plot_ablation_results

        plot_ablation_results(
            all_results,
            str(output_dir / "ablation_chart.png"),
            metric_name="ari",
        )
    except Exception as e:
        logger.warning(f"Could not generate ablation chart: {e}")

    return all_results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run SpaFormers ablation studies")
    parser.add_argument("--output_dir", type=str, default="./outputs/ablation")
    parser.add_argument("--task", type=str, default="spatial_domain")
    parser.add_argument("--experiments", nargs="+", default=None,
                        help="Specific experiments to run (default: all)")
    args = parser.parse_args()

    run_all_ablations(args.output_dir, args.task, args.experiments)
