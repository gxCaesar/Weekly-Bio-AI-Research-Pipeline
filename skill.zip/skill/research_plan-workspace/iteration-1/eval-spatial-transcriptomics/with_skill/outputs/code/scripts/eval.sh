#!/bin/bash
# Evaluate a trained SpaFormers model
set -e

CHECKPOINT=${1:-outputs/default/best_model.pt}
CONFIG=${2:-configs/default.yaml}
TASK=${3:-spatial_domain}
OUTPUT_DIR=${4:-outputs/eval}

echo "Evaluating SpaFormers"
echo "  Checkpoint: $CHECKPOINT"
echo "  Config: $CONFIG"
echo "  Task: $TASK"
echo "  Output: $OUTPUT_DIR"

mkdir -p "$OUTPUT_DIR"

python main.py \
    --config "$CONFIG" \
    --mode eval \
    --task "$TASK" \
    --checkpoint "$CHECKPOINT" \
    --output_dir "$OUTPUT_DIR" \
    2>&1 | tee "$OUTPUT_DIR/eval.log"

echo ""
echo "Evaluation complete. Results saved to $OUTPUT_DIR"

# Print results if available
if [ -f "$OUTPUT_DIR/eval_results_${TASK}.json" ]; then
    echo ""
    echo "Results:"
    cat "$OUTPUT_DIR/eval_results_${TASK}.json"
fi
