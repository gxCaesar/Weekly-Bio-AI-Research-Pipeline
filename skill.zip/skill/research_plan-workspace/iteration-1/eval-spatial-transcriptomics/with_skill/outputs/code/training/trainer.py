"""
Training loop for SpaFormers with mixed-precision, gradient accumulation,
multi-GPU support, and comprehensive logging.
"""

import json
import logging
import time
from pathlib import Path
from typing import Dict, Optional

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.cuda.amp import GradScaler, autocast
from tqdm import tqdm

from training.optimizer import build_optimizer, build_scheduler
from training.callbacks import CheckpointCallback, EarlyStoppingCallback, WandbCallback
from evaluation.metrics import compute_metrics

logger = logging.getLogger(__name__)


class Trainer:
    """
    Unified trainer for SpaFormers pre-training and fine-tuning.
    Supports AMP, gradient accumulation, DDP, and comprehensive callbacks.
    """

    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader],
        config: dict,
        device: torch.device,
        mode: str = "pretrain",
        output_dir: str = "./outputs",
        loss_fn: Optional[nn.Module] = None,
    ):
        """
        Args:
            model: Model to train
            train_loader: Training data loader
            val_loader: Validation data loader (optional)
            config: Full configuration dictionary
            device: Training device
            mode: 'pretrain' or 'finetune'
            output_dir: Output directory for checkpoints and logs
            loss_fn: Optional external loss function (for pre-training)
        """
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.config = config
        self.device = device
        self.mode = mode
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.loss_fn = loss_fn

        # Get training config
        if mode == "pretrain":
            self.train_cfg = config.get("pretraining", {})
        else:
            self.train_cfg = config.get("finetuning", {})

        self.epochs = self.train_cfg.get("epochs", 50)
        self.batch_size = self.train_cfg.get("batch_size", 32)
        self.grad_accum_steps = self.train_cfg.get("gradient_accumulation_steps", 1)
        self.max_grad_norm = self.train_cfg.get("max_grad_norm", 1.0)

        # Mixed precision
        use_fp16 = self.train_cfg.get("fp16", False)
        use_bf16 = self.train_cfg.get("bf16", True)
        self.use_amp = use_fp16 or use_bf16
        self.amp_dtype = torch.bfloat16 if use_bf16 else torch.float16
        self.scaler = GradScaler(enabled=use_fp16)  # GradScaler not needed for bf16

        # Gradient checkpointing
        if self.train_cfg.get("gradient_checkpointing", False):
            if hasattr(self.model, "encoder") and hasattr(
                self.model.encoder, "gradient_checkpointing_enable"
            ):
                self.model.encoder.gradient_checkpointing_enable()

        # Optimizer and scheduler
        num_steps = len(train_loader) * self.epochs // self.grad_accum_steps
        self.optimizer = build_optimizer(model, config, mode)
        self.scheduler = build_scheduler(self.optimizer, config, mode, num_steps)

        # Callbacks
        log_cfg = config.get("logging", {})
        eval_cfg = config.get("evaluation", {})

        self.log_every = log_cfg.get("log_every", 100)
        self.eval_every = eval_cfg.get("eval_every", 5)

        self.checkpoint_cb = CheckpointCallback(
            output_dir=str(self.output_dir),
            save_every=log_cfg.get("save_every", 10),
            save_best=log_cfg.get("save_best", True),
            save_total_limit=log_cfg.get("save_total_limit", 5),
        )

        self.early_stop_cb = EarlyStoppingCallback(patience=15)

        self.wandb_cb = WandbCallback(
            project=log_cfg.get("wandb_project", "spaformers"),
            entity=log_cfg.get("wandb_entity"),
            config=config,
            name=f"{mode}_{config.get('model', {}).get('name', 'spaformers')}",
        )

        # Training state
        self.global_step = 0
        self.best_metric = 0.0

    def train(self) -> Dict[str, float]:
        """
        Run the full training loop.

        Returns:
            Dictionary of final metrics
        """
        logger.info(f"Starting {self.mode} training for {self.epochs} epochs")
        logger.info(f"  Batch size: {self.batch_size}")
        logger.info(f"  Gradient accumulation: {self.grad_accum_steps}")
        logger.info(f"  Effective batch size: {self.batch_size * self.grad_accum_steps}")
        logger.info(f"  AMP: {self.use_amp} ({self.amp_dtype})")
        logger.info(f"  Device: {self.device}")

        final_metrics = {}

        for epoch in range(1, self.epochs + 1):
            # Train one epoch
            train_metrics = self._train_epoch(epoch)

            # Log training metrics
            self.wandb_cb.log(
                {f"train/{k}": v for k, v in train_metrics.items()},
                step=self.global_step,
            )

            # Evaluate
            eval_metrics = {}
            if self.val_loader is not None and epoch % self.eval_every == 0:
                eval_metrics = self._evaluate(epoch)
                self.wandb_cb.log(
                    {f"val/{k}": v for k, v in eval_metrics.items()},
                    step=self.global_step,
                )

            # Checkpoint
            all_metrics = {**train_metrics, **eval_metrics}
            self.checkpoint_cb.save_checkpoint(
                model=self.model,
                optimizer=self.optimizer,
                scheduler=self.scheduler,
                epoch=epoch,
                step=self.global_step,
                metrics=all_metrics,
                config=self.config,
            )

            # Early stopping
            if eval_metrics and self.early_stop_cb.check(eval_metrics):
                logger.info(f"Early stopping at epoch {epoch}")
                break

            final_metrics = all_metrics

        # Save final results
        results_path = self.output_dir / "training_results.json"
        with open(results_path, "w") as f:
            json.dump(final_metrics, f, indent=2)

        self.wandb_cb.finish()
        logger.info(f"Training complete. Results saved to {results_path}")

        return final_metrics

    def _train_epoch(self, epoch: int) -> Dict[str, float]:
        """Train for one epoch."""
        self.model.train()
        total_loss = 0.0
        loss_components = {}
        n_batches = 0
        start_time = time.time()

        self.optimizer.zero_grad()

        progress_bar = tqdm(
            self.train_loader,
            desc=f"Epoch {epoch}/{self.epochs}",
            leave=False,
        )

        for step, batch in enumerate(progress_bar):
            # Move batch to device
            batch = {
                k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                for k, v in batch.items()
            }

            # Forward pass with AMP
            with autocast(device_type="cuda", dtype=self.amp_dtype, enabled=self.use_amp):
                if self.mode == "pretrain" and self.loss_fn is not None:
                    # Pre-training forward
                    outputs = self.model(
                        expression=batch["expression"],
                        spatial_coords=batch["spatial_coords"],
                        neighbor_indices=batch["neighbor_indices"],
                        gene_mask=batch.get("gene_mask"),
                        attention_mask=batch.get("attention_mask"),
                    )
                    loss, loss_dict = self.loss_fn(
                        predictions=outputs["scgp_predictions"],
                        targets=outputs["targets"],
                        mask=batch.get("gene_mask", torch.ones(1, device=self.device).bool()),
                        features=outputs["features"],
                        spatial_coords=batch["spatial_coords"],
                        neighbor_indices=batch["neighbor_indices"],
                        attention_mask=batch.get("attention_mask"),
                    )
                    for k, v in loss_dict.items():
                        loss_components[k] = loss_components.get(k, 0) + v
                else:
                    # Fine-tuning forward
                    outputs = self.model(**batch)
                    loss = outputs["loss"]

                loss = loss / self.grad_accum_steps

            # Backward pass
            if self.train_cfg.get("fp16", False):
                self.scaler.scale(loss).backward()
            else:
                loss.backward()

            total_loss += loss.item() * self.grad_accum_steps
            n_batches += 1

            # Optimizer step
            if (step + 1) % self.grad_accum_steps == 0:
                if self.train_cfg.get("fp16", False):
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(), self.max_grad_norm
                    )
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                else:
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(), self.max_grad_norm
                    )
                    self.optimizer.step()

                self.scheduler.step()
                self.optimizer.zero_grad()
                self.global_step += 1

                # Log
                if self.global_step % self.log_every == 0:
                    avg_loss = total_loss / n_batches
                    lr = self.optimizer.param_groups[0]["lr"]
                    progress_bar.set_postfix(
                        loss=f"{avg_loss:.4f}", lr=f"{lr:.2e}"
                    )

        elapsed = time.time() - start_time
        avg_loss = total_loss / max(n_batches, 1)

        metrics = {"loss": avg_loss, "epoch_time": elapsed}
        for k, v in loss_components.items():
            metrics[f"loss_{k}"] = v / max(n_batches, 1)

        logger.info(
            f"Epoch {epoch}: loss={avg_loss:.4f}, "
            f"lr={self.optimizer.param_groups[0]['lr']:.2e}, "
            f"time={elapsed:.1f}s"
        )

        return metrics

    @torch.no_grad()
    def _evaluate(self, epoch: int) -> Dict[str, float]:
        """Evaluate on validation set."""
        self.model.eval()
        all_predictions = []
        all_labels = []
        total_loss = 0.0
        n_batches = 0

        for batch in tqdm(self.val_loader, desc="Evaluating", leave=False):
            batch = {
                k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                for k, v in batch.items()
            }

            with autocast(device_type="cuda", dtype=self.amp_dtype, enabled=self.use_amp):
                outputs = self.model(**batch)

            if "loss" in outputs:
                total_loss += outputs["loss"].item()

            if "predictions" in outputs:
                all_predictions.append(outputs["predictions"].cpu())
            if "labels" in batch:
                all_labels.append(batch["labels"].cpu())

            n_batches += 1

        metrics = {"loss": total_loss / max(n_batches, 1)}

        if all_predictions and all_labels:
            predictions = torch.cat(all_predictions)
            labels = torch.cat(all_labels)

            eval_metrics = compute_metrics(
                predictions.numpy(),
                labels.numpy(),
                task=self.mode if self.mode != "pretrain" else "spatial_domain",
            )
            metrics.update(eval_metrics)

        logger.info(f"Eval epoch {epoch}: {metrics}")

        return metrics

    def resume_from_checkpoint(self, checkpoint_path: str) -> int:
        """
        Resume training from a checkpoint.

        Args:
            checkpoint_path: Path to checkpoint file

        Returns:
            Epoch to resume from
        """
        checkpoint = torch.load(checkpoint_path, map_location=self.device)

        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])

        epoch = checkpoint.get("epoch", 0)
        self.global_step = checkpoint.get("step", 0)

        logger.info(f"Resumed from checkpoint: epoch {epoch}, step {self.global_step}")

        return epoch
