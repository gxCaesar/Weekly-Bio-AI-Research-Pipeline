#!/bin/bash
# Train SpaFormers model
set -e

CONFIG=${1:-configs/default.yaml}
OUTPUT_DIR=${2:-outputs/default}
NUM_GPUS=${3:-1}
MODE=${4:-train_eval}

echo "Training SpaFormers"
echo "  Config: $CONFIG"
echo "  Output: $OUTPUT_DIR"
echo "  GPUs: $NUM_GPUS"
echo "  Mode: $MODE"

mkdir -p "$OUTPUT_DIR"

if [ "$NUM_GPUS" -gt 1 ]; then
    echo "Using DistributedDataParallel with $NUM_GPUS GPUs"
    torchrun --nproc_per_node="$NUM_GPUS" main.py \
        --config "$CONFIG" \
        --mode "$MODE" \
        --output_dir "$OUTPUT_DIR" \
        2>&1 | tee "$OUTPUT_DIR/train.log"
else
    python main.py \
        --config "$CONFIG" \
        --mode "$MODE" \
        --output_dir "$OUTPUT_DIR" \
        2>&1 | tee "$OUTPUT_DIR/train.log"
fi

echo "Training complete. Logs saved to $OUTPUT_DIR/train.log"
