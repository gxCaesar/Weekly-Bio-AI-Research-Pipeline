"""
Optimizer and learning rate scheduler factory for SpaFormers.
"""

import math
from typing import Optional

import torch
import torch.nn as nn
from torch.optim import AdamW, Adam, SGD
from torch.optim.lr_scheduler import (
    CosineAnnealingLR,
    CosineAnnealingWarmRestarts,
    LinearLR,
    SequentialLR,
    LambdaLR,
)


def build_optimizer(
    model: nn.Module,
    config: dict,
    mode: str = "pretrain",
) -> torch.optim.Optimizer:
    """
    Build optimizer with weight decay separation.

    Args:
        model: Model to optimize
        config: Training configuration
        mode: 'pretrain' or 'finetune'

    Returns:
        Configured optimizer
    """
    if mode == "pretrain":
        train_cfg = config.get("pretraining", {})
    else:
        train_cfg = config.get("finetuning", {})

    lr = train_cfg.get("learning_rate", 1e-4)
    weight_decay = train_cfg.get("weight_decay", 0.05)

    # Separate parameters into weight_decay and no_weight_decay groups
    decay_params = []
    no_decay_params = []

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue

        if any(nd in name for nd in ("bias", "LayerNorm", "layernorm", "norm", "bn")):
            no_decay_params.append(param)
        elif any(nd in name for nd in ("embedding",)):
            no_decay_params.append(param)
        else:
            decay_params.append(param)

    param_groups = [
        {"params": decay_params, "weight_decay": weight_decay},
        {"params": no_decay_params, "weight_decay": 0.0},
    ]

    optimizer = AdamW(
        param_groups,
        lr=lr,
        betas=(0.9, 0.98 if mode == "pretrain" else 0.999),
        eps=1e-8,
    )

    return optimizer


def build_scheduler(
    optimizer: torch.optim.Optimizer,
    config: dict,
    mode: str = "pretrain",
    num_training_steps: Optional[int] = None,
) -> torch.optim.lr_scheduler._LRScheduler:
    """
    Build learning rate scheduler with warmup.

    Args:
        optimizer: Configured optimizer
        config: Training configuration
        mode: 'pretrain' or 'finetune'
        num_training_steps: Total number of training steps

    Returns:
        Learning rate scheduler
    """
    if mode == "pretrain":
        train_cfg = config.get("pretraining", {})
    else:
        train_cfg = config.get("finetuning", {})

    warmup_ratio = train_cfg.get("warmup_ratio", 0.05)
    min_lr = train_cfg.get("min_learning_rate", 1e-6)
    lr = train_cfg.get("learning_rate", 1e-4)

    if num_training_steps is None:
        epochs = train_cfg.get("epochs", 50)
        batch_size = train_cfg.get("batch_size", 32)
        num_training_steps = epochs * 1000  # Rough estimate

    warmup_steps = int(num_training_steps * warmup_ratio)
    decay_steps = num_training_steps - warmup_steps

    # Warmup scheduler
    warmup_scheduler = LinearLR(
        optimizer,
        start_factor=0.01,
        end_factor=1.0,
        total_iters=warmup_steps,
    )

    # Cosine decay scheduler
    def cosine_with_min_lr(current_step: int) -> float:
        if current_step >= decay_steps:
            return min_lr / lr
        progress = current_step / decay_steps
        return max(min_lr / lr, 0.5 * (1.0 + math.cos(math.pi * progress)))

    decay_scheduler = LambdaLR(optimizer, lr_lambda=cosine_with_min_lr)

    # Combine warmup and decay
    scheduler = SequentialLR(
        optimizer,
        schedulers=[warmup_scheduler, decay_scheduler],
        milestones=[warmup_steps],
    )

    return scheduler
