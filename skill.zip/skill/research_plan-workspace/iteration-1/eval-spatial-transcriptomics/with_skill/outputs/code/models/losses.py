"""
Loss functions for SpaFormers pre-training and fine-tuning.
"""

from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class SCGPLoss(nn.Module):
    """
    Spatial-Conditioned Gene Prediction (SCGP) Loss.
    Cross-entropy loss for predicting masked gene expression bins,
    conditioned on spatial neighborhood context.
    """

    def __init__(self, num_bins: int = 64, label_smoothing: float = 0.1):
        """
        Args:
            num_bins: Number of expression bins
            label_smoothing: Label smoothing factor
        """
        super().__init__()
        self.num_bins = num_bins
        self.criterion = nn.CrossEntropyLoss(
            label_smoothing=label_smoothing, ignore_index=-1
        )

    def forward(
        self,
        predictions: torch.Tensor,
        targets: torch.Tensor,
        mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute SCGP loss on masked positions.

        Args:
            predictions: Predicted bin logits (batch, n_spots, n_genes, num_bins)
                         or (batch, n_genes, num_bins) for spot-level
            targets: Ground truth bin indices (batch, n_spots, n_genes) or (batch, n_genes)
            mask: Boolean mask indicating which genes were masked (batch, n_genes)

        Returns:
            Scalar loss
        """
        if predictions.dim() == 4:
            # (batch, n_spots, n_genes, num_bins)
            batch_size, n_spots, n_genes, num_bins = predictions.shape

            # Expand mask for n_spots dimension
            mask_expanded = mask.unsqueeze(1).expand(-1, n_spots, -1)

            # Select masked positions
            pred_masked = predictions[mask_expanded].view(-1, num_bins)
            target_masked = targets[mask_expanded].view(-1).long()
        else:
            # (batch, n_genes, num_bins)
            pred_masked = predictions[mask].view(-1, self.num_bins + 1)
            target_masked = targets[mask].view(-1).long()

        # Ignore invalid targets
        valid = target_masked >= 0
        if valid.sum() == 0:
            return torch.tensor(0.0, device=predictions.device, requires_grad=True)

        pred_masked = pred_masked[valid]
        target_masked = target_masked[valid]

        loss = self.criterion(pred_masked, target_masked)
        return loss


class SCCLLoss(nn.Module):
    """
    Spatial Context Contrastive Learning (SCCL) Loss.
    InfoNCE loss that encourages spatially close spots to have similar
    representations and spatially distant spots to have different representations.
    """

    def __init__(self, temperature: float = 0.07, hidden_dim: int = 768):
        """
        Args:
            temperature: Temperature for InfoNCE
            hidden_dim: Input feature dimension
        """
        super().__init__()
        self.temperature = temperature

        # Projection head for contrastive learning
        self.projector = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 128),
        )

    def forward(
        self,
        features: torch.Tensor,
        spatial_coords: torch.Tensor,
        neighbor_indices: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Compute SCCL loss.

        Args:
            features: Spot representations (batch, n_spots, hidden_dim)
            spatial_coords: Spatial coordinates (batch, n_spots, 2)
            neighbor_indices: K-NN indices (batch, n_spots, K)
            attention_mask: Valid spot mask (batch, n_spots)

        Returns:
            Scalar loss
        """
        batch_size, n_spots, _ = features.shape

        # Project to contrastive space
        z = self.projector(features)  # (batch, n_spots, 128)
        z = F.normalize(z, dim=-1)

        total_loss = torch.tensor(0.0, device=features.device, requires_grad=True)
        count = 0

        for b in range(batch_size):
            if attention_mask is not None:
                valid_mask = attention_mask[b]  # (n_spots,)
                n_valid = valid_mask.sum().item()
                if n_valid < 4:
                    continue
            else:
                n_valid = n_spots

            z_b = z[b, :n_valid]  # (n_valid, 128)
            nb_b = neighbor_indices[b, :n_valid]  # (n_valid, K)

            # Similarity matrix
            sim_matrix = torch.matmul(z_b, z_b.t()) / self.temperature

            # For each spot, its spatial neighbors are positive pairs
            # Create positive mask from neighbor indices
            pos_mask = torch.zeros(n_valid, n_valid, device=features.device, dtype=torch.bool)
            for i in range(n_valid):
                for j_idx in range(nb_b.shape[1]):
                    j = nb_b[i, j_idx].item()
                    if 0 <= j < n_valid:
                        pos_mask[i, j] = True
                        pos_mask[j, i] = True

            # Remove self-loops
            pos_mask.fill_diagonal_(False)

            # InfoNCE: for each spot, log-softmax over all spots, then select positives
            n_pos = pos_mask.sum(dim=1).float().clamp(min=1)

            # Mask out self
            self_mask = ~torch.eye(n_valid, device=features.device, dtype=torch.bool)
            sim_matrix = sim_matrix.masked_fill(~self_mask, float("-inf"))

            log_prob = F.log_softmax(sim_matrix, dim=-1)

            # Mean log probability over positive pairs
            pos_log_prob = (log_prob * pos_mask.float()).sum(dim=-1) / n_pos
            batch_loss = -pos_log_prob.mean()

            total_loss = total_loss + batch_loss
            count += 1

        if count > 0:
            total_loss = total_loss / count

        return total_loss


class CRCLoss(nn.Module):
    """
    Cross-Resolution Consistency (CRC) Loss.
    Ensures representations are consistent across different spatial resolutions
    by comparing pooled representations at different scales.
    """

    def __init__(self, pool_sizes: list = None, hidden_dim: int = 768):
        """
        Args:
            pool_sizes: List of spatial pooling sizes (e.g., [4, 16])
            hidden_dim: Feature dimension
        """
        super().__init__()
        self.pool_sizes = pool_sizes or [4, 16]
        self.hidden_dim = hidden_dim

        # Projection to align fine and coarse representations
        self.fine_proj = nn.Linear(hidden_dim, hidden_dim)
        self.coarse_proj = nn.Linear(hidden_dim, hidden_dim)

    def _spatial_pool(
        self,
        features: torch.Tensor,
        spatial_coords: torch.Tensor,
        pool_size: int,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Pool features by spatial proximity.

        Args:
            features: (batch, n_spots, hidden_dim)
            spatial_coords: (batch, n_spots, 2)
            pool_size: Number of spots to pool together
            attention_mask: (batch, n_spots)

        Returns:
            Pooled features (batch, n_groups, hidden_dim)
        """
        batch_size, n_spots, hidden_dim = features.shape
        n_groups = max(1, n_spots // pool_size)

        pooled = torch.zeros(
            batch_size, n_groups, hidden_dim, device=features.device
        )

        for b in range(batch_size):
            if attention_mask is not None:
                valid = attention_mask[b]
                n_valid = valid.sum().item()
            else:
                n_valid = n_spots

            if n_valid < pool_size:
                pooled[b, 0] = features[b, :n_valid].mean(dim=0)
                continue

            # Assign spots to groups based on spatial clustering
            coords_b = spatial_coords[b, :n_valid]
            from sklearn.cluster import MiniBatchKMeans

            coords_np = coords_b.detach().cpu().numpy()
            n_clusters = min(n_groups, n_valid)
            kmeans = MiniBatchKMeans(
                n_clusters=n_clusters, random_state=42, batch_size=256
            )
            labels = kmeans.fit_predict(coords_np)
            labels = torch.from_numpy(labels).to(features.device)

            for g in range(n_clusters):
                group_mask = labels == g
                if group_mask.sum() > 0:
                    pooled[b, g] = features[b, :n_valid][group_mask].mean(dim=0)

        return pooled

    def forward(
        self,
        features: torch.Tensor,
        spatial_coords: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Compute CRC loss.

        Args:
            features: Spot representations (batch, n_spots, hidden_dim)
            spatial_coords: (batch, n_spots, 2)
            attention_mask: (batch, n_spots)

        Returns:
            Scalar loss
        """
        total_loss = torch.tensor(0.0, device=features.device, requires_grad=True)

        # Fine-grained features (original resolution)
        fine_features = self.fine_proj(features)

        for pool_size in self.pool_sizes:
            # Coarse features (pooled)
            coarse_features = self._spatial_pool(
                features, spatial_coords, pool_size, attention_mask
            )
            coarse_features = self.coarse_proj(coarse_features)

            # Pool fine features at the same resolution for comparison
            fine_pooled = self._spatial_pool(
                fine_features, spatial_coords, pool_size, attention_mask
            )

            # Normalize
            fine_pooled = F.normalize(fine_pooled, dim=-1)
            coarse_features = F.normalize(coarse_features, dim=-1)

            # MSE loss between fine-pooled and coarse representations
            n_groups = min(fine_pooled.shape[1], coarse_features.shape[1])
            loss = F.mse_loss(fine_pooled[:, :n_groups], coarse_features[:, :n_groups])
            total_loss = total_loss + loss

        total_loss = total_loss / len(self.pool_sizes)
        return total_loss


class PretrainLoss(nn.Module):
    """
    Combined pre-training loss for SpaFormers.
    L = L_SCGP + lambda1 * L_SCCL + lambda2 * L_CRC
    """

    def __init__(self, config: dict):
        """
        Args:
            config: Pre-training configuration
        """
        super().__init__()

        model_cfg = config.get("model", {})
        pretrain_cfg = config.get("pretraining", {})

        self.scgp_weight = pretrain_cfg.get("scgp_weight", 1.0)
        self.sccl_weight = pretrain_cfg.get("sccl_weight", 0.5)
        self.crc_weight = pretrain_cfg.get("crc_weight", 0.3)

        hidden_dim = model_cfg.get("hidden_dim", 768)
        num_bins = model_cfg.get("num_bins", 64)

        self.scgp_loss = SCGPLoss(num_bins=num_bins)
        self.sccl_loss = SCCLLoss(
            temperature=pretrain_cfg.get("sccl_temperature", 0.07),
            hidden_dim=hidden_dim,
        )
        self.crc_loss = CRCLoss(
            pool_sizes=pretrain_cfg.get("crc_pool_sizes", [4, 16]),
            hidden_dim=hidden_dim,
        )

    def forward(
        self,
        predictions: torch.Tensor,
        targets: torch.Tensor,
        mask: torch.Tensor,
        features: torch.Tensor,
        spatial_coords: torch.Tensor,
        neighbor_indices: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, dict]:
        """
        Compute combined pre-training loss.

        Args:
            predictions: SCGP predictions
            targets: SCGP targets (binned expression)
            mask: Gene mask for SCGP
            features: Encoder output features
            spatial_coords: Spatial coordinates
            neighbor_indices: K-NN indices
            attention_mask: Valid spot mask

        Returns:
            total_loss: Combined scalar loss
            loss_dict: Dictionary of individual losses for logging
        """
        loss_dict = {}

        # SCGP loss
        l_scgp = self.scgp_loss(predictions, targets, mask)
        loss_dict["scgp"] = l_scgp.item()

        total = self.scgp_weight * l_scgp

        # SCCL loss
        if self.sccl_weight > 0:
            l_sccl = self.sccl_loss(
                features, spatial_coords, neighbor_indices, attention_mask
            )
            loss_dict["sccl"] = l_sccl.item()
            total = total + self.sccl_weight * l_sccl

        # CRC loss
        if self.crc_weight > 0:
            l_crc = self.crc_loss(features, spatial_coords, attention_mask)
            loss_dict["crc"] = l_crc.item()
            total = total + self.crc_weight * l_crc

        loss_dict["total"] = total.item()

        return total, loss_dict
