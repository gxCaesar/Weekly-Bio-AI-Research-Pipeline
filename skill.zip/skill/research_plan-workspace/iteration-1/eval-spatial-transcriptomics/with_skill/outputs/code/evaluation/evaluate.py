"""
Full evaluation pipeline for SpaFormers.
"""

import json
import logging
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast
from tqdm import tqdm

from evaluation.metrics import compute_metrics

logger = logging.getLogger(__name__)


class Evaluator:
    """Run evaluation on a trained model across tasks and datasets."""

    def __init__(
        self,
        model: nn.Module,
        device: torch.device,
        config: dict,
    ):
        """
        Args:
            model: Trained model
            device: Device for evaluation
            config: Configuration
        """
        self.model = model.to(device)
        self.device = device
        self.config = config
        self.use_amp = config.get("finetuning", {}).get("bf16", True)
        self.amp_dtype = torch.bfloat16

    @torch.no_grad()
    def evaluate(
        self,
        data_loader: DataLoader,
        task: str = "spatial_domain",
        output_dir: Optional[str] = None,
    ) -> Dict[str, float]:
        """
        Evaluate model on a dataset.

        Args:
            data_loader: Evaluation data loader
            task: Task name
            output_dir: Optional directory to save results

        Returns:
            Dictionary of metrics
        """
        self.model.eval()

        all_predictions = []
        all_labels = []
        all_features = []
        all_coords = []
        all_continuous_targets = []

        for batch in tqdm(data_loader, desc=f"Evaluating ({task})", leave=False):
            batch = {
                k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                for k, v in batch.items()
            }

            with autocast(device_type="cuda", dtype=self.amp_dtype, enabled=self.use_amp):
                outputs = self.model(**batch)

            if "predictions" in outputs:
                all_predictions.append(outputs["predictions"].cpu().numpy())
            elif "logits" in outputs:
                preds = outputs["logits"].argmax(dim=-1).cpu().numpy()
                all_predictions.append(preds)

            if "labels" in batch:
                all_labels.append(batch["labels"].cpu().numpy())

            if "features" in outputs:
                all_features.append(outputs["features"].cpu().numpy())

            if "spatial_coords" in batch:
                all_coords.append(batch["spatial_coords"].cpu().numpy())

            if "counts" in batch:
                all_continuous_targets.append(batch["counts"].cpu().numpy())
            elif "proportions" in batch:
                all_continuous_targets.append(batch["proportions"].cpu().numpy())

        # Concatenate results
        predictions = np.concatenate(all_predictions) if all_predictions else np.array([])
        labels = np.concatenate(all_labels) if all_labels else np.array([])
        features = np.concatenate(all_features) if all_features else None
        coords = np.concatenate(all_coords) if all_coords else None
        continuous = (
            np.concatenate(all_continuous_targets) if all_continuous_targets else None
        )

        # Compute metrics
        metrics = compute_metrics(
            predictions=predictions,
            labels=labels,
            task=task,
            embeddings=features,
            spatial_coords=coords,
            y_true_continuous=continuous,
        )

        # Log results
        logger.info(f"Evaluation results ({task}):")
        for k, v in sorted(metrics.items()):
            logger.info(f"  {k}: {v:.4f}")

        # Save results
        if output_dir:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            results = {
                "task": task,
                "metrics": {k: float(v) for k, v in metrics.items()},
                "n_samples": len(predictions),
            }

            with open(output_dir / f"eval_results_{task}.json", "w") as f:
                json.dump(results, f, indent=2)

            # Save predictions
            np.save(output_dir / f"predictions_{task}.npy", predictions)
            if features is not None:
                np.save(output_dir / f"features_{task}.npy", features)

        return metrics

    def evaluate_all_tasks(
        self,
        task_loaders: Dict[str, DataLoader],
        output_dir: str,
    ) -> Dict[str, Dict[str, float]]:
        """
        Evaluate across multiple tasks.

        Args:
            task_loaders: Dictionary of task_name -> DataLoader
            output_dir: Output directory

        Returns:
            Dictionary of task_name -> metrics
        """
        all_results = {}

        for task_name, loader in task_loaders.items():
            logger.info(f"\n{'='*50}")
            logger.info(f"Evaluating: {task_name}")
            logger.info(f"{'='*50}")

            metrics = self.evaluate(
                loader,
                task=task_name,
                output_dir=output_dir,
            )
            all_results[task_name] = metrics

        # Save combined results
        output_dir = Path(output_dir)
        with open(output_dir / "eval_results_all.json", "w") as f:
            json.dump(
                {k: {mk: float(mv) for mk, mv in v.items()} for k, v in all_results.items()},
                f,
                indent=2,
            )

        # Print summary table
        logger.info("\n" + "=" * 70)
        logger.info("EVALUATION SUMMARY")
        logger.info("=" * 70)
        for task_name, metrics in all_results.items():
            logger.info(f"\n{task_name}:")
            for k, v in sorted(metrics.items()):
                logger.info(f"  {k:20s}: {v:.4f}")

        return all_results
