"""
Visualization utilities for SpaFormers results.
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.manifold import TSNE

logger = logging.getLogger(__name__)

# Publication-quality settings
plt.rcParams.update({
    "font.size": 12,
    "axes.labelsize": 14,
    "axes.titlesize": 16,
    "xtick.labelsize": 11,
    "ytick.labelsize": 11,
    "legend.fontsize": 11,
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "font.family": "sans-serif",
})


def plot_spatial_domains(
    spatial_coords: np.ndarray,
    labels: np.ndarray,
    predictions: np.ndarray,
    output_path: str,
    title: str = "Spatial Domain Identification",
    spot_size: float = 5.0,
) -> None:
    """
    Plot ground truth and predicted spatial domains side by side.

    Args:
        spatial_coords: (n_spots, 2) spatial coordinates
        labels: Ground truth domain labels
        predictions: Predicted domain labels
        output_path: Path to save figure
        title: Figure title
        spot_size: Marker size for spots
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    # Color map
    n_domains = max(labels.max(), predictions.max()) + 1
    cmap = plt.cm.get_cmap("tab20", n_domains)

    # Ground truth
    valid = labels >= 0
    scatter1 = axes[0].scatter(
        spatial_coords[valid, 0],
        spatial_coords[valid, 1],
        c=labels[valid],
        cmap=cmap,
        s=spot_size,
        alpha=0.8,
    )
    axes[0].set_title("Ground Truth")
    axes[0].set_xlabel("X coordinate")
    axes[0].set_ylabel("Y coordinate")
    axes[0].set_aspect("equal")
    plt.colorbar(scatter1, ax=axes[0], label="Domain")

    # Predictions
    scatter2 = axes[1].scatter(
        spatial_coords[:, 0],
        spatial_coords[:, 1],
        c=predictions,
        cmap=cmap,
        s=spot_size,
        alpha=0.8,
    )
    axes[1].set_title("Predicted")
    axes[1].set_xlabel("X coordinate")
    axes[1].set_ylabel("Y coordinate")
    axes[1].set_aspect("equal")
    plt.colorbar(scatter2, ax=axes[1], label="Domain")

    plt.suptitle(title, fontsize=16, fontweight="bold")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Saved spatial domain plot: {output_path}")


def plot_embedding_tsne(
    embeddings: np.ndarray,
    labels: np.ndarray,
    output_path: str,
    title: str = "t-SNE Visualization of Learned Embeddings",
    perplexity: int = 30,
) -> None:
    """
    Plot t-SNE visualization of learned embeddings.

    Args:
        embeddings: (n_spots, hidden_dim) feature embeddings
        labels: Ground truth labels for coloring
        output_path: Path to save figure
        title: Figure title
        perplexity: t-SNE perplexity
    """
    # Subsample if too large
    max_samples = 10000
    if len(embeddings) > max_samples:
        indices = np.random.choice(len(embeddings), max_samples, replace=False)
        embeddings = embeddings[indices]
        labels = labels[indices]

    tsne = TSNE(n_components=2, perplexity=perplexity, random_state=42, n_iter=1000)
    coords_2d = tsne.fit_transform(embeddings)

    valid = labels >= 0
    n_classes = int(labels[valid].max()) + 1
    cmap = plt.cm.get_cmap("tab20", n_classes)

    fig, ax = plt.subplots(figsize=(8, 8))
    scatter = ax.scatter(
        coords_2d[valid, 0],
        coords_2d[valid, 1],
        c=labels[valid],
        cmap=cmap,
        s=3,
        alpha=0.6,
    )
    ax.set_title(title)
    ax.set_xlabel("t-SNE 1")
    ax.set_ylabel("t-SNE 2")
    plt.colorbar(scatter, ax=ax, label="Label")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Saved t-SNE plot: {output_path}")


def plot_ablation_results(
    results: Dict[str, Dict[str, float]],
    output_path: str,
    metric_name: str = "ari",
    title: str = "Ablation Study Results",
) -> None:
    """
    Plot ablation study results as a bar chart.

    Args:
        results: Dictionary of experiment_name -> metrics
        output_path: Path to save figure
        metric_name: Metric to plot
        title: Figure title
    """
    names = list(results.keys())
    values = [results[name].get(metric_name, 0) for name in names]

    # Sort by value
    sorted_pairs = sorted(zip(names, values), key=lambda x: x[1], reverse=True)
    names, values = zip(*sorted_pairs)

    fig, ax = plt.subplots(figsize=(10, 6))

    colors = ["#2196F3" if "Full" in name or "SpaFormers" in name else "#90CAF9" for name in names]
    bars = ax.barh(range(len(names)), values, color=colors, edgecolor="white", height=0.6)

    ax.set_yticks(range(len(names)))
    ax.set_yticklabels(names)
    ax.set_xlabel(metric_name.upper())
    ax.set_title(title)

    # Add value labels
    for bar, val in zip(bars, values):
        ax.text(
            bar.get_width() + 0.005,
            bar.get_y() + bar.get_height() / 2,
            f"{val:.3f}",
            va="center",
            fontsize=10,
        )

    ax.invert_yaxis()
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Saved ablation plot: {output_path}")


def plot_training_curves(
    train_losses: List[float],
    val_metrics: Optional[Dict[str, List[float]]] = None,
    output_path: str = "training_curves.png",
) -> None:
    """
    Plot training loss and validation metrics over epochs.

    Args:
        train_losses: Training losses per epoch
        val_metrics: Optional dict of metric name -> values per evaluation
        output_path: Path to save figure
    """
    n_plots = 1 + (len(val_metrics) if val_metrics else 0)
    fig, axes = plt.subplots(1, min(n_plots, 3), figsize=(6 * min(n_plots, 3), 5))

    if n_plots == 1:
        axes = [axes]

    # Training loss
    axes[0].plot(train_losses, color="#2196F3", linewidth=1.5)
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Loss")
    axes[0].set_title("Training Loss")
    axes[0].grid(True, alpha=0.3)

    # Validation metrics
    if val_metrics:
        metric_names = list(val_metrics.keys())
        for i, name in enumerate(metric_names[:2]):
            ax_idx = i + 1
            if ax_idx < len(axes):
                axes[ax_idx].plot(
                    val_metrics[name], color="#FF5722", linewidth=1.5, marker="o", markersize=3
                )
                axes[ax_idx].set_xlabel("Evaluation Step")
                axes[ax_idx].set_ylabel(name.upper())
                axes[ax_idx].set_title(f"Validation {name.upper()}")
                axes[ax_idx].grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Saved training curves: {output_path}")


def plot_comparison_table(
    results: Dict[str, Dict[str, float]],
    output_path: str,
    metrics: Optional[List[str]] = None,
    title: str = "Method Comparison",
) -> None:
    """
    Create a comparison heatmap of methods vs metrics.

    Args:
        results: Dict of method_name -> {metric: value}
        output_path: Path to save figure
        metrics: Optional list of metric names to include
        title: Figure title
    """
    methods = list(results.keys())

    if metrics is None:
        metrics = sorted(
            set().union(*(r.keys() for r in results.values()))
        )

    data = np.zeros((len(methods), len(metrics)))
    for i, method in enumerate(methods):
        for j, metric in enumerate(metrics):
            data[i, j] = results[method].get(metric, 0)

    fig, ax = plt.subplots(figsize=(len(metrics) * 2 + 2, len(methods) * 0.8 + 2))

    sns.heatmap(
        data,
        annot=True,
        fmt=".3f",
        xticklabels=[m.upper() for m in metrics],
        yticklabels=methods,
        cmap="YlOrRd",
        ax=ax,
        linewidths=0.5,
    )

    ax.set_title(title, fontsize=14, fontweight="bold")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Saved comparison table: {output_path}")
