"""
SpaFormers: Spatial-Aware Transcriptomic Foundation Model
Main entry point for pre-training, fine-tuning, and evaluation.
"""

import argparse
import json
import logging
import random
import sys
from pathlib import Path

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader

from data.dataset import SpatialTranscriptomicsDataset, PretrainSTDataset, load_dataset
from data.collator import SpaFormersCollator, PretrainCollator
from models.model import SpaFormersForPretraining, SpaFormersForFineTuning
from models.losses import PretrainLoss
from training.trainer import Trainer
from evaluation.evaluate import Evaluator

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("spaformers")


def set_seed(seed: int) -> None:
    """Set random seeds for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_config(path: str) -> dict:
    """Load YAML configuration file."""
    with open(path) as f:
        config = yaml.safe_load(f)
    return config


def merge_configs(base: dict, override: dict) -> dict:
    """Recursively merge override config into base config."""
    merged = base.copy()
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = merge_configs(merged[key], value)
        else:
            merged[key] = value
    return merged


def setup_device(config: dict) -> torch.device:
    """Set up compute device."""
    hw_cfg = config.get("hardware", {})
    gpu_ids = hw_cfg.get("gpu_ids", [0])

    if torch.cuda.is_available():
        device = torch.device(f"cuda:{gpu_ids[0]}")
        logger.info(f"Using GPU: {torch.cuda.get_device_name(device)}")
        logger.info(f"GPU memory: {torch.cuda.get_device_properties(device).total_mem / 1e9:.1f} GB")
    else:
        device = torch.device("cpu")
        logger.info("Using CPU")

    return device


def run_pretrain(config: dict, output_dir: str) -> None:
    """Run pre-training pipeline."""
    import anndata as ad

    logger.info("=" * 60)
    logger.info("PHASE: PRE-TRAINING")
    logger.info("=" * 60)

    device = setup_device(config)

    # Load pre-training data
    data_dir = Path(config["data"]["data_dir"])
    h5ad_files = sorted(data_dir.glob("**/*.h5ad"))

    if not h5ad_files:
        logger.error(f"No h5ad files found in {data_dir}. Run data/download.py first.")
        sys.exit(1)

    logger.info(f"Loading {len(h5ad_files)} data files for pre-training")
    adata_list = [ad.read_h5ad(str(f)) for f in h5ad_files]

    # Create pre-training dataset
    pretrain_cfg = config.get("pretraining", {})
    dataset = PretrainSTDataset(
        adata_list=adata_list,
        patch_size=config.get("model", {}).get("max_spots", 256),
        max_neighbors=config.get("model", {}).get("mssa", {}).get("local_k", 20),
        mask_ratio=pretrain_cfg.get("mask_ratio", 0.3),
        use_binned=True,
    )

    collator = PretrainCollator(max_patch_size=config.get("model", {}).get("max_spots", 512))
    train_loader = DataLoader(
        dataset,
        batch_size=pretrain_cfg.get("batch_size", 32),
        shuffle=True,
        num_workers=config.get("data", {}).get("num_workers", 4),
        pin_memory=config.get("data", {}).get("pin_memory", True),
        collate_fn=collator,
        drop_last=True,
    )

    # Create model and loss
    model = SpaFormersForPretraining(config)
    loss_fn = PretrainLoss(config)

    # Train
    trainer = Trainer(
        model=model,
        train_loader=train_loader,
        val_loader=None,
        config=config,
        device=device,
        mode="pretrain",
        output_dir=output_dir,
        loss_fn=loss_fn,
    )

    trainer.train()
    logger.info("Pre-training complete!")


def run_finetune(
    config: dict,
    output_dir: str,
    checkpoint: str,
    task: str = "spatial_domain",
) -> None:
    """Run fine-tuning pipeline."""
    logger.info("=" * 60)
    logger.info(f"PHASE: FINE-TUNING ({task})")
    logger.info("=" * 60)

    device = setup_device(config)

    # Load dataset
    dataset_name = config.get("data", {}).get("dataset", "dlpfc")
    data_dir = config.get("data", {}).get("data_dir", "./data/processed")

    train_dataset = load_dataset(data_dir, dataset_name, task=task, config=config, split="train")
    val_dataset = load_dataset(data_dir, dataset_name, task=task, config=config, split="val")

    collator = SpaFormersCollator()
    ft_cfg = config.get("finetuning", {})

    train_loader = DataLoader(
        train_dataset,
        batch_size=ft_cfg.get("batch_size", 64),
        shuffle=True,
        num_workers=config.get("data", {}).get("num_workers", 4),
        pin_memory=True,
        collate_fn=collator,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=ft_cfg.get("batch_size", 64),
        shuffle=False,
        num_workers=config.get("data", {}).get("num_workers", 4),
        pin_memory=True,
        collate_fn=collator,
    )

    # Create model and load pre-trained weights
    model = SpaFormersForFineTuning(config, task=task)
    if checkpoint:
        model.load_pretrained(checkpoint)

    # Train
    trainer = Trainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        config=config,
        device=device,
        mode="finetune",
        output_dir=output_dir,
    )

    results = trainer.train()

    # Save fine-tuning results
    results_path = Path(output_dir) / f"finetune_results_{task}.json"
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2)

    logger.info(f"Fine-tuning complete! Results: {results_path}")


def run_eval(
    config: dict,
    output_dir: str,
    checkpoint: str,
    task: str = "spatial_domain",
) -> None:
    """Run evaluation pipeline."""
    logger.info("=" * 60)
    logger.info(f"PHASE: EVALUATION ({task})")
    logger.info("=" * 60)

    device = setup_device(config)

    # Load dataset
    dataset_name = config.get("data", {}).get("dataset", "dlpfc")
    data_dir = config.get("data", {}).get("data_dir", "./data/processed")

    test_dataset = load_dataset(data_dir, dataset_name, task=task, config=config, split="test")

    collator = SpaFormersCollator()
    test_loader = DataLoader(
        test_dataset,
        batch_size=config.get("finetuning", {}).get("batch_size", 64),
        shuffle=False,
        num_workers=config.get("data", {}).get("num_workers", 4),
        pin_memory=True,
        collate_fn=collator,
    )

    # Load model
    model = SpaFormersForFineTuning(config, task=task)
    ckpt = torch.load(checkpoint, map_location="cpu")
    model.load_state_dict(ckpt.get("model_state_dict", ckpt))

    # Evaluate
    evaluator = Evaluator(model, device, config)
    results = evaluator.evaluate(test_loader, task=task, output_dir=output_dir)

    logger.info(f"Evaluation results: {results}")


def main():
    parser = argparse.ArgumentParser(description="SpaFormers: Spatial Transcriptomic Foundation Model")
    parser.add_argument("--config", type=str, required=True, help="Path to config YAML")
    parser.add_argument(
        "--mode",
        choices=["pretrain", "finetune", "eval", "train_eval"],
        default="train_eval",
        help="Run mode",
    )
    parser.add_argument("--task", type=str, default="spatial_domain",
                        choices=["spatial_domain", "gene_imputation", "cell_annotation", "cell_deconvolution"],
                        help="Downstream task")
    parser.add_argument("--checkpoint", type=str, default=None, help="Path to checkpoint")
    parser.add_argument("--output_dir", type=str, default="./outputs", help="Output directory")
    parser.add_argument("--seed", type=int, default=None, help="Random seed (overrides config)")
    args = parser.parse_args()

    # Load configuration
    config = load_config(args.config)

    # Set seed
    seed = args.seed or config.get("hardware", {}).get("seed", 42)
    set_seed(seed)
    logger.info(f"Random seed: {seed}")

    # Save config
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with open(output_dir / "config.yaml", "w") as f:
        yaml.dump(config, f, default_flow_style=False)

    # Run
    if args.mode == "pretrain":
        run_pretrain(config, str(output_dir))

    elif args.mode == "finetune":
        run_finetune(config, str(output_dir), args.checkpoint, args.task)

    elif args.mode == "eval":
        if not args.checkpoint:
            logger.error("--checkpoint required for eval mode")
            sys.exit(1)
        run_eval(config, str(output_dir), args.checkpoint, args.task)

    elif args.mode == "train_eval":
        # Pre-train -> fine-tune -> evaluate
        pretrain_dir = str(output_dir / "pretrain")
        run_pretrain(config, pretrain_dir)

        checkpoint = str(Path(pretrain_dir) / "best_model.pt")
        if not Path(checkpoint).exists():
            checkpoint = str(Path(pretrain_dir) / "last.pt")

        finetune_dir = str(output_dir / f"finetune_{args.task}")
        run_finetune(config, finetune_dir, checkpoint, args.task)

        eval_checkpoint = str(Path(finetune_dir) / "best_model.pt")
        if not Path(eval_checkpoint).exists():
            eval_checkpoint = str(Path(finetune_dir) / "last.pt")

        eval_dir = str(output_dir / f"eval_{args.task}")
        run_eval(config, eval_dir, eval_checkpoint, args.task)


if __name__ == "__main__":
    main()
