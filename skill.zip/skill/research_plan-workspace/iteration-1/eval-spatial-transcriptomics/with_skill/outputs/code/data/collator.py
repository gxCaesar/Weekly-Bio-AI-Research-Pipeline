"""
Custom data collation functions for SpaFormers.
Handles variable-length spatial patches and neighbor indices.
"""

import logging
from typing import Dict, List, Optional

import torch
import numpy as np

logger = logging.getLogger(__name__)


class SpaFormersCollator:
    """
    Collator for fine-tuning datasets.
    Pads batches and creates attention masks for variable-length sequences.
    """

    def __init__(self, max_spots: int = 8192, pad_value: int = 0):
        """
        Args:
            max_spots: Maximum number of spots (for memory pre-allocation)
            pad_value: Padding value for expression data
        """
        self.max_spots = max_spots
        self.pad_value = pad_value

    def __call__(self, batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """
        Collate a batch of spot-level samples.

        For fine-tuning, each sample is a single spot with its context.
        Simple stacking is sufficient.
        """
        collated = {}

        # Stack tensors that have the same shape across the batch
        keys_to_stack = ["expression", "spatial_coords", "neighbor_indices", "index"]
        for key in keys_to_stack:
            if key in batch[0]:
                collated[key] = torch.stack([item[key] for item in batch])

        # Labels
        if "labels" in batch[0]:
            collated["labels"] = torch.stack([item["labels"] for item in batch])

        if "proportions" in batch[0]:
            collated["proportions"] = torch.stack([item["proportions"] for item in batch])

        if "counts" in batch[0]:
            collated["counts"] = torch.stack([item["counts"] for item in batch])

        return collated


class PretrainCollator:
    """
    Collator for pre-training datasets.
    Handles variable-size spatial patches by padding.
    """

    def __init__(self, max_patch_size: int = 512, pad_value: int = 0):
        """
        Args:
            max_patch_size: Maximum patch size to pad to
            pad_value: Padding value
        """
        self.max_patch_size = max_patch_size
        self.pad_value = pad_value

    def __call__(self, batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """
        Collate variable-size spatial patches.

        Pads all patches to the maximum size in the batch and creates
        attention masks to indicate real vs. padded positions.
        """
        batch_size = len(batch)

        # Find max patch size in this batch
        max_n = min(
            max(item["n_spots"].item() for item in batch),
            self.max_patch_size,
        )

        n_genes = batch[0]["expression"].shape[1]
        max_neighbors = batch[0]["neighbor_indices"].shape[1]

        # Initialize padded tensors
        expression = torch.full(
            (batch_size, max_n, n_genes), self.pad_value, dtype=torch.float32
        )
        spatial_coords = torch.zeros(batch_size, max_n, 2, dtype=torch.float32)
        neighbor_indices = torch.zeros(
            batch_size, max_n, max_neighbors, dtype=torch.long
        )
        gene_mask = torch.zeros(batch_size, n_genes, dtype=torch.bool)
        attention_mask = torch.zeros(batch_size, max_n, dtype=torch.bool)
        n_spots = torch.zeros(batch_size, dtype=torch.long)

        for i, item in enumerate(batch):
            n = min(item["n_spots"].item(), max_n)

            expression[i, :n] = item["expression"][:n]
            spatial_coords[i, :n] = item["spatial_coords"][:n]

            # Clamp neighbor indices to be within the valid range
            nb = item["neighbor_indices"][:n].clamp(0, n - 1)
            neighbor_indices[i, :n] = nb

            gene_mask[i] = item["gene_mask"]
            attention_mask[i, :n] = True
            n_spots[i] = n

        return {
            "expression": expression,
            "spatial_coords": spatial_coords,
            "neighbor_indices": neighbor_indices,
            "gene_mask": gene_mask,
            "attention_mask": attention_mask,
            "n_spots": n_spots,
        }


class GraphCollator:
    """
    Collator for graph-based baseline methods.
    Creates batched graph representation with proper indexing.
    """

    def __init__(self):
        pass

    def __call__(self, batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """Collate graph samples by stacking with offset indices."""
        collated = {}

        collated["expression"] = torch.stack([item["expression"] for item in batch])
        collated["spatial_coords"] = torch.stack(
            [item["spatial_coords"] for item in batch]
        )
        collated["neighbor_indices"] = torch.stack(
            [item["neighbor_indices"] for item in batch]
        )

        if "labels" in batch[0]:
            collated["labels"] = torch.stack([item["labels"] for item in batch])

        if "index" in batch[0]:
            collated["index"] = torch.stack([item["index"] for item in batch])

        return collated
