"""
Evaluation metrics for spatial transcriptomics analysis tasks.
"""

import logging
from typing import Dict, Optional

import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.metrics import (
    adjusted_rand_score,
    normalized_mutual_info_score,
    accuracy_score,
    f1_score,
    silhouette_score,
    mean_squared_error,
)
from scipy.stats import pearsonr, spearmanr

logger = logging.getLogger(__name__)


def compute_ari(labels_true: np.ndarray, labels_pred: np.ndarray) -> float:
    """Compute Adjusted Rand Index."""
    # Filter out invalid labels
    valid = labels_true >= 0
    if valid.sum() == 0:
        return 0.0
    return adjusted_rand_score(labels_true[valid], labels_pred[valid])


def compute_nmi(labels_true: np.ndarray, labels_pred: np.ndarray) -> float:
    """Compute Normalized Mutual Information."""
    valid = labels_true >= 0
    if valid.sum() == 0:
        return 0.0
    return normalized_mutual_info_score(
        labels_true[valid], labels_pred[valid], average_method="arithmetic"
    )


def hungarian_accuracy(labels_true: np.ndarray, labels_pred: np.ndarray) -> float:
    """
    Compute accuracy using Hungarian matching for cluster-to-class assignment.
    Handles the case where predicted cluster IDs don't match ground truth labels.
    """
    valid = labels_true >= 0
    if valid.sum() == 0:
        return 0.0

    labels_true = labels_true[valid]
    labels_pred = labels_pred[valid]

    n_true = int(labels_true.max()) + 1
    n_pred = int(labels_pred.max()) + 1
    n = max(n_true, n_pred)

    # Build cost matrix
    cost_matrix = np.zeros((n, n))
    for i in range(len(labels_true)):
        t = int(labels_true[i])
        p = int(labels_pred[i])
        if t < n and p < n:
            cost_matrix[t, p] += 1

    # Hungarian assignment (maximize matches = minimize negative)
    row_ind, col_ind = linear_sum_assignment(-cost_matrix)

    # Map predictions to true labels
    mapping = dict(zip(col_ind, row_ind))
    mapped_pred = np.array([mapping.get(int(p), -1) for p in labels_pred])

    accuracy = (mapped_pred == labels_true).mean()
    return accuracy


def compute_silhouette(
    embeddings: np.ndarray, labels: np.ndarray
) -> float:
    """Compute silhouette score for embedding quality."""
    valid = labels >= 0
    if valid.sum() < 2:
        return 0.0

    n_unique = len(np.unique(labels[valid]))
    if n_unique < 2:
        return 0.0

    return silhouette_score(embeddings[valid], labels[valid])


def compute_pcc(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute mean Pearson Correlation Coefficient across genes."""
    if y_true.ndim == 1:
        r, _ = pearsonr(y_true, y_pred)
        return r

    correlations = []
    for i in range(y_true.shape[1]):
        if np.std(y_true[:, i]) > 0 and np.std(y_pred[:, i]) > 0:
            r, _ = pearsonr(y_true[:, i], y_pred[:, i])
            correlations.append(r)

    return np.mean(correlations) if correlations else 0.0


def compute_chaos(
    labels: np.ndarray,
    spatial_coords: np.ndarray,
    n_neighbors: int = 10,
) -> float:
    """
    Compute CHAOS score (spatial smoothness of clustering).
    Lower is better (more spatially coherent domains).
    """
    from sklearn.neighbors import NearestNeighbors

    valid = labels >= 0
    if valid.sum() < n_neighbors + 1:
        return 1.0

    coords = spatial_coords[valid]
    labs = labels[valid]

    nn = NearestNeighbors(n_neighbors=n_neighbors)
    nn.fit(coords)
    _, indices = nn.kneighbors(coords)

    # For each spot, compute fraction of neighbors with different labels
    chaos = 0.0
    for i in range(len(labs)):
        neighbor_labels = labs[indices[i]]
        different = (neighbor_labels != labs[i]).mean()
        chaos += different

    chaos /= len(labs)
    return chaos


def compute_metrics(
    predictions: np.ndarray,
    labels: np.ndarray,
    task: str = "spatial_domain",
    embeddings: Optional[np.ndarray] = None,
    spatial_coords: Optional[np.ndarray] = None,
    y_true_continuous: Optional[np.ndarray] = None,
) -> Dict[str, float]:
    """
    Compute all relevant metrics for a given task.

    Args:
        predictions: Model predictions
        labels: Ground truth labels
        task: Task name
        embeddings: Optional embeddings for silhouette score
        spatial_coords: Optional spatial coords for CHAOS score
        y_true_continuous: Optional continuous ground truth for imputation

    Returns:
        Dictionary of metric name -> value
    """
    metrics = {}

    if task in ("spatial_domain", "cell_annotation"):
        # Classification metrics
        metrics["ari"] = compute_ari(labels, predictions)
        metrics["nmi"] = compute_nmi(labels, predictions)
        metrics["accuracy"] = hungarian_accuracy(labels, predictions)

        valid = labels >= 0
        if valid.sum() > 0:
            metrics["f1_macro"] = f1_score(
                labels[valid],
                predictions[valid],
                average="macro",
                zero_division=0,
            )

        # Embedding quality
        if embeddings is not None:
            metrics["silhouette"] = compute_silhouette(embeddings, labels)

        # Spatial coherence
        if spatial_coords is not None:
            metrics["chaos"] = compute_chaos(labels=predictions, spatial_coords=spatial_coords)

    elif task == "gene_imputation":
        if y_true_continuous is not None:
            metrics["mse"] = mean_squared_error(y_true_continuous, predictions)
            metrics["pcc"] = compute_pcc(y_true_continuous, predictions)

    elif task == "cell_deconvolution":
        if y_true_continuous is not None:
            metrics["mse"] = mean_squared_error(y_true_continuous, predictions)
            metrics["pcc"] = compute_pcc(y_true_continuous, predictions)

    return metrics
