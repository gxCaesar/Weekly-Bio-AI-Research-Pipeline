"""Baseline methods for comparison."""

from baselines.stagate_baseline import STAGATEBaseline
from baselines.graphst_baseline import GraphSTBaseline

__all__ = ["STAGATEBaseline", "GraphSTBaseline"]
