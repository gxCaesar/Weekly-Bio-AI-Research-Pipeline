"""
Dataset download utilities for SpaFormers.
Supports automatic download of public spatial transcriptomics datasets.
"""

import os
import urllib.request
import zipfile
import tarfile
import logging
from pathlib import Path
from typing import Optional

import scanpy as sc
import anndata as ad

logger = logging.getLogger(__name__)

# Dataset registry with download URLs
DATASET_REGISTRY = {
    "dlpfc": {
        "description": "Human DLPFC 10x Visium from spatialLIBD (12 slices)",
        "url": "http://spatial.libd.org/spatialLIBD/",
        "sample_ids": [
            "151507", "151508", "151509", "151510",
            "151669", "151670", "151671", "151672",
            "151673", "151674", "151675", "151676",
        ],
        "platform": "visium",
    },
    "mouse_brain_visium": {
        "description": "Mouse Brain 10x Visium dataset",
        "url": "https://www.10xgenomics.com/datasets",
        "sample_ids": ["anterior1", "anterior2", "posterior1", "posterior2"],
        "platform": "visium",
    },
    "breast_cancer": {
        "description": "Human Breast Cancer 10x Visium",
        "url": "https://www.10xgenomics.com/datasets",
        "sample_ids": ["block_a_section_1", "block_a_section_2"],
        "platform": "visium",
    },
    "merfish_mouse_brain": {
        "description": "MERFISH Mouse Brain from Allen Institute",
        "url": "https://alleninstitute.org/",
        "sample_ids": ["merfish_mouse_brain"],
        "platform": "merfish",
    },
    "stereoseq_mouse_embryo": {
        "description": "Stereo-seq Mouse Embryo from BGI",
        "url": "https://db.cngb.org/stomics/",
        "sample_ids": ["E9.5", "E10.5", "E11.5"],
        "platform": "stereoseq",
    },
}


def download_file(url: str, output_path: str, chunk_size: int = 8192) -> None:
    """Download a file from a URL with progress reporting."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if output_path.exists():
        logger.info(f"File already exists: {output_path}")
        return

    logger.info(f"Downloading {url} -> {output_path}")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "SpaFormers/1.0"})
        with urllib.request.urlopen(req) as response:
            total_size = int(response.headers.get("Content-Length", 0))
            downloaded = 0
            with open(output_path, "wb") as f:
                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        pct = downloaded / total_size * 100
                        if downloaded % (chunk_size * 100) == 0:
                            logger.info(f"  Progress: {pct:.1f}%")
        logger.info(f"Download complete: {output_path}")
    except Exception as e:
        logger.error(f"Failed to download {url}: {e}")
        if output_path.exists():
            output_path.unlink()
        raise


def extract_archive(archive_path: str, output_dir: str) -> None:
    """Extract a zip or tar.gz archive."""
    archive_path = Path(archive_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if archive_path.suffix == ".zip":
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(output_dir)
    elif archive_path.suffixes[-2:] == [".tar", ".gz"] or archive_path.suffix == ".tgz":
        with tarfile.open(archive_path, "r:gz") as tf:
            tf.extractall(output_dir)
    else:
        logger.warning(f"Unknown archive format: {archive_path}")
        return

    logger.info(f"Extracted {archive_path} to {output_dir}")


def download_dlpfc(output_dir: str) -> list:
    """
    Download DLPFC dataset using scanpy/squidpy built-in functions.
    Falls back to manual download if needed.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    sample_ids = DATASET_REGISTRY["dlpfc"]["sample_ids"]
    downloaded_files = []

    for sample_id in sample_ids:
        h5ad_path = output_dir / f"{sample_id}.h5ad"

        if h5ad_path.exists():
            logger.info(f"DLPFC {sample_id} already exists at {h5ad_path}")
            downloaded_files.append(str(h5ad_path))
            continue

        try:
            # Try using squidpy's built-in dataset loader
            import squidpy as sq

            adata = sq.datasets.visium(sample_id)
            adata.write_h5ad(h5ad_path)
            logger.info(f"Downloaded DLPFC {sample_id} via squidpy")
        except (ImportError, Exception) as e:
            logger.warning(f"Squidpy download failed for {sample_id}: {e}")
            try:
                # Alternative: use scanpy read_visium with 10x format
                spaceranger_dir = output_dir / sample_id / "outs"
                if spaceranger_dir.exists():
                    adata = sc.read_visium(str(spaceranger_dir))
                    adata.write_h5ad(h5ad_path)
                    logger.info(f"Read DLPFC {sample_id} from spaceranger output")
                else:
                    logger.error(
                        f"Cannot download DLPFC {sample_id}. "
                        f"Please manually download from {DATASET_REGISTRY['dlpfc']['url']} "
                        f"and place h5ad files in {output_dir}"
                    )
                    continue
            except Exception as e2:
                logger.error(f"Failed to process {sample_id}: {e2}")
                continue

        downloaded_files.append(str(h5ad_path))

    return downloaded_files


def download_merfish(output_dir: str) -> list:
    """Download MERFISH Mouse Brain dataset."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    h5ad_path = output_dir / "merfish_mouse_brain.h5ad"
    downloaded_files = []

    if h5ad_path.exists():
        logger.info(f"MERFISH dataset already exists at {h5ad_path}")
        return [str(h5ad_path)]

    try:
        import squidpy as sq

        adata = sq.datasets.merfish()
        adata.write_h5ad(h5ad_path)
        logger.info("Downloaded MERFISH Mouse Brain via squidpy")
        downloaded_files.append(str(h5ad_path))
    except (ImportError, Exception) as e:
        logger.error(
            f"Failed to download MERFISH data: {e}. "
            f"Please manually download from Allen Institute."
        )

    return downloaded_files


def download_dataset(
    dataset_name: str,
    output_dir: str,
    sample_id: Optional[str] = None,
) -> list:
    """
    Download a dataset by name.

    Args:
        dataset_name: Name of the dataset (must be in DATASET_REGISTRY)
        output_dir: Directory to save downloaded files
        sample_id: Optional specific sample to download

    Returns:
        List of paths to downloaded files
    """
    if dataset_name not in DATASET_REGISTRY:
        available = ", ".join(DATASET_REGISTRY.keys())
        raise ValueError(
            f"Unknown dataset: {dataset_name}. Available: {available}"
        )

    info = DATASET_REGISTRY[dataset_name]
    logger.info(f"Downloading dataset: {dataset_name} ({info['description']})")

    output_dir = Path(output_dir) / dataset_name
    output_dir.mkdir(parents=True, exist_ok=True)

    if dataset_name == "dlpfc":
        return download_dlpfc(str(output_dir))
    elif dataset_name == "merfish_mouse_brain":
        return download_merfish(str(output_dir))
    else:
        logger.warning(
            f"Automatic download for {dataset_name} is not yet supported. "
            f"Please manually download from: {info['url']}"
        )
        return []


def list_datasets() -> None:
    """Print available datasets."""
    print("\nAvailable datasets:")
    print("-" * 80)
    for name, info in DATASET_REGISTRY.items():
        print(f"  {name:30s} | {info['description']}")
        print(f"  {'':30s} | Platform: {info['platform']}")
        print(f"  {'':30s} | URL: {info['url']}")
        print()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Download ST datasets")
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        choices=list(DATASET_REGISTRY.keys()) + ["all", "list"],
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="./data/raw",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)

    if args.dataset == "list":
        list_datasets()
    elif args.dataset == "all":
        for name in DATASET_REGISTRY:
            try:
                download_dataset(name, args.output_dir)
            except Exception as e:
                logger.error(f"Failed to download {name}: {e}")
    else:
        download_dataset(args.dataset, args.output_dir)
