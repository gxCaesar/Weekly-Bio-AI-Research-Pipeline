"""
STAGATE baseline: Graph Attention Auto-Encoder for spatial domain identification.
Reference: Dong & Zhang, Nature Communications, 2022.
"""

import logging
from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


class GraphAttentionLayer(nn.Module):
    """Graph Attention Network (GAT) layer."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        num_heads: int = 4,
        dropout: float = 0.1,
        alpha: float = 0.2,
        concat: bool = True,
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.num_heads = num_heads
        self.concat = concat

        self.W = nn.Parameter(torch.empty(num_heads, in_features, out_features))
        self.a_src = nn.Parameter(torch.empty(num_heads, out_features, 1))
        self.a_dst = nn.Parameter(torch.empty(num_heads, out_features, 1))

        self.leaky_relu = nn.LeakyReLU(alpha)
        self.dropout = nn.Dropout(dropout)

        nn.init.xavier_uniform_(self.W)
        nn.init.xavier_uniform_(self.a_src)
        nn.init.xavier_uniform_(self.a_dst)

    def forward(
        self,
        x: torch.Tensor,
        neighbor_indices: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            x: Node features (n_nodes, in_features)
            neighbor_indices: K-NN indices (n_nodes, K)

        Returns:
            Updated features (n_nodes, out_features * num_heads) or (n_nodes, out_features)
        """
        n_nodes = x.shape[0]
        K = neighbor_indices.shape[1]

        # Linear transformation: (num_heads, n_nodes, out_features)
        h = torch.einsum("ni,hio->hno", x, self.W)

        # Compute attention scores
        # Source scores
        e_src = torch.einsum("hno,hod->hnd", h, self.a_src).squeeze(-1)  # (heads, n_nodes)
        # Destination scores for neighbors
        nb_idx = neighbor_indices.clamp(0, n_nodes - 1)
        h_neighbors = h[:, nb_idx]  # (heads, n_nodes, K, out_features)
        e_dst = torch.einsum("hnko,hod->hnkd", h_neighbors, self.a_dst).squeeze(
            -1
        )  # (heads, n_nodes, K)

        # Combine and apply LeakyReLU
        attn = self.leaky_relu(e_src.unsqueeze(-1) + e_dst)  # (heads, n_nodes, K)

        # Softmax over neighbors
        attn = F.softmax(attn, dim=-1)
        attn = self.dropout(attn)

        # Weighted aggregation
        out = torch.einsum("hnk,hnko->hno", attn, h_neighbors)  # (heads, n_nodes, out)

        if self.concat:
            out = out.permute(1, 0, 2).contiguous().view(n_nodes, -1)
        else:
            out = out.mean(dim=0)

        return out


class STAGATEBaseline(nn.Module):
    """
    STAGATE: Graph attention auto-encoder for spatial domain identification.
    Uses adaptive graph construction and GAT for spatial-aware representation.
    """

    def __init__(self, config: dict):
        """
        Args:
            config: Configuration dictionary
        """
        super().__init__()
        model_cfg = config.get("model", config)

        in_features = model_cfg.get("num_genes", 2000)
        hidden_dim = model_cfg.get("hidden_dim", 512)
        num_heads = model_cfg.get("num_heads", 4)
        gat_cfg = model_cfg.get("gat", {})
        n_layers = gat_cfg.get("num_gat_layers", 4)
        alpha = gat_cfg.get("alpha", 0.2)
        dropout = model_cfg.get("dropout", 0.1)

        # Encoder
        encoder_layers = []
        current_dim = in_features
        for i in range(n_layers):
            out_dim = hidden_dim // num_heads if i < n_layers - 1 else hidden_dim // num_heads
            concat = i < n_layers - 1
            layer = GraphAttentionLayer(
                current_dim,
                out_dim,
                num_heads=num_heads,
                dropout=dropout,
                alpha=alpha,
                concat=concat,
            )
            encoder_layers.append(layer)
            current_dim = out_dim * num_heads if concat else out_dim

        self.encoder_layers = nn.ModuleList(encoder_layers)

        # Decoder (reconstruction)
        self.decoder = nn.Sequential(
            nn.Linear(current_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, in_features),
        )

        self.hidden_dim = current_dim

        # Classification head
        task_cfg = config.get("tasks", {}).get("spatial_domain", {})
        num_classes = task_cfg.get("num_classes", 7)
        self.classifier = nn.Sequential(
            nn.Linear(current_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes),
        )

        n_params = sum(p.numel() for p in self.parameters())
        logger.info(f"STAGATE baseline: {n_params / 1e6:.1f}M parameters")

    def encode(
        self,
        x: torch.Tensor,
        neighbor_indices: torch.Tensor,
    ) -> torch.Tensor:
        """
        Encode node features.

        Args:
            x: Input features (n_nodes, in_features) -- continuous expression values
            neighbor_indices: K-NN indices (n_nodes, K)

        Returns:
            Latent representation (n_nodes, hidden_dim)
        """
        h = x
        for layer in self.encoder_layers:
            h = F.elu(layer(h, neighbor_indices))
        return h

    def forward(
        self,
        expression: torch.Tensor,
        spatial_coords: torch.Tensor,
        neighbor_indices: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass.

        Args:
            expression: (batch, n_genes) or (n_nodes, n_genes) for full-graph mode
            spatial_coords: (batch, 2) or (n_nodes, 2)
            neighbor_indices: (batch, K) or (n_nodes, K)
            labels: Optional ground truth labels

        Returns:
            Dictionary with embeddings, predictions, and loss
        """
        # STAGATE operates in full-graph mode
        if expression.dim() == 3:
            expression = expression.squeeze(0)
            neighbor_indices = neighbor_indices.squeeze(0)
            if labels is not None:
                labels = labels.squeeze(0)

        # Encode
        z = self.encode(expression, neighbor_indices)

        # Reconstruct
        x_recon = self.decoder(z)

        # Classify
        logits = self.classifier(z)

        output = {
            "features": z,
            "logits": logits,
            "reconstruction": x_recon,
            "predictions": logits.argmax(dim=-1),
        }

        # Loss: reconstruction + classification
        recon_loss = F.mse_loss(x_recon, expression)
        output["recon_loss"] = recon_loss

        if labels is not None:
            cls_loss = F.cross_entropy(logits, labels, ignore_index=-1)
            output["loss"] = recon_loss + cls_loss
            output["cls_loss"] = cls_loss
        else:
            output["loss"] = recon_loss

        return output
