"""
Core modules for SpaFormers:
- HierarchicalSpatialPE: Hierarchical Spatial Positional Encoding (HSPE)
- MultiScaleSpatialAttention: Multi-Scale Spatial Attention (MSSA)
- GeneTokenEmbedding: Adaptive binning + embedding for gene expression
- SpaFormersBlock: Single transformer block with MSSA
"""

import math
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class RoPE2D(nn.Module):
    """
    2D Rotary Position Embedding.
    Extends the standard 1D RoPE to 2D spatial coordinates.
    Each spatial dimension (x, y) uses half of the embedding dimension.
    """

    def __init__(self, dim: int, max_freq: float = 10000.0):
        """
        Args:
            dim: Embedding dimension (must be divisible by 4 for 2D)
            max_freq: Maximum frequency for the sinusoidal functions
        """
        super().__init__()
        assert dim % 4 == 0, f"dim must be divisible by 4, got {dim}"
        self.dim = dim
        self.half_dim = dim // 2
        self.quarter_dim = dim // 4

        # Precompute frequency bands
        inv_freq = 1.0 / (
            max_freq ** (torch.arange(0, self.quarter_dim, dtype=torch.float32) / self.quarter_dim)
        )
        self.register_buffer("inv_freq", inv_freq)

    def forward(
        self, coords: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Compute rotation matrices for 2D coordinates.

        Args:
            coords: Spatial coordinates (batch, n_spots, 2) with (x, y)

        Returns:
            cos: Cosine components (batch, n_spots, dim)
            sin: Sine components (batch, n_spots, dim)
        """
        x = coords[..., 0:1]  # (batch, n_spots, 1)
        y = coords[..., 1:2]  # (batch, n_spots, 1)

        # Compute frequencies for x and y separately
        x_freqs = x * self.inv_freq.unsqueeze(0).unsqueeze(0)  # (batch, n_spots, quarter_dim)
        y_freqs = y * self.inv_freq.unsqueeze(0).unsqueeze(0)

        # Concatenate x and y frequencies, then duplicate for sin/cos pairs
        freqs = torch.cat([x_freqs, y_freqs, x_freqs, y_freqs], dim=-1)  # (batch, n_spots, dim)

        cos_vals = freqs.cos()
        sin_vals = freqs.sin()

        return cos_vals, sin_vals


def apply_rope_2d(
    q: torch.Tensor,
    k: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Apply 2D rotary position embedding to query and key tensors.

    Args:
        q: Query tensor (batch, heads, n_spots, head_dim)
        k: Key tensor (batch, heads, n_spots, head_dim)
        cos: Cosine rotations (batch, n_spots, head_dim)
        sin: Sine rotations (batch, n_spots, head_dim)

    Returns:
        Rotated (q, k) tensors
    """
    # Reshape cos/sin for broadcasting with heads dimension
    cos = cos.unsqueeze(1)  # (batch, 1, n_spots, head_dim)
    sin = sin.unsqueeze(1)

    def rotate(x: torch.Tensor) -> torch.Tensor:
        """Apply rotary embedding to a tensor."""
        d = x.shape[-1]
        x1 = x[..., : d // 2]
        x2 = x[..., d // 2 :]
        x_rotated = torch.cat([-x2, x1], dim=-1)
        return x * cos[..., :d] + x_rotated * sin[..., :d]

    return rotate(q), rotate(k)


class MultiResolutionHashEncoding(nn.Module):
    """
    Multi-resolution spatial hash encoding inspired by Instant-NGP.
    Maps 2D spatial coordinates to feature vectors at multiple resolutions.
    """

    def __init__(
        self,
        n_levels: int = 6,
        n_features: int = 64,
        table_size: int = 65536,
        resolutions: Optional[list] = None,
        output_dim: int = 384,
    ):
        """
        Args:
            n_levels: Number of resolution levels
            n_features: Features per level
            table_size: Hash table size per level
            resolutions: List of grid resolutions (one per level)
            output_dim: Output dimension after projection
        """
        super().__init__()
        self.n_levels = n_levels
        self.n_features = n_features
        self.table_size = table_size

        if resolutions is None:
            resolutions = [2 ** (i + 4) for i in range(n_levels)]
        self.resolutions = resolutions

        # Hash tables: one per level
        self.hash_tables = nn.ModuleList([
            nn.Embedding(table_size, n_features) for _ in range(n_levels)
        ])

        # Initialize with small values
        for table in self.hash_tables:
            nn.init.uniform_(table.weight, -1e-4, 1e-4)

        # Projection to output dimension
        total_features = n_levels * n_features
        self.projection = nn.Sequential(
            nn.Linear(total_features, output_dim),
            nn.GELU(),
            nn.Linear(output_dim, output_dim),
        )

    def _hash_coords(
        self, coords: torch.Tensor, resolution: int
    ) -> torch.Tensor:
        """
        Hash 2D coordinates at a given resolution.

        Args:
            coords: (batch, n_spots, 2) normalized to [0, 1]
            resolution: Grid resolution

        Returns:
            Hash indices (batch, n_spots)
        """
        # Quantize coordinates to grid
        scaled = coords * resolution
        grid_x = scaled[..., 0].long().clamp(0, resolution - 1)
        grid_y = scaled[..., 1].long().clamp(0, resolution - 1)

        # Spatial hash function (based on prime numbers)
        prime1 = 73856093
        prime2 = 19349663
        hashed = (grid_x * prime1) ^ (grid_y * prime2)
        hashed = hashed % self.table_size

        return hashed.abs()

    def forward(self, coords: torch.Tensor) -> torch.Tensor:
        """
        Compute multi-resolution hash encoding.

        Args:
            coords: Spatial coordinates (batch, n_spots, 2) in [0, 1]

        Returns:
            Hash features (batch, n_spots, output_dim)
        """
        features_list = []

        for level, resolution in enumerate(self.resolutions):
            hash_indices = self._hash_coords(coords, resolution)
            level_features = self.hash_tables[level](hash_indices)
            features_list.append(level_features)

        # Concatenate all levels
        multi_res_features = torch.cat(features_list, dim=-1)

        # Project to output dimension
        output = self.projection(multi_res_features)

        return output


class HierarchicalSpatialPE(nn.Module):
    """
    Hierarchical Spatial Positional Encoding (HSPE).
    Combines 2D-RoPE with multi-resolution hash encoding via gated fusion.
    """

    def __init__(self, config: dict):
        """
        Args:
            config: Model configuration dictionary containing 'hspe' key
        """
        super().__init__()
        hidden_dim = config.get("hidden_dim", 768)
        hspe_config = config.get("hspe", {})

        rope_dim = hspe_config.get("rope_dim", hidden_dim // 2)
        hash_levels = hspe_config.get("hash_levels", 6)
        hash_features = hspe_config.get("hash_features", 64)
        hash_table_size = hspe_config.get("hash_table_size", 65536)
        hash_resolutions = hspe_config.get(
            "hash_resolutions", [16, 32, 64, 128, 256, 512]
        )

        # 2D-RoPE for precise positional encoding
        # RoPE is applied inside the attention mechanism, not here
        # We compute cos/sin here and pass them to the attention layer
        self.rope = RoPE2D(dim=hidden_dim // config.get("num_heads", 12))

        # Multi-resolution hash encoding
        hash_output_dim = hidden_dim
        self.hash_encoder = MultiResolutionHashEncoding(
            n_levels=hash_levels,
            n_features=hash_features,
            table_size=hash_table_size,
            resolutions=hash_resolutions,
            output_dim=hash_output_dim,
        )

        # Gated fusion
        self.gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.Sigmoid(),
        )

        # Simple positional embedding for additive encoding
        self.spatial_proj = nn.Sequential(
            nn.Linear(2, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
        )

    def forward(
        self, coords: torch.Tensor
    ) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        """
        Compute HSPE.

        Args:
            coords: Spatial coordinates (batch, n_spots, 2) in [0, 1]

        Returns:
            spatial_embedding: Additive spatial embedding (batch, n_spots, hidden_dim)
            rope_params: (cos, sin) for RoPE application in attention
        """
        # Simple spatial projection (additive embedding)
        spatial_embed = self.spatial_proj(coords)

        # Multi-resolution hash encoding
        hash_embed = self.hash_encoder(coords)

        # Gated fusion of spatial projection and hash encoding
        gate_input = torch.cat([spatial_embed, hash_embed], dim=-1)
        gate = self.gate(gate_input)
        fused_embed = gate * spatial_embed + (1 - gate) * hash_embed

        # RoPE parameters (to be applied in attention)
        rope_cos, rope_sin = self.rope(coords)

        return fused_embed, (rope_cos, rope_sin)


class GeneTokenEmbedding(nn.Module):
    """
    Gene expression embedding using adaptive binning.
    Maps discretized gene expression values to dense vectors.
    """

    def __init__(
        self,
        num_genes: int = 2000,
        num_bins: int = 64,
        hidden_dim: int = 768,
        dropout: float = 0.1,
    ):
        """
        Args:
            num_genes: Number of genes (HVGs)
            num_bins: Number of expression bins
            hidden_dim: Output embedding dimension
            dropout: Dropout rate
        """
        super().__init__()
        self.num_genes = num_genes
        self.num_bins = num_bins
        self.hidden_dim = hidden_dim

        # Bin embedding: maps bin index to a vector
        self.bin_embedding = nn.Embedding(num_bins + 1, hidden_dim, padding_idx=0)

        # Gene identity embedding: each gene has a learned embedding
        self.gene_embedding = nn.Embedding(num_genes, hidden_dim)

        # Combination layer
        self.combine = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.LayerNorm(hidden_dim),
            nn.Dropout(dropout),
        )

        # CLS token for aggregation
        self.cls_token = nn.Parameter(torch.randn(1, 1, hidden_dim) * 0.02)

    def forward(
        self,
        expression: torch.Tensor,
        gene_indices: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Embed gene expression values.

        Args:
            expression: Binned expression values (batch, n_genes) or (batch, n_spots, n_genes)
            gene_indices: Gene index mapping (optional, defaults to 0..n_genes-1)

        Returns:
            Gene embeddings (batch, n_spots, hidden_dim) or (batch, hidden_dim)
        """
        is_3d = expression.dim() == 3

        if is_3d:
            batch_size, n_spots, n_genes = expression.shape
        else:
            batch_size, n_genes = expression.shape
            n_spots = 1
            expression = expression.unsqueeze(1)  # (batch, 1, n_genes)

        # Bin embeddings
        expr_long = expression.long().clamp(0, self.num_bins)
        bin_emb = self.bin_embedding(expr_long)  # (batch, n_spots, n_genes, hidden_dim)

        # Gene identity embeddings
        if gene_indices is None:
            gene_indices = torch.arange(n_genes, device=expression.device)
        gene_emb = self.gene_embedding(gene_indices)  # (n_genes, hidden_dim)
        gene_emb = gene_emb.unsqueeze(0).unsqueeze(0).expand(
            batch_size, n_spots, -1, -1
        )

        # Combine bin and gene embeddings
        combined = torch.cat([bin_emb, gene_emb], dim=-1)
        combined = self.combine(combined)  # (batch, n_spots, n_genes, hidden_dim)

        # Aggregate across genes (mean pooling)
        # Each spot gets one hidden_dim vector representing all its gene expression
        spot_embedding = combined.mean(dim=2)  # (batch, n_spots, hidden_dim)

        if not is_3d:
            spot_embedding = spot_embedding.squeeze(1)  # (batch, hidden_dim)

        return spot_embedding


class MultiScaleSpatialAttention(nn.Module):
    """
    Multi-Scale Spatial Attention (MSSA).
    Combines local window attention (K-NN based) with global sparse attention.
    """

    def __init__(
        self,
        hidden_dim: int = 768,
        num_heads: int = 12,
        dropout: float = 0.1,
        local_k: int = 20,
        num_global_tokens: int = 256,
        use_rope: bool = True,
    ):
        """
        Args:
            hidden_dim: Hidden dimension
            num_heads: Number of attention heads
            dropout: Attention dropout
            local_k: Number of local neighbors for window attention
            num_global_tokens: Number of global summary tokens
            use_rope: Whether to apply 2D-RoPE
        """
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        self.local_k = local_k
        self.num_global_tokens = num_global_tokens
        self.use_rope = use_rope
        self.scale = self.head_dim ** -0.5

        # QKV projections for local attention
        self.q_proj = nn.Linear(hidden_dim, hidden_dim)
        self.k_proj = nn.Linear(hidden_dim, hidden_dim)
        self.v_proj = nn.Linear(hidden_dim, hidden_dim)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)

        # Global attention components
        self.global_q_proj = nn.Linear(hidden_dim, hidden_dim)
        self.global_k_proj = nn.Linear(hidden_dim, hidden_dim)
        self.global_v_proj = nn.Linear(hidden_dim, hidden_dim)
        self.global_out_proj = nn.Linear(hidden_dim, hidden_dim)

        # Learnable global tokens (cluster centroids in feature space)
        self.global_tokens = nn.Parameter(
            torch.randn(1, num_global_tokens, hidden_dim) * 0.02
        )

        # Cross-attention from global to local
        self.cross_q_proj = nn.Linear(hidden_dim, hidden_dim)
        self.cross_k_proj = nn.Linear(hidden_dim, hidden_dim)
        self.cross_v_proj = nn.Linear(hidden_dim, hidden_dim)
        self.cross_out_proj = nn.Linear(hidden_dim, hidden_dim)

        # Gating for combining local and global
        self.gate_proj = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.Sigmoid(),
        )

        self.attn_dropout = nn.Dropout(dropout)

    def _local_attention(
        self,
        x: torch.Tensor,
        neighbor_indices: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        rope_params: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> torch.Tensor:
        """
        Local window attention based on spatial K-NN.

        Args:
            x: Input features (batch, n_spots, hidden_dim)
            neighbor_indices: K-NN indices (batch, n_spots, K)
            attention_mask: Valid spot mask (batch, n_spots)
            rope_params: Optional (cos, sin) for 2D-RoPE

        Returns:
            Local attention output (batch, n_spots, hidden_dim)
        """
        batch_size, n_spots, _ = x.shape
        K = neighbor_indices.shape[2]

        # Q for each spot
        q = self.q_proj(x)  # (batch, n_spots, hidden_dim)

        # Gather K and V for neighbors
        # Expand neighbor_indices for gathering
        nb_idx = neighbor_indices.clamp(0, n_spots - 1)
        nb_idx_expanded = nb_idx.unsqueeze(-1).expand(-1, -1, -1, self.hidden_dim)

        # Gather neighbor features
        x_expanded = x.unsqueeze(2).expand(-1, -1, K, -1)
        k_neighbors = torch.gather(
            x.unsqueeze(1).expand(-1, n_spots, -1, -1),
            2,
            nb_idx_expanded,
        )
        v_neighbors = k_neighbors.clone()

        k_neighbors = self.k_proj(k_neighbors)
        v_neighbors = self.v_proj(v_neighbors)

        # Reshape for multi-head attention
        q = q.view(batch_size, n_spots, self.num_heads, self.head_dim).transpose(1, 2)
        k_neighbors = k_neighbors.view(
            batch_size, n_spots, K, self.num_heads, self.head_dim
        ).permute(0, 3, 1, 2, 4)
        v_neighbors = v_neighbors.view(
            batch_size, n_spots, K, self.num_heads, self.head_dim
        ).permute(0, 3, 1, 2, 4)

        # Apply RoPE if available
        if self.use_rope and rope_params is not None:
            rope_cos, rope_sin = rope_params
            q, _ = apply_rope_2d(q, q, rope_cos, rope_sin)

        # Compute attention: q (batch, heads, n_spots, head_dim) x k (batch, heads, n_spots, K, head_dim)
        q_expanded = q.unsqueeze(3)  # (batch, heads, n_spots, 1, head_dim)
        attn_scores = (q_expanded * k_neighbors).sum(-1) * self.scale
        # attn_scores: (batch, heads, n_spots, K)

        # Mask invalid neighbors
        if attention_mask is not None:
            nb_mask = torch.gather(
                attention_mask.unsqueeze(1).expand(-1, n_spots, -1),
                2,
                nb_idx,
            )
            nb_mask = nb_mask.unsqueeze(1).expand(-1, self.num_heads, -1, -1)
            attn_scores = attn_scores.masked_fill(~nb_mask, float("-inf"))

        attn_weights = F.softmax(attn_scores, dim=-1)
        attn_weights = self.attn_dropout(attn_weights)

        # Weighted sum of values
        attn_weights_expanded = attn_weights.unsqueeze(-1)
        local_out = (attn_weights_expanded * v_neighbors).sum(dim=3)
        # local_out: (batch, heads, n_spots, head_dim)

        local_out = local_out.transpose(1, 2).contiguous().view(
            batch_size, n_spots, self.hidden_dim
        )
        local_out = self.out_proj(local_out)

        return local_out

    def _global_attention(
        self, x: torch.Tensor, attention_mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Global sparse attention using learnable global tokens.

        1. Global tokens attend to all local tokens (summarize)
        2. Local tokens attend to updated global tokens (broadcast)

        Args:
            x: Input features (batch, n_spots, hidden_dim)
            attention_mask: Valid spot mask (batch, n_spots)

        Returns:
            Global context (batch, n_spots, hidden_dim)
        """
        batch_size, n_spots, _ = x.shape

        # Expand global tokens
        global_tokens = self.global_tokens.expand(batch_size, -1, -1)

        # Step 1: Global tokens attend to local tokens
        gq = self.global_q_proj(global_tokens)
        gk = self.global_k_proj(x)
        gv = self.global_v_proj(x)

        gq = gq.view(
            batch_size, self.num_global_tokens, self.num_heads, self.head_dim
        ).transpose(1, 2)
        gk = gk.view(
            batch_size, n_spots, self.num_heads, self.head_dim
        ).transpose(1, 2)
        gv = gv.view(
            batch_size, n_spots, self.num_heads, self.head_dim
        ).transpose(1, 2)

        g_attn = torch.matmul(gq, gk.transpose(-2, -1)) * self.scale

        if attention_mask is not None:
            mask_expanded = attention_mask.unsqueeze(1).unsqueeze(2)
            g_attn = g_attn.masked_fill(~mask_expanded, float("-inf"))

        g_attn = F.softmax(g_attn, dim=-1)
        g_attn = self.attn_dropout(g_attn)

        global_updated = torch.matmul(g_attn, gv)
        global_updated = global_updated.transpose(1, 2).contiguous().view(
            batch_size, self.num_global_tokens, self.hidden_dim
        )
        global_updated = self.global_out_proj(global_updated)

        # Step 2: Local tokens attend to global tokens (cross-attention)
        cq = self.cross_q_proj(x)
        ck = self.cross_k_proj(global_updated)
        cv = self.cross_v_proj(global_updated)

        cq = cq.view(
            batch_size, n_spots, self.num_heads, self.head_dim
        ).transpose(1, 2)
        ck = ck.view(
            batch_size, self.num_global_tokens, self.num_heads, self.head_dim
        ).transpose(1, 2)
        cv = cv.view(
            batch_size, self.num_global_tokens, self.num_heads, self.head_dim
        ).transpose(1, 2)

        c_attn = torch.matmul(cq, ck.transpose(-2, -1)) * self.scale
        c_attn = F.softmax(c_attn, dim=-1)
        c_attn = self.attn_dropout(c_attn)

        cross_out = torch.matmul(c_attn, cv)
        cross_out = cross_out.transpose(1, 2).contiguous().view(
            batch_size, n_spots, self.hidden_dim
        )
        cross_out = self.cross_out_proj(cross_out)

        return cross_out

    def forward(
        self,
        x: torch.Tensor,
        neighbor_indices: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        rope_params: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        use_global: bool = True,
    ) -> torch.Tensor:
        """
        Forward pass combining local and global attention.

        Args:
            x: Input features (batch, n_spots, hidden_dim)
            neighbor_indices: K-NN indices (batch, n_spots, K)
            attention_mask: Valid spot mask (batch, n_spots)
            rope_params: Optional (cos, sin) for 2D-RoPE
            use_global: Whether to use global attention in this layer

        Returns:
            Attention output (batch, n_spots, hidden_dim)
        """
        # Local attention (always applied)
        local_out = self._local_attention(
            x, neighbor_indices, attention_mask, rope_params
        )

        if use_global:
            # Global attention
            global_out = self._global_attention(x, attention_mask)

            # Gated fusion
            gate_input = torch.cat([local_out, global_out], dim=-1)
            gate = self.gate_proj(gate_input)
            output = gate * local_out + (1 - gate) * global_out
        else:
            output = local_out

        return output


class SpaFormersBlock(nn.Module):
    """
    A single SpaFormers transformer block.
    Pre-norm architecture with MSSA and FFN.
    """

    def __init__(
        self,
        hidden_dim: int = 768,
        num_heads: int = 12,
        ffn_dim: int = 3072,
        dropout: float = 0.1,
        attention_dropout: float = 0.1,
        local_k: int = 20,
        num_global_tokens: int = 256,
        use_rope: bool = True,
    ):
        super().__init__()

        # Pre-norm
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.norm2 = nn.LayerNorm(hidden_dim)

        # MSSA
        self.attention = MultiScaleSpatialAttention(
            hidden_dim=hidden_dim,
            num_heads=num_heads,
            dropout=attention_dropout,
            local_k=local_k,
            num_global_tokens=num_global_tokens,
            use_rope=use_rope,
        )

        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(hidden_dim, ffn_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(ffn_dim, hidden_dim),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        x: torch.Tensor,
        neighbor_indices: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        rope_params: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        use_global: bool = True,
    ) -> torch.Tensor:
        """
        Forward pass of one transformer block.

        Args:
            x: Input (batch, n_spots, hidden_dim)
            neighbor_indices: K-NN indices (batch, n_spots, K)
            attention_mask: Valid spot mask (batch, n_spots)
            rope_params: Optional (cos, sin) for RoPE
            use_global: Whether to use global attention

        Returns:
            Output (batch, n_spots, hidden_dim)
        """
        # MSSA with residual
        residual = x
        x = self.norm1(x)
        x = self.attention(
            x,
            neighbor_indices,
            attention_mask=attention_mask,
            rope_params=rope_params,
            use_global=use_global,
        )
        x = x + residual

        # FFN with residual
        residual = x
        x = self.norm2(x)
        x = self.ffn(x)
        x = x + residual

        return x


class StandardAttention(nn.Module):
    """
    Standard full self-attention (for ablation comparison).
    """

    def __init__(
        self,
        hidden_dim: int = 768,
        num_heads: int = 12,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        self.scale = self.head_dim ** -0.5

        self.qkv = nn.Linear(hidden_dim, hidden_dim * 3)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)
        self.attn_dropout = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        batch_size, seq_len, hidden_dim = x.shape

        qkv = self.qkv(x)
        qkv = qkv.reshape(
            batch_size, seq_len, 3, self.num_heads, self.head_dim
        ).permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)

        attn = torch.matmul(q, k.transpose(-2, -1)) * self.scale

        if attention_mask is not None:
            mask = attention_mask.unsqueeze(1).unsqueeze(2)
            attn = attn.masked_fill(~mask, float("-inf"))

        attn = F.softmax(attn, dim=-1)
        attn = self.attn_dropout(attn)

        out = torch.matmul(attn, v)
        out = out.transpose(1, 2).contiguous().view(batch_size, seq_len, hidden_dim)
        out = self.out_proj(out)

        return out


class Sinusoidal2DPE(nn.Module):
    """
    Simple 2D sinusoidal positional encoding (for ablation comparison).
    """

    def __init__(self, hidden_dim: int = 768):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.proj = nn.Linear(hidden_dim, hidden_dim)

    def forward(self, coords: torch.Tensor) -> torch.Tensor:
        """
        Args:
            coords: (batch, n_spots, 2)

        Returns:
            Positional encoding (batch, n_spots, hidden_dim)
        """
        half_dim = self.hidden_dim // 4
        emb = math.log(10000.0) / half_dim
        emb = torch.exp(
            torch.arange(half_dim, device=coords.device, dtype=torch.float32) * -emb
        )

        x = coords[..., 0:1] * emb.unsqueeze(0).unsqueeze(0)
        y = coords[..., 1:2] * emb.unsqueeze(0).unsqueeze(0)

        pe = torch.cat([x.sin(), x.cos(), y.sin(), y.cos()], dim=-1)
        pe = self.proj(pe)

        return pe
