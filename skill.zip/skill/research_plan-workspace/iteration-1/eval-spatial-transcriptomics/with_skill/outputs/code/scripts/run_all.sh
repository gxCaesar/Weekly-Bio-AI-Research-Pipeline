#!/bin/bash
# SpaFormers: Complete experiment pipeline
# Downloads data, pre-trains, fine-tunes, evaluates, and runs ablations
set -e

echo "============================================"
echo "SpaFormers: Full Experiment Pipeline"
echo "============================================"

CONFIG=${1:-configs/default.yaml}
OUTPUT_DIR=${2:-outputs/full_run}
NUM_GPUS=${3:-1}
TASK=${4:-spatial_domain}

echo "Config: $CONFIG"
echo "Output: $OUTPUT_DIR"
echo "GPUs: $NUM_GPUS"
echo "Task: $TASK"
echo ""

# Step 1: Download and preprocess data
echo ">>> Step 1: Data preparation"
python data/download.py --dataset dlpfc --output_dir data/raw/
python data/preprocess.py --input_dir data/raw/dlpfc --output_dir data/processed/dlpfc --config "$CONFIG" --platform visium
echo "Data preparation complete."
echo ""

# Step 2: Pre-training
echo ">>> Step 2: Pre-training"
bash scripts/train.sh "$CONFIG" "$OUTPUT_DIR/pretrain" "$NUM_GPUS" pretrain
echo "Pre-training complete."
echo ""

# Step 3: Fine-tuning
echo ">>> Step 3: Fine-tuning ($TASK)"
PRETRAIN_CKPT="$OUTPUT_DIR/pretrain/best_model.pt"
if [ ! -f "$PRETRAIN_CKPT" ]; then
    PRETRAIN_CKPT="$OUTPUT_DIR/pretrain/last.pt"
fi

if [ "$NUM_GPUS" -gt 1 ]; then
    torchrun --nproc_per_node="$NUM_GPUS" main.py \
        --config "$CONFIG" \
        --mode finetune \
        --task "$TASK" \
        --checkpoint "$PRETRAIN_CKPT" \
        --output_dir "$OUTPUT_DIR/finetune_$TASK"
else
    python main.py \
        --config "$CONFIG" \
        --mode finetune \
        --task "$TASK" \
        --checkpoint "$PRETRAIN_CKPT" \
        --output_dir "$OUTPUT_DIR/finetune_$TASK"
fi
echo "Fine-tuning complete."
echo ""

# Step 4: Evaluation
echo ">>> Step 4: Evaluation"
bash scripts/eval.sh "$OUTPUT_DIR/finetune_$TASK/best_model.pt" "$CONFIG" "$TASK" "$OUTPUT_DIR/eval_$TASK"
echo "Evaluation complete."
echo ""

# Step 5: Run baselines
echo ">>> Step 5: Running baselines"
bash scripts/run_baselines.sh "$OUTPUT_DIR/baselines" "$TASK"
echo "Baselines complete."
echo ""

# Step 6: Run ablation studies
echo ">>> Step 6: Ablation studies"
bash scripts/run_ablation.sh "$OUTPUT_DIR/ablation" "$TASK"
echo "Ablation studies complete."
echo ""

echo "============================================"
echo "All experiments complete!"
echo "Results saved to: $OUTPUT_DIR"
echo "============================================"
