"""
Training callbacks: checkpointing, early stopping, logging.
"""

import json
import logging
import os
from pathlib import Path
from typing import Dict, Optional

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


class CheckpointCallback:
    """Save model checkpoints periodically and keep best model."""

    def __init__(
        self,
        output_dir: str,
        save_every: int = 10,
        save_best: bool = True,
        save_total_limit: int = 5,
        metric_name: str = "ari",
        metric_mode: str = "max",
    ):
        """
        Args:
            output_dir: Directory to save checkpoints
            save_every: Save every N epochs
            save_best: Whether to save the best model
            save_total_limit: Maximum number of checkpoints to keep
            metric_name: Metric name for best model selection
            metric_mode: 'max' or 'min'
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.save_every = save_every
        self.save_best = save_best
        self.save_total_limit = save_total_limit
        self.metric_name = metric_name
        self.metric_mode = metric_mode

        self.best_metric = float("-inf") if metric_mode == "max" else float("inf")
        self.saved_checkpoints = []

    def _is_better(self, current: float) -> bool:
        if self.metric_mode == "max":
            return current > self.best_metric
        return current < self.best_metric

    def save_checkpoint(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: torch.optim.lr_scheduler._LRScheduler,
        epoch: int,
        step: int,
        metrics: Optional[Dict[str, float]] = None,
        config: Optional[dict] = None,
    ) -> Optional[str]:
        """Save a checkpoint."""
        checkpoint = {
            "epoch": epoch,
            "step": step,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "scheduler_state_dict": scheduler.state_dict(),
            "metrics": metrics or {},
            "config": config or {},
        }

        saved_path = None

        # Save periodic checkpoint
        if epoch % self.save_every == 0:
            path = self.output_dir / f"checkpoint_epoch_{epoch}.pt"
            torch.save(checkpoint, str(path))
            self.saved_checkpoints.append(str(path))
            saved_path = str(path)
            logger.info(f"Saved checkpoint: {path}")

            # Remove old checkpoints if over limit
            while len(self.saved_checkpoints) > self.save_total_limit:
                old_path = self.saved_checkpoints.pop(0)
                if os.path.exists(old_path) and "best" not in old_path:
                    os.remove(old_path)

        # Save best model
        if self.save_best and metrics:
            current_metric = metrics.get(self.metric_name, None)
            if current_metric is not None and self._is_better(current_metric):
                self.best_metric = current_metric
                best_path = self.output_dir / "best_model.pt"
                torch.save(checkpoint, str(best_path))
                logger.info(
                    f"New best model (epoch {epoch}): "
                    f"{self.metric_name}={current_metric:.4f}"
                )
                saved_path = str(best_path)

        # Always save last checkpoint
        last_path = self.output_dir / "last.pt"
        torch.save(checkpoint, str(last_path))

        return saved_path


class EarlyStoppingCallback:
    """Stop training when validation metric stops improving."""

    def __init__(
        self,
        patience: int = 10,
        min_delta: float = 0.001,
        metric_name: str = "ari",
        metric_mode: str = "max",
    ):
        """
        Args:
            patience: Number of epochs to wait
            min_delta: Minimum improvement to count as progress
            metric_name: Metric to monitor
            metric_mode: 'max' or 'min'
        """
        self.patience = patience
        self.min_delta = min_delta
        self.metric_name = metric_name
        self.metric_mode = metric_mode

        self.best_metric = float("-inf") if metric_mode == "max" else float("inf")
        self.counter = 0
        self.should_stop = False

    def check(self, metrics: Dict[str, float]) -> bool:
        """
        Check if training should stop.

        Args:
            metrics: Dictionary of current metrics

        Returns:
            True if training should stop
        """
        current = metrics.get(self.metric_name, None)
        if current is None:
            return False

        if self.metric_mode == "max":
            improved = current > self.best_metric + self.min_delta
        else:
            improved = current < self.best_metric - self.min_delta

        if improved:
            self.best_metric = current
            self.counter = 0
        else:
            self.counter += 1

        if self.counter >= self.patience:
            self.should_stop = True
            logger.info(
                f"Early stopping triggered after {self.patience} epochs "
                f"without improvement. Best {self.metric_name}: {self.best_metric:.4f}"
            )

        return self.should_stop


class WandbCallback:
    """Weights & Biases logging callback."""

    def __init__(
        self,
        project: str = "spaformers",
        entity: Optional[str] = None,
        config: Optional[dict] = None,
        name: Optional[str] = None,
    ):
        """
        Args:
            project: W&B project name
            entity: W&B entity/team
            config: Config to log
            name: Run name
        """
        self.enabled = False
        try:
            import wandb

            wandb.init(
                project=project,
                entity=entity,
                config=config or {},
                name=name,
            )
            self.enabled = True
            logger.info(f"W&B initialized: project={project}")
        except ImportError:
            logger.warning("wandb not installed. Logging disabled.")
        except Exception as e:
            logger.warning(f"wandb init failed: {e}. Logging disabled.")

    def log(self, metrics: Dict[str, float], step: int) -> None:
        """Log metrics to W&B."""
        if self.enabled:
            import wandb

            wandb.log(metrics, step=step)

    def finish(self) -> None:
        """Finish W&B run."""
        if self.enabled:
            import wandb

            wandb.finish()
