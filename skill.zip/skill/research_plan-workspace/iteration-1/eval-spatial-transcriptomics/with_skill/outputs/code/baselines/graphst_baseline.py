"""
GraphST baseline: Graph self-supervised contrastive learning for spatial transcriptomics.
Reference: Long et al., Nature Communications, 2023.
"""

import logging
from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


class GCNLayer(nn.Module):
    """Graph Convolutional Network layer."""

    def __init__(self, in_features: int, out_features: int, dropout: float = 0.1):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self, x: torch.Tensor, neighbor_indices: torch.Tensor
    ) -> torch.Tensor:
        """
        Args:
            x: (n_nodes, in_features)
            neighbor_indices: (n_nodes, K)

        Returns:
            Updated features (n_nodes, out_features)
        """
        n_nodes = x.shape[0]
        K = neighbor_indices.shape[1]

        # Aggregate neighbor features (mean)
        nb_idx = neighbor_indices.clamp(0, n_nodes - 1)
        neighbor_feats = x[nb_idx]  # (n_nodes, K, in_features)
        agg = neighbor_feats.mean(dim=1)  # (n_nodes, in_features)

        # Combine self and neighbor
        combined = x + agg
        out = self.linear(combined)
        out = self.dropout(out)

        return out


class GraphSTBaseline(nn.Module):
    """
    GraphST: Graph self-supervised contrastive learning for spatial transcriptomics.
    Uses GCN encoder with augmentation-based contrastive learning.
    """

    def __init__(self, config: dict):
        super().__init__()
        model_cfg = config.get("model", config)

        in_features = model_cfg.get("num_genes", 2000)
        hidden_dim = model_cfg.get("hidden_dim", 512)
        gcn_cfg = model_cfg.get("gcn", {})
        n_layers = gcn_cfg.get("num_gcn_layers", 3)
        contrastive_dim = gcn_cfg.get("contrastive_dim", 128)
        dropout = model_cfg.get("dropout", 0.1)

        # GCN encoder
        layers = []
        current_dim = in_features
        for i in range(n_layers):
            out_dim = hidden_dim
            layers.append(GCNLayer(current_dim, out_dim, dropout))
            current_dim = out_dim

        self.encoder_layers = nn.ModuleList(layers)

        # Contrastive projection head
        self.projector = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, contrastive_dim),
        )

        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, in_features),
        )

        # Classification head
        task_cfg = config.get("tasks", {}).get("spatial_domain", {})
        num_classes = task_cfg.get("num_classes", 7)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, num_classes),
        )

        self.hidden_dim = hidden_dim
        self.temperature = 0.07

        n_params = sum(p.numel() for p in self.parameters())
        logger.info(f"GraphST baseline: {n_params / 1e6:.1f}M parameters")

    def encode(
        self,
        x: torch.Tensor,
        neighbor_indices: torch.Tensor,
    ) -> torch.Tensor:
        """Encode features through GCN layers."""
        h = x
        for layer in self.encoder_layers:
            h = F.elu(layer(h, neighbor_indices))
        return h

    def _augment(
        self,
        x: torch.Tensor,
        drop_rate: float = 0.2,
    ) -> torch.Tensor:
        """Create augmented view by randomly dropping features."""
        mask = torch.bernoulli(torch.ones_like(x) * (1 - drop_rate))
        return x * mask

    def _contrastive_loss(
        self, z1: torch.Tensor, z2: torch.Tensor
    ) -> torch.Tensor:
        """Compute InfoNCE contrastive loss between two views."""
        z1 = F.normalize(z1, dim=-1)
        z2 = F.normalize(z2, dim=-1)

        sim = torch.matmul(z1, z2.t()) / self.temperature
        n = z1.shape[0]

        labels = torch.arange(n, device=z1.device)
        loss = (F.cross_entropy(sim, labels) + F.cross_entropy(sim.t(), labels)) / 2

        return loss

    def forward(
        self,
        expression: torch.Tensor,
        spatial_coords: torch.Tensor,
        neighbor_indices: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass.

        Args:
            expression: (n_nodes, n_genes)
            spatial_coords: (n_nodes, 2)
            neighbor_indices: (n_nodes, K)
            labels: Optional labels

        Returns:
            Output dictionary
        """
        if expression.dim() == 3:
            expression = expression.squeeze(0)
            neighbor_indices = neighbor_indices.squeeze(0)
            if labels is not None:
                labels = labels.squeeze(0)

        # Encode original view
        z = self.encode(expression, neighbor_indices)

        # Create augmented view and encode
        x_aug = self._augment(expression)
        z_aug = self.encode(x_aug, neighbor_indices)

        # Project for contrastive loss
        p1 = self.projector(z)
        p2 = self.projector(z_aug)

        # Contrastive loss (sample a subset for efficiency)
        n = z.shape[0]
        max_samples = min(n, 1024)
        indices = torch.randperm(n)[:max_samples]
        contrastive_loss = self._contrastive_loss(p1[indices], p2[indices])

        # Reconstruct
        x_recon = self.decoder(z)
        recon_loss = F.mse_loss(x_recon, expression)

        # Classify
        logits = self.classifier(z)

        output = {
            "features": z,
            "logits": logits,
            "predictions": logits.argmax(dim=-1),
            "contrastive_loss": contrastive_loss,
            "recon_loss": recon_loss,
        }

        total_loss = contrastive_loss + recon_loss

        if labels is not None:
            cls_loss = F.cross_entropy(logits, labels, ignore_index=-1)
            total_loss = total_loss + cls_loss
            output["cls_loss"] = cls_loss

        output["loss"] = total_loss

        return output
