"""
PyTorch Dataset classes for SpaFormers.
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset
import anndata as ad
from scipy.sparse import issparse

logger = logging.getLogger(__name__)


class SpatialTranscriptomicsDataset(Dataset):
    """
    Dataset for fine-tuning SpaFormers on downstream tasks.

    Each sample is a single spatial spot/cell with:
    - Gene expression (binned or continuous)
    - Spatial coordinates
    - Spatial neighbor indices
    - Optional: labels for supervised tasks
    """

    def __init__(
        self,
        adata: ad.AnnData,
        task: str = "spatial_domain",
        use_hvg: bool = True,
        use_binned: bool = True,
        label_key: Optional[str] = None,
        max_neighbors: int = 20,
    ):
        """
        Args:
            adata: Preprocessed AnnData object
            task: Task type ('spatial_domain', 'gene_imputation', 'cell_annotation', 'cell_deconvolution')
            use_hvg: Whether to subset to highly variable genes
            use_binned: Whether to use binned expression values
            label_key: Key in adata.obs for labels
            max_neighbors: Maximum number of spatial neighbors
        """
        super().__init__()
        self.task = task
        self.use_binned = use_binned
        self.max_neighbors = max_neighbors

        # Subset to HVGs if requested
        if use_hvg and "highly_variable" in adata.var:
            self.gene_names = adata.var_names[adata.var["highly_variable"]].tolist()
            adata_sub = adata[:, adata.var["highly_variable"]].copy()
        else:
            self.gene_names = adata.var_names.tolist()
            adata_sub = adata.copy()

        # Expression data
        if use_binned and "binned" in adata_sub.layers:
            X = adata_sub.layers["binned"]
        elif "normalized" in adata_sub.layers:
            X = adata_sub.layers["normalized"]
        else:
            X = adata_sub.X

        if issparse(X):
            X = X.toarray()
        self.expression = X.astype(np.float32)

        # Raw counts for gene imputation task
        if "counts" in adata_sub.layers:
            counts = adata_sub.layers["counts"]
            if issparse(counts):
                counts = counts.toarray()
            self.counts = counts.astype(np.float32)
        else:
            self.counts = self.expression.copy()

        # Spatial coordinates
        if "spatial_normalized" in adata_sub.obsm:
            self.spatial_coords = adata_sub.obsm["spatial_normalized"].astype(np.float32)
        elif "spatial" in adata_sub.obsm:
            self.spatial_coords = adata_sub.obsm["spatial"].astype(np.float32)
        else:
            raise ValueError("No spatial coordinates found in adata.obsm")

        # Spatial neighbors
        if "spatial_neighbors" in adata_sub.obsm:
            self.neighbor_indices = adata_sub.obsm["spatial_neighbors"][:, :max_neighbors].astype(
                np.int64
            )
        else:
            logger.warning("No spatial neighbor indices found; building from coords")
            self._build_neighbors(max_neighbors)

        # Labels
        self.labels = None
        if label_key is not None and label_key in adata_sub.obs:
            labels = adata_sub.obs[label_key]
            if labels.dtype == "category":
                self.label_categories = labels.cat.categories.tolist()
                self.labels = labels.cat.codes.values.astype(np.int64)
            else:
                self.labels = labels.values.astype(np.float32)

        # Cell type proportions for deconvolution
        self.proportions = None
        if task == "cell_deconvolution" and "cell_type_proportions" in adata_sub.obsm:
            self.proportions = adata_sub.obsm["cell_type_proportions"].astype(np.float32)

        self.n_spots = self.expression.shape[0]
        self.n_genes = self.expression.shape[1]
        logger.info(
            f"Dataset created: {self.n_spots} spots, {self.n_genes} genes, task={task}"
        )

    def _build_neighbors(self, k: int) -> None:
        """Build K-NN neighbor indices from spatial coordinates."""
        from sklearn.neighbors import NearestNeighbors

        nn = NearestNeighbors(n_neighbors=k, metric="euclidean")
        nn.fit(self.spatial_coords)
        _, indices = nn.kneighbors(self.spatial_coords)
        self.neighbor_indices = indices.astype(np.int64)

    def __len__(self) -> int:
        return self.n_spots

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = {
            "expression": torch.from_numpy(self.expression[idx]),
            "spatial_coords": torch.from_numpy(self.spatial_coords[idx]),
            "neighbor_indices": torch.from_numpy(self.neighbor_indices[idx]),
            "index": torch.tensor(idx, dtype=torch.long),
        }

        if self.labels is not None:
            item["labels"] = torch.tensor(self.labels[idx])

        if self.proportions is not None:
            item["proportions"] = torch.from_numpy(self.proportions[idx])

        if self.task == "gene_imputation":
            item["counts"] = torch.from_numpy(self.counts[idx])

        return item


class PretrainSTDataset(Dataset):
    """
    Dataset for SpaFormers pre-training.
    Returns spatial patches (groups of spatially neighboring spots) for
    efficient batch processing and spatial context modeling.
    """

    def __init__(
        self,
        adata_list: List[ad.AnnData],
        patch_size: int = 256,
        max_neighbors: int = 20,
        mask_ratio: float = 0.3,
        use_binned: bool = True,
    ):
        """
        Args:
            adata_list: List of preprocessed AnnData objects (one per sample/slice)
            patch_size: Number of spots per spatial patch
            max_neighbors: Maximum number of spatial neighbors per spot
            mask_ratio: Fraction of genes to mask for SCGP
            use_binned: Whether to use binned expression values
        """
        super().__init__()
        self.patch_size = patch_size
        self.max_neighbors = max_neighbors
        self.mask_ratio = mask_ratio
        self.use_binned = use_binned

        self.samples = []
        self._prepare_samples(adata_list)

        logger.info(
            f"PretrainDataset: {len(self.samples)} patches from "
            f"{len(adata_list)} samples, patch_size={patch_size}"
        )

    def _prepare_samples(self, adata_list: List[ad.AnnData]) -> None:
        """Extract spatial patches from each AnnData."""
        for sample_idx, adata in enumerate(adata_list):
            # Get HVG subset
            if "highly_variable" in adata.var:
                adata_sub = adata[:, adata.var["highly_variable"]].copy()
            else:
                adata_sub = adata.copy()

            # Expression
            if self.use_binned and "binned" in adata_sub.layers:
                X = adata_sub.layers["binned"]
            elif "normalized" in adata_sub.layers:
                X = adata_sub.layers["normalized"]
            else:
                X = adata_sub.X

            if issparse(X):
                X = X.toarray()
            X = X.astype(np.float32)

            # Spatial coords
            if "spatial_normalized" in adata_sub.obsm:
                coords = adata_sub.obsm["spatial_normalized"].astype(np.float32)
            else:
                coords = adata_sub.obsm["spatial"].astype(np.float32)

            # Neighbors
            if "spatial_neighbors" in adata_sub.obsm:
                neighbors = adata_sub.obsm["spatial_neighbors"][
                    :, : self.max_neighbors
                ].astype(np.int64)
            else:
                from sklearn.neighbors import NearestNeighbors

                nn = NearestNeighbors(
                    n_neighbors=self.max_neighbors, metric="euclidean"
                )
                nn.fit(coords)
                _, neighbors = nn.kneighbors(coords)
                neighbors = neighbors.astype(np.int64)

            n_spots = X.shape[0]

            # Create patches via spatial clustering
            if n_spots <= self.patch_size:
                # Small sample: use entire sample as one patch
                self.samples.append(
                    {
                        "expression": X,
                        "spatial_coords": coords,
                        "neighbor_indices": neighbors,
                        "sample_idx": sample_idx,
                        "n_spots": n_spots,
                    }
                )
            else:
                # Large sample: create overlapping spatial patches
                from sklearn.cluster import MiniBatchKMeans

                n_patches = max(1, n_spots // self.patch_size)
                kmeans = MiniBatchKMeans(
                    n_clusters=n_patches, random_state=42, batch_size=1024
                )
                cluster_labels = kmeans.fit_predict(coords)

                for c in range(n_patches):
                    mask = cluster_labels == c
                    patch_indices = np.where(mask)[0]

                    # Ensure minimum patch size
                    if len(patch_indices) < 32:
                        continue

                    # Truncate if too large
                    if len(patch_indices) > self.patch_size:
                        patch_indices = np.random.choice(
                            patch_indices, self.patch_size, replace=False
                        )

                    patch_X = X[patch_indices]
                    patch_coords = coords[patch_indices]

                    # Rebuild local neighbors within patch
                    from sklearn.neighbors import NearestNeighbors

                    k = min(self.max_neighbors, len(patch_indices) - 1)
                    nn = NearestNeighbors(n_neighbors=k, metric="euclidean")
                    nn.fit(patch_coords)
                    _, patch_neighbors = nn.kneighbors(patch_coords)

                    self.samples.append(
                        {
                            "expression": patch_X,
                            "spatial_coords": patch_coords,
                            "neighbor_indices": patch_neighbors.astype(np.int64),
                            "sample_idx": sample_idx,
                            "n_spots": len(patch_indices),
                        }
                    )

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        sample = self.samples[idx]
        n = sample["n_spots"]
        n_genes = sample["expression"].shape[1]

        # Generate mask for SCGP
        mask = np.zeros(n_genes, dtype=np.bool_)
        n_mask = int(n_genes * self.mask_ratio)
        mask_indices = np.random.choice(n_genes, n_mask, replace=False)
        mask[mask_indices] = True

        return {
            "expression": torch.from_numpy(sample["expression"]),
            "spatial_coords": torch.from_numpy(sample["spatial_coords"]),
            "neighbor_indices": torch.from_numpy(sample["neighbor_indices"]),
            "gene_mask": torch.from_numpy(mask),
            "n_spots": torch.tensor(n, dtype=torch.long),
        }


def load_dataset(
    data_dir: str,
    dataset_name: str,
    task: str = "spatial_domain",
    config: Optional[dict] = None,
    split: str = "all",
    label_key: Optional[str] = None,
) -> SpatialTranscriptomicsDataset:
    """
    Load a preprocessed dataset.

    Args:
        data_dir: Directory containing processed h5ad files
        dataset_name: Name of the dataset
        task: Task type
        config: Configuration dictionary
        split: Data split ('train', 'val', 'test', 'all')
        label_key: Key for labels in adata.obs

    Returns:
        SpatialTranscriptomicsDataset
    """
    data_dir = Path(data_dir) / dataset_name

    # Detect label key based on dataset
    label_map = {
        "dlpfc": "ground_truth",
        "mouse_brain_visium": "region",
        "breast_cancer": "annotation",
        "merfish_mouse_brain": "cell_type",
    }

    if label_key is None:
        label_key = label_map.get(dataset_name, None)

    h5ad_files = sorted(data_dir.glob("*.h5ad"))
    if not h5ad_files:
        raise FileNotFoundError(f"No h5ad files found in {data_dir}")

    # Load and concatenate
    adatas = [ad.read_h5ad(str(f)) for f in h5ad_files]

    if len(adatas) == 1:
        adata = adatas[0]
    else:
        adata = ad.concat(adatas, join="inner")

    max_neighbors = 20
    if config is not None:
        max_neighbors = config.get("model", {}).get("mssa", {}).get("local_k", 20)

    dataset = SpatialTranscriptomicsDataset(
        adata=adata,
        task=task,
        use_hvg=True,
        use_binned=True,
        label_key=label_key,
        max_neighbors=max_neighbors,
    )

    return dataset
