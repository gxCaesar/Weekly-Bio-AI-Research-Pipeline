"""
Task-specific heads for downstream fine-tuning.

Each head takes the encoder's spot-level representations and
produces task-specific outputs.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class SpatialDomainHead(nn.Module):
    """
    Head for spatial domain identification / clustering.

    Supports both supervised classification and unsupervised clustering.

    Args:
        d_model: Input embedding dimension.
        n_domains: Number of spatial domains (for supervised mode).
        hidden_dim: Hidden layer dimension.
        use_clustering: If True, output embeddings for clustering.
    """

    def __init__(
        self,
        d_model: int = 512,
        n_domains: int = 7,
        hidden_dim: int = 256,
        use_clustering: bool = False,
    ):
        super().__init__()
        self.use_clustering = use_clustering

        self.head = nn.Sequential(
            nn.Linear(d_model, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
        )

        if not use_clustering:
            self.classifier = nn.Linear(hidden_dim, n_domains)
        else:
            # Output normalized embeddings for clustering
            self.projector = nn.Linear(hidden_dim, hidden_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Spot representations [n_spots, d_model].

        Returns:
            If supervised: logits [n_spots, n_domains].
            If clustering: normalized embeddings [n_spots, hidden_dim].
        """
        h = self.head(x)

        if self.use_clustering:
            h = self.projector(h)
            return F.normalize(h, dim=-1)
        else:
            return self.classifier(h)


class CellTypeAnnotationHead(nn.Module):
    """
    Head for cell type annotation and deconvolution.

    In annotation mode: outputs cell type probabilities.
    In deconvolution mode: outputs cell type proportions per spot.

    Args:
        d_model: Input embedding dimension.
        n_cell_types: Number of cell types.
        mode: 'annotation' or 'deconvolution'.
    """

    def __init__(
        self,
        d_model: int = 512,
        n_cell_types: int = 20,
        mode: str = "annotation",
    ):
        super().__init__()
        self.mode = mode

        self.shared = nn.Sequential(
            nn.Linear(d_model, 256),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(256, 128),
            nn.ReLU(),
        )

        if mode == "annotation":
            self.output = nn.Linear(128, n_cell_types)
        elif mode == "deconvolution":
            # Softmax output for proportions
            self.output = nn.Sequential(
                nn.Linear(128, n_cell_types),
                nn.Softmax(dim=-1),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Spot representations [n_spots, d_model].

        Returns:
            annotation: logits [n_spots, n_cell_types].
            deconvolution: proportions [n_spots, n_cell_types].
        """
        h = self.shared(x)
        return self.output(h)


class GeneExpressionPredictionHead(nn.Module):
    """
    Head for gene expression prediction / imputation.

    Predicts expression values for masked genes using the spot
    representation and gene identity embeddings.

    Args:
        d_model: Input embedding dimension.
        n_genes: Number of genes.
        vocab_size: Token vocabulary size (for classification mode).
        mode: 'regression' or 'classification'.
    """

    def __init__(
        self,
        d_model: int = 512,
        n_genes: int = 5000,
        vocab_size: int = 67,
        mode: str = "classification",
    ):
        super().__init__()
        self.mode = mode
        self.n_genes = n_genes

        # Spot-gene interaction
        self.spot_proj = nn.Linear(d_model, d_model)
        self.gene_proj = nn.Linear(d_model, d_model)

        if mode == "classification":
            self.output = nn.Sequential(
                nn.Linear(d_model, d_model),
                nn.GELU(),
                nn.LayerNorm(d_model),
                nn.Linear(d_model, vocab_size),
            )
        elif mode == "regression":
            self.output = nn.Sequential(
                nn.Linear(d_model, d_model),
                nn.GELU(),
                nn.LayerNorm(d_model),
                nn.Linear(d_model, 1),
            )

    def forward(
        self,
        spot_repr: torch.Tensor,
        gene_embeddings: torch.Tensor,
        gene_mask: Optional[torch.BoolTensor] = None,
    ) -> torch.Tensor:
        """
        Predict gene expression.

        Args:
            spot_repr: Spot representations [n_spots, d_model].
            gene_embeddings: Gene identity embeddings [n_genes, d_model].
            gene_mask: Which genes to predict [n_spots, n_genes].

        Returns:
            Predictions [n_spots, n_genes, vocab_size] or [n_spots, n_genes, 1].
        """
        # Project spot and gene representations
        spot_h = self.spot_proj(spot_repr)  # [n_spots, d_model]
        gene_h = self.gene_proj(gene_embeddings)  # [n_genes, d_model]

        # Combine via element-wise product (broadcasting)
        combined = spot_h.unsqueeze(1) * gene_h.unsqueeze(0)
        # [n_spots, n_genes, d_model]

        # Apply output head
        output = self.output(combined)

        if gene_mask is not None:
            # Only return predictions for masked positions
            output = output[gene_mask]

        return output


class SVGDetectionHead(nn.Module):
    """
    Head for spatially variable gene (SVG) detection.

    Computes a spatial variability score for each gene based on
    the learned representations.

    Args:
        d_model: Input embedding dimension.
        n_genes: Number of genes.
    """

    def __init__(self, d_model: int = 512, n_genes: int = 5000):
        super().__init__()

        self.gene_scorer = nn.Sequential(
            nn.Linear(d_model, 256),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(256, 1),
        )

        self.spatial_scorer = nn.Sequential(
            nn.Linear(d_model, 256),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(256, 1),
        )

    def forward(
        self,
        gene_level_repr: torch.Tensor,
        spot_repr: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute SVG scores.

        Args:
            gene_level_repr: Gene-level representations [n_spots, n_genes, d_model].
            spot_repr: Spot-level representations [n_spots, d_model].

        Returns:
            SVG scores [n_genes].
        """
        # Gene-level spatial variability scores
        gene_scores = self.gene_scorer(gene_level_repr)  # [n_spots, n_genes, 1]
        gene_scores = gene_scores.squeeze(-1)  # [n_spots, n_genes]

        # Compute spatial variance of gene scores
        gene_spatial_var = gene_scores.var(dim=0)  # [n_genes]

        return gene_spatial_var


class SpatialCommunicationHead(nn.Module):
    """
    Head for spatial cell-cell communication inference.

    Uses spot-level representations and spatial graph to infer
    ligand-receptor interaction strengths.

    Args:
        d_model: Input embedding dimension.
        n_lr_pairs: Number of ligand-receptor pairs.
    """

    def __init__(self, d_model: int = 512, n_lr_pairs: int = 1000):
        super().__init__()

        self.sender_proj = nn.Linear(d_model, 256)
        self.receiver_proj = nn.Linear(d_model, 256)
        self.interaction_scorer = nn.Sequential(
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, n_lr_pairs),
            nn.Sigmoid(),
        )

    def forward(
        self,
        spot_repr: torch.Tensor,
        edge_index: torch.Tensor,
    ) -> torch.Tensor:
        """
        Infer cell-cell communication scores.

        Args:
            spot_repr: Spot representations [n_spots, d_model].
            edge_index: Spatial graph edges [2, n_edges].

        Returns:
            Communication scores [n_edges, n_lr_pairs].
        """
        src, dst = edge_index

        sender_h = self.sender_proj(spot_repr[src])
        receiver_h = self.receiver_proj(spot_repr[dst])

        combined = torch.cat([sender_h, receiver_h], dim=-1)
        scores = self.interaction_scorer(combined)

        return scores
