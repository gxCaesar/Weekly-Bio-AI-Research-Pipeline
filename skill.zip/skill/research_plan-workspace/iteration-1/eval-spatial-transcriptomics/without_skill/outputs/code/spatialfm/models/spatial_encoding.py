"""
Spatial encoding modules for SpatialFM.

Provides multiple strategies for encoding spatial information:
- Fourier-based absolute position encoding
- Relative spatial bias for attention
- Graph structure encoding (degree, shortest path)
"""

import math
import numpy as np
import torch
import torch.nn as nn
from torch_geometric.utils import degree
from typing import Optional


class FourierSpatialEncoding(nn.Module):
    """
    Fourier feature encoding for 2D spatial coordinates.

    Maps (x, y) coordinates to high-dimensional features using
    sinusoidal functions at multiple frequency scales. This enables
    the model to capture spatial patterns at different resolutions.

    Args:
        d_model: Output embedding dimension.
        n_frequencies: Number of frequency bands.
        max_freq: Maximum frequency (controls finest spatial scale).
        learnable: If True, frequency parameters are learnable.
    """

    def __init__(
        self,
        d_model: int = 512,
        n_frequencies: int = 64,
        max_freq: float = 10.0,
        learnable: bool = False,
    ):
        super().__init__()
        self.d_model = d_model
        self.n_frequencies = n_frequencies

        # Generate frequency bands (log-spaced)
        freqs = torch.logspace(0, math.log10(max_freq), n_frequencies)

        if learnable:
            self.freqs = nn.Parameter(freqs)
        else:
            self.register_buffer("freqs", freqs)

        # Project from 4*n_frequencies (sin/cos for x and y) to d_model
        self.projection = nn.Linear(4 * n_frequencies, d_model)

    def forward(self, coords: torch.Tensor) -> torch.Tensor:
        """
        Encode spatial coordinates.

        Args:
            coords: Spatial coordinates [batch_size, 2] or [n_spots, 2].

        Returns:
            Spatial embeddings [batch_size, d_model] or [n_spots, d_model].
        """
        x, y = coords[:, 0:1], coords[:, 1:2]  # [N, 1]

        # Compute Fourier features
        x_freq = x * self.freqs.unsqueeze(0) * 2 * math.pi  # [N, n_freq]
        y_freq = y * self.freqs.unsqueeze(0) * 2 * math.pi  # [N, n_freq]

        features = torch.cat(
            [torch.sin(x_freq), torch.cos(x_freq),
             torch.sin(y_freq), torch.cos(y_freq)],
            dim=-1,
        )  # [N, 4*n_freq]

        return self.projection(features)  # [N, d_model]


class RelativeSpatialBias(nn.Module):
    """
    Relative spatial bias for attention computation.

    Computes an attention bias based on the pairwise spatial distance
    and direction between spots/cells. This is added to the attention
    logits before softmax.

    Args:
        n_heads: Number of attention heads.
        n_distance_bins: Number of distance bins for discretization.
        n_angle_bins: Number of angle bins for direction encoding.
        max_distance: Maximum distance for binning.
    """

    def __init__(
        self,
        n_heads: int = 8,
        n_distance_bins: int = 64,
        n_angle_bins: int = 8,
        max_distance: float = 1.0,
    ):
        super().__init__()
        self.n_heads = n_heads
        self.n_distance_bins = n_distance_bins
        self.n_angle_bins = n_angle_bins
        self.max_distance = max_distance

        # Learnable bias table
        self.distance_bias = nn.Embedding(n_distance_bins, n_heads)
        self.angle_bias = nn.Embedding(n_angle_bins, n_heads)

    def forward(
        self, coords: torch.Tensor, attention_mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Compute spatial attention bias.

        Args:
            coords: Spatial coordinates [n_spots, 2].
            attention_mask: Optional mask [n_spots, n_spots].

        Returns:
            Spatial bias [n_heads, n_spots, n_spots].
        """
        n = coords.shape[0]

        # Pairwise distances
        diff = coords.unsqueeze(0) - coords.unsqueeze(1)  # [N, N, 2]
        distances = torch.norm(diff, dim=-1)  # [N, N]

        # Discretize distances
        dist_bins = torch.clamp(
            (distances / self.max_distance * self.n_distance_bins).long(),
            0,
            self.n_distance_bins - 1,
        )
        dist_bias = self.distance_bias(dist_bins)  # [N, N, n_heads]

        # Compute angles
        angles = torch.atan2(diff[:, :, 1], diff[:, :, 0])  # [N, N]
        angle_bins = (
            ((angles + math.pi) / (2 * math.pi) * self.n_angle_bins).long()
            % self.n_angle_bins
        )
        ang_bias = self.angle_bias(angle_bins)  # [N, N, n_heads]

        # Combine biases: [n_heads, N, N]
        total_bias = (dist_bias + ang_bias).permute(2, 0, 1)

        if attention_mask is not None:
            total_bias = total_bias.masked_fill(
                ~attention_mask.unsqueeze(0), float("-inf")
            )

        return total_bias


class GraphStructureEncoding(nn.Module):
    """
    Graph structure encoding inspired by Graphormer.

    Encodes graph-level structural features:
    - Node degree encoding
    - Shortest path distance encoding (optional, expensive)

    Args:
        d_model: Embedding dimension.
        max_degree: Maximum node degree to encode.
        max_path_length: Maximum shortest path length (if used).
        use_shortest_path: Whether to compute shortest path encoding.
    """

    def __init__(
        self,
        d_model: int = 512,
        max_degree: int = 50,
        max_path_length: int = 10,
        use_shortest_path: bool = False,
    ):
        super().__init__()
        self.d_model = d_model
        self.use_shortest_path = use_shortest_path

        # Degree encoding
        self.in_degree_encoder = nn.Embedding(max_degree + 1, d_model)
        self.out_degree_encoder = nn.Embedding(max_degree + 1, d_model)

        # Shortest path encoding (optional)
        if use_shortest_path:
            self.path_encoder = nn.Embedding(max_path_length + 1, 1)
            self.max_path_length = max_path_length

    def forward(
        self,
        edge_index: torch.Tensor,
        n_nodes: int,
    ) -> torch.Tensor:
        """
        Compute graph structure encodings.

        Args:
            edge_index: Graph edge indices [2, n_edges].
            n_nodes: Number of nodes in graph.

        Returns:
            Node-level structure encoding [n_nodes, d_model].
        """
        # Compute node degrees
        in_deg = degree(edge_index[1], num_nodes=n_nodes).long()
        out_deg = degree(edge_index[0], num_nodes=n_nodes).long()

        # Clamp to max degree
        max_deg = self.in_degree_encoder.num_embeddings - 1
        in_deg = torch.clamp(in_deg, max=max_deg)
        out_deg = torch.clamp(out_deg, max=max_deg)

        # Encode degrees
        encoding = self.in_degree_encoder(in_deg) + self.out_degree_encoder(out_deg)

        return encoding


class MultiScaleSpatialEncoding(nn.Module):
    """
    Multi-scale spatial encoding that captures spatial patterns
    at multiple resolutions.

    Combines:
    - Fine-scale Fourier features
    - Coarse-scale Fourier features
    - Graph structure encoding

    Args:
        d_model: Output embedding dimension.
        n_scales: Number of spatial scales.
    """

    def __init__(self, d_model: int = 512, n_scales: int = 4):
        super().__init__()
        self.n_scales = n_scales

        # Fourier encoders at different scales
        self.fourier_encoders = nn.ModuleList([
            FourierSpatialEncoding(
                d_model=d_model // n_scales,
                n_frequencies=32,
                max_freq=10.0 * (2 ** i),
            )
            for i in range(n_scales)
        ])

        # Combine multi-scale features
        self.combine = nn.Linear(d_model, d_model)

    def forward(self, coords: torch.Tensor) -> torch.Tensor:
        """
        Multi-scale spatial encoding.

        Args:
            coords: Spatial coordinates [n_spots, 2].

        Returns:
            Multi-scale spatial embeddings [n_spots, d_model].
        """
        scale_features = []
        for encoder in self.fourier_encoders:
            scale_features.append(encoder(coords))

        combined = torch.cat(scale_features, dim=-1)
        return self.combine(combined)
