"""
Spatial Graph Transformer Encoder for SpatialFM.

Core architecture that combines local message passing on spatial graphs
with global Transformer attention, augmented with spatial position
encodings and graph structure encodings.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import softmax as pyg_softmax
from typing import Optional, Tuple

from spatialfm.models.spatial_encoding import (
    FourierSpatialEncoding,
    RelativeSpatialBias,
    GraphStructureEncoding,
    MultiScaleSpatialEncoding,
)


class GeneEmbedding(nn.Module):
    """
    Embedding layer for gene expression tokens.

    Combines gene identity embeddings with expression value embeddings.

    Args:
        n_genes: Number of genes in the vocabulary.
        vocab_size: Number of expression tokens (bins + special tokens).
        d_model: Embedding dimension.
    """

    def __init__(self, n_genes: int, vocab_size: int, d_model: int = 512):
        super().__init__()
        self.gene_id_embed = nn.Embedding(n_genes, d_model)
        self.expr_embed = nn.Embedding(vocab_size, d_model)
        self.layer_norm = nn.LayerNorm(d_model)

    def forward(
        self, gene_ids: torch.LongTensor, expr_tokens: torch.LongTensor
    ) -> torch.Tensor:
        """
        Embed gene expression tokens.

        Args:
            gene_ids: Gene indices [n_genes].
            expr_tokens: Expression tokens [n_spots, n_genes].

        Returns:
            Gene embeddings [n_spots, n_genes, d_model].
        """
        # Gene identity embedding: shared across all spots
        gene_emb = self.gene_id_embed(gene_ids)  # [n_genes, d_model]
        gene_emb = gene_emb.unsqueeze(0).expand(
            expr_tokens.shape[0], -1, -1
        )  # [n_spots, n_genes, d_model]

        # Expression value embedding
        expr_emb = self.expr_embed(expr_tokens)  # [n_spots, n_genes, d_model]

        # Combine
        combined = gene_emb + expr_emb
        return self.layer_norm(combined)


class SpotAggregation(nn.Module):
    """
    Aggregate gene-level embeddings into spot-level representations.

    Uses attention-based pooling over the gene dimension.

    Args:
        d_model: Model dimension.
        n_heads: Number of attention heads for gene pooling.
    """

    def __init__(self, d_model: int = 512, n_heads: int = 4):
        super().__init__()
        self.attention_pool = nn.MultiheadAttention(
            d_model, n_heads, batch_first=True
        )
        self.cls_token = nn.Parameter(torch.randn(1, 1, d_model))
        self.layer_norm = nn.LayerNorm(d_model)

    def forward(self, gene_embeddings: torch.Tensor) -> torch.Tensor:
        """
        Aggregate gene embeddings to spot embedding.

        Args:
            gene_embeddings: [n_spots, n_genes, d_model].

        Returns:
            Spot embeddings: [n_spots, d_model].
        """
        n_spots = gene_embeddings.shape[0]

        # Prepend CLS token
        cls = self.cls_token.expand(n_spots, -1, -1)
        x = torch.cat([cls, gene_embeddings], dim=1)

        # Self-attention pooling
        attn_out, _ = self.attention_pool(x, x, x)

        # Take CLS token output
        spot_embed = attn_out[:, 0, :]
        return self.layer_norm(spot_embed)


class LocalSpatialAttention(MessagePassing):
    """
    Local attention on the spatial graph via message passing.

    Performs attention-weighted message passing along spatial graph edges,
    enabling efficient local information aggregation.

    Args:
        d_model: Model dimension.
        n_heads: Number of attention heads.
        dropout: Dropout rate.
    """

    def __init__(self, d_model: int = 512, n_heads: int = 8, dropout: float = 0.1):
        super().__init__(aggr="add", node_dim=0)
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)

        self.edge_proj = nn.Linear(1, n_heads)  # Project edge distance
        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        edge_attr: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Local spatial attention via message passing.

        Args:
            x: Node features [n_nodes, d_model].
            edge_index: Edge indices [2, n_edges].
            edge_attr: Edge attributes (distances) [n_edges, 1].

        Returns:
            Updated node features [n_nodes, d_model].
        """
        residual = x
        x = self.layer_norm(x)

        # Compute Q, K, V
        q = self.q_proj(x)
        k = self.k_proj(x)
        v = self.v_proj(x)

        # Message passing
        out = self.propagate(edge_index, q=q, k=k, v=v, edge_attr=edge_attr)
        out = self.out_proj(out)
        out = self.dropout(out)

        return residual + out

    def message(
        self,
        q_i: torch.Tensor,
        k_j: torch.Tensor,
        v_j: torch.Tensor,
        edge_attr: Optional[torch.Tensor],
        index: torch.Tensor,
    ) -> torch.Tensor:
        """Compute attention-weighted messages."""
        # Reshape for multi-head attention
        n_edges = q_i.shape[0]
        q_i = q_i.view(n_edges, self.n_heads, self.head_dim)
        k_j = k_j.view(n_edges, self.n_heads, self.head_dim)
        v_j = v_j.view(n_edges, self.n_heads, self.head_dim)

        # Attention scores
        attn = (q_i * k_j).sum(dim=-1) / math.sqrt(self.head_dim)

        # Add edge distance bias
        if edge_attr is not None:
            edge_bias = self.edge_proj(edge_attr)  # [n_edges, n_heads]
            attn = attn + edge_bias

        # Softmax over incoming edges
        attn = pyg_softmax(attn, index)
        attn = self.dropout(attn)

        # Weighted values
        msg = attn.unsqueeze(-1) * v_j  # [n_edges, n_heads, head_dim]
        return msg.view(n_edges, self.d_model)


class GlobalSpatialAttention(nn.Module):
    """
    Global attention with spatial bias.

    Full self-attention over all nodes with added spatial position bias.

    Args:
        d_model: Model dimension.
        n_heads: Number of attention heads.
        dropout: Dropout rate.
    """

    def __init__(self, d_model: int = 512, n_heads: int = 8, dropout: float = 0.1):
        super().__init__()
        self.attention = nn.MultiheadAttention(
            d_model, n_heads, dropout=dropout, batch_first=True
        )
        self.spatial_bias = RelativeSpatialBias(n_heads=n_heads)
        self.layer_norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,
        coords: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Global attention with spatial bias.

        Args:
            x: Node features [n_nodes, d_model].
            coords: Spatial coordinates [n_nodes, 2].
            attention_mask: Optional mask [n_nodes, n_nodes].

        Returns:
            Updated node features [n_nodes, d_model].
        """
        residual = x
        x = self.layer_norm(x)

        # Add batch dimension for nn.MultiheadAttention
        x = x.unsqueeze(0)  # [1, n_nodes, d_model]

        # Compute spatial bias
        spatial_bias = self.spatial_bias(coords, attention_mask)

        # Apply attention with spatial bias
        attn_out, _ = self.attention(
            x, x, x, attn_mask=spatial_bias.mean(dim=0)
        )

        attn_out = attn_out.squeeze(0)  # [n_nodes, d_model]
        attn_out = self.dropout(attn_out)

        return residual + attn_out


class FeedForward(nn.Module):
    """Feed-forward network with GELU activation."""

    def __init__(self, d_model: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.net(x)


class SpatialGraphTransformerLayer(nn.Module):
    """
    Single layer of the Spatial Graph Transformer.

    Alternates between local (graph-based) and global attention:
    - Even layers: Local spatial attention on graph edges
    - Odd layers: Global attention with spatial bias

    Args:
        d_model: Model dimension.
        n_heads: Number of attention heads.
        d_ff: Feed-forward dimension.
        dropout: Dropout rate.
        layer_idx: Layer index (determines local vs global).
        use_local: Whether this layer uses local attention.
    """

    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        d_ff: int = 2048,
        dropout: float = 0.1,
        layer_idx: int = 0,
        use_local: bool = True,
    ):
        super().__init__()
        self.layer_idx = layer_idx

        if use_local and layer_idx % 2 == 0:
            self.attention = LocalSpatialAttention(d_model, n_heads, dropout)
            self.is_local = True
        else:
            self.attention = GlobalSpatialAttention(d_model, n_heads, dropout)
            self.is_local = False

        self.ffn = FeedForward(d_model, d_ff, dropout)

    def forward(
        self,
        x: torch.Tensor,
        coords: torch.Tensor,
        edge_index: torch.Tensor,
        edge_attr: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Forward pass through one transformer layer.

        Args:
            x: Node features [n_nodes, d_model].
            coords: Spatial coordinates [n_nodes, 2].
            edge_index: Graph edges [2, n_edges].
            edge_attr: Edge distances [n_edges, 1].

        Returns:
            Updated features [n_nodes, d_model].
        """
        if self.is_local:
            x = self.attention(x, edge_index, edge_attr)
        else:
            x = self.attention(x, coords)

        x = self.ffn(x)
        return x


class SpatialGraphTransformerEncoder(nn.Module):
    """
    Full Spatial Graph Transformer Encoder.

    Processes spatial transcriptomics data through:
    1. Gene expression tokenization and embedding
    2. Spot-level aggregation
    3. Spatial position encoding
    4. Stacked Spatial Graph Transformer layers

    Args:
        n_genes: Number of genes.
        vocab_size: Token vocabulary size.
        d_model: Model dimension.
        n_heads: Number of attention heads.
        n_layers: Number of transformer layers.
        d_ff: Feed-forward dimension.
        dropout: Dropout rate.
        use_multiscale_pos: Use multi-scale spatial encoding.
    """

    def __init__(
        self,
        n_genes: int = 5000,
        vocab_size: int = 67,
        d_model: int = 512,
        n_heads: int = 8,
        n_layers: int = 12,
        d_ff: int = 2048,
        dropout: float = 0.1,
        use_multiscale_pos: bool = True,
    ):
        super().__init__()
        self.d_model = d_model
        self.n_layers = n_layers

        # Gene expression embedding
        self.gene_embedding = GeneEmbedding(n_genes, vocab_size, d_model)
        self.spot_aggregation = SpotAggregation(d_model)

        # Spatial encoding
        if use_multiscale_pos:
            self.spatial_encoding = MultiScaleSpatialEncoding(d_model)
        else:
            self.spatial_encoding = FourierSpatialEncoding(d_model)

        # Graph structure encoding
        self.graph_encoding = GraphStructureEncoding(d_model)

        # Transformer layers
        self.layers = nn.ModuleList([
            SpatialGraphTransformerLayer(
                d_model=d_model,
                n_heads=n_heads,
                d_ff=d_ff,
                dropout=dropout,
                layer_idx=i,
                use_local=True,
            )
            for i in range(n_layers)
        ])

        # Final layer norm
        self.final_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        expr_tokens: torch.LongTensor,
        gene_ids: torch.LongTensor,
        coords: torch.Tensor,
        edge_index: torch.Tensor,
        edge_attr: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Encode spatial transcriptomics data.

        Args:
            expr_tokens: Tokenized expression [n_spots, n_genes].
            gene_ids: Gene indices [n_genes].
            coords: Spatial coordinates [n_spots, 2].
            edge_index: Spatial graph edges [2, n_edges].
            edge_attr: Edge distances [n_edges, 1].

        Returns:
            Spot-level representations [n_spots, d_model].
        """
        # 1. Gene expression embedding
        gene_emb = self.gene_embedding(gene_ids, expr_tokens)
        # [n_spots, n_genes, d_model]

        # 2. Aggregate genes to spot-level
        x = self.spot_aggregation(gene_emb)  # [n_spots, d_model]

        # 3. Add spatial encoding
        spatial_emb = self.spatial_encoding(coords)  # [n_spots, d_model]
        x = x + spatial_emb

        # 4. Add graph structure encoding
        graph_emb = self.graph_encoding(edge_index, x.shape[0])
        x = x + graph_emb

        # 5. Transformer layers
        for layer in self.layers:
            x = layer(x, coords, edge_index, edge_attr)

        # 6. Final normalization
        x = self.final_norm(x)

        return x

    def get_gene_level_representations(
        self,
        expr_tokens: torch.LongTensor,
        gene_ids: torch.LongTensor,
    ) -> torch.Tensor:
        """
        Get gene-level representations (before spot aggregation).
        Useful for gene-specific tasks like SVG detection.

        Args:
            expr_tokens: Tokenized expression [n_spots, n_genes].
            gene_ids: Gene indices [n_genes].

        Returns:
            Gene-level representations [n_spots, n_genes, d_model].
        """
        return self.gene_embedding(gene_ids, expr_tokens)
