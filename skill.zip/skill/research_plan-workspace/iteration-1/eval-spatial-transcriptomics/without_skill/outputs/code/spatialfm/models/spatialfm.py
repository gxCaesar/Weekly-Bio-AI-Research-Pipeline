"""
SpatialFM: Foundation Model for Spatial Transcriptomics.

Main model class that integrates the encoder with pretraining
objectives and downstream task heads.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, Tuple

from spatialfm.models.encoder import SpatialGraphTransformerEncoder
from spatialfm.models.task_heads import (
    SpatialDomainHead,
    CellTypeAnnotationHead,
    GeneExpressionPredictionHead,
    SVGDetectionHead,
    SpatialCommunicationHead,
)


class SpatialFM(nn.Module):
    """
    SpatialFM Foundation Model.

    A unified foundation model for spatial transcriptomics that
    supports pretraining and multiple downstream tasks.

    Architecture overview:
        Input -> Gene Embedding -> Spot Aggregation ->
        Spatial Graph Transformer Encoder -> Task-specific Heads

    Args:
        n_genes: Number of genes.
        vocab_size: Token vocabulary size.
        d_model: Model dimension.
        n_heads: Number of attention heads.
        n_layers: Number of transformer layers.
        d_ff: Feed-forward dimension.
        dropout: Dropout rate.
        use_multiscale_pos: Use multi-scale spatial encoding.
    """

    def __init__(
        self,
        n_genes: int = 5000,
        vocab_size: int = 67,
        d_model: int = 512,
        n_heads: int = 8,
        n_layers: int = 12,
        d_ff: int = 2048,
        dropout: float = 0.1,
        use_multiscale_pos: bool = True,
    ):
        super().__init__()

        self.n_genes = n_genes
        self.vocab_size = vocab_size
        self.d_model = d_model

        # Core encoder
        self.encoder = SpatialGraphTransformerEncoder(
            n_genes=n_genes,
            vocab_size=vocab_size,
            d_model=d_model,
            n_heads=n_heads,
            n_layers=n_layers,
            d_ff=d_ff,
            dropout=dropout,
            use_multiscale_pos=use_multiscale_pos,
        )

        # Pretraining heads
        self.gene_prediction_head = GeneExpressionPredictionHead(
            d_model=d_model,
            n_genes=n_genes,
            vocab_size=vocab_size,
            mode="classification",
        )

        # Contrastive learning projector
        self.contrastive_projector = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.ReLU(),
            nn.Linear(d_model, 256),
        )

        # Task heads (initialized on demand)
        self._task_heads: Dict[str, nn.Module] = {}

    def forward(
        self,
        expr_tokens: torch.LongTensor,
        gene_ids: torch.LongTensor,
        coords: torch.Tensor,
        edge_index: torch.Tensor,
        edge_attr: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Forward pass through the encoder.

        Args:
            expr_tokens: Tokenized expression [n_spots, n_genes].
            gene_ids: Gene indices [n_genes].
            coords: Spatial coordinates [n_spots, 2].
            edge_index: Spatial graph edges [2, n_edges].
            edge_attr: Edge distances [n_edges, 1].

        Returns:
            Spot-level representations [n_spots, d_model].
        """
        return self.encoder(expr_tokens, gene_ids, coords, edge_index, edge_attr)

    def pretrain_forward(
        self,
        expr_tokens: torch.LongTensor,
        masked_tokens: torch.LongTensor,
        gene_ids: torch.LongTensor,
        coords: torch.Tensor,
        edge_index: torch.Tensor,
        edge_attr: Optional[torch.Tensor] = None,
        labels: Optional[torch.LongTensor] = None,
        spatial_mask: Optional[torch.BoolTensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Pretraining forward pass with multiple objectives.

        Args:
            expr_tokens: Original expression tokens [n_spots, n_genes].
            masked_tokens: Masked expression tokens [n_spots, n_genes].
            gene_ids: Gene indices [n_genes].
            coords: Spatial coordinates [n_spots, 2].
            edge_index: Graph edges [2, n_edges].
            edge_attr: Edge distances [n_edges, 1].
            labels: Ground truth tokens at masked positions.
            spatial_mask: Mask of spatially masked spots [n_spots].

        Returns:
            Dictionary of losses.
        """
        outputs = {}

        # 1. Encode masked input
        spot_repr = self.encoder(
            masked_tokens, gene_ids, coords, edge_index, edge_attr
        )

        # 2. Masked gene prediction loss
        gene_embeddings = self.encoder.gene_embedding.gene_id_embed.weight
        gene_pred = self.gene_prediction_head(spot_repr, gene_embeddings)

        if labels is not None:
            # Only compute loss at masked positions
            mask = labels != -100
            if mask.any():
                pred_flat = gene_pred[mask]
                label_flat = labels[mask]
                outputs["mgp_loss"] = F.cross_entropy(pred_flat, label_flat)

        # 3. Spatial contrastive loss
        proj = self.contrastive_projector(spot_repr)
        proj = F.normalize(proj, dim=-1)
        outputs["contrastive_loss"] = self._spatial_contrastive_loss(
            proj, coords, edge_index
        )

        # 4. Spatial context prediction loss
        if spatial_mask is not None:
            outputs["scp_loss"] = self._spatial_context_loss(
                spot_repr, coords, edge_index, spatial_mask
            )

        # 5. Total loss
        outputs["total_loss"] = sum(outputs.values())

        return outputs

    def _spatial_contrastive_loss(
        self,
        embeddings: torch.Tensor,
        coords: torch.Tensor,
        edge_index: torch.Tensor,
        temperature: float = 0.1,
    ) -> torch.Tensor:
        """
        Compute spatial contrastive loss (InfoNCE).

        Positive pairs: spatially adjacent spots (connected by edges).
        Negative pairs: randomly sampled non-adjacent spots.
        """
        src, dst = edge_index
        n_spots = embeddings.shape[0]

        # Positive pairs from edges (sample subset for efficiency)
        n_pos = min(len(src), 1024)
        idx = torch.randperm(len(src))[:n_pos]
        pos_src = embeddings[src[idx]]
        pos_dst = embeddings[dst[idx]]

        # Positive similarity
        pos_sim = (pos_src * pos_dst).sum(dim=-1) / temperature

        # Negative similarities (against all embeddings)
        neg_sim = torch.mm(pos_src, embeddings.t()) / temperature

        # InfoNCE loss
        labels = dst[idx]
        loss = F.cross_entropy(neg_sim, labels)

        return loss

    def _spatial_context_loss(
        self,
        spot_repr: torch.Tensor,
        coords: torch.Tensor,
        edge_index: torch.Tensor,
        spatial_mask: torch.BoolTensor,
    ) -> torch.Tensor:
        """
        Predict the spatial context of masked spots.
        Uses neighbor representations to reconstruct masked spot features.
        """
        masked_spots = spot_repr[spatial_mask]
        src, dst = edge_index

        # For each masked spot, compute mean of unmasked neighbors
        predicted = torch.zeros_like(masked_spots)
        counts = torch.zeros(masked_spots.shape[0], device=spot_repr.device)

        masked_indices = torch.where(spatial_mask)[0]
        idx_map = {int(v): i for i, v in enumerate(masked_indices)}

        for i in range(len(src)):
            s, d = int(src[i]), int(dst[i])
            if s in idx_map and not spatial_mask[d]:
                predicted[idx_map[s]] += spot_repr[d]
                counts[idx_map[s]] += 1

        valid = counts > 0
        if valid.sum() > 0:
            predicted[valid] /= counts[valid].unsqueeze(-1)
            loss = F.mse_loss(masked_spots[valid], predicted[valid].detach())
        else:
            loss = torch.tensor(0.0, device=spot_repr.device)

        return loss

    def add_task_head(self, task_name: str, head: nn.Module):
        """Register a task-specific head."""
        self._task_heads[task_name] = head
        self.add_module(f"task_head_{task_name}", head)

    def task_forward(
        self,
        task_name: str,
        expr_tokens: torch.LongTensor,
        gene_ids: torch.LongTensor,
        coords: torch.Tensor,
        edge_index: torch.Tensor,
        edge_attr: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> torch.Tensor:
        """
        Forward pass for a specific downstream task.

        Args:
            task_name: Name of the task head.
            Other args: Same as forward().

        Returns:
            Task-specific output.
        """
        if task_name not in self._task_heads:
            raise ValueError(
                f"Unknown task: {task_name}. "
                f"Available: {list(self._task_heads.keys())}"
            )

        # Encode
        spot_repr = self.forward(
            expr_tokens, gene_ids, coords, edge_index, edge_attr
        )

        # Task head
        head = self._task_heads[task_name]

        if task_name == "spatial_domain":
            return head(spot_repr)
        elif task_name == "cell_type":
            return head(spot_repr)
        elif task_name == "gene_prediction":
            gene_emb = self.encoder.gene_embedding.gene_id_embed.weight
            return head(spot_repr, gene_emb, **kwargs)
        elif task_name == "svg_detection":
            gene_repr = self.encoder.get_gene_level_representations(
                expr_tokens, gene_ids
            )
            return head(gene_repr, spot_repr)
        elif task_name == "communication":
            return head(spot_repr, edge_index)
        else:
            return head(spot_repr, **kwargs)

    @classmethod
    def from_pretrained(cls, checkpoint_path: str, **kwargs) -> "SpatialFM":
        """
        Load a pretrained SpatialFM model.

        Args:
            checkpoint_path: Path to the checkpoint file.

        Returns:
            Loaded SpatialFM model.
        """
        checkpoint = torch.load(checkpoint_path, map_location="cpu")
        config = checkpoint.get("config", {})
        config.update(kwargs)

        model = cls(**config)
        model.load_state_dict(checkpoint["model_state_dict"], strict=False)

        return model

    def save_pretrained(self, save_path: str, config: Optional[Dict] = None):
        """Save model checkpoint with config."""
        checkpoint = {
            "model_state_dict": self.state_dict(),
            "config": config or {
                "n_genes": self.n_genes,
                "vocab_size": self.vocab_size,
                "d_model": self.d_model,
            },
        }
        torch.save(checkpoint, save_path)

    def freeze_encoder(self):
        """Freeze encoder parameters for downstream fine-tuning."""
        for param in self.encoder.parameters():
            param.requires_grad = False

    def unfreeze_encoder(self):
        """Unfreeze encoder parameters."""
        for param in self.encoder.parameters():
            param.requires_grad = True

    def get_num_params(self, trainable_only: bool = True) -> int:
        """Count model parameters."""
        if trainable_only:
            return sum(p.numel() for p in self.parameters() if p.requires_grad)
        return sum(p.numel() for p in self.parameters())
