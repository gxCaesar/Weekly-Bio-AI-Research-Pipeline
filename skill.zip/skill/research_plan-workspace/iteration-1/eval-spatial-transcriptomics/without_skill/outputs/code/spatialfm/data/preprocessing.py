"""
Preprocessing utilities for spatial transcriptomics data.

Handles quality control, normalization, gene selection,
and spatial graph construction.
"""

import numpy as np
import anndata as ad
import scanpy as sc
from scipy.spatial import Delaunay
from sklearn.neighbors import NearestNeighbors
from typing import Optional, List, Tuple


def preprocess_adata(
    adata: ad.AnnData,
    gene_list: Optional[List[str]] = None,
    n_genes: int = 5000,
    min_genes: int = 200,
    min_cells: int = 10,
    min_counts: int = 500,
    normalize_total: float = 1e4,
) -> Optional[ad.AnnData]:
    """
    Preprocess an AnnData object for SpatialFM.

    Steps:
        1. Quality control (filter cells/spots and genes)
        2. Normalization (library size + log1p)
        3. Gene selection (HVG or provided gene list)

    Args:
        adata: Input AnnData object.
        gene_list: Predefined list of genes to use. If None, selects HVGs.
        n_genes: Number of highly variable genes to select.
        min_genes: Minimum number of genes per cell/spot.
        min_cells: Minimum number of cells/spots per gene.
        min_counts: Minimum total counts per cell/spot.
        normalize_total: Target sum for normalization.

    Returns:
        Preprocessed AnnData object, or None if too few cells remain.
    """
    adata = adata.copy()

    # Quality control
    sc.pp.filter_cells(adata, min_genes=min_genes)
    sc.pp.filter_cells(adata, min_counts=min_counts)
    sc.pp.filter_genes(adata, min_cells=min_cells)

    if adata.n_obs < 10:
        return None

    # Normalization
    sc.pp.normalize_total(adata, target_sum=normalize_total)
    sc.pp.log1p(adata)

    # Gene selection
    if gene_list is not None:
        # Use provided gene list, keeping only genes present in data
        common_genes = [g for g in gene_list if g in adata.var_names]
        if len(common_genes) < 100:
            return None
        adata = adata[:, common_genes]
    else:
        # Select highly variable genes
        if adata.n_vars > n_genes:
            sc.pp.highly_variable_genes(
                adata, n_top_genes=n_genes, flavor="seurat_v3",
                span=0.3 if adata.n_obs > 1000 else 1.0,
            )
            adata = adata[:, adata.var.highly_variable]

    return adata


def build_spatial_graph(
    coords: np.ndarray,
    method: str = "knn",
    k: int = 6,
    radius: Optional[float] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Build a spatial graph from coordinates.

    Args:
        coords: Spatial coordinates, shape [n_spots, 2].
        method: Graph construction method ('knn', 'delaunay', 'radius').
        k: Number of neighbors for KNN graph.
        radius: Radius for radius graph.

    Returns:
        edge_index: Edge indices, shape [2, n_edges].
        edge_attr: Edge attributes (distances), shape [n_edges, 1].
    """
    if method == "knn":
        return _build_knn_graph(coords, k)
    elif method == "delaunay":
        return _build_delaunay_graph(coords)
    elif method == "radius":
        if radius is None:
            # Auto-determine radius from median nearest-neighbor distance
            nn = NearestNeighbors(n_neighbors=2).fit(coords)
            distances, _ = nn.kneighbors(coords)
            radius = np.median(distances[:, 1]) * 3.0
        return _build_radius_graph(coords, radius)
    else:
        raise ValueError(f"Unknown graph construction method: {method}")


def _build_knn_graph(
    coords: np.ndarray, k: int
) -> Tuple[np.ndarray, np.ndarray]:
    """Build k-nearest-neighbor graph."""
    nn = NearestNeighbors(n_neighbors=k + 1, metric="euclidean")
    nn.fit(coords)
    distances, indices = nn.kneighbors(coords)

    # Skip self-loops (first neighbor is self)
    n_spots = coords.shape[0]
    src_list = []
    dst_list = []
    dist_list = []

    for i in range(n_spots):
        for j in range(1, k + 1):
            src_list.append(i)
            dst_list.append(indices[i, j])
            dist_list.append(distances[i, j])

    edge_index = np.array([src_list, dst_list])
    edge_attr = np.array(dist_list).reshape(-1, 1)

    return edge_index, edge_attr


def _build_delaunay_graph(
    coords: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Build Delaunay triangulation graph."""
    tri = Delaunay(coords)

    edges = set()
    for simplex in tri.simplices:
        for i in range(3):
            for j in range(i + 1, 3):
                a, b = simplex[i], simplex[j]
                edges.add((a, b))
                edges.add((b, a))

    edges = list(edges)
    src = [e[0] for e in edges]
    dst = [e[1] for e in edges]

    edge_index = np.array([src, dst])

    # Compute distances
    distances = np.sqrt(
        np.sum((coords[src] - coords[dst]) ** 2, axis=1)
    ).reshape(-1, 1)

    return edge_index, distances


def _build_radius_graph(
    coords: np.ndarray, radius: float
) -> Tuple[np.ndarray, np.ndarray]:
    """Build radius graph (connect all nodes within radius)."""
    nn = NearestNeighbors(radius=radius, metric="euclidean")
    nn.fit(coords)
    connectivity = nn.radius_neighbors_graph(coords, mode="distance")

    # Convert sparse matrix to edge list
    coo = connectivity.tocoo()
    mask = coo.row != coo.col  # Remove self-loops

    edge_index = np.array([coo.row[mask], coo.col[mask]])
    edge_attr = coo.data[mask].reshape(-1, 1)

    return edge_index, edge_attr


def normalize_coordinates(
    coords: np.ndarray, method: str = "zero_one"
) -> np.ndarray:
    """
    Normalize spatial coordinates.

    Args:
        coords: Spatial coordinates [n_spots, 2].
        method: Normalization method ('zero_one', 'standardize', 'unit_sphere').

    Returns:
        Normalized coordinates.
    """
    if method == "zero_one":
        min_vals = coords.min(axis=0)
        max_vals = coords.max(axis=0)
        range_vals = max_vals - min_vals
        range_vals[range_vals == 0] = 1.0
        return (coords - min_vals) / range_vals
    elif method == "standardize":
        return (coords - coords.mean(axis=0)) / (coords.std(axis=0) + 1e-8)
    elif method == "unit_sphere":
        centered = coords - coords.mean(axis=0)
        max_dist = np.max(np.sqrt(np.sum(centered ** 2, axis=1)))
        return centered / (max_dist + 1e-8)
    else:
        raise ValueError(f"Unknown normalization method: {method}")


def compute_gene_statistics(
    adata_list: List[ad.AnnData],
) -> dict:
    """
    Compute gene-level statistics across multiple datasets.
    Useful for selecting a universal gene set for the foundation model.

    Args:
        adata_list: List of AnnData objects.

    Returns:
        Dictionary with gene statistics.
    """
    from collections import Counter

    gene_counts = Counter()
    gene_mean_expr = {}
    gene_var_expr = {}

    for adata in adata_list:
        for gene in adata.var_names:
            gene_counts[gene] += 1

    # Select genes present in at least 50% of datasets
    n_datasets = len(adata_list)
    common_genes = [
        gene for gene, count in gene_counts.items()
        if count >= n_datasets * 0.5
    ]

    return {
        "gene_counts": gene_counts,
        "common_genes": sorted(common_genes),
        "n_common_genes": len(common_genes),
        "n_total_genes": len(gene_counts),
    }
