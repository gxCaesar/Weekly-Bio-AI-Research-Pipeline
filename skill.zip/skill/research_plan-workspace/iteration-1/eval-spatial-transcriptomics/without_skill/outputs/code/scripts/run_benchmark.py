#!/usr/bin/env python
"""
Run evaluation benchmarks for SpatialFM.

Usage:
    python scripts/run_benchmark.py --task spatial_domain --checkpoint checkpoints/best_model.pt
    python scripts/run_benchmark.py --task cell_type --checkpoint checkpoints/best_model.pt --dataset merfish_brain
    python scripts/run_benchmark.py --task all --checkpoint checkpoints/best_model.pt
"""

import argparse
import logging
import os
import sys
import json
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from spatialfm.models.spatialfm import SpatialFM
from spatialfm.models.task_heads import (
    SpatialDomainHead,
    CellTypeAnnotationHead,
    GeneExpressionPredictionHead,
    SVGDetectionHead,
)
from spatialfm.evaluation.metrics import (
    compute_clustering_metrics,
    compute_classification_metrics,
    compute_regression_metrics,
    compute_svg_metrics,
    compute_integration_metrics,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("spatialfm.benchmark")


BENCHMARK_TASKS = [
    "spatial_domain",
    "cell_type",
    "gene_prediction",
    "svg_detection",
    "integration",
]


def parse_args():
    parser = argparse.ArgumentParser(description="SpatialFM Benchmarking")
    parser.add_argument(
        "--task",
        type=str,
        required=True,
        choices=BENCHMARK_TASKS + ["all"],
        help="Benchmark task to run",
    )
    parser.add_argument(
        "--checkpoint", type=str, required=True, help="Model checkpoint path"
    )
    parser.add_argument(
        "--dataset", type=str, default="dlpfc", help="Dataset name"
    )
    parser.add_argument(
        "--data_dir", type=str, default="./data/benchmark", help="Data directory"
    )
    parser.add_argument(
        "--output_dir", type=str, default="./results", help="Results output directory"
    )
    parser.add_argument("--n_domains", type=int, default=7)
    parser.add_argument("--n_cell_types", type=int, default=20)
    parser.add_argument("--device", type=str, default="cuda")
    return parser.parse_args()


def load_model(checkpoint_path: str, device: str) -> SpatialFM:
    """Load pretrained model from checkpoint."""
    model = SpatialFM.from_pretrained(checkpoint_path)
    model = model.to(device)
    model.eval()
    return model


@torch.no_grad()
def benchmark_spatial_domain(model, data, device, n_domains=7):
    """Benchmark spatial domain identification."""
    logger.info("Running spatial domain benchmark...")

    # Add task head
    head = SpatialDomainHead(
        d_model=model.d_model, n_domains=n_domains, use_clustering=True
    ).to(device)
    model.add_task_head("spatial_domain", head)

    results = []
    for sample in data:
        # Get embeddings
        expr_tokens = sample.x_tokens.to(device)
        gene_ids = sample.gene_ids.to(device)
        coords = sample.pos.to(device)
        edge_index = sample.edge_index.to(device)
        edge_attr = sample.edge_attr.to(device) if sample.edge_attr is not None else None

        embeddings = model.task_forward(
            "spatial_domain", expr_tokens, gene_ids, coords, edge_index, edge_attr
        )

        # Cluster embeddings
        from sklearn.cluster import KMeans
        emb_np = embeddings.cpu().numpy()
        kmeans = KMeans(n_clusters=n_domains, random_state=42, n_init=10)
        pred_labels = kmeans.fit_predict(emb_np)

        if hasattr(sample, "spatial_domain") and sample.spatial_domain is not None:
            true_labels = np.array(sample.spatial_domain)
            metrics = compute_clustering_metrics(true_labels, pred_labels)
            results.append(metrics)
            logger.info(f"Sample metrics: {metrics}")

    # Average across samples
    if results:
        avg_metrics = {
            key: np.mean([r[key] for r in results]) for key in results[0]
        }
        logger.info(f"Average metrics: {avg_metrics}")
        return avg_metrics

    return {}


@torch.no_grad()
def benchmark_cell_type(model, data, device, n_cell_types=20):
    """Benchmark cell type annotation."""
    logger.info("Running cell type annotation benchmark...")

    head = CellTypeAnnotationHead(
        d_model=model.d_model, n_cell_types=n_cell_types
    ).to(device)
    model.add_task_head("cell_type", head)

    all_true = []
    all_pred = []

    for sample in data:
        expr_tokens = sample.x_tokens.to(device)
        gene_ids = sample.gene_ids.to(device)
        coords = sample.pos.to(device)
        edge_index = sample.edge_index.to(device)
        edge_attr = sample.edge_attr.to(device) if sample.edge_attr is not None else None

        logits = model.task_forward(
            "cell_type", expr_tokens, gene_ids, coords, edge_index, edge_attr
        )
        pred = logits.argmax(dim=-1).cpu().numpy()

        if hasattr(sample, "cell_type") and sample.cell_type is not None:
            all_true.extend(sample.cell_type)
            all_pred.extend(pred)

    if all_true:
        metrics = compute_classification_metrics(
            np.array(all_true), np.array(all_pred)
        )
        logger.info(f"Cell type metrics: {metrics}")
        return metrics

    return {}


def main():
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    # Load model
    logger.info(f"Loading model from {args.checkpoint}")
    model = load_model(args.checkpoint, device)
    logger.info(f"Model loaded. Parameters: {model.get_num_params():,}")

    # Load benchmark data (placeholder - actual data loading depends on dataset)
    logger.info(f"Loading benchmark data: {args.dataset}")
    # data = load_benchmark_data(args.dataset, args.data_dir)

    # Run benchmarks
    tasks = BENCHMARK_TASKS if args.task == "all" else [args.task]
    all_results = {}

    for task in tasks:
        logger.info(f"\n{'='*50}")
        logger.info(f"Task: {task}")
        logger.info(f"{'='*50}")

        # Note: actual benchmark requires loaded data
        # This is the framework - data loading is dataset-specific
        logger.info(f"Benchmark framework ready for task: {task}")
        logger.info("Provide benchmark data to run evaluation.")

    # Save results
    os.makedirs(args.output_dir, exist_ok=True)
    results_path = os.path.join(args.output_dir, f"benchmark_{args.dataset}.json")
    with open(results_path, "w") as f:
        json.dump(all_results, f, indent=2)
    logger.info(f"Results saved to {results_path}")


if __name__ == "__main__":
    main()
