"""
Fine-tuning runner for downstream tasks.

Supports:
- Full fine-tuning
- Frozen encoder (linear probing)
- Gradual unfreezing
"""

import os
import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from typing import Optional, Dict, List, Any
from dataclasses import dataclass

from spatialfm.models.spatialfm import SpatialFM

logger = logging.getLogger(__name__)


@dataclass
class FinetuneConfig:
    """Configuration for fine-tuning."""

    # Task
    task_name: str = "spatial_domain"
    n_classes: int = 7

    # Training
    max_epochs: int = 50
    learning_rate: float = 1e-4
    encoder_lr: float = 1e-5
    weight_decay: float = 0.01
    max_grad_norm: float = 1.0

    # Strategy
    freeze_encoder: bool = False
    gradual_unfreeze: bool = False
    unfreeze_epoch: int = 10

    # Logging
    log_interval: int = 50
    output_dir: str = "./finetune_checkpoints"


class FinetuneRunner:
    """
    Fine-tuning runner for downstream tasks.

    Args:
        config: FinetuneConfig instance.
        model: Pretrained SpatialFM model.
        train_data: Training data (list of PyG Data objects).
        val_data: Validation data.
    """

    def __init__(
        self,
        config: FinetuneConfig,
        model: SpatialFM,
        train_data: List,
        val_data: Optional[List] = None,
    ):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = model.to(self.device)
        self.train_data = train_data
        self.val_data = val_data

        # Freeze encoder if requested
        if config.freeze_encoder:
            self.model.freeze_encoder()

        # Optimizer with different learning rates
        encoder_params = list(self.model.encoder.parameters())
        head_params = [
            p for n, p in self.model.named_parameters()
            if "encoder" not in n and p.requires_grad
        ]

        param_groups = [
            {"params": head_params, "lr": config.learning_rate},
        ]
        if not config.freeze_encoder:
            param_groups.append(
                {"params": encoder_params, "lr": config.encoder_lr}
            )

        self.optimizer = AdamW(
            param_groups, weight_decay=config.weight_decay
        )

        self.scheduler = CosineAnnealingLR(
            self.optimizer, T_max=config.max_epochs, eta_min=1e-6
        )

        # Loss function
        if config.task_name in ["spatial_domain", "cell_type"]:
            self.criterion = nn.CrossEntropyLoss()
        elif config.task_name == "gene_prediction":
            self.criterion = nn.CrossEntropyLoss(ignore_index=-100)
        else:
            self.criterion = nn.MSELoss()

    def train(self) -> Dict[str, float]:
        """Run fine-tuning loop."""
        logger.info(f"Starting fine-tuning for task: {self.config.task_name}")
        os.makedirs(self.config.output_dir, exist_ok=True)

        best_val_metric = 0.0

        for epoch in range(self.config.max_epochs):
            # Gradual unfreezing
            if (
                self.config.gradual_unfreeze
                and epoch == self.config.unfreeze_epoch
            ):
                self.model.unfreeze_encoder()
                logger.info(f"Unfreezing encoder at epoch {epoch}")

            # Train
            train_loss = self._train_epoch(epoch)
            self.scheduler.step()

            # Validate
            if self.val_data is not None:
                val_metrics = self._validate()
                val_metric = val_metrics.get("accuracy", val_metrics.get("loss", 0))

                logger.info(
                    f"Epoch {epoch+1}/{self.config.max_epochs} | "
                    f"Train Loss: {train_loss:.4f} | "
                    f"Val Metrics: {val_metrics}"
                )

                if val_metric > best_val_metric:
                    best_val_metric = val_metric
                    self._save_checkpoint(epoch, best=True)
            else:
                logger.info(
                    f"Epoch {epoch+1}/{self.config.max_epochs} | "
                    f"Train Loss: {train_loss:.4f}"
                )

        return {"best_val_metric": best_val_metric}

    def _train_epoch(self, epoch: int) -> float:
        """Train for one epoch."""
        self.model.train()
        total_loss = 0.0
        n_batches = 0

        for data in self.train_data:
            loss = self._train_step(data)
            total_loss += loss
            n_batches += 1

        return total_loss / max(n_batches, 1)

    def _train_step(self, data) -> float:
        """Single training step."""
        self.optimizer.zero_grad()

        # Move data to device
        expr_tokens = data.x_tokens.to(self.device)
        gene_ids = data.gene_ids.to(self.device)
        coords = data.pos.to(self.device)
        edge_index = data.edge_index.to(self.device)
        edge_attr = data.edge_attr.to(self.device) if data.edge_attr is not None else None

        # Forward
        output = self.model.task_forward(
            self.config.task_name,
            expr_tokens, gene_ids, coords, edge_index, edge_attr,
        )

        # Compute loss (depends on task)
        if self.config.task_name == "spatial_domain":
            labels = torch.LongTensor(data.spatial_domain).to(self.device)
            loss = self.criterion(output, labels)
        elif self.config.task_name == "cell_type":
            labels = torch.LongTensor(data.cell_type).to(self.device)
            loss = self.criterion(output, labels)
        else:
            loss = output.mean()  # Placeholder

        loss.backward()
        torch.nn.utils.clip_grad_norm_(
            self.model.parameters(), self.config.max_grad_norm
        )
        self.optimizer.step()

        return loss.item()

    @torch.no_grad()
    def _validate(self) -> Dict[str, float]:
        """Validate on validation data."""
        self.model.eval()
        total_loss = 0.0
        correct = 0
        total = 0

        for data in self.val_data:
            expr_tokens = data.x_tokens.to(self.device)
            gene_ids = data.gene_ids.to(self.device)
            coords = data.pos.to(self.device)
            edge_index = data.edge_index.to(self.device)
            edge_attr = data.edge_attr.to(self.device) if data.edge_attr is not None else None

            output = self.model.task_forward(
                self.config.task_name,
                expr_tokens, gene_ids, coords, edge_index, edge_attr,
            )

            if self.config.task_name in ["spatial_domain", "cell_type"]:
                if self.config.task_name == "spatial_domain":
                    labels = torch.LongTensor(data.spatial_domain).to(self.device)
                else:
                    labels = torch.LongTensor(data.cell_type).to(self.device)

                loss = self.criterion(output, labels)
                preds = output.argmax(dim=-1)
                correct += (preds == labels).sum().item()
                total += labels.shape[0]

            total_loss += loss.item()

        metrics = {"loss": total_loss / max(len(self.val_data), 1)}
        if total > 0:
            metrics["accuracy"] = correct / total

        return metrics

    def _save_checkpoint(self, epoch: int, best: bool = False):
        """Save fine-tuning checkpoint."""
        path = os.path.join(
            self.config.output_dir,
            "best_model.pt" if best else f"checkpoint_{epoch+1}.pt",
        )
        torch.save(
            {
                "epoch": epoch,
                "model_state_dict": self.model.state_dict(),
                "optimizer_state_dict": self.optimizer.state_dict(),
                "config": self.config,
            },
            path,
        )
