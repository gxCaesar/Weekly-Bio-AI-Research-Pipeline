"""
Evaluation metrics for spatial transcriptomics tasks.

Implements standard metrics for:
- Spatial domain identification (clustering metrics)
- Cell type annotation (classification metrics)
- Gene expression prediction (regression metrics)
- Data integration (batch correction metrics)
"""

import numpy as np
from sklearn.metrics import (
    adjusted_rand_score,
    normalized_mutual_info_score,
    homogeneity_score,
    completeness_score,
    v_measure_score,
    accuracy_score,
    f1_score,
    cohen_kappa_score,
    confusion_matrix,
    roc_auc_score,
    average_precision_score,
    mean_squared_error,
)
from sklearn.metrics.pairwise import euclidean_distances
from scipy.stats import pearsonr, spearmanr
from typing import Dict, Optional
import warnings


def compute_clustering_metrics(
    true_labels: np.ndarray,
    pred_labels: np.ndarray,
) -> Dict[str, float]:
    """
    Compute clustering quality metrics.

    Used for spatial domain identification evaluation.

    Args:
        true_labels: Ground truth domain labels.
        pred_labels: Predicted cluster labels.

    Returns:
        Dictionary of metrics: ARI, NMI, Homogeneity, Completeness, V-measure.
    """
    return {
        "ARI": adjusted_rand_score(true_labels, pred_labels),
        "NMI": normalized_mutual_info_score(
            true_labels, pred_labels, average_method="arithmetic"
        ),
        "Homogeneity": homogeneity_score(true_labels, pred_labels),
        "Completeness": completeness_score(true_labels, pred_labels),
        "V-measure": v_measure_score(true_labels, pred_labels),
    }


def compute_classification_metrics(
    true_labels: np.ndarray,
    pred_labels: np.ndarray,
    pred_probs: Optional[np.ndarray] = None,
) -> Dict[str, float]:
    """
    Compute classification metrics.

    Used for cell type annotation evaluation.

    Args:
        true_labels: Ground truth labels.
        pred_labels: Predicted labels.
        pred_probs: Predicted probabilities (optional, for AUROC).

    Returns:
        Dictionary of metrics: Accuracy, macro-F1, weighted-F1, Kappa.
    """
    metrics = {
        "Accuracy": accuracy_score(true_labels, pred_labels),
        "Macro-F1": f1_score(true_labels, pred_labels, average="macro"),
        "Weighted-F1": f1_score(true_labels, pred_labels, average="weighted"),
        "Kappa": cohen_kappa_score(true_labels, pred_labels),
    }

    if pred_probs is not None:
        try:
            metrics["AUROC"] = roc_auc_score(
                true_labels, pred_probs, multi_class="ovr", average="macro"
            )
        except ValueError:
            pass

    return metrics


def compute_regression_metrics(
    true_values: np.ndarray,
    pred_values: np.ndarray,
) -> Dict[str, float]:
    """
    Compute regression metrics.

    Used for gene expression prediction evaluation.

    Args:
        true_values: Ground truth expression values [n_spots, n_genes].
        pred_values: Predicted expression values [n_spots, n_genes].

    Returns:
        Dictionary of metrics: RMSE, Pearson, Spearman, per-gene correlations.
    """
    # Global metrics
    rmse = np.sqrt(mean_squared_error(true_values.flatten(), pred_values.flatten()))

    # Per-gene correlations
    n_genes = true_values.shape[1]
    pearson_per_gene = []
    spearman_per_gene = []

    for g in range(n_genes):
        true_g = true_values[:, g]
        pred_g = pred_values[:, g]

        if true_g.std() > 0 and pred_g.std() > 0:
            r, _ = pearsonr(true_g, pred_g)
            rho, _ = spearmanr(true_g, pred_g)
            pearson_per_gene.append(r)
            spearman_per_gene.append(rho)

    return {
        "RMSE": rmse,
        "Pearson_mean": np.mean(pearson_per_gene) if pearson_per_gene else 0.0,
        "Pearson_median": np.median(pearson_per_gene) if pearson_per_gene else 0.0,
        "Spearman_mean": np.mean(spearman_per_gene) if spearman_per_gene else 0.0,
        "n_valid_genes": len(pearson_per_gene),
    }


def compute_svg_metrics(
    true_svg: np.ndarray,
    pred_scores: np.ndarray,
) -> Dict[str, float]:
    """
    Compute SVG detection metrics.

    Args:
        true_svg: Binary labels (1 = SVG, 0 = non-SVG).
        pred_scores: Predicted spatial variability scores.

    Returns:
        Dictionary of metrics: AUROC, AUPRC.
    """
    return {
        "AUROC": roc_auc_score(true_svg, pred_scores),
        "AUPRC": average_precision_score(true_svg, pred_scores),
    }


def compute_integration_metrics(
    embeddings: np.ndarray,
    batch_labels: np.ndarray,
    cell_type_labels: Optional[np.ndarray] = None,
    k: int = 30,
) -> Dict[str, float]:
    """
    Compute data integration metrics.

    Measures both batch mixing (removal of batch effects) and
    conservation of biological variation.

    Args:
        embeddings: Integrated embeddings [n_cells, d].
        batch_labels: Batch assignments.
        cell_type_labels: Cell type labels (optional).
        k: Number of neighbors for kNN-based metrics.

    Returns:
        Dictionary of metrics: kBET acceptance rate, LISI, ASW.
    """
    from sklearn.neighbors import NearestNeighbors
    from sklearn.metrics import silhouette_score

    metrics = {}

    # Average Silhouette Width for batch mixing
    # Lower is better (batches well mixed)
    try:
        batch_asw = silhouette_score(embeddings, batch_labels)
        # Convert to 0-1 scale where 1 is better
        metrics["Batch_ASW"] = 1 - (batch_asw + 1) / 2
    except ValueError:
        metrics["Batch_ASW"] = 0.0

    # Cell type ASW (higher is better - biology preserved)
    if cell_type_labels is not None:
        try:
            bio_asw = silhouette_score(embeddings, cell_type_labels)
            metrics["Bio_ASW"] = (bio_asw + 1) / 2
        except ValueError:
            metrics["Bio_ASW"] = 0.0

    # kNN-based batch mixing (LISI approximation)
    nn = NearestNeighbors(n_neighbors=k + 1).fit(embeddings)
    _, indices = nn.kneighbors(embeddings)

    # For each cell, compute fraction of neighbors from same batch
    n_cells = len(batch_labels)
    same_batch_frac = []
    for i in range(n_cells):
        neighbors = indices[i, 1:]  # Exclude self
        same_batch = np.sum(batch_labels[neighbors] == batch_labels[i])
        same_batch_frac.append(same_batch / k)

    # Ideal: fraction equals batch proportion (well mixed)
    unique_batches = np.unique(batch_labels)
    expected_frac = 1.0 / len(unique_batches)
    lisi_approx = 1 - np.abs(np.mean(same_batch_frac) - expected_frac)
    metrics["LISI_approx"] = lisi_approx

    # Graph connectivity
    if cell_type_labels is not None:
        metrics["Graph_connectivity"] = _graph_connectivity(
            embeddings, cell_type_labels, k
        )

    return metrics


def _graph_connectivity(
    embeddings: np.ndarray,
    labels: np.ndarray,
    k: int,
) -> float:
    """
    Compute graph connectivity metric.

    Measures whether cells of the same type are connected in kNN graph.
    """
    from sklearn.neighbors import NearestNeighbors
    from scipy.sparse.csgraph import connected_components
    from scipy.sparse import csr_matrix

    nn = NearestNeighbors(n_neighbors=k + 1).fit(embeddings)
    knn_graph = nn.kneighbors_graph(embeddings)

    # For each cell type, check connectivity
    unique_labels = np.unique(labels)
    connectivities = []

    for label in unique_labels:
        mask = labels == label
        sub_graph = knn_graph[mask][:, mask]
        n_components, _ = connected_components(sub_graph, directed=False)
        n_cells_type = mask.sum()
        if n_cells_type > 0:
            connectivity = 1.0 / n_components
            connectivities.append(connectivity)

    return np.mean(connectivities) if connectivities else 0.0
