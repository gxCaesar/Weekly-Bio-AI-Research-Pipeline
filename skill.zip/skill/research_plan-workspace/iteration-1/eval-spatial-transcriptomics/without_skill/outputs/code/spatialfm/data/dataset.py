"""
Spatial transcriptomics dataset classes for PyTorch Geometric.

Supports loading data from AnnData objects with spatial coordinates,
constructing spatial graphs, and tokenizing gene expression values
for the SpatialFM model.
"""

import numpy as np
import torch
from torch.utils.data import Dataset
from torch_geometric.data import Data, InMemoryDataset
from scipy.sparse import issparse
from typing import Optional, List, Tuple, Dict, Any
import anndata as ad
import scanpy as sc

from spatialfm.data.preprocessing import preprocess_adata, build_spatial_graph
from spatialfm.data.tokenizer import GeneExpressionTokenizer


class SpatialTranscriptomicsDataset(InMemoryDataset):
    """
    PyTorch Geometric dataset for spatial transcriptomics data.

    Each sample corresponds to a tissue section represented as a graph,
    where nodes are spots/cells and edges encode spatial adjacency.

    Args:
        adata_paths: List of paths to AnnData (.h5ad) files.
        gene_list: Ordered list of gene names to use. If None, uses
            highly variable genes from the combined dataset.
        n_genes: Number of genes to select if gene_list is not provided.
        n_bins: Number of expression bins for tokenization.
        graph_method: Method for spatial graph construction
            ('knn', 'delaunay', 'radius').
        k_neighbors: Number of neighbors for KNN graph.
        radius: Radius for radius graph.
        transform: Optional PyG transform.
        pre_transform: Optional PyG pre-transform.
    """

    def __init__(
        self,
        adata_paths: List[str],
        gene_list: Optional[List[str]] = None,
        n_genes: int = 5000,
        n_bins: int = 64,
        graph_method: str = "knn",
        k_neighbors: int = 6,
        radius: Optional[float] = None,
        transform=None,
        pre_transform=None,
    ):
        self.adata_paths = adata_paths
        self.gene_list = gene_list
        self.n_genes = n_genes
        self.n_bins = n_bins
        self.graph_method = graph_method
        self.k_neighbors = k_neighbors
        self.radius = radius

        # Initialize tokenizer
        self.tokenizer = GeneExpressionTokenizer(n_bins=n_bins)

        super().__init__(root=None, transform=transform, pre_transform=pre_transform)

        # Load and process data
        self.data_list = self._process_all()

    def _process_all(self) -> List[Data]:
        """Process all AnnData files into PyG Data objects."""
        data_list = []

        for path in self.adata_paths:
            adata = ad.read_h5ad(path)
            data = self._process_single(adata)
            if data is not None:
                data_list.append(data)

        # Fit tokenizer on all data
        if not self.tokenizer.is_fitted:
            all_expr = []
            for data in data_list:
                all_expr.append(data.x_raw)
            combined = torch.cat(all_expr, dim=0)
            self.tokenizer.fit(combined)

        # Tokenize all data
        for data in data_list:
            data.x_tokens = self.tokenizer.transform(data.x_raw)

        return data_list

    def _process_single(self, adata: ad.AnnData) -> Optional[Data]:
        """
        Process a single AnnData object into a PyG Data object.

        Returns:
            PyG Data object with attributes:
                - x_raw: Raw normalized expression [n_spots, n_genes]
                - x_tokens: Tokenized expression [n_spots, n_genes]
                - pos: Spatial coordinates [n_spots, 2]
                - edge_index: Spatial graph edges [2, n_edges]
                - edge_attr: Edge attributes (distances) [n_edges, 1]
                - gene_ids: Gene indices [n_genes]
        """
        # Preprocess
        adata = preprocess_adata(
            adata, gene_list=self.gene_list, n_genes=self.n_genes
        )

        if adata is None or adata.n_obs < 10:
            return None

        # Extract expression matrix
        if issparse(adata.X):
            expr = torch.FloatTensor(adata.X.toarray())
        else:
            expr = torch.FloatTensor(np.array(adata.X))

        # Extract spatial coordinates
        if "spatial" in adata.obsm:
            coords = torch.FloatTensor(np.array(adata.obsm["spatial"][:, :2]))
        elif "X_spatial" in adata.obsm:
            coords = torch.FloatTensor(np.array(adata.obsm["X_spatial"][:, :2]))
        else:
            raise ValueError("No spatial coordinates found in adata.obsm")

        # Build spatial graph
        edge_index, edge_attr = build_spatial_graph(
            coords.numpy(),
            method=self.graph_method,
            k=self.k_neighbors,
            radius=self.radius,
        )

        # Gene indices
        gene_ids = torch.arange(expr.shape[1])

        # Create PyG Data object
        data = Data(
            x_raw=expr,
            pos=coords,
            edge_index=torch.LongTensor(edge_index),
            edge_attr=torch.FloatTensor(edge_attr),
            gene_ids=gene_ids,
            n_spots=expr.shape[0],
            n_genes=expr.shape[1],
        )

        # Add labels if available
        if "cell_type" in adata.obs:
            data.cell_type = adata.obs["cell_type"].values
        if "spatial_domain" in adata.obs:
            data.spatial_domain = adata.obs["spatial_domain"].values

        return data

    def len(self) -> int:
        return len(self.data_list)

    def get(self, idx: int) -> Data:
        return self.data_list[idx]


class SubgraphSampler:
    """
    Samples subgraphs from large spatial transcriptomics graphs
    for mini-batch training.

    Uses spatial locality to extract contiguous subgraphs that
    preserve local spatial structure.

    Args:
        n_nodes_per_subgraph: Target number of nodes per subgraph.
        overlap_ratio: Fraction of overlap between adjacent subgraphs.
        sampling_strategy: 'random', 'spatial_cluster', or 'grid'.
    """

    def __init__(
        self,
        n_nodes_per_subgraph: int = 1024,
        overlap_ratio: float = 0.1,
        sampling_strategy: str = "spatial_cluster",
    ):
        self.n_nodes = n_nodes_per_subgraph
        self.overlap_ratio = overlap_ratio
        self.strategy = sampling_strategy

    def sample(self, data: Data) -> List[Data]:
        """
        Sample subgraphs from a large graph.

        Args:
            data: Full graph Data object.

        Returns:
            List of subgraph Data objects.
        """
        if data.n_spots <= self.n_nodes:
            return [data]

        if self.strategy == "random":
            return self._random_sample(data)
        elif self.strategy == "spatial_cluster":
            return self._spatial_cluster_sample(data)
        elif self.strategy == "grid":
            return self._grid_sample(data)
        else:
            raise ValueError(f"Unknown sampling strategy: {self.strategy}")

    def _random_sample(self, data: Data) -> List[Data]:
        """Random node sampling with spatial neighborhood expansion."""
        subgraphs = []
        n_subgraphs = max(1, data.n_spots // self.n_nodes)

        for _ in range(n_subgraphs):
            # Random seed node
            seed = np.random.randint(0, data.n_spots)

            # BFS expansion from seed to get spatially contiguous subgraph
            node_mask = self._bfs_expand(data, seed, self.n_nodes)
            subgraph = self._extract_subgraph(data, node_mask)
            subgraphs.append(subgraph)

        return subgraphs

    def _spatial_cluster_sample(self, data: Data) -> List[Data]:
        """K-means clustering on spatial coordinates for balanced subgraphs."""
        from sklearn.cluster import KMeans

        n_clusters = max(1, data.n_spots // self.n_nodes)
        coords = data.pos.numpy()

        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        labels = kmeans.fit_predict(coords)

        subgraphs = []
        for c in range(n_clusters):
            node_mask = torch.BoolTensor(labels == c)
            subgraph = self._extract_subgraph(data, node_mask)
            subgraphs.append(subgraph)

        return subgraphs

    def _grid_sample(self, data: Data) -> List[Data]:
        """Grid-based spatial partitioning."""
        coords = data.pos.numpy()
        x_min, y_min = coords.min(axis=0)
        x_max, y_max = coords.max(axis=0)

        # Compute grid size
        area = (x_max - x_min) * (y_max - y_min)
        cell_area = area * self.n_nodes / data.n_spots
        cell_size = np.sqrt(cell_area)

        n_x = max(1, int(np.ceil((x_max - x_min) / cell_size)))
        n_y = max(1, int(np.ceil((y_max - y_min) / cell_size)))

        subgraphs = []
        for i in range(n_x):
            for j in range(n_y):
                x_lo = x_min + i * cell_size
                x_hi = x_min + (i + 1) * cell_size
                y_lo = y_min + j * cell_size
                y_hi = y_min + (j + 1) * cell_size

                mask = (
                    (coords[:, 0] >= x_lo)
                    & (coords[:, 0] < x_hi)
                    & (coords[:, 1] >= y_lo)
                    & (coords[:, 1] < y_hi)
                )
                node_mask = torch.BoolTensor(mask)

                if node_mask.sum() > 10:
                    subgraph = self._extract_subgraph(data, node_mask)
                    subgraphs.append(subgraph)

        return subgraphs

    def _bfs_expand(
        self, data: Data, seed: int, target_size: int
    ) -> torch.BoolTensor:
        """BFS expansion from seed node to collect target_size nodes."""
        visited = set()
        queue = [seed]
        visited.add(seed)

        edge_index = data.edge_index.numpy()
        adj = {}
        for i in range(edge_index.shape[1]):
            src, dst = edge_index[0, i], edge_index[1, i]
            if src not in adj:
                adj[src] = []
            adj[src].append(dst)

        while len(visited) < target_size and queue:
            node = queue.pop(0)
            for neighbor in adj.get(node, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
                    if len(visited) >= target_size:
                        break

        mask = torch.zeros(data.n_spots, dtype=torch.bool)
        mask[list(visited)] = True
        return mask

    def _extract_subgraph(self, data: Data, node_mask: torch.BoolTensor) -> Data:
        """Extract subgraph given a node mask."""
        node_indices = torch.where(node_mask)[0]
        idx_map = {int(old): new for new, old in enumerate(node_indices)}

        # Filter edges
        src, dst = data.edge_index
        edge_mask = node_mask[src] & node_mask[dst]
        new_src = torch.tensor([idx_map[int(s)] for s in src[edge_mask]])
        new_dst = torch.tensor([idx_map[int(d)] for d in dst[edge_mask]])

        subgraph = Data(
            x_raw=data.x_raw[node_mask],
            pos=data.pos[node_mask],
            edge_index=torch.stack([new_src, new_dst], dim=0),
            edge_attr=data.edge_attr[edge_mask] if data.edge_attr is not None else None,
            gene_ids=data.gene_ids,
            n_spots=int(node_mask.sum()),
            n_genes=data.n_genes,
        )

        if hasattr(data, "x_tokens") and data.x_tokens is not None:
            subgraph.x_tokens = data.x_tokens[node_mask]

        return subgraph
