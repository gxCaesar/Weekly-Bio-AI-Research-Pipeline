"""
Pretraining loop for SpatialFM.

Implements the multi-objective pretraining strategy:
1. Spatial Masked Gene Prediction (SMGP)
2. Spatial Contrastive Learning (SCL)
3. Spatial Context Prediction (SCP)
"""

import os
import time
import logging
import torch
import torch.nn as nn
import torch.distributed as dist
from torch.utils.data import DataLoader
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, LinearLR, SequentialLR
from typing import Optional, Dict, Any
from dataclasses import dataclass, field

from spatialfm.models.spatialfm import SpatialFM
from spatialfm.data.dataset import SpatialTranscriptomicsDataset, SubgraphSampler
from spatialfm.data.tokenizer import GeneExpressionTokenizer

logger = logging.getLogger(__name__)


@dataclass
class PretrainConfig:
    """Configuration for pretraining."""

    # Model
    n_genes: int = 5000
    vocab_size: int = 67
    d_model: int = 512
    n_heads: int = 8
    n_layers: int = 12
    d_ff: int = 2048
    dropout: float = 0.1

    # Training
    max_epochs: int = 100
    batch_size: int = 4
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    warmup_epochs: int = 10
    max_grad_norm: float = 1.0
    mixed_precision: bool = True

    # Masking
    gene_mask_ratio: float = 0.15
    spatial_mask_ratio: float = 0.15

    # Loss weights
    mgp_weight: float = 1.0
    contrastive_weight: float = 0.1
    scp_weight: float = 0.1

    # Logging and checkpointing
    log_interval: int = 100
    save_interval: int = 5
    output_dir: str = "./checkpoints"
    wandb_project: Optional[str] = "spatialfm"
    wandb_run_name: Optional[str] = None

    # Distributed training
    distributed: bool = False
    local_rank: int = 0

    # Subgraph sampling
    n_nodes_per_subgraph: int = 2048
    sampling_strategy: str = "spatial_cluster"


class PretrainRunner:
    """
    Pretraining runner for SpatialFM.

    Handles the full pretraining loop including:
    - Data loading and masking
    - Multi-objective optimization
    - Logging and checkpointing
    - Distributed training support

    Args:
        config: PretrainConfig instance.
        model: SpatialFM model (optional, created from config if None).
        dataset: Training dataset.
    """

    def __init__(
        self,
        config: PretrainConfig,
        model: Optional[SpatialFM] = None,
        dataset: Optional[SpatialTranscriptomicsDataset] = None,
    ):
        self.config = config
        self.device = torch.device(
            f"cuda:{config.local_rank}" if torch.cuda.is_available() else "cpu"
        )

        # Model
        if model is None:
            self.model = SpatialFM(
                n_genes=config.n_genes,
                vocab_size=config.vocab_size,
                d_model=config.d_model,
                n_heads=config.n_heads,
                n_layers=config.n_layers,
                d_ff=config.d_ff,
                dropout=config.dropout,
            )
        else:
            self.model = model

        self.model = self.model.to(self.device)

        # Dataset and sampler
        self.dataset = dataset
        self.subgraph_sampler = SubgraphSampler(
            n_nodes_per_subgraph=config.n_nodes_per_subgraph,
            sampling_strategy=config.sampling_strategy,
        )

        # Tokenizer reference
        if dataset is not None:
            self.tokenizer = dataset.tokenizer
        else:
            self.tokenizer = GeneExpressionTokenizer(n_bins=config.vocab_size - 3)

        # Optimizer
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay,
            betas=(0.9, 0.999),
        )

        # Learning rate scheduler: warmup + cosine decay
        warmup_scheduler = LinearLR(
            self.optimizer,
            start_factor=0.01,
            end_factor=1.0,
            total_iters=config.warmup_epochs,
        )
        cosine_scheduler = CosineAnnealingLR(
            self.optimizer,
            T_max=config.max_epochs - config.warmup_epochs,
            eta_min=1e-6,
        )
        self.scheduler = SequentialLR(
            self.optimizer,
            schedulers=[warmup_scheduler, cosine_scheduler],
            milestones=[config.warmup_epochs],
        )

        # Mixed precision
        self.scaler = torch.amp.GradScaler("cuda") if config.mixed_precision else None

        # Distributed training
        if config.distributed:
            self.model = nn.parallel.DistributedDataParallel(
                self.model,
                device_ids=[config.local_rank],
            )

        # Logging
        self.global_step = 0
        self.best_loss = float("inf")

    def train(self):
        """Run the full pretraining loop."""
        logger.info(
            f"Starting pretraining for {self.config.max_epochs} epochs"
        )
        logger.info(
            f"Model parameters: {self.model.get_num_params():,}"
            if not self.config.distributed
            else f"Model parameters: {self.model.module.get_num_params():,}"
        )

        os.makedirs(self.config.output_dir, exist_ok=True)

        for epoch in range(self.config.max_epochs):
            epoch_loss = self._train_epoch(epoch)
            self.scheduler.step()

            # Logging
            lr = self.optimizer.param_groups[0]["lr"]
            logger.info(
                f"Epoch {epoch+1}/{self.config.max_epochs} | "
                f"Loss: {epoch_loss:.4f} | LR: {lr:.6f}"
            )

            # Checkpointing
            if (epoch + 1) % self.config.save_interval == 0:
                self._save_checkpoint(epoch, epoch_loss)

            if epoch_loss < self.best_loss:
                self.best_loss = epoch_loss
                self._save_checkpoint(epoch, epoch_loss, is_best=True)

    def _train_epoch(self, epoch: int) -> float:
        """Train for one epoch."""
        self.model.train()
        total_loss = 0.0
        n_batches = 0

        for data_idx in range(len(self.dataset)):
            data = self.dataset.get(data_idx)
            subgraphs = self.subgraph_sampler.sample(data)

            for subgraph in subgraphs:
                loss = self._train_step(subgraph)
                total_loss += loss
                n_batches += 1
                self.global_step += 1

                if self.global_step % self.config.log_interval == 0:
                    avg_loss = total_loss / n_batches
                    logger.info(
                        f"Step {self.global_step} | "
                        f"Loss: {loss:.4f} | "
                        f"Avg Loss: {avg_loss:.4f}"
                    )

        return total_loss / max(n_batches, 1)

    def _train_step(self, data) -> float:
        """Execute a single training step."""
        data = data.to(self.device) if hasattr(data, 'to') else data

        # Apply masking
        masked_tokens, labels, gene_mask = self.tokenizer.mask_tokens(
            data.x_tokens, mask_ratio=self.config.gene_mask_ratio
        )

        # Spatial masking
        n_spots = data.n_spots
        spatial_mask = torch.zeros(n_spots, dtype=torch.bool)
        n_spatial_mask = int(n_spots * self.config.spatial_mask_ratio)
        spatial_mask_indices = torch.randperm(n_spots)[:n_spatial_mask]
        spatial_mask[spatial_mask_indices] = True

        # Move to device
        masked_tokens = masked_tokens.to(self.device)
        labels = labels.to(self.device)
        spatial_mask = spatial_mask.to(self.device)
        coords = data.pos.to(self.device)
        edge_index = data.edge_index.to(self.device)
        edge_attr = data.edge_attr.to(self.device) if data.edge_attr is not None else None
        gene_ids = data.gene_ids.to(self.device)

        self.optimizer.zero_grad()

        if self.config.mixed_precision:
            with torch.amp.autocast("cuda"):
                outputs = self.model.pretrain_forward(
                    expr_tokens=data.x_tokens.to(self.device),
                    masked_tokens=masked_tokens,
                    gene_ids=gene_ids,
                    coords=coords,
                    edge_index=edge_index,
                    edge_attr=edge_attr,
                    labels=labels,
                    spatial_mask=spatial_mask,
                )
                loss = (
                    self.config.mgp_weight * outputs.get("mgp_loss", 0)
                    + self.config.contrastive_weight * outputs.get("contrastive_loss", 0)
                    + self.config.scp_weight * outputs.get("scp_loss", 0)
                )

            self.scaler.scale(loss).backward()
            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(
                self.model.parameters(), self.config.max_grad_norm
            )
            self.scaler.step(self.optimizer)
            self.scaler.update()
        else:
            outputs = self.model.pretrain_forward(
                expr_tokens=data.x_tokens.to(self.device),
                masked_tokens=masked_tokens,
                gene_ids=gene_ids,
                coords=coords,
                edge_index=edge_index,
                edge_attr=edge_attr,
                labels=labels,
                spatial_mask=spatial_mask,
            )
            loss = (
                self.config.mgp_weight * outputs.get("mgp_loss", 0)
                + self.config.contrastive_weight * outputs.get("contrastive_loss", 0)
                + self.config.scp_weight * outputs.get("scp_loss", 0)
            )

            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                self.model.parameters(), self.config.max_grad_norm
            )
            self.optimizer.step()

        return loss.item()

    def _save_checkpoint(
        self, epoch: int, loss: float, is_best: bool = False
    ):
        """Save model checkpoint."""
        model = (
            self.model.module
            if self.config.distributed
            else self.model
        )

        checkpoint = {
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": self.scheduler.state_dict(),
            "loss": loss,
            "global_step": self.global_step,
            "config": {
                "n_genes": self.config.n_genes,
                "vocab_size": self.config.vocab_size,
                "d_model": self.config.d_model,
                "n_heads": self.config.n_heads,
                "n_layers": self.config.n_layers,
                "d_ff": self.config.d_ff,
                "dropout": self.config.dropout,
            },
        }

        if is_best:
            path = os.path.join(self.config.output_dir, "best_model.pt")
        else:
            path = os.path.join(
                self.config.output_dir, f"checkpoint_epoch_{epoch+1}.pt"
            )

        torch.save(checkpoint, path)
        logger.info(f"Saved checkpoint to {path}")
