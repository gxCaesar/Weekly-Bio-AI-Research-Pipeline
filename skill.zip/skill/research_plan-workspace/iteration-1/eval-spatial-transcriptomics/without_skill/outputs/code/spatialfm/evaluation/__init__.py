"""Evaluation metrics and benchmarks."""

from spatialfm.evaluation.metrics import (
    compute_clustering_metrics,
    compute_classification_metrics,
    compute_regression_metrics,
    compute_integration_metrics,
)
