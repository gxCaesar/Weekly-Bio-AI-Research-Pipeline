"""
Gene expression tokenization for SpatialFM.

Converts continuous gene expression values into discrete tokens
for the Transformer-based model.
"""

import numpy as np
import torch
from typing import Optional


class GeneExpressionTokenizer:
    """
    Tokenize continuous gene expression values into discrete bins.

    Special tokens:
        0: [PAD] - padding token
        1: [MASK] - mask token for pretraining
        2: [ZERO] - zero expression token
        3 to n_bins+2: Expression level bins

    Args:
        n_bins: Number of expression level bins (default: 64).
        strategy: Binning strategy ('uniform', 'quantile', 'log_uniform').
    """

    # Special token IDs
    PAD_TOKEN = 0
    MASK_TOKEN = 1
    ZERO_TOKEN = 2
    EXPR_TOKEN_OFFSET = 3

    def __init__(self, n_bins: int = 64, strategy: str = "quantile"):
        self.n_bins = n_bins
        self.strategy = strategy
        self.vocab_size = n_bins + self.EXPR_TOKEN_OFFSET
        self.bin_edges: Optional[np.ndarray] = None
        self.is_fitted = False

    def fit(self, expression_matrix: torch.Tensor) -> "GeneExpressionTokenizer":
        """
        Fit the tokenizer on expression data to determine bin edges.

        Args:
            expression_matrix: Gene expression matrix [n_cells, n_genes].

        Returns:
            Self.
        """
        values = expression_matrix.numpy().flatten()
        nonzero_values = values[values > 0]

        if len(nonzero_values) == 0:
            self.bin_edges = np.linspace(0, 1, self.n_bins + 1)
        elif self.strategy == "uniform":
            self.bin_edges = np.linspace(
                nonzero_values.min(), nonzero_values.max(), self.n_bins + 1
            )
        elif self.strategy == "quantile":
            percentiles = np.linspace(0, 100, self.n_bins + 1)
            self.bin_edges = np.percentile(nonzero_values, percentiles)
            # Remove duplicates
            self.bin_edges = np.unique(self.bin_edges)
            if len(self.bin_edges) < self.n_bins + 1:
                # Fill in with uniform spacing
                self.bin_edges = np.linspace(
                    nonzero_values.min(), nonzero_values.max(), self.n_bins + 1
                )
        elif self.strategy == "log_uniform":
            log_min = np.log1p(nonzero_values.min())
            log_max = np.log1p(nonzero_values.max())
            log_edges = np.linspace(log_min, log_max, self.n_bins + 1)
            self.bin_edges = np.expm1(log_edges)
        else:
            raise ValueError(f"Unknown binning strategy: {self.strategy}")

        self.is_fitted = True
        return self

    def transform(self, expression_matrix: torch.Tensor) -> torch.LongTensor:
        """
        Tokenize gene expression values.

        Args:
            expression_matrix: Gene expression matrix [n_cells, n_genes].

        Returns:
            Token IDs [n_cells, n_genes].
        """
        if not self.is_fitted:
            raise RuntimeError("Tokenizer must be fitted before transform.")

        values = expression_matrix.numpy()
        tokens = np.full_like(values, self.ZERO_TOKEN, dtype=np.int64)

        # Tokenize nonzero values
        nonzero_mask = values > 0
        if nonzero_mask.any():
            bin_indices = np.digitize(values[nonzero_mask], self.bin_edges) - 1
            bin_indices = np.clip(bin_indices, 0, self.n_bins - 1)
            tokens[nonzero_mask] = bin_indices + self.EXPR_TOKEN_OFFSET

        return torch.LongTensor(tokens)

    def inverse_transform(self, tokens: torch.LongTensor) -> torch.FloatTensor:
        """
        Convert tokens back to approximate expression values.

        Args:
            tokens: Token IDs [n_cells, n_genes].

        Returns:
            Approximate expression values [n_cells, n_genes].
        """
        if not self.is_fitted:
            raise RuntimeError("Tokenizer must be fitted before inverse_transform.")

        token_np = tokens.numpy()
        values = np.zeros_like(token_np, dtype=np.float32)

        # Convert expression tokens back to bin centers
        expr_mask = token_np >= self.EXPR_TOKEN_OFFSET
        if expr_mask.any():
            bin_indices = token_np[expr_mask] - self.EXPR_TOKEN_OFFSET
            bin_indices = np.clip(bin_indices, 0, len(self.bin_edges) - 2)
            bin_centers = (self.bin_edges[bin_indices] + self.bin_edges[bin_indices + 1]) / 2
            values[expr_mask] = bin_centers

        return torch.FloatTensor(values)

    def mask_tokens(
        self,
        tokens: torch.LongTensor,
        mask_ratio: float = 0.15,
        mask_prob: float = 0.8,
        random_prob: float = 0.1,
    ) -> tuple:
        """
        Apply masking for pretraining (MLM-style).

        Args:
            tokens: Input token IDs [n_cells, n_genes].
            mask_ratio: Fraction of tokens to mask.
            mask_prob: Probability of replacing with [MASK].
            random_prob: Probability of replacing with random token.

        Returns:
            masked_tokens: Tokens with masking applied.
            labels: Original tokens at masked positions, -100 elsewhere.
            mask: Boolean mask of masked positions.
        """
        labels = tokens.clone()
        masked_tokens = tokens.clone()

        # Create random mask
        probability_matrix = torch.full(tokens.shape, mask_ratio)
        # Don't mask padding or already-masked tokens
        probability_matrix[tokens == self.PAD_TOKEN] = 0.0
        mask = torch.bernoulli(probability_matrix).bool()

        # Set labels for non-masked positions to -100 (ignore in loss)
        labels[~mask] = -100

        # 80% of masked tokens -> [MASK]
        indices_replaced = torch.bernoulli(
            torch.full(tokens.shape, mask_prob)
        ).bool() & mask
        masked_tokens[indices_replaced] = self.MASK_TOKEN

        # 10% of masked tokens -> random token
        indices_random = (
            torch.bernoulli(torch.full(tokens.shape, random_prob)).bool()
            & mask
            & ~indices_replaced
        )
        random_tokens = torch.randint(
            self.EXPR_TOKEN_OFFSET, self.vocab_size, tokens.shape
        )
        masked_tokens[indices_random] = random_tokens[indices_random]

        # 10% keep original

        return masked_tokens, labels, mask
