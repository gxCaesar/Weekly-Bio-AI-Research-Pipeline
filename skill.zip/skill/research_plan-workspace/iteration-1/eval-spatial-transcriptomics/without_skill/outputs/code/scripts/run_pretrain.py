#!/usr/bin/env python
"""
Launch SpatialFM pretraining.

Usage:
    python scripts/run_pretrain.py --config configs/pretrain_default.yaml
    python scripts/run_pretrain.py --config configs/pretrain_default.yaml --n_layers 24 --d_model 768

For distributed training:
    torchrun --nproc_per_node=8 scripts/run_pretrain.py --config configs/pretrain_default.yaml --distributed
"""

import argparse
import logging
import yaml
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from spatialfm.models.spatialfm import SpatialFM
from spatialfm.data.dataset import SpatialTranscriptomicsDataset
from spatialfm.training.pretrain import PretrainRunner, PretrainConfig

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("spatialfm.pretrain")


def parse_args():
    parser = argparse.ArgumentParser(description="SpatialFM Pretraining")
    parser.add_argument("--config", type=str, required=True, help="Config YAML path")
    parser.add_argument("--data_dir", type=str, default=None, help="Data directory")
    parser.add_argument("--output_dir", type=str, default=None, help="Output directory")
    parser.add_argument("--n_layers", type=int, default=None)
    parser.add_argument("--d_model", type=int, default=None)
    parser.add_argument("--n_heads", type=int, default=None)
    parser.add_argument("--max_epochs", type=int, default=None)
    parser.add_argument("--learning_rate", type=float, default=None)
    parser.add_argument("--distributed", action="store_true")
    parser.add_argument("--local_rank", type=int, default=0)
    return parser.parse_args()


def main():
    args = parse_args()

    # Load config
    with open(args.config, "r") as f:
        config_dict = yaml.safe_load(f)

    # Override with CLI arguments
    model_cfg = config_dict.get("model", {})
    train_cfg = config_dict.get("training", {})
    data_cfg = config_dict.get("data", {})
    sampling_cfg = config_dict.get("sampling", {})
    log_cfg = config_dict.get("logging", {})

    if args.n_layers is not None:
        model_cfg["n_layers"] = args.n_layers
    if args.d_model is not None:
        model_cfg["d_model"] = args.d_model
    if args.n_heads is not None:
        model_cfg["n_heads"] = args.n_heads
    if args.max_epochs is not None:
        train_cfg["max_epochs"] = args.max_epochs
    if args.learning_rate is not None:
        train_cfg["learning_rate"] = args.learning_rate
    if args.output_dir is not None:
        log_cfg["output_dir"] = args.output_dir
    if args.data_dir is not None:
        data_cfg["data_dir"] = args.data_dir

    # Build PretrainConfig
    pretrain_config = PretrainConfig(
        n_genes=model_cfg.get("n_genes", 5000),
        vocab_size=model_cfg.get("vocab_size", 67),
        d_model=model_cfg.get("d_model", 512),
        n_heads=model_cfg.get("n_heads", 8),
        n_layers=model_cfg.get("n_layers", 12),
        d_ff=model_cfg.get("d_ff", 2048),
        dropout=model_cfg.get("dropout", 0.1),
        max_epochs=train_cfg.get("max_epochs", 100),
        batch_size=train_cfg.get("batch_size", 4),
        learning_rate=train_cfg.get("learning_rate", 1e-4),
        weight_decay=train_cfg.get("weight_decay", 0.01),
        warmup_epochs=train_cfg.get("warmup_epochs", 10),
        max_grad_norm=train_cfg.get("max_grad_norm", 1.0),
        mixed_precision=train_cfg.get("mixed_precision", True),
        gene_mask_ratio=train_cfg.get("gene_mask_ratio", 0.15),
        spatial_mask_ratio=train_cfg.get("spatial_mask_ratio", 0.15),
        mgp_weight=train_cfg.get("mgp_weight", 1.0),
        contrastive_weight=train_cfg.get("contrastive_weight", 0.1),
        scp_weight=train_cfg.get("scp_weight", 0.1),
        log_interval=log_cfg.get("log_interval", 100),
        save_interval=log_cfg.get("save_interval", 5),
        output_dir=log_cfg.get("output_dir", "./checkpoints"),
        wandb_project=log_cfg.get("wandb_project", "spatialfm"),
        wandb_run_name=log_cfg.get("wandb_run_name", None),
        n_nodes_per_subgraph=sampling_cfg.get("n_nodes_per_subgraph", 2048),
        sampling_strategy=sampling_cfg.get("sampling_strategy", "spatial_cluster"),
        distributed=args.distributed,
        local_rank=args.local_rank,
    )

    logger.info(f"Configuration: {pretrain_config}")

    # Load data
    data_dir = data_cfg.get("data_dir", "./data/pretrain")
    h5ad_files = [
        os.path.join(data_dir, f)
        for f in os.listdir(data_dir)
        if f.endswith(".h5ad")
    ]
    logger.info(f"Found {len(h5ad_files)} data files in {data_dir}")

    if len(h5ad_files) == 0:
        logger.error(f"No .h5ad files found in {data_dir}")
        sys.exit(1)

    dataset = SpatialTranscriptomicsDataset(
        adata_paths=h5ad_files,
        n_genes=data_cfg.get("n_genes", 5000),
        n_bins=data_cfg.get("n_bins", 64),
        graph_method=data_cfg.get("graph_method", "knn"),
        k_neighbors=data_cfg.get("k_neighbors", 6),
    )

    # Initialize runner and train
    runner = PretrainRunner(config=pretrain_config, dataset=dataset)
    runner.train()

    logger.info("Pretraining complete!")


if __name__ == "__main__":
    main()
