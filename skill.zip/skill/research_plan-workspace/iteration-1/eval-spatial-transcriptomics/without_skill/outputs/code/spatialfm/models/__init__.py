"""Model architectures for SpatialFM."""

from spatialfm.models.spatialfm import SpatialFM
from spatialfm.models.encoder import SpatialGraphTransformerEncoder
from spatialfm.models.spatial_encoding import (
    FourierSpatialEncoding,
    RelativeSpatialBias,
    GraphStructureEncoding,
)
from spatialfm.models.task_heads import (
    SpatialDomainHead,
    CellTypeAnnotationHead,
    GeneExpressionPredictionHead,
    SVGDetectionHead,
)
