"""
SpatialFM: A Foundation Model for Spatial Transcriptomics

This package implements the SpatialFM foundation model for spatial
transcriptomics data analysis. SpatialFM uses a spatial-aware graph
Transformer architecture with novel pretraining strategies to learn
unified representations of gene expression and spatial organization.

Modules:
    data: Data loading, preprocessing, and tokenization
    models: Model architectures (encoder, decoder, task heads)
    training: Pretraining and fine-tuning loops
    evaluation: Evaluation metrics and benchmarks
    utils: Utility functions
"""

__version__ = "0.1.0"
__author__ = "SpatialFM Team"

from spatialfm.models.spatialfm import SpatialFM
from spatialfm.models.encoder import SpatialGraphTransformerEncoder
from spatialfm.data.dataset import SpatialTranscriptomicsDataset
