# 空间转录组学基础模型文献综述

## 1. 引言

空间转录组学(Spatial Transcriptomics, ST)是近年来生物信息学领域最具变革性的技术之一。它不仅能够测量组织中基因的表达水平，还能保留基因表达的空间位置信息，从而为理解组织结构、细胞间通信和疾病微环境提供了前所未有的视角。随着10x Visium、MERFISH、Slide-seq、Stereo-seq等平台的快速发展，空间转录组学数据正以指数级速度增长。然而，现有的分析方法大多针对特定任务设计，缺乏统一的建模框架。

基础模型(Foundation Model)的概念源自自然语言处理领域，以GPT、BERT等为代表。其核心思想是通过在大规模数据上进行预训练，学习通用的数据表征，随后通过微调适应各种下游任务。在单细胞生物学领域，scGPT、Geneformer、scFoundation等模型已经证明了基础模型范式的巨大潜力。然而，将基础模型扩展到空间转录组学领域面临独特的挑战：需要同时建模基因表达的高维特征和空间组织的几何结构。

本文献综述旨在系统梳理空间转录组学分析方法和生物学基础模型的最新进展，识别当前研究的空白，为构建空间转录组学基础模型奠定理论基础。

## 2. 空间转录组学技术平台

### 2.1 基于测序的方法

#### 2.1.1 10x Visium
10x Visium是目前应用最广泛的空间转录组学平台之一。它使用带有条形码的寡核苷酸阵列捕获组织切片中的mRNA，每个捕获点(spot)的直径约55微米，包含约1-10个细胞。Visium能够检测全转录组水平的基因表达，但其空间分辨率相对有限。2023年推出的Visium HD将分辨率提升至2微米级别。

#### 2.1.2 Slide-seq / Slide-seq V2
Slide-seq由MIT团队开发，使用DNA条形码微珠阵列实现约10微米的空间分辨率。Slide-seq V2在灵敏度上比V1提高了约10倍，使其在检测低表达基因方面更具优势。

#### 2.1.3 Stereo-seq
华大基因开发的Stereo-seq平台采用DNA纳米球(DNB)芯片技术，可在纳米级分辨率下实现超大视野(厘米级)的空间转录组分析。该平台在小鼠胚胎发育图谱等大规模项目中展现了卓越性能。

#### 2.1.4 HDST与DBiT-seq
HDST(High-Definition Spatial Transcriptomics)将分辨率提高到2微米级别。DBiT-seq通过确定性条形码技术实现了在同一组织切片上同时检测转录组和蛋白质组的能力。

### 2.2 基于成像的方法

#### 2.2.1 MERFISH
MERFISH(Multiplexed Error-Robust Fluorescence In Situ Hybridization)由庄小威实验室开发，利用组合标记和多轮成像实现单分子灵敏度的空间基因表达检测。最新的MERFISH技术可同时检测数千个基因，达到亚细胞分辨率。

#### 2.2.2 seqFISH / seqFISH+
seqFISH通过连续荧光原位杂交技术实现空间基因表达检测。seqFISH+扩展了检测通量，可同时检测超过10,000个基因。

#### 2.2.3 STARmap与STARmap PLUS
STARmap(Spatially-resolved Transcript Amplicon Readout Mapping)使用SNAIL探针实现厚组织切片中基因表达的三维空间检测。STARmap PLUS进一步整合了蛋白质检测能力。

### 2.3 技术平台比较

| 特征 | Visium | Slide-seq V2 | Stereo-seq | MERFISH | seqFISH+ |
|------|--------|-------------|-----------|---------|----------|
| 分辨率 | ~55um (HD: 2um) | ~10um | 亚细胞 | 亚细胞 | 亚细胞 |
| 基因通量 | 全转录组 | 全转录组 | 全转录组 | ~数千 | ~10,000 |
| 视野大小 | ~6.5mm x 6.5mm | ~3mm | 厘米级 | 可变 | 可变 |
| 灵敏度 | 中等 | 中-高 | 高 | 极高 | 高 |
| 主要限制 | 分辨率低 | 视野较小 | 数据量巨大 | 基因数有限 | 操作复杂 |

## 3. 空间转录组学计算方法

### 3.1 空间聚类与域识别

#### 3.1.1 SpaGCN
SpaGCN(Spatial Graph Convolutional Network)将基因表达数据与组织学图像信息整合，通过图卷积网络实现空间域的自动识别。该方法使用可学习的图构建策略，能够自适应地确定空间邻域关系。

**关键创新**: 整合组织学图像特征，使用图卷积自动聚类
**局限性**: 对图构建参数敏感，扩展性有限

#### 3.1.2 BayesSpace
BayesSpace采用贝叶斯统计框架，通过马尔可夫随机场建模空间先验，实现空间域识别和表达增强。该方法在统计学上具有严谨的理论基础。

**关键创新**: 贝叶斯框架，空间先验建模
**局限性**: 计算成本高，不适用于大规模数据

#### 3.1.3 STAGATE
STAGATE(Spatial Transcriptomics Analysis via Graph Attention auto-Encoder)使用图注意力自编码器学习空间感知的基因表达表征。该方法引入了自适应的图注意力机制来捕获空间依赖关系。

**关键创新**: 图注意力机制，自适应空间建模
**局限性**: 需要预定义邻域范围

#### 3.1.4 SEDR
SEDR(Spatially Embedded Deep Representation)结合变分图自编码器和深度嵌入聚类，在低维嵌入空间中同时学习基因表达特征和空间结构。

#### 3.1.5 GraphST
GraphST使用自监督对比学习框架，通过图神经网络联合学习基因表达和空间位置的表征，支持空间聚类、批次校正等多种下游任务。

### 3.2 空间可变基因检测

#### 3.2.1 SpatialDE / SpatialDE2
SpatialDE使用高斯过程回归检测具有空间表达模式的基因。SpatialDE2通过引入可扩展的近似推断算法，显著提高了计算效率。

#### 3.2.2 SPARK / SPARK-X
SPARK(Spatial PAttern Recognition via Kernels)采用核方法进行空间可变基因检测，SPARK-X进一步提高了计算效率和统计功效。

#### 3.2.3 Hotspot
Hotspot通过局部自相关性分析识别具有空间模式的基因和基因模块，特别适合高分辨率空间转录组数据。

### 3.3 细胞类型解卷积

#### 3.3.1 cell2location
cell2location使用贝叶斯模型将单细胞RNA-seq参考图谱与空间转录组数据整合，推断每个空间位置的细胞类型组成。

#### 3.3.2 RCTD (spacexr)
RCTD(Robust Cell Type Decomposition)采用统计回归框架进行细胞类型解卷积，在准确性和鲁棒性方面表现优异。

#### 3.3.3 Tangram
Tangram使用深度学习将单细胞数据映射到空间坐标系，同时支持基因插补和细胞类型注释。

#### 3.3.4 CARD
CARD(Conditional Autoregressive-based Deconvolution)通过条件自回归模型建模空间依赖关系，在解卷积中引入空间先验信息。

### 3.4 空间细胞通讯分析

#### 3.4.1 COMMOT
COMMOT(COMMunication analysis by Optimal Transport)使用最优传输理论推断空间分辨的细胞间通讯网络。

#### 3.4.2 stLearn
stLearn整合基因表达、空间距离和组织形态学信息，提供空间轨迹推断和配体-受体相互作用分析。

#### 3.4.3 SpaTalk
SpaTalk利用图神经网络和知识图谱推断空间分辨的细胞间通讯，支持配体-受体-转录因子-靶基因的完整信号通路重建。

### 3.5 空间表达超分辨率

#### 3.5.1 Tangram
如上所述，Tangram不仅可用于解卷积，还能通过将高分辨率单细胞数据映射到空间坐标来增强空间分辨率。

#### 3.5.2 iStar
iStar使用组织学图像引导的超分辨率方法，将低分辨率Visium数据增强到接近单细胞分辨率。

#### 3.5.3 XFuse
XFuse结合深度生成模型和组织学图像，同时实现基因表达的空间超分辨率和新基因预测。

### 3.6 三维空间重建

#### 3.6.1 PASTE / PASTE2
PASTE(Probabilistic Alignment of ST Experiments)使用最优传输方法对齐来自连续切片的空间转录组数据，实现三维组织重建。PASTE2扩展了对部分重叠切片的支持。

#### 3.6.2 STAligner
STAligner使用图注意力网络在批次间对齐空间转录组数据，同时保持空间结构和基因表达的一致性。

## 4. 单细胞与空间组学基础模型

### 4.1 单细胞基础模型

#### 4.1.1 scGPT
scGPT是首批将GPT架构应用于单细胞转录组数据的基础模型之一。该模型在超过3300万个细胞上进行预训练，使用基于基因表达值的token化策略，支持细胞类型注释、基因扰动预测、多批次整合和基因调控网络推断等多种下游任务。

**架构**: 基于Transformer的自回归生成模型
**预训练策略**: 掩码基因表达预测(Masked Gene Expression Prediction)
**关键创新**: 基因token嵌入、条件生成
**局限性**: 未建模空间信息，计算成本高

#### 4.1.2 Geneformer
Geneformer由Theodoris等人在Nature上发表，使用rank-value编码将基因表达转化为token序列，在大规模单细胞数据上预训练。该模型在罕见疾病基因发现和药物靶点预测方面表现出色。

**架构**: BERT风格的双向Transformer
**预训练策略**: 掩码基因预测
**关键创新**: Rank-value编码，无需表达值的离散化
**局限性**: 忽略基因表达的精确定量信息

#### 4.1.3 scFoundation
scFoundation(xTrimoscFoundation)是目前规模最大的单细胞基础模型之一，在超过5000万个人类单细胞上预训练，使用了全部约20,000个基因作为输入特征。该模型采用非对称的编码器-解码器架构来处理超长基因序列。

**架构**: 非对称Transformer编码器-解码器
**预训练策略**: 掩码基因表达建模
**关键创新**: 高效处理全基因组输入，大规模预训练
**局限性**: 资源需求极高，未考虑空间信息

#### 4.1.4 UCE (Universal Cell Embedding)
UCE通过将基因序列信息(通过蛋白质语言模型ESM-2获取)整合到单细胞表征学习中，构建了跨物种的通用细胞嵌入模型。

**关键创新**: 跨物种泛化，利用蛋白质语言模型
**局限性**: 空间信息缺失

#### 4.1.5 CellPLM
CellPLM采用了细胞级别的掩码自编码器架构，不同于逐基因的Token化策略，而是将整个细胞视为一个实体进行建模。

### 4.2 空间感知模型

#### 4.2.1 SPACE (Spatially Aware Cell Embedding)
SPACE是为数不多的尝试将空间信息整合到细胞表征学习中的方法。它通过空间邻域图约束学习空间一致的细胞嵌入。

#### 4.2.2 SpatialScope
SpatialScope整合单细胞参考和空间转录组数据，在保持空间约束的同时实现单细胞分辨率的空间图谱重建。

#### 4.2.3 STNet
STNet使用H&E组织学图像预测空间基因表达，展示了视觉特征与基因表达之间的关联。

### 4.3 多模态生物学基础模型

#### 4.3.1 BiomedGPT
BiomedGPT是一个多模态生物医学基础模型，能够处理文本、图像和分子数据。虽然它未直接处理空间转录组数据，但其多模态架构为空间转录组基础模型的设计提供了参考。

#### 4.3.2 GeneCompass
GeneCompass整合了多种先验知识(基因调控网络、转录因子motif等)到单细胞基础模型中，展示了知识增强的预训练策略的有效性。

#### 4.3.3 scMultiSim
scMultiSim提供了多模态单细胞数据的模拟框架，对于评估多模态基础模型具有重要价值。

## 5. 图神经网络与空间数据建模

### 5.1 图Transformer

#### 5.1.1 Graphormer
Graphormer由微软提出，在标准Transformer中引入图结构编码(度编码、空间编码、边编码)，在多个分子属性预测基准上达到SOTA。

**与空间转录组的关联**: 空间转录组数据天然具有图结构，Graphormer的空间编码策略可直接借鉴。

#### 5.1.2 GPS (General, Powerful, Scalable)
GPS框架将消息传递GNN与全局Transformer注意力结合，在保持图归纳偏置的同时实现全局信息聚合。

#### 5.1.3 TokenGT
TokenGT将图节点和边转化为token序列，直接使用标准Transformer处理图数据，展示了图结构数据与序列模型的统一可能性。

### 5.2 空间数据的几何深度学习

#### 5.2.1 等变神经网络
E(n)-等变图神经网络(EGNN)在保持旋转和平移等变性的同时处理空间坐标数据，对于建模组织切片的空间结构具有理论优势。

#### 5.2.2 点云处理网络
PointNet/PointNet++等点云处理网络可将空间转录组数据视为带有基因表达特征的点云进行处理。

#### 5.2.3 空间注意力机制
Spatial Attention在计算机视觉领域广泛应用，可根据空间位置调整注意力权重，适合捕获空间转录组中的局部和全局空间模式。

### 5.3 可扩展图学习

#### 5.3.1 GraphSAINT
GraphSAINT通过子图采样实现大规模图神经网络的训练，对于处理包含数十万甚至数百万spot/cell的空间转录组数据具有重要参考价值。

#### 5.3.2 Cluster-GCN
Cluster-GCN通过图聚类和分块训练策略提高图神经网络的可扩展性。

## 6. 预训练策略与自监督学习

### 6.1 掩码建模

掩码语言建模(MLM)是BERT的核心预训练策略，已被scGPT、Geneformer等单细胞模型成功借鉴。在空间转录组场景下，掩码策略可以扩展为:

- **基因掩码**: 随机掩码部分基因的表达值，预测被掩码的基因表达
- **空间掩码**: 掩码特定空间位置的基因表达谱，利用空间邻域信息预测
- **混合掩码**: 同时在基因维度和空间维度上进行掩码

### 6.2 对比学习

#### 6.2.1 空间对比学习
利用空间邻近关系构建正样本对(空间邻近的spot/cell)和负样本对(空间远离的spot/cell)，学习空间感知的表征。

#### 6.2.2 跨模态对比学习
将基因表达与组织学图像特征进行对比学习，实现跨模态的表征对齐。

### 6.3 生成式预训练

#### 6.3.1 变分自编码器(VAE)
在单细胞领域，scVI等基于VAE的模型已被广泛使用。空间转录组的VAE需要额外建模空间依赖关系。

#### 6.3.2 扩散模型
扩散模型在图像生成领域取得了巨大成功。将扩散模型应用于空间基因表达数据，可以实现空间表达谱的生成和插补。

#### 6.3.3 流匹配(Flow Matching)
流匹配作为生成模型的新范式，在连续数据建模方面具有优势，适合建模基因表达值的连续分布。

### 6.4 多任务预训练

结合多种预训练目标(掩码预测、对比学习、生成建模)的多任务预训练策略，可以让模型同时学习不同粒度和不同方面的数据表征。

## 7. 关键数据资源

### 7.1 大规模空间转录组数据集

| 数据集 | 平台 | 物种 | 组织 | 规模 |
|-------|------|------|------|------|
| Human Cell Atlas ST | 多平台 | 人类 | 多组织 | 持续增长 |
| BRAIN Initiative | MERFISH/Visium | 人类/小鼠 | 脑 | 百万级细胞 |
| Stereo-seq Mouse Embryo | Stereo-seq | 小鼠 | 全胚胎 | 数十亿reads |
| SpatialDB | 多平台 | 多物种 | 多组织 | 综合数据库 |
| STOmicsDB | Stereo-seq等 | 多物种 | 多组织 | 综合数据库 |
| SODB | 多平台 | 多物种 | 多组织 | 综合数据库 |

### 7.2 基准数据集

| 任务 | 数据集 | 说明 |
|------|--------|------|
| 空间域识别 | DLPFC (Visium) | 人类前额叶皮质，12个切片，手动注释 |
| 细胞类型解卷积 | 模拟数据 + 真实数据 | 使用scRNA-seq参考验证 |
| 空间可变基因 | 合成数据 | 已知空间模式的模拟数据 |
| 批次整合 | 多切片数据 | 来自同一组织的多个切片 |

## 8. 当前研究空白与挑战

### 8.1 缺乏统一的空间转录组基础模型

现有的单细胞基础模型(scGPT, Geneformer等)未建模空间信息，而空间转录组的专用方法(SpaGCN, STAGATE等)又仅针对特定任务设计。需要一个能够统一建模基因表达和空间结构的基础模型。

### 8.2 跨平台泛化

不同空间转录组平台在分辨率、基因通量、噪声特征等方面存在显著差异。如何构建能够跨平台泛化的基础模型是一个核心挑战。

### 8.3 多尺度空间建模

组织具有多尺度的空间组织结构(亚细胞-细胞-微环境-组织域-器官)。现有方法大多只在单一尺度上建模，缺乏多尺度的统一建模能力。

### 8.4 可扩展性

高分辨率空间转录组数据(如Stereo-seq、MERFISH)可包含数百万个细胞/spot，现有方法的计算效率难以满足需求。

### 8.5 多模态整合

空间转录组数据通常伴随组织学图像(H&E染色)，如何有效整合基因表达、空间位置和形态学信息仍是开放问题。

### 8.6 三维空间建模

大多数方法仅处理二维组织切片，缺乏对三维空间结构的建模能力。

### 8.7 零样本/少样本泛化

面对新的组织类型或疾病条件时，模型应具备零样本或少样本泛化的能力。

## 9. 研究机遇总结

基于以上综述，我们识别出构建空间转录组学基础模型的核心机遇:

1. **架构设计**: 将图Transformer与空间编码相结合，构建能够同时处理基因表达高维特征和空间几何结构的统一架构
2. **预训练策略**: 设计空间感知的掩码建模和对比学习策略，在基因维度和空间维度上同时进行预训练
3. **多尺度建模**: 利用层次化图结构或多分辨率注意力机制，实现从亚细胞到组织域的多尺度空间建模
4. **跨平台统一**: 通过平台无关的数据标准化和条件生成策略，实现跨平台的统一建模
5. **多模态融合**: 整合基因表达、空间位置、组织学图像等多模态信息，构建更丰富的组织表征
6. **大规模预训练**: 汇集来自多个平台、多个物种、多个组织的空间转录组数据，进行大规模预训练

## 10. 参考文献

1. Stahl, P.L. et al. Visualization and analysis of gene expression in tissue sections by spatial transcriptomics. Science 353, 78-82 (2016).
2. Chen, K.H. et al. Spatially resolved, highly multiplexed RNA profiling in single cells. Science 348, aaa6090 (2015).
3. Rodriques, S.G. et al. Slide-seq: A scalable technology for measuring genome-wide expression at high spatial resolution. Science 363, 1463-1467 (2019).
4. Chen, A. et al. Spatiotemporal transcriptomic atlas of mouse organogenesis using DNA nanoball-patterned arrays. Cell 185, 1777-1792 (2022).
5. Hu, J. et al. SpaGCN: Integrating gene expression, spatial location and histology to identify spatial domains and spatially variable genes by graph convolutional network. Nature Methods 18, 1342-1351 (2021).
6. Zhao, E. et al. BayesSpace enables the robust characterization of spatial gene expression architecture. Nature Biotechnology 39, 1375-1384 (2021).
7. Dong, K. & Zhang, S. STAGATE: Deciphering spatial domains from spatially resolved transcriptomics with an adaptive graph attention auto-encoder. Nature Communications 13, 1739 (2022).
8. Cui, H. et al. scGPT: Building a foundation model for single-cell multi-omics using generative AI. Nature Methods 21, 1470-1480 (2024).
9. Theodoris, C.V. et al. Transfer learning enables predictions in network biology. Nature 618, 616-624 (2023).
10. Hao, M. et al. Large-scale foundation model on single-cell transcriptomics. Nature Methods 21, 1481-1491 (2024).
11. Ying, C. et al. Do Transformers Really Perform Bad for Graph Representation? Advances in Neural Information Processing Systems 34 (2021).
12. Rampasek, L. et al. Recipe for a General, Powerful, Scalable Graph Transformer. Advances in Neural Information Processing Systems 35 (2022).
13. Long, Y. et al. Spatially informed clustering, integration, and deconvolution of spatial transcriptomics with GraphST. Nature Communications 14, 1155 (2023).
14. Saarinen, N. et al. SpatialDE2: Fast and localized variance component analysis of spatial transcriptomics. bioRxiv (2023).
15. Kleshchevnikov, V. et al. cell2location maps fine-grained cell types in spatial transcriptomics. Nature Biotechnology 40, 661-671 (2022).
16. Biancalani, T. et al. Deep learning and alignment of spatially resolved single-cell transcriptomes with Tangram. Nature Methods 18, 1352-1362 (2021).
17. Cang, Z. et al. Screening cell-cell communication in spatial transcriptomics via collective optimal transport. Nature Methods 20, 218-228 (2023).
18. Zong, Y. et al. PASTE: Probabilistic alignment of ST experiments. Nature Methods 19, 567-575 (2022).
19. Satorras, V.G. et al. E(n) Equivariant Graph Neural Networks. ICML (2021).
20. Rosen, Y. et al. Universal Cell Embeddings: A Foundation Model for Cell Biology. bioRxiv (2023).
