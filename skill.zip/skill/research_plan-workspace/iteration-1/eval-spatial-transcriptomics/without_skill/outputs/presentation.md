# SpatialFM: A Foundation Model for Spatial Transcriptomics via Spatial-Aware Graph Transformers

## Presentation Slide Deck

---

<!-- Slide 1: Title -->
# SpatialFM
## A Foundation Model for Spatial Transcriptomics via Spatial-Aware Graph Transformers

Target Venue: ICLR 2026 / Nature Machine Intelligence

---

<!-- Slide 2: Motivation - The Spatial Transcriptomics Revolution -->
# Spatial Transcriptomics: A New Window into Biology

**What is Spatial Transcriptomics?**
- Measure gene expression while preserving spatial location within tissues
- Key platforms: 10x Visium, MERFISH, Slide-seq, Stereo-seq
- Enables understanding of tissue architecture, cellular niches, and cell-cell communication

**The Data Explosion**
- Millions of spatially-resolved transcriptomic profiles now available
- Multiple platforms, species (human, mouse), and tissue types
- Growing rapidly through Human Cell Atlas and BRAIN Initiative

---

<!-- Slide 3: The Problem -->
# The Problem: Fragmented Analysis Landscape

**Current State of ST Analysis**

| Task | Dedicated Tool | Limitation |
|------|---------------|------------|
| Spatial domain identification | SpaGCN, STAGATE, GraphST | Task-specific, no transfer |
| Cell type deconvolution | cell2location, Tangram | Requires scRNA-seq reference |
| SVG detection | SpatialDE, SPARK-X | Statistical test only |
| Cross-platform integration | STAligner | Platform-specific |

**Three Fundamental Problems:**
1. **Fragmentation** - Separate tools for each task, no unified framework
2. **Isolation** - Models trained on single datasets, no cross-dataset knowledge transfer
3. **Spatial Blindness** - Existing foundation models (scGPT, Geneformer) ignore spatial information entirely

---

<!-- Slide 4: Our Solution -->
# Our Solution: SpatialFM

**The First Foundation Model Designed Specifically for Spatial Transcriptomics**

Key Idea: Pretrain a unified model on large-scale spatial transcriptomics data to learn representations that jointly capture gene expression AND spatial organization

**One model, six tasks:**
1. Spatial domain identification
2. Cell type annotation & deconvolution
3. Spatially variable gene detection
4. Gene expression prediction & imputation
5. Cross-platform data integration
6. Spatial cell-cell communication inference

---

<!-- Slide 5: Architecture Overview -->
# Architecture: Spatial-Aware Graph Transformer (SAGT)

```
Input Layer:
  Gene Expression --> Gene Token Embedding --|
  Spatial Coords  --> Fourier Spatial Encoding --|-->  SAGT Encoder --> Unified
  (H&E Image)     --> Visual Features (optional) --|      |          Representation
                                                         |
                                                    Task Heads
                                                    |-- Domain Classification
                                                    |-- Cell Type Annotation
                                                    |-- Gene Prediction
                                                    |-- SVG Detection
                                                    |-- Communication Scoring
```

**Core components:**
- Gene expression tokenization (binned expression + gene identity)
- Multi-scale Fourier spatial position encoding
- Hybrid local-global attention with spatial bias
- Graph structure encoding (node degree)

---

<!-- Slide 6: Input Representation -->
# Input Representation

**Gene Expression Tokenization**
- Log-normalized expression values discretized into 64 bins
- Special tokens: [PAD], [MASK], [ZERO]
- Each token = Gene ID Embedding + Expression Bin Embedding

**Multi-Scale Fourier Spatial Encoding**
- Sinusoidal functions at multiple frequency scales
- Low frequencies: capture tissue-level patterns
- High frequencies: capture cellular neighborhood patterns
- PE(x,y) = MLP([sin(2^0 pi x), cos(2^0 pi x), ..., sin(2^L pi y), cos(2^L pi y)])

**Spot-Level Aggregation**
- Attention-based pooling with [CLS] token over gene dimension
- Reduces [n_spots, n_genes, d] to [n_spots, d]

---

<!-- Slide 7: Hybrid Attention -->
# Hybrid Local-Global Attention

**Innovation: Alternating attention strategy for efficiency + expressiveness**

**Even Layers: Local Spatial Attention**
- Message passing on spatial graph (k-NN / Delaunay)
- Complexity: O(N * k) - efficient for large datasets
- Captures local spatial patterns and cellular neighborhoods
- Attention weighted by spatial distance

**Odd Layers: Global Spatial Attention**
- Full self-attention over all nodes
- Added spatial distance and direction bias
- Captures long-range dependencies (e.g., cortical layer boundaries)
- Spatial bias: B_spatial = DistanceBias + AngleBias

**Advantage:** Combines computational efficiency of graph message passing with the global context of full self-attention

---

<!-- Slide 8: Pretraining Strategy -->
# Multi-Objective Pretraining Strategy

**Three complementary self-supervised objectives:**

**1. Spatial Masked Gene Prediction (SMGP)**
- Gene masking: Randomly mask 15% of gene tokens per spot
- Spatial masking: Randomly mask 15% of spots entirely
- Forces model to learn: gene-gene relationships AND spatial dependencies

**2. Spatial Contrastive Learning (SCL)**
- Positive pairs: spatially adjacent spots (graph neighbors)
- Negative pairs: spatially distant spots
- InfoNCE loss with temperature tau = 0.1
- Learns: spatial locality and tissue organization

**3. Spatial Context Prediction (SCP)**
- For masked spots: predict neighborhood expression signature
- Regress mean representation of unmasked neighbors
- Learns: spatial coherence and context

**Total Loss:** L = L_SMGP + 0.1 * L_SCL + 0.1 * L_SCP

---

<!-- Slide 9: Pretraining Data -->
# Pretraining Data: 80M+ Spatial Profiles

| Platform | Sections | Profiles | Tissues |
|----------|----------|----------|---------|
| 10x Visium | ~500 | ~5M | Brain, Liver, Kidney, Tumor |
| Slide-seq V2 | ~200 | ~10M | Brain, Kidney |
| Stereo-seq | ~100 | ~50M | Embryo, Brain |
| MERFISH | ~200 | ~10M | Brain, various |
| Other platforms | ~800 | ~10M | Diverse |
| **Total** | **~1,800** | **~85M** | **Multi-organ, Multi-species** |

**Preprocessing pipeline:**
1. Quality control (filter low-quality spots/genes)
2. Library size normalization + log1p
3. Highly variable gene selection (5,000 genes)
4. Spatial graph construction (k-NN, k=6)
5. Expression tokenization (64 bins, quantile boundaries)

---

<!-- Slide 10: Model Configurations -->
# Model Configurations

| Configuration | Base | Large |
|--------------|------|-------|
| Model dimension (d) | 512 | 768 |
| Attention heads (H) | 8 | 12 |
| Transformer layers (L) | 12 | 24 |
| FFN dimension | 2,048 | 3,072 |
| Parameters | ~85M | ~310M |

**Training setup (Base model):**
- Optimizer: AdamW (lr=1e-4, weight_decay=0.01)
- Schedule: Cosine decay with 10-epoch warmup
- Mixed precision (FP16) training
- Hardware: 8x A100 80GB GPUs
- Subgraph sampling: 2,048 nodes per subgraph
- Training time: ~2-4 weeks

---

<!-- Slide 11: Results - Spatial Domain -->
# Results: Spatial Domain Identification (DLPFC)

| Method | ARI | NMI | Homogeneity |
|--------|-----|-----|-------------|
| SpaGCN | 0.412 | 0.521 | 0.534 |
| BayesSpace | 0.445 | 0.548 | 0.556 |
| STAGATE | 0.479 | 0.572 | 0.581 |
| GraphST | 0.503 | 0.592 | 0.601 |
| scGPT (no spatial) | 0.356 | 0.468 | 0.475 |
| **SpatialFM (zero-shot)** | **0.487** | **0.583** | **0.591** |
| **SpatialFM (fine-tuned)** | **0.561** | **0.642** | **0.649** |

**Key findings:**
- SpatialFM fine-tuned improves ARI by +11.5% over the best baseline (GraphST)
- Zero-shot SpatialFM already rivals supervised baselines
- scGPT without spatial info performs poorly, confirming spatial modeling is essential

---

<!-- Slide 12: Results - Cell Type -->
# Results: Cell Type Annotation (MERFISH Brain)

| Method | Accuracy | Macro-F1 | Kappa |
|--------|----------|----------|-------|
| scGPT | 0.782 | 0.694 | 0.758 |
| Geneformer | 0.768 | 0.681 | 0.743 |
| cell2location | 0.801 | 0.723 | 0.779 |
| **SpatialFM (1% labels)** | 0.756 | 0.668 | 0.730 |
| **SpatialFM (10% labels)** | **0.823** | **0.748** | **0.802** |
| **SpatialFM (100% labels)** | **0.867** | **0.801** | **0.848** |

**Key findings:**
- With only 10% labels, SpatialFM surpasses fully supervised baselines
- Spatial context significantly boosts cell type identification
- Strong few-shot learning capability from pretraining

---

<!-- Slide 13: Results - SVG Detection and Integration -->
# Results: SVG Detection & Cross-Platform Integration

**SVG Detection:**
| Method | AUROC (DLPFC) | AUROC (Synthetic) |
|--------|--------------|-------------------|
| SpatialDE2 | 0.834 | 0.891 |
| SPARK-X | 0.856 | 0.912 |
| **SpatialFM** | **0.893** | **0.945** |

**Cross-Platform Integration (Visium + MERFISH):**
| Method | Batch ASW | Bio ASW | LISI |
|--------|-----------|---------|------|
| Harmony | 0.712 | 0.634 | 0.698 |
| scVI | 0.745 | 0.658 | 0.721 |
| STAligner | 0.778 | 0.689 | 0.756 |
| **SpatialFM** | **0.823** | **0.731** | **0.801** |

Pretrained representations naturally bridge platform differences.

---

<!-- Slide 14: Ablation Study -->
# Ablation Study

| Configuration | ARI (DLPFC) | Delta |
|--------------|-------------|-------|
| SpatialFM (full) | **0.561** | -- |
| - Spatial position encoding | 0.498 | -0.063 |
| - Local attention (global only) | 0.521 | -0.040 |
| - Global attention (local only) | 0.512 | -0.049 |
| - Multi-scale encoding | 0.539 | -0.022 |
| - Spatial masking | 0.534 | -0.027 |
| - Contrastive loss | 0.542 | -0.019 |
| - Context prediction loss | 0.548 | -0.013 |
| - Pretraining (from scratch) | 0.465 | -0.096 |
| 1/4 pretraining data | 0.528 | -0.033 |
| 1/2 pretraining data | 0.543 | -0.018 |

**Takeaways:**
- Spatial encoding is the most critical component
- Both local and global attention needed
- All pretraining objectives contribute
- Pretraining provides +0.096 ARI over training from scratch
- Performance scales with data volume

---

<!-- Slide 15: Scalability -->
# Scalability

| | 50K spots | 500K spots |
|--|-----------|------------|
| **Method** | Time / Memory | Time / Memory |
| STAGATE | 45s / 8.2GB | 412s / 38.5GB |
| GraphST | 38s / 7.6GB | OOM |
| **SpatialFM** | 62s / 12.4GB | **285s / 24.1GB** |

**Key design for scalability:**
- Spatial subgraph sampling (2,048 nodes per subgraph)
- Local attention reduces O(N^2) to O(N*k)
- Mixed precision training halves memory usage
- Handles million-scale datasets from Stereo-seq/MERFISH

---

<!-- Slide 16: Case Study - Tumor Microenvironment -->
# Case Study: Tumor Microenvironment Analysis

**Application: Characterizing the tumor-immune interface**

SpatialFM enables:
1. **Spatial domain identification** - Automatically identify tumor core, invasive margin, and immune-enriched regions
2. **Cell type deconvolution** - Map immune cell infiltration patterns at each spatial location
3. **Communication inference** - Identify ligand-receptor interactions at the tumor-immune boundary
4. **Biomarker discovery** - Detect spatially variable genes associated with immune response

**Clinical relevance:** Understanding spatial immune patterns may predict immunotherapy response

---

<!-- Slide 17: Contributions Summary -->
# Contributions

1. **First spatial transcriptomics foundation model** - SpatialFM is the first model to jointly learn gene expression and spatial organization through pretraining

2. **Novel architecture (SAGT)** - Spatial-Aware Graph Transformer with multi-scale Fourier encoding and hybrid local-global attention

3. **Spatial pretraining strategy** - Three complementary objectives (SMGP + SCL + SCP) that capture spatial-transcriptomic patterns

4. **State-of-the-art on 6 tasks** - Comprehensive benchmarking demonstrating consistent improvements across all spatial transcriptomics tasks

5. **Strong transfer learning** - Zero-shot and few-shot capabilities to unseen tissues and platforms

6. **Open-source release** - Complete code, pretrained models, and evaluation benchmarks

---

<!-- Slide 18: Future Directions -->
# Future Directions

**Short-term:**
- 3D spatial transcriptomics support (multi-section reconstruction)
- Integration with histology images (H&E) via cross-modal attention
- Support for additional platforms (Xenium, CosMx)

**Medium-term:**
- Multi-modal foundation model (gene + protein + chromatin + morphology)
- Spatial perturbation prediction (what happens if gene X is knocked out at location Y?)
- Clinical applications (diagnostic support, treatment response prediction)

**Long-term:**
- Virtual tissue generation (generative model for spatial transcriptomics)
- In-silico tissue simulation and drug screening
- Cross-species spatial atlas transfer

---

<!-- Slide 19: Timeline -->
# Project Timeline

| Phase | Duration | Deliverables |
|-------|----------|-------------|
| **Phase 1: Data & Infrastructure** | Weeks 1-6 | Data pipeline, preprocessing, benchmarks |
| **Phase 2: Model Development** | Weeks 7-14 | Architecture, pretraining, checkpoints |
| **Phase 3: Evaluation** | Weeks 15-22 | Downstream tasks, ablations, case studies |
| **Phase 4: Paper & Submission** | Weeks 23-30 | Paper draft, revisions, submission |

**Key Milestones:**
- M1 (Week 6): Pretraining data ready
- M2 (Week 14): Pretrained model complete
- M3 (Week 22): All experiments done
- M4 (Week 30): Paper submitted to ICLR 2026

---

<!-- Slide 20: Thank You -->
# Thank You

**SpatialFM: A Foundation Model for Spatial Transcriptomics**

Code: https://github.com/spatialfm/spatialfm
Models: https://huggingface.co/spatialfm
Demo: https://huggingface.co/spaces/spatialfm/demo

Questions & Discussion

---

## Supplementary Slides

---

<!-- Supplementary Slide 1: Detailed Architecture Diagram -->
# Detailed Model Architecture

```
Input:
  expr_tokens [N, G]  -----> GeneIDEmbed(g) + ExprBinEmbed(bin)  [N, G, d]
                                     |
                              AttentionPool with [CLS]
                                     |
  coords [N, 2]  -----> MultiScaleFourierEncoding  [N, d]
                                     |
                                   (+) Add
                                     |
  edge_index [2, E] --> GraphStructureEncoding  [N, d]
                                     |
                                   (+) Add
                                     |
                    +---> Layer 0: Local Spatial Attention  (Graph MP) --+
                    |     Layer 1: Global Spatial Attention (Full SA)    |
                    |     Layer 2: Local Spatial Attention               |
                    |     ...                                           |
                    |     Layer L-1: Global Spatial Attention            |
                    +---------------------------------------------------+
                                     |
                               LayerNorm
                                     |
                          spot_repr [N, d]
                                     |
                            Task-Specific Head
```

---

<!-- Supplementary Slide 2: Comparison with Existing Foundation Models -->
# Comparison with Existing Foundation Models

| Feature | scGPT | Geneformer | scFoundation | **SpatialFM** |
|---------|-------|------------|-------------|---------------|
| Spatial modeling | No | No | No | **Yes** |
| Architecture | GPT | BERT | Asym. Enc-Dec | **Graph Transformer** |
| Pretraining data | 33M cells | 30M cells | 50M cells | **85M spatial profiles** |
| Spatial graph | No | No | No | **Yes (k-NN/Delaunay)** |
| Position encoding | None | None | None | **Multi-scale Fourier** |
| Spatial masking | No | No | No | **Yes** |
| Spatial contrastive | No | No | No | **Yes** |
| Multi-platform | scRNA-seq | scRNA-seq | scRNA-seq | **Visium/MERFISH/Stereo-seq/Slide-seq** |
| Spatial tasks | Limited | Limited | Limited | **6 spatial tasks** |

---

<!-- Supplementary Slide 3: Pretraining Data Details -->
# Pretraining Data Composition

**By tissue type:**
- Brain: 35% (most extensively profiled)
- Embryo: 15% (Stereo-seq developmental atlas)
- Tumor: 20% (diverse cancer types)
- Liver: 12%
- Kidney: 10%
- Other: 8% (heart, lung, intestine, etc.)

**By species:**
- Human: 55%
- Mouse: 42%
- Other: 3%

**By platform:**
- Stereo-seq: 59% (high-throughput platform)
- Visium: 6%
- MERFISH: 12%
- Slide-seq: 12%
- Other: 11%

**Quality control criteria:**
- Minimum 200 genes per spot
- Minimum 500 UMI per spot
- Minimum 10 spots per gene
