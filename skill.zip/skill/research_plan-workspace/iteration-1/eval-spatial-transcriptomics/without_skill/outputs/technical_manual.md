# SpatialFM 技术手册

## 空间转录组学基础模型 - 使用与开发指南

---

## 目录

1. [系统概述](#1-系统概述)
2. [环境配置](#2-环境配置)
3. [数据准备](#3-数据准备)
4. [模型架构详解](#4-模型架构详解)
5. [预训练流程](#5-预训练流程)
6. [下游任务微调](#6-下游任务微调)
7. [评估与基准测试](#7-评估与基准测试)
8. [API参考](#8-api参考)
9. [常见问题与故障排除](#9-常见问题与故障排除)
10. [开发者指南](#10-开发者指南)

---

## 1. 系统概述

### 1.1 什么是SpatialFM

SpatialFM是一个专门为空间转录组学数据设计的基础模型。它采用空间感知的图Transformer架构(SAGT)，通过在大规模多平台空间转录组数据上进行预训练，学习基因表达和空间组织的统一表征。

### 1.2 核心能力

SpatialFM支持以下六种核心分析任务:

| 任务 | 输入 | 输出 | 典型应用 |
|------|------|------|---------|
| 空间域识别 | ST数据 | 空间域标签/聚类 | 组织结构解析 |
| 细胞类型注释 | ST数据 + 参考 | 细胞类型概率 | 细胞图谱构建 |
| 空间可变基因检测 | ST数据 | 基因排序 | 标记基因发现 |
| 基因表达预测 | ST数据(部分) | 缺失基因表达 | 数据增强/插补 |
| 跨平台整合 | 多平台ST数据 | 统一嵌入 | 数据整合 |
| 空间细胞通讯 | ST数据 | 通讯分数 | 信号通路分析 |

### 1.3 系统架构

```
SpatialFM 系统架构
├── 数据层 (spatialfm.data)
│   ├── 数据加载与预处理 (preprocessing.py)
│   ├── 基因表达Token化 (tokenizer.py)
│   └── PyG数据集 (dataset.py)
├── 模型层 (spatialfm.models)
│   ├── 空间位置编码 (spatial_encoding.py)
│   ├── 图Transformer编码器 (encoder.py)
│   ├── 任务特定头 (task_heads.py)
│   └── 主模型 (spatialfm.py)
├── 训练层 (spatialfm.training)
│   ├── 预训练 (pretrain.py)
│   └── 微调 (finetune.py)
└── 评估层 (spatialfm.evaluation)
    └── 评估指标 (metrics.py)
```

### 1.4 技术规格

| 属性 | 基础模型 (Base) | 大模型 (Large) |
|------|----------------|---------------|
| 模型维度 | 512 | 768 |
| 注意力头数 | 8 | 12 |
| Transformer层数 | 12 | 24 |
| FFN维度 | 2048 | 3072 |
| 参数量 | ~85M | ~310M |
| 基因数 | 5,000 | 5,000 |
| Token词表大小 | 67 | 67 |

## 2. 环境配置

### 2.1 系统要求

**硬件要求:**
- 推理: 1x GPU (16GB+ 显存) 或 CPU
- 微调: 1x GPU (24GB+ 显存)
- 预训练: 8x GPU (80GB 显存, 推荐A100)
- 内存: 64GB+ RAM
- 存储: 50GB+ (模型 + 数据)

**软件要求:**
- Python >= 3.10
- CUDA >= 11.8 (GPU版本)
- Git

### 2.2 安装步骤

#### 方式一: pip安装 (推荐)

```bash
# 创建虚拟环境
conda create -n spatialfm python=3.10
conda activate spatialfm

# 安装PyTorch (根据CUDA版本选择)
pip install torch==2.1.0 --index-url https://download.pytorch.org/whl/cu118

# 安装PyTorch Geometric
pip install torch-geometric torch-scatter torch-sparse

# 安装SpatialFM
pip install spatialfm
```

#### 方式二: 从源码安装

```bash
git clone https://github.com/spatialfm/spatialfm.git
cd spatialfm
pip install -e ".[dev]"
```

### 2.3 验证安装

```python
import spatialfm
print(f"SpatialFM version: {spatialfm.__version__}")

# 检查GPU可用性
import torch
print(f"CUDA available: {torch.cuda.is_available()}")
print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'N/A'}")

# 测试模型创建
from spatialfm import SpatialFM
model = SpatialFM(n_genes=100, d_model=128, n_layers=2)
print(f"Model parameters: {model.get_num_params():,}")
```

## 3. 数据准备

### 3.1 支持的数据格式

SpatialFM使用AnnData格式(.h5ad)作为标准输入格式。

**必需字段:**
- `adata.X`: 基因表达矩阵 (n_cells x n_genes)
- `adata.obsm['spatial']`: 空间坐标 (n_cells x 2)

**可选字段:**
- `adata.obs['cell_type']`: 细胞类型标签
- `adata.obs['spatial_domain']`: 空间域注释
- `adata.obs['batch']`: 批次信息

### 3.2 数据预处理

```python
import anndata as ad
from spatialfm.data.preprocessing import preprocess_adata, build_spatial_graph

# 加载数据
adata = ad.read_h5ad("path/to/data.h5ad")

# 预处理 (质量控制 + 标准化 + 基因选择)
adata = preprocess_adata(
    adata,
    min_genes=200,       # 每个spot最少基因数
    min_cells=10,        # 每个基因最少spot数
    min_counts=500,      # 每个spot最少UMI数
    n_genes=5000,        # 选择的高变基因数
    normalize_total=1e4, # 归一化总数
)

# 构建空间图
import numpy as np
coords = np.array(adata.obsm['spatial'][:, :2])
edge_index, edge_attr = build_spatial_graph(
    coords,
    method='knn',    # 'knn', 'delaunay', 或 'radius'
    k=6,             # KNN图的邻居数
)
```

### 3.3 Token化

```python
from spatialfm.data.tokenizer import GeneExpressionTokenizer
import torch

# 创建tokenizer
tokenizer = GeneExpressionTokenizer(n_bins=64, strategy='quantile')

# 拟合tokenizer (在预训练数据上)
expr_matrix = torch.FloatTensor(adata.X.toarray())  # 如果是稀疏矩阵
tokenizer.fit(expr_matrix)

# Token化
tokens = tokenizer.transform(expr_matrix)
print(f"Token shape: {tokens.shape}")  # [n_spots, n_genes]
print(f"Vocabulary size: {tokenizer.vocab_size}")
```

### 3.4 构建数据集

```python
from spatialfm.data.dataset import SpatialTranscriptomicsDataset

# 从多个h5ad文件创建数据集
dataset = SpatialTranscriptomicsDataset(
    adata_paths=[
        "data/sample1.h5ad",
        "data/sample2.h5ad",
        "data/sample3.h5ad",
    ],
    n_genes=5000,
    n_bins=64,
    graph_method='knn',
    k_neighbors=6,
)

print(f"Dataset size: {len(dataset)} samples")
print(f"Sample 0: {dataset.get(0).n_spots} spots, {dataset.get(0).n_genes} genes")
```

### 3.5 大规模数据的子图采样

```python
from spatialfm.data.dataset import SubgraphSampler

sampler = SubgraphSampler(
    n_nodes_per_subgraph=2048,
    sampling_strategy='spatial_cluster',  # 或 'random', 'grid'
)

data = dataset.get(0)
subgraphs = sampler.sample(data)
print(f"Generated {len(subgraphs)} subgraphs from {data.n_spots} spots")
```

## 4. 模型架构详解

### 4.1 输入表征层

输入表征层将原始数据转换为模型可处理的嵌入表示。

#### 4.1.1 基因表达嵌入

每个基因的表达值被编码为两个嵌入的和:
- **基因身份嵌入 (Gene ID Embedding)**: 每个基因有一个唯一的可学习向量，编码基因的功能身份
- **表达值嵌入 (Expression Bin Embedding)**: 将离散化的表达值映射为向量

```
Token表示 = GeneIDEmbed(gene_index) + ExprBinEmbed(expression_bin)
```

#### 4.1.2 空间位置编码

采用多尺度傅里叶特征编码，在多个频率尺度上捕获空间模式:

```
PE(x, y) = MLP([sin(2^0*pi*x), cos(2^0*pi*x), ..., 
                sin(2^L*pi*x), cos(2^L*pi*x),
                sin(2^0*pi*y), cos(2^0*pi*y), ...,
                sin(2^L*pi*y), cos(2^L*pi*y)])
```

低频分量捕获组织级别的宏观空间模式，高频分量捕获细胞邻域级别的微观空间模式。

#### 4.1.3 图结构编码

参考Graphormer的设计，为每个节点添加基于图结构的编码:
- **入度编码**: 反映该节点的连接密度
- **出度编码**: (无向图中与入度相同)

### 4.2 空间图Transformer编码器

编码器由L层堆叠的空间感知Transformer层组成，交替使用局部注意力和全局注意力:

```
偶数层 (0, 2, 4, ...): 局部空间注意力 (在空间图上的消息传递)
奇数层 (1, 3, 5, ...): 全局空间注意力 (全节点自注意力 + 空间偏置)
```

**局部注意力的优势:**
- 计算复杂度: O(N * k)，其中k是平均邻居数
- 强化局部空间一致性
- 高效处理大规模数据

**全局注意力的优势:**
- 捕获长程空间依赖
- 建模跨区域的基因表达模式

### 4.3 注意力机制中的空间偏置

在全局注意力层中，注意力分数被空间偏置调制:

```
Attention(Q, K, V) = softmax(QK^T / sqrt(d) + B_spatial) * V
```

其中B_spatial编码了:
- **空间距离偏置**: 基于节点对之间的欧氏距离
- **空间方向偏置**: 基于节点对之间的角度方向

### 4.4 任务特定头

每个下游任务使用独立的头部网络:

```python
# 空间域识别
SpatialDomainHead:
  Input: [n_spots, d_model] -> Linear -> ReLU -> Linear -> [n_spots, n_domains]

# 细胞类型注释
CellTypeAnnotationHead:
  Input: [n_spots, d_model] -> Linear -> ReLU -> Linear -> Softmax -> [n_spots, n_types]

# 基因表达预测
GeneExpressionPredictionHead:
  Input: [n_spots, d_model] x [n_genes, d_model] -> 
         Element-wise product -> MLP -> [n_spots, n_genes, vocab_size]
```

## 5. 预训练流程

### 5.1 预训练目标

SpatialFM使用三个互补的预训练目标:

#### 5.1.1 空间掩码基因预测 (SMGP)

**基因维度掩码:**
- 随机掩码每个spot中15%的基因token
- 80%替换为[MASK]，10%替换为随机token，10%保持不变
- 模型预测被掩码基因的原始表达bin

**空间维度掩码:**
- 随机掩码15%的空间位置的全部基因表达
- 模型需要利用空间邻域的信息重建被掩码位置的表达谱
- 这迫使模型学习有意义的空间依赖关系

#### 5.1.2 空间对比学习 (SCL)

利用空间邻近性构建自监督信号:
- **正样本对**: 空间图中相连的spot对
- **负样本对**: 从全图随机采样
- **损失函数**: InfoNCE
- **温度系数**: 0.1

#### 5.1.3 空间上下文预测 (SCP)

对于被空间掩码的位置:
- 预测目标: 该位置邻域的平均表征
- 损失函数: MSE
- 仅使用未被掩码的邻居进行监督

### 5.2 预训练配置

```yaml
# configs/pretrain_default.yaml
model:
  n_genes: 5000
  vocab_size: 67
  d_model: 512
  n_heads: 8
  n_layers: 12
  d_ff: 2048
  dropout: 0.1

training:
  max_epochs: 100
  learning_rate: 1.0e-4
  weight_decay: 0.01
  warmup_epochs: 10
  gene_mask_ratio: 0.15
  spatial_mask_ratio: 0.15
  mgp_weight: 1.0
  contrastive_weight: 0.1
  scp_weight: 0.1
```

### 5.3 启动预训练

```bash
# 单GPU预训练
python scripts/run_pretrain.py \
    --config configs/pretrain_default.yaml \
    --data_dir ./data/pretrain \
    --output_dir ./checkpoints

# 多GPU分布式预训练
torchrun --nproc_per_node=8 scripts/run_pretrain.py \
    --config configs/pretrain_default.yaml \
    --distributed \
    --data_dir ./data/pretrain \
    --output_dir ./checkpoints
```

### 5.4 监控训练进度

```bash
# 使用Weights & Biases
# 在配置中设置 wandb_project: "spatialfm"
# 查看: https://wandb.ai/<your-account>/spatialfm

# 查看训练日志
tail -f logs/pretrain.log
```

### 5.5 预训练注意事项

1. **学习率预热**: 前10个epoch使用线性预热，避免训练初期不稳定
2. **混合精度训练**: 默认启用FP16混合精度，显著减少显存占用
3. **梯度裁剪**: 梯度范数上限为1.0，防止梯度爆炸
4. **检查点保存**: 每5个epoch保存一次，同时保存最佳模型

## 6. 下游任务微调

### 6.1 加载预训练模型

```python
from spatialfm import SpatialFM

# 从检查点加载
model = SpatialFM.from_pretrained("checkpoints/best_model.pt")

# 查看模型信息
print(f"Parameters: {model.get_num_params():,}")
```

### 6.2 空间域识别

```python
from spatialfm.models.task_heads import SpatialDomainHead
from spatialfm.training.finetune import FinetuneRunner, FinetuneConfig

# 添加任务头
head = SpatialDomainHead(d_model=512, n_domains=7)
model.add_task_head("spatial_domain", head)

# 配置微调
config = FinetuneConfig(
    task_name="spatial_domain",
    n_classes=7,
    max_epochs=50,
    learning_rate=1e-4,
    encoder_lr=1e-5,        # 编码器使用较小的学习率
    freeze_encoder=False,    # 是否冻结编码器
    gradual_unfreeze=True,   # 逐步解冻
    unfreeze_epoch=10,       # 第10个epoch开始解冻
)

# 启动微调
runner = FinetuneRunner(config, model, train_data, val_data)
results = runner.train()
```

### 6.3 细胞类型注释

```python
from spatialfm.models.task_heads import CellTypeAnnotationHead

# 注释模式
head = CellTypeAnnotationHead(
    d_model=512, 
    n_cell_types=20, 
    mode='annotation'
)
model.add_task_head("cell_type", head)

# 解卷积模式
head_deconv = CellTypeAnnotationHead(
    d_model=512,
    n_cell_types=20,
    mode='deconvolution'  # 输出细胞类型比例
)
model.add_task_head("deconvolution", head_deconv)
```

### 6.4 零样本推理

```python
# 不需要微调，直接使用预训练表征
import torch
from sklearn.cluster import KMeans

model.eval()
with torch.no_grad():
    # 获取表征
    embeddings = model(
        expr_tokens, gene_ids, coords, edge_index, edge_attr
    )
    
    # 使用K-means聚类进行空间域识别
    emb_np = embeddings.cpu().numpy()
    kmeans = KMeans(n_clusters=7, random_state=42)
    domains = kmeans.fit_predict(emb_np)
```

### 6.5 微调策略建议

| 数据量 | 推荐策略 | 编码器学习率 |
|-------|---------|------------|
| < 100 spots | 冻结编码器(线性探测) | 0 |
| 100 - 1000 spots | 逐步解冻 | 1e-5 |
| 1000 - 10000 spots | 全量微调(较小lr) | 5e-6 |
| > 10000 spots | 全量微调 | 1e-5 |

## 7. 评估与基准测试

### 7.1 评估指标

#### 空间域识别
```python
from spatialfm.evaluation.metrics import compute_clustering_metrics

metrics = compute_clustering_metrics(true_labels, pred_labels)
# 返回: ARI, NMI, Homogeneity, Completeness, V-measure
```

#### 细胞类型注释
```python
from spatialfm.evaluation.metrics import compute_classification_metrics

metrics = compute_classification_metrics(true_labels, pred_labels, pred_probs)
# 返回: Accuracy, Macro-F1, Weighted-F1, Kappa, AUROC
```

#### 基因表达预测
```python
from spatialfm.evaluation.metrics import compute_regression_metrics

metrics = compute_regression_metrics(true_expr, pred_expr)
# 返回: RMSE, Pearson_mean, Pearson_median, Spearman_mean
```

#### 数据整合
```python
from spatialfm.evaluation.metrics import compute_integration_metrics

metrics = compute_integration_metrics(embeddings, batch_labels, cell_type_labels)
# 返回: Batch_ASW, Bio_ASW, LISI_approx, Graph_connectivity
```

### 7.2 运行基准测试

```bash
python scripts/run_benchmark.py \
    --task spatial_domain \
    --checkpoint checkpoints/best_model.pt \
    --dataset dlpfc \
    --output_dir results/
```

### 7.3 标准基准数据集

| 基准 | 任务 | 平台 | 说明 |
|------|------|------|------|
| DLPFC | 空间域识别 | Visium | 人脑12切片，7层注释 |
| MERFISH Brain | 细胞类型注释 | MERFISH | 小鼠脑，单细胞分辨率 |
| Slide-seq Cerebellum | 细胞类型注释 | Slide-seq V2 | 小鼠小脑 |
| 合成SVG | SVG检测 | - | 已知空间模式 |
| Visium+MERFISH配对 | 跨平台整合 | 多平台 | 同一组织 |

## 8. API参考

### 8.1 核心类

#### SpatialFM

```python
class SpatialFM(nn.Module):
    """空间转录组学基础模型"""
    
    def __init__(
        self,
        n_genes: int = 5000,       # 基因数量
        vocab_size: int = 67,      # Token词表大小
        d_model: int = 512,        # 模型维度
        n_heads: int = 8,          # 注意力头数
        n_layers: int = 12,        # Transformer层数
        d_ff: int = 2048,          # FFN维度
        dropout: float = 0.1,      # Dropout率
    ): ...
    
    def forward(self, expr_tokens, gene_ids, coords, edge_index, edge_attr=None):
        """编码器前向传播，返回spot级别表征"""
        ...
    
    def pretrain_forward(self, expr_tokens, masked_tokens, gene_ids, coords, 
                         edge_index, edge_attr=None, labels=None, spatial_mask=None):
        """预训练前向传播，返回损失字典"""
        ...
    
    def task_forward(self, task_name, expr_tokens, gene_ids, coords, 
                     edge_index, edge_attr=None, **kwargs):
        """下游任务前向传播"""
        ...
    
    @classmethod
    def from_pretrained(cls, checkpoint_path, **kwargs):
        """从检查点加载预训练模型"""
        ...
    
    def save_pretrained(self, save_path, config=None):
        """保存模型检查点"""
        ...
    
    def freeze_encoder(self):
        """冻结编码器参数"""
        ...
    
    def unfreeze_encoder(self):
        """解冻编码器参数"""
        ...
```

#### GeneExpressionTokenizer

```python
class GeneExpressionTokenizer:
    """基因表达Token化器"""
    
    # 特殊token
    PAD_TOKEN = 0
    MASK_TOKEN = 1
    ZERO_TOKEN = 2
    
    def __init__(self, n_bins=64, strategy='quantile'): ...
    def fit(self, expression_matrix): ...
    def transform(self, expression_matrix): ...
    def inverse_transform(self, tokens): ...
    def mask_tokens(self, tokens, mask_ratio=0.15): ...
```

#### SpatialTranscriptomicsDataset

```python
class SpatialTranscriptomicsDataset(InMemoryDataset):
    """空间转录组学数据集"""
    
    def __init__(
        self,
        adata_paths: List[str],    # h5ad文件路径列表
        gene_list: Optional[List[str]] = None,
        n_genes: int = 5000,
        n_bins: int = 64,
        graph_method: str = 'knn',
        k_neighbors: int = 6,
    ): ...
```

### 8.2 空间编码模块

```python
# 傅里叶空间编码
FourierSpatialEncoding(d_model=512, n_frequencies=64)

# 相对空间偏置
RelativeSpatialBias(n_heads=8, n_distance_bins=64, n_angle_bins=8)

# 图结构编码
GraphStructureEncoding(d_model=512, max_degree=50)

# 多尺度空间编码
MultiScaleSpatialEncoding(d_model=512, n_scales=4)
```

### 8.3 任务头

```python
# 空间域识别
SpatialDomainHead(d_model, n_domains, use_clustering=False)

# 细胞类型注释/解卷积
CellTypeAnnotationHead(d_model, n_cell_types, mode='annotation')

# 基因表达预测
GeneExpressionPredictionHead(d_model, n_genes, vocab_size, mode='classification')

# SVG检测
SVGDetectionHead(d_model, n_genes)

# 空间细胞通讯
SpatialCommunicationHead(d_model, n_lr_pairs)
```

## 9. 常见问题与故障排除

### 9.1 内存问题

**问题**: GPU显存不足 (OOM)

**解决方案**:
1. 减小子图大小: `n_nodes_per_subgraph=1024`
2. 启用混合精度训练: `mixed_precision=True`
3. 减小批次大小: `batch_size=2`
4. 使用梯度累积: 在训练循环中累积多步梯度
5. 使用更小的模型: 减少`d_model`或`n_layers`

### 9.2 训练不收敛

**问题**: 预训练损失不下降或振荡

**解决方案**:
1. 检查学习率: 尝试更小的学习率 (如5e-5)
2. 增加预热epoch数: `warmup_epochs=20`
3. 检查数据质量: 确保数据预处理正确
4. 检查梯度范数: 降低`max_grad_norm`

### 9.3 下游性能差

**问题**: 微调后性能低于基线

**解决方案**:
1. 尝试冻结编码器: `freeze_encoder=True`
2. 使用更小的编码器学习率: `encoder_lr=1e-6`
3. 增加训练epoch数
4. 检查标签质量和类别平衡

### 9.4 数据加载问题

**问题**: 无法加载h5ad文件

**解决方案**:
1. 检查文件路径是否正确
2. 确保adata.obsm中有'spatial'键
3. 检查基因名称格式一致性
4. 对于大文件，使用backed模式: `ad.read_h5ad(path, backed='r')`

## 10. 开发者指南

### 10.1 添加新的预训练目标

```python
# 在 spatialfm/models/spatialfm.py 中
def pretrain_forward(self, ...):
    outputs = {}
    
    # ... 现有目标 ...
    
    # 添加新的预训练目标
    outputs["new_objective_loss"] = self._compute_new_objective(...)
    
    # 更新总损失
    outputs["total_loss"] = sum(outputs.values())
    
    return outputs
```

### 10.2 添加新的下游任务

1. 在`task_heads.py`中定义新的头部网络:

```python
class NewTaskHead(nn.Module):
    def __init__(self, d_model, ...):
        super().__init__()
        # 定义网络层
    
    def forward(self, spot_repr, ...):
        # 前向传播
        return output
```

2. 在`spatialfm.py`的`task_forward`中注册:

```python
elif task_name == "new_task":
    return head(spot_repr, **kwargs)
```

3. 在`metrics.py`中添加评估指标。

### 10.3 支持新的数据平台

在`preprocessing.py`中添加平台特定的预处理逻辑:

```python
def preprocess_platform_x(adata, ...):
    """针对平台X的预处理"""
    # 平台特定的质量控制
    # 坐标转换
    # 基因名称标准化
    return adata
```

### 10.4 代码规范

- 使用Black进行代码格式化: `black spatialfm/`
- 使用isort排序导入: `isort spatialfm/`
- 运行类型检查: `mypy spatialfm/`
- 运行测试: `pytest tests/`

### 10.5 贡献指南

1. Fork项目仓库
2. 创建功能分支: `git checkout -b feature/new-feature`
3. 遵循代码规范编写代码
4. 添加单元测试
5. 提交Pull Request

---

**文档版本**: v0.1.0  
**最后更新**: 2025年4月
