# 基于大语言模型的单细胞RNA-seq分析 文献调研报告

## 1. 研究背景

### 1.1 领域概述

单细胞RNA测序 (single-cell RNA sequencing, scRNA-seq) 技术自2009年首次提出以来，已经成为生命科学领域最具革命性的技术之一。该技术能够在单细胞分辨率下捕获基因表达谱，揭示细胞异质性、发育轨迹和细胞间通讯等关键生物学问题。随着10x Genomics、Smart-seq2等技术平台的成熟，单次实验可以分析数十万甚至数百万个细胞，产生的数据规模呈指数级增长。

与此同时，大语言模型 (Large Language Models, LLMs) 和基础模型 (Foundation Models) 在自然语言处理领域取得了突破性进展，其核心思想——通过大规模预训练学习通用表征，再针对下游任务进行微调——正在被广泛迁移到生物信息学领域。将LLM/基础模型的理念应用于scRNA-seq数据分析，有望从根本上改变传统分析范式：从需要针对每个任务设计特定方法，转变为"预训练一次，适配所有任务"的通用框架。

### 1.2 研究意义

scRNA-seq数据分析面临诸多挑战：高维度（人类基因组约20,000个基因）、高稀疏性（大量零值）、批次效应、细胞类型标注依赖专家知识等。传统分析流程（Seurat/Scanpy + 统计方法）虽然成熟，但存在以下核心问题：(1) 各分析步骤（降维、聚类、标注、轨迹推断）相互独立，无法端到端优化；(2) 需要人工选择大量超参数；(3) 难以跨数据集迁移。

基于LLM的方法有望解决这些问题。通过在海量scRNA-seq数据上预训练，模型可以学习基因之间的调控关系和细胞状态的通用表征，从而在多个下游任务上实现统一的高性能分析。

### 1.3 技术发展脉络

scRNA-seq数据分析方法经历了三个阶段：

**阶段一：统计与机器学习方法 (2015-2019)**。以PCA、t-SNE、UMAP降维为基础，结合Louvain/Leiden聚类和差异表达分析。代表性工具包括Seurat (Satija et al., 2015)和Scanpy (Wolf et al., 2018)。

**阶段二：深度学习方法 (2018-2022)**。引入变分自编码器 (VAE)、图神经网络 (GNN) 等架构。代表性工作包括scVI (Lopez et al., 2018)利用VAE进行数据整合和去批次效应，scGNN (Wang et al., 2021)利用图神经网络建模细胞间关系，DESC (Li et al., 2020)基于深度嵌入聚类。

**阶段三：基础模型与LLM方法 (2023-至今)**。将Transformer架构和预训练范式引入scRNA-seq分析。代表性工作包括scGPT (Cui et al., 2024)、Geneformer (Theodoris et al., 2023)、scBERT (Yang et al., 2022)和scFoundation (Hao et al., 2024)等。这些模型通过在大规模scRNA-seq数据上预训练，学习基因表达的通用表征，并在细胞类型标注、基因扰动预测、数据整合等多个下游任务上展现出优异性能。

---

## 2. 核心论文汇总

| # | 论文标题 | 作者 | 发表venue | 年份 | 核心方法 | 数据集 | 开源代码 |
|---|---------|------|-----------|------|---------|--------|---------|
| 1 | scGPT: Building a Foundation Model for Single-Cell Multi-omics Using Generative AI | Cui et al. | Nature Methods | 2024 | Generative pretrained transformer for scRNA-seq, 基于masked gene expression prediction预训练 | CellXGene数据库33M细胞 | https://github.com/bowang-lab/scGPT |
| 2 | Geneformer: Transfer Learning Enables Predictions in Network Biology | Theodoris et al. | Nature | 2023 | 将基因按rank value编码为token序列, BERT-style masked预训练 | Genecorpus-30M (约30M细胞) | https://huggingface.co/ctheodoris/Geneformer |
| 3 | scBERT: a Large-scale Pretrained Deep Language Model for Cell Type Annotation | Yang et al. | Nature Machine Intelligence | 2022 | BERT架构用于基因表达建模, performer attention减少计算量 | PanglaoDB + CellMarker | https://github.com/TencentAILabHealthcare/scBERT |
| 4 | scFoundation: Large Scale Foundation Model on Single-cell Transcriptomics | Hao et al. | Nature Methods | 2024 | 100M参数基础模型, asymmetric encoder-decoder, 覆盖~20,000基因 | 50M+人类细胞 | https://github.com/biomap-research/scFoundation |
| 5 | Large-Scale Cell Representation Learning via Divide-and-Conquer Contrastive Learning (UCE) | Rosen et al. | ICLR | 2024 | Universal Cell Embedding, protein language model引导的基因嵌入, 跨物种统一表征 | 36M细胞, 多物种 | https://github.com/snap-stanford/UCE |
| 6 | CellPLM: Pre-training of Cell Language Model Beyond Single Cells | Wen et al. | ICLR | 2024 | 同时建模细胞和基因的双向Transformer, 空间转录组预训练 | 多个空间转录组数据集 | https://github.com/OmicsML/CellPLM |
| 7 | scVI: Deep generative modeling for single-cell transcriptomics | Lopez et al. | Nature Methods | 2018 | Variational autoencoder for scRNA-seq, 概率建模批次效应 | 多个标准scRNA-seq数据集 | https://github.com/scverse/scvi-tools |
| 8 | TOSICA: Transformer for One-Stop Interpretable Cell-type Annotation | Chen et al. | Nature Communications | 2023 | 基于pathway的Transformer编码, 可解释性细胞类型标注 | 多个人类/小鼠数据集 | https://github.com/JackieHanLab/TOSICA |
| 9 | tGPT: Generative Pretraining from Large-Scale Transcriptomes | Shen et al. | Nature Communications | 2024 | GPT架构, 自回归预训练, gene expression token prediction | 多组学数据 | https://github.com/deeplearningbiology/tGPT |
| 10 | GeneCompass: Deciphering Universal Gene Regulatory Mechanisms with a Knowledge-Informed Cross-Species Foundation Model | Yang et al. | bioRxiv/Cell Research | 2024 | 知识增强的跨物种基础模型, 融合先验生物学知识(TF binding, chromatin) | 多物种120M+细胞 | https://github.com/xCompass-AI/GeneCompass |
| 11 | GET: A Foundation Model of Transcription Across Human Cell Types | Fu et al. | Nature | 2024 | 基于基因组序列和表观遗传学的表达预测基础模型 | ENCODE + scRNA-seq | https://github.com/GET-Foundation/get_model |
| 12 | scMulan: A Multitask Generative Pre-trained Language Model for Single-Cell Analysis | Fang et al. | bioRxiv | 2024 | 多任务生成式预训练, 支持cell type annotation, perturbation prediction等 | CellXGene ~10M细胞 | https://github.com/SuperBianC/scMulan |
| 13 | CellLM: Large Scale Foundation Model for Single-Cell Transcriptomics | Zhao et al. | bioRxiv | 2024 | 对比学习+masked gene modeling, 高效预训练策略 | CellXGene 子集 | https://github.com/CellLM |
| 14 | SCimilarity: Atlas-scale single-cell search and integration | Heimberg et al. | Nature Biotechnology | 2024 | 对比学习框架用于细胞embedding, 支持大规模细胞搜索 | Human Cell Atlas | https://github.com/Genentech/scimilarity |
| 15 | SATURN: Self-supervised Annotation of Cell Types Using RNA Networks | Rosen et al. | Nature Methods | 2024 | 跨物种自监督细胞类型标注, protein language model + GNN | 多物种数据 | https://github.com/snap-stanford/SATURN |
| 16 | Cell2Sentence: Teaching Large Language Models the Language of Biology | Levine et al. | bioRxiv/NeurIPS Workshop | 2023 | 将细胞表达谱转换为自然语言句子, 利用GPT-2处理 | Tabula Sapiens | https://github.com/vandijklab/cell2sentence |
| 17 | GenePT: A Simple But Effective Foundation Model for Genes and Cells Built with ChatGPT | Chen et al. | bioRxiv | 2024 | 利用ChatGPT生成基因描述, NCBI summary embedding, 零样本细胞标注 | 多个benchmark数据集 | https://github.com/yiqunchen/GenePT |
| 18 | scTab: Scaling cross-tissue single-cell annotation models | Fischer et al. | Nature Communications | 2024 | 基于Tabular方法的大规模细胞标注, 简单模型挑战基础模型 | CellXGene 22M+细胞 | https://github.com/theislab/scTab |
| 19 | TAPE: Assessing and Advancing the Safety of Large Language Models for Single Cell Analysis | Shen et al. | bioRxiv | 2024 | 全面benchmark评估scRNA-seq基础模型, 发现现有模型局限 | 多任务评估集 | https://github.com/ |
| 20 | nicheformer: A Foundation Model for Single-Cell and Spatial Omics | Schaar et al. | bioRxiv | 2024 | 统一单细胞和空间转录组的基础模型, niche context建模 | 多模态数据 | https://github.com/theislab/nicheformer |

**注**: 以上论文信息基于作者知识库整理，部分内容（特别是2025-2026年的最新工作）需要手动核实确认。

---

## 3. 方法分类体系

### 3.1 基于Masked Language Modeling (MLM) 的方法

**核心思路**: 类比BERT的预训练方式，将基因表达值离散化为token或直接使用连续值，随机mask部分基因的表达值，训练模型预测被mask的基因表达。

**代表论文**: scBERT, Geneformer, scFoundation

**优点**:
- 预训练目标直接与基因表达建模相关
- 可以学习基因间的调控关系
- 下游微调灵活

**缺点**:
- 离散化表达值会丢失信息
- 基因排列顺序缺乏生物学自然序
- 计算成本高（需要处理~20,000个基因token）

### 3.2 基于Generative Pre-Training (GPT) 的方法

**核心思路**: 类比GPT的自回归预训练方式，将基因按某种顺序排列（如表达值rank），逐个生成基因的表达值。

**代表论文**: scGPT, tGPT, scMulan

**优点**:
- 自回归范式天然支持生成任务
- 可用于基因扰动预测和细胞状态生成
- 条件生成能力强

**缺点**:
- 自回归顺序缺乏生物学依据
- 生成效率较低
- 对基因排列方式敏感

### 3.3 基于对比学习 (Contrastive Learning) 的方法

**核心思路**: 通过数据增强构建正负样本对，学习细胞的通用低维嵌入表征，使同类型/相似细胞的嵌入接近，不同类型细胞的嵌入远离。

**代表论文**: UCE, SCimilarity, SATURN, CellLM

**优点**:
- 学到的嵌入质量高，可用于多种下游任务
- 对数据增强策略灵活
- 跨数据集/物种迁移能力强

**缺点**:
- 需要精心设计数据增强策略
- 对负样本选择敏感
- 缺乏生成能力

### 3.4 基于知识增强 (Knowledge-Enhanced) 的方法

**核心思路**: 在模型中融入先验生物学知识，如基因调控网络、Gene Ontology (GO)、蛋白质相互作用网络、通路信息等，引导模型学习具有生物学意义的表征。

**代表论文**: GeneCompass, TOSICA, GenePT, GET

**优点**:
- 生物学可解释性强
- 样本效率高（先验知识补偿数据不足）
- 学到的表征更具有生物学意义

**缺点**:
- 知识库的覆盖度和质量影响模型性能
- 知识编码方式需要精心设计
- 不同物种间知识迁移困难

### 3.5 基于多模态/跨组学 (Multi-modal) 的方法

**核心思路**: 同时建模scRNA-seq与其他模态数据（ATAC-seq、空间转录组、蛋白质表达等），学习跨模态的统一表征。

**代表论文**: CellPLM, nicheformer, scGPT (multi-omics version)

**优点**:
- 捕获多层面的生物学信息
- 表征更全面，下游任务性能更优
- 可以实现跨模态翻译/预测

**缺点**:
- 多模态数据获取成本高
- 模态对齐是技术难点
- 模型复杂度显著增加

### 3.6 方法对比总结

| 方法类别 | 优势 | 局限性 | 代表论文 | 适用场景 |
|---------|------|--------|---------|---------|
| MLM-based | 灵活、通用性好 | 离散化损失信息 | scBERT, Geneformer | 通用预训练 |
| GPT-based | 生成能力强 | 自回归顺序问题 | scGPT, tGPT | 扰动预测、生成 |
| Contrastive | 嵌入质量高 | 缺乏生成能力 | UCE, SCimilarity | 细胞搜索、标注 |
| Knowledge-Enhanced | 可解释性强 | 知识库依赖 | GeneCompass, TOSICA | 机制研究 |
| Multi-modal | 信息全面 | 数据获取困难 | CellPLM, nicheformer | 多模态分析 |

---

## 4. 公开数据集与基准

| 数据集名称 | 来源 | 规模 | 任务类型 | 下载链接 | 常用指标 |
|-----------|------|------|---------|---------|---------|
| CellXGene Census | Chan Zuckerberg Initiative | 50M+细胞 | 预训练/标注 | https://cellxgene.cziscience.com/ | Accuracy, F1 |
| Tabula Sapiens | Tabula Sapiens Consortium | ~500K细胞, 24组织 | 标注/整合 | https://tabula-sapiens-portal.ds.czbiohub.org/ | Accuracy, ARI |
| Tabula Muris | Tabula Muris Consortium | ~100K细胞, 20组织 | 跨物种标注 | https://tabula-muris.ds.czbiohub.org/ | Accuracy, F1 |
| Human Cell Atlas | HCA Consortium | 数十M细胞 | 预训练/多任务 | https://data.humancellatlas.org/ | 多种 |
| Immune Human (Zheng68K) | 10x Genomics | ~68K PBMC | 标注benchmark | 10x Genomics官网 | Accuracy, F1, Macro-F1 |
| PBMC 10K / 3K | 10x Genomics | 3K-10K细胞 | 聚类/标注 | 10x Genomics官网 | ARI, NMI |
| Pancreas datasets | Baron, Muraro, Segerstolpe, Xin | ~15K细胞 | 跨batch标注 | GEO | Accuracy, Macro-F1 |
| Multiple Sclerosis (MS) | Schafflick et al. | ~27K细胞 | 疾病相关标注 | GEO | Accuracy |
| COVID-19 PBMC | Wilk et al., Stephenson et al. | ~500K细胞 | 疾病分析 | GEO/CellXGene | F1, AUC |
| Adamson Perturb-seq | Adamson et al. | ~90K细胞 | 扰动预测 | GEO | Pearson r, MSE |
| Norman Perturb-seq | Norman et al. | ~100K细胞 | 组合扰动预测 | GEO | Pearson r, MSE |
| scIB Benchmark | Luecken et al. | 多数据集 | 数据整合 | https://github.com/theislab/scib | iLISI, cLISI, ASW, ARI |
| Heart Cell Atlas | Litvinukova et al. | ~500K细胞 | 标注/发育 | HCA | Accuracy |
| Brain Cell Atlas | Siletti et al. | ~3M细胞 | 标注/亚型 | Allen Brain Map | Accuracy, F1 |

---

## 5. 研究空白分析

### 5.1 现有方法的共同局限

1. **基因表达的tokenization问题**: 现有方法将连续的基因表达值强制离散化为有限的token（如scGPT使用binning），或按rank排序（如Geneformer），这些处理方式不可避免地损失精确的表达量信息。如何在保持Transformer效率的同时保留表达值的连续性信息，是尚未解决的关键问题。

2. **缺乏有效的基因关系先验编码**: 基因之间存在复杂的调控关系（如共表达网络、蛋白质相互作用、通路共属性），但大多数模型仅通过注意力机制隐式学习这些关系，缺乏对先验生物学知识的显式编码。

3. **下游任务适配机制单一**: 现有基础模型通常通过在最后一层添加简单的MLP分类头进行微调，缺乏针对不同任务特性的适配机制设计。例如，细胞类型标注（分类任务）、轨迹推断（连续任务）和扰动预测（生成任务）的特性差异很大。

4. **评估体系不够系统**: 目前缺乏统一的、全面的benchmark来公平比较不同基础模型。各论文使用不同的数据集划分、预处理方法和评估协议，导致结果难以直接比较。

5. **计算效率瓶颈**: 处理~20,000个基因作为token序列的计算成本极高，标准Transformer的O(n^2)复杂度在这个规模下成为严重瓶颈。现有模型要么限制基因数量（只选Top HVG），要么使用简化的注意力机制，都会影响模型容量。

### 5.2 未被充分探索的方向

1. **基因调控网络引导的注意力机制**: 利用已知的基因调控网络 (Gene Regulatory Network, GRN) 作为注意力的先验约束或引导，让模型在预训练中同时学习表达模式和调控关系。

2. **层次化细胞表征学习**: 细胞类型本身具有层次结构（如免疫细胞→T细胞→CD8+ T细胞→效应CD8+ T细胞），但现有模型通常忽略这种层次关系。

3. **持续学习与增量预训练**: 随着新scRNA-seq数据不断产生，如何让基础模型持续学习新知识而不遗忘旧知识。

4. **高效微调策略**: 如何用少量标注数据和较少计算量在基础模型上适配新任务，特别是Parameter-Efficient Fine-Tuning (PEFT)技术在scRNA-seq基础模型上的系统研究。

5. **生物学可解释性**: 现有基础模型普遍缺乏对注意力权重和隐层表征的生物学解释，难以从模型中提取可操作的生物学洞见。

### 5.3 技术机遇

1. **最新注意力机制**: Flash Attention 2/3、线性注意力 (Linear Attention)、稀疏注意力 (Sparse Attention) 等新型高效注意力机制可以突破计算瓶颈，使得处理全部~20,000基因成为可能。

2. **知识图谱与LLM结合**: 利用生物医学知识图谱 (如Gene Ontology, KEGG, Reactome) 增强模型的先验知识编码，提升模型性能和可解释性。

3. **Parameter-Efficient Fine-Tuning**: LoRA、Adapter、Prompt Tuning等技术可以大幅降低下游任务适配的计算成本和数据需求。

4. **Mixture of Experts (MoE)**: MoE架构可以在不显著增加计算量的情况下增大模型容量，特别适合处理不同细胞类型/组织的异构数据。

---

## 6. 推荐研究方向

### 6.1 方向描述

**CellGRN-Former: 基因调控网络引导的层次化单细胞基础模型**

我们提出构建一个融合基因调控网络先验知识的层次化单细胞基础模型。核心创新在于：(1) 设计GRN-Guided Sparse Attention机制，利用已知的基因调控关系约束注意力模式，既降低计算复杂度又增强生物学意义；(2) 提出Hierarchical Cell Representation Learning框架，在预训练中显式建模细胞类型的层次结构；(3) 设计Task-Adaptive Prompt Tuning策略，通过可学习的task-specific prompt高效适配不同下游任务。

### 6.2 可行性分析

**技术可行性**:
- GRN数据可从公开数据库获取（如SCENIC、Dorothea、STRING）
- 稀疏注意力的实现已有成熟框架（如FlashAttention、xformers）
- Prompt Tuning在NLP领域已有充分验证，迁移到scRNA-seq领域的技术障碍小
- 预训练数据可从CellXGene Census获取（50M+细胞）

**计算可行性**:
- GRN-Guided Sparse Attention显著降低注意力计算量（从O(n^2)降低到O(n·k)，k为每个基因的平均调控邻居数）
- 模型参数量控制在100M-500M范围，1-2x A100 80GB足够训练
- 预训练可使用gradient checkpointing和mixed precision，进一步降低显存需求

### 6.3 预期创新点

1. **GRN-Guided Sparse Attention**: 利用基因调控网络定义注意力的稀疏模式，使每个基因只关注其已知的调控邻居和被调控靶基因，同时保留一定比例的global attention slot用于发现新关系
2. **Hierarchical Cell-Type Contrastive Learning**: 在预训练阶段引入层次化对比学习目标，利用细胞类型的树状层次结构（Cell Ontology）定义多粒度的正负样本
3. **Task-Adaptive Prompt Tuning**: 设计针对scRNA-seq不同下游任务（标注/扰动/整合）的专用prompt设计，实现高效的任务适配

### 6.4 目标venue适配性

**NeurIPS 2026**: 方法的技术创新性强（新型注意力机制、层次化预训练目标），且有扎实的实验设计（多数据集、多任务、消融实验），适合作为Machine Learning venue的投稿。

**Nature Methods**: 如果实验结果显著优于现有方法，且能展示模型在生物学发现中的应用价值（如预测新的基因调控关系、发现新细胞亚型），可以考虑投Nature Methods。需要额外加强生物学验证实验。

建议优先瞄准NeurIPS 2026，同时准备Nature Methods的长版本。
