# CellGRN-Former 技术手册

## 1. 环境配置

### 1.1 系统要求

- **操作系统**: Linux (Ubuntu 20.04/22.04 推荐)
- **GPU**: NVIDIA A100 80GB x 1-2
- **CUDA**: 11.8 或 12.1
- **Python**: 3.10+
- **内存**: 128GB+ RAM 推荐（处理大规模数据集）
- **磁盘**: 500GB+ 可用空间（数据集+checkpoint）

### 1.2 安装步骤

```bash
# 1. 创建conda环境
conda create -n cellgrn python=3.10 -y
conda activate cellgrn

# 2. 安装PyTorch (CUDA 11.8)
pip install torch==2.2.0 torchvision==0.17.0 torchaudio==2.2.0 --index-url https://download.pytorch.org/whl/cu118

# 3. 安装Flash Attention (需要CUDA编译)
pip install flash-attn --no-build-isolation

# 4. 安装项目依赖
cd code/
pip install -r requirements.txt

# 5. 安装额外的baseline依赖（可选）
pip install scgpt geneformer
```

### 1.3 验证安装

```bash
# 验证PyTorch和CUDA
python -c "import torch; print(f'PyTorch: {torch.__version__}'); print(f'CUDA available: {torch.cuda.is_available()}'); print(f'GPU: {torch.cuda.get_device_name(0)}')"

# 验证关键包
python -c "import scanpy; import anndata; import scvi; print('All packages OK')"

# 验证项目可导入
python -c "from models.model import CellGRNFormer; print('Model import OK')"
```

**预期输出示例**:
```
PyTorch: 2.2.0
CUDA available: True
GPU: NVIDIA A100-SXM4-80GB
All packages OK
Model import OK
```

---

## 2. 数据准备

### 2.1 下载数据

```bash
cd code/

# 下载预训练数据 (CellXGene Census)
# 注意: 全量数据约33M细胞, 建议先用小规模测试
# 小规模测试 (1M细胞, 约30GB):
python data/download.py --dataset cellxgene_census --output_dir data/raw --max_cells 1000000

# 全量下载 (33M细胞, 约200GB, 需要数小时):
# python data/download.py --dataset cellxgene_census --output_dir data/raw

# 下载评估数据集
python data/download.py --dataset tabula_sapiens --output_dir data/raw
python data/download.py --dataset zheng68k --output_dir data/raw
python data/download.py --dataset pancreas --output_dir data/raw
python data/download.py --dataset norman_perturb --output_dir data/raw

# 下载GRN数据 (基因调控网络)
python data/download.py --dataset grn --output_dir data/raw
```

### 2.2 预处理

```bash
# 预处理所有数据集 (QC -> 归一化 -> HVG选择 -> GRN mask构建)
python data/preprocess.py \
    --input_dir data/raw \
    --output_dir data/processed \
    --n_hvg 4000 \
    --min_genes 200 \
    --max_genes 8000 \
    --max_mito_pct 20.0 \
    --grn_path data/raw/grn/dorothea_grn.npz
```

### 2.3 验证数据

预处理完成后，`data/processed/` 目录应包含:

| 文件 | 大小(预估) | 说明 |
|-----|-----------|------|
| `cellxgene_homo_sapiens.h5ad` | 5-50 GB | 预训练数据(取决于细胞数) |
| `tabula_sapiens.h5ad` | ~2 GB | 标注评估数据 |
| `zheng68k_pbmc.h5ad` | ~200 MB | PBMC标注评估 |
| `pancreas.h5ad` | ~50 MB | 整合评估数据 |
| `norman_perturb.h5ad` | ~300 MB | 扰动预测评估 |
| `*_gene_properties.csv` | ~1 MB each | 基因属性文件 |
| `grn_attention_mask.npy` | ~60 MB | GRN注意力mask (4000x4000) |

---

## 3. 运行基线实验

### 3.1 基线1: scGPT

```bash
# 确保已安装scgpt: pip install scgpt
python main.py \
    --config configs/baseline_scgpt.yaml \
    --mode train_eval \
    --output_dir outputs/baselines/scgpt
```

**预期训练时间**: ~12小时 (1x A100)
**预期结果范围**: Cell annotation accuracy ~85-92%

### 3.2 基线2: Geneformer

```bash
# 确保已安装geneformer: pip install geneformer
python main.py \
    --config configs/baseline_geneformer.yaml \
    --mode train_eval \
    --output_dir outputs/baselines/geneformer
```

**预期训练时间**: ~8小时 (1x A100)
**预期结果范围**: Cell annotation accuracy ~82-90%

### 3.3 基线3: scVI

```bash
python main.py \
    --config configs/baseline_scvi.yaml \
    --mode train_eval \
    --output_dir outputs/baselines/scvi
```

**预期训练时间**: ~2小时 (1x A100)
**预期结果范围**: Integration iLISI ~1.5-2.0, cLISI ~1.0-1.2

### 3.4 一键运行所有基线

```bash
bash scripts/run_baselines.sh
```

---

## 4. 训练我们的模型

### 4.1 默认配置训练（预训练）

```bash
# 单卡训练
python main.py \
    --config configs/default.yaml \
    --mode train \
    --output_dir outputs/pretrain

# 双卡分布式训练 (推荐)
torchrun --nproc_per_node=2 main.py \
    --config configs/default.yaml \
    --mode train \
    --output_dir outputs/pretrain

# 或使用脚本
bash scripts/train.sh configs/default.yaml outputs/pretrain 2
```

### 4.2 训练监控

**Wandb 监控**:
- 默认会初始化 wandb 项目 `cellgrn-former`
- 在浏览器打开 https://wandb.ai 查看训练曲线
- 关键指标: `train/loss`, `train/mgep_loss`, `train/hccl_loss`, `eval/loss`

**日志文件**:
- 训练日志: stdout (建议 `tee` 到文件)
- Metrics JSON: `outputs/pretrain/logs/metrics.json`
- Checkpoints: `outputs/pretrain/best_model.pt`, `outputs/pretrain/last.pt`

**预期训练时间**:
- 1M细胞, 10 epochs: ~6小时 (2x A100)
- 5M细胞, 10 epochs: ~24小时 (2x A100)
- 33M细胞, 10 epochs: ~4天 (2x A100)

**训练正常的标志**:
- `train/loss` 在前1-2个epoch下降较快，之后缓慢下降
- `train/mgep_loss` 持续下降
- `train/hccl_loss` 在初期可能波动较大，之后趋于稳定
- GPU显存占用稳定在25-45GB

### 4.3 下游微调（细胞类型标注）

```bash
python main.py \
    --config configs/default.yaml \
    --mode train_eval \
    --checkpoint outputs/pretrain/best_model.pt \
    --task annotation \
    --output_dir outputs/finetune_annotation
```

**预期微调时间**: ~2-4小时

### 4.4 断点续训

```bash
# 从最近的checkpoint恢复
python main.py \
    --config configs/default.yaml \
    --mode train \
    --checkpoint outputs/pretrain/last.pt \
    --output_dir outputs/pretrain
```

---

## 5. 评估

### 5.1 运行评估

```bash
# 评估预训练模型
bash scripts/eval.sh outputs/pretrain/best_model.pt

# 评估微调模型
python main.py \
    --config configs/default.yaml \
    --mode eval \
    --checkpoint outputs/finetune_annotation/best_model.pt \
    --output_dir outputs/eval
```

### 5.2 结果文件

评估完成后，结果保存在 `outputs/eval/eval_results.json`:

```json
{
  "annotation": {
    "accuracy": 0.XXXX,
    "macro_f1": 0.XXXX,
    "weighted_f1": 0.XXXX
  },
  "clustering": {
    "ari": 0.XXXX,
    "nmi": 0.XXXX,
    "asw": 0.XXXX
  }
}
```

---

## 6. 消融实验

### 6.1 运行所有消融实验

```bash
bash scripts/run_ablation.sh outputs/pretrain/best_model.pt
```

### 6.2 各消融实验说明

| 实验 | 配置文件 | 消融内容 | 验证目的 |
|------|---------|---------|---------|
| no_ggsa | `ablation_no_ggsa.yaml` | 移除GRN稀疏注意力，使用全注意力 | 验证GRN先验的贡献 |
| no_hccl | `ablation_no_hccl.yaml` | 移除层次化对比学习 | 验证HCCL的贡献 |
| no_tapt | `ablation_no_tapt.yaml` | 使用全参数微调代替TAPT | 验证TAPT效率 |
| binning_tokenization | `ablation_binning_tokenization.yaml` | 使用binning代替连续tokenization | 验证EACT的贡献 |

### 6.3 查看消融结果

```bash
cat outputs/ablation/ablation_summary.json
```

---

## 7. 常见问题

### OOM (显存不足)

**症状**: `CUDA out of memory`

**解决方案**:
1. 减小 `batch_size`（在config中修改，如 32 -> 16）
2. 增大 `gradient_accumulation_steps`（保持等效batch size）
3. 在config中设置 `gradient_checkpointing: true`
4. 减小 `num_hvg`（如 4000 -> 2000）

**显存占用参考**:
| 配置 | batch_size | gradient_ckpt | 峰值显存 |
|------|-----------|---------------|---------|
| 默认 | 32 | True | ~25 GB |
| 默认 | 32 | False | ~45 GB |
| 默认 | 64 | True | ~40 GB |
| 无GGSA | 16 | True | ~35 GB |

### 训练loss不下降

1. 检查学习率（尝试 1e-5 到 1e-3 范围）
2. 检查数据预处理是否正确（`data/processed/` 文件是否完整）
3. 检查GRN mask是否正确加载（查看日志中的 "GRN mask" 信息）
4. 减小 warmup_ratio 尝试更快启动

### CUDA版本不匹配

```bash
# 检查CUDA版本
nvidia-smi
python -c "import torch; print(torch.version.cuda)"

# 重新安装对应版本
# CUDA 11.8:
pip install torch==2.2.0 --index-url https://download.pytorch.org/whl/cu118
# CUDA 12.1:
pip install torch==2.2.0 --index-url https://download.pytorch.org/whl/cu121
```

### 数据下载失败

1. CellXGene Census需要稳定的网络连接，建议使用代理
2. 如果下载中断，删除不完整的文件后重新运行（download脚本会检查已有文件）
3. 可以先用小规模数据（`--max_cells 100000`）测试流程

### wandb连接失败

```bash
# 离线模式运行
WANDB_MODE=offline python main.py --config configs/default.yaml --mode train
```

---

## 8. 预期结果格式

### 8.1 主结果表

学生应产出如下格式的结果表:

| Method | Cell Ann. Acc | Macro-F1 | Clustering ARI | Clustering NMI | Pert. Pearson r |
|--------|:---:|:---:|:---:|:---:|:---:|
| scVI | XX.X | XX.X | XX.X | XX.X | - |
| scBERT | XX.X | XX.X | XX.X | XX.X | - |
| Geneformer | XX.X | XX.X | XX.X | XX.X | XX.X |
| scGPT | XX.X | XX.X | XX.X | XX.X | XX.X |
| scFoundation | XX.X | XX.X | XX.X | XX.X | XX.X |
| **CellGRN-Former** | **XX.X** | **XX.X** | **XX.X** | **XX.X** | **XX.X** |

### 8.2 消融结果表

| Configuration | Cell Ann. Acc | Macro-F1 | Delta |
|:---|:---:|:---:|:---:|
| Full Model | XX.X | XX.X | - |
| w/o GGSA | XX.X | XX.X | -X.X |
| w/o HCCL | XX.X | XX.X | -X.X |
| w/o TAPT (full FT) | XX.X | XX.X | +/-X.X |
| w/ Binning (no EACT) | XX.X | XX.X | -X.X |

### 8.3 需要生成的图表

1. **UMAP可视化**: 不同方法的细胞嵌入UMAP图（使用 `evaluation/visualize.py`）
2. **性能对比柱状图**: 各方法在主要指标上的对比
3. **消融热力图**: 消融实验结果可视化
4. **注意力权重可视化**: 展示GRN-guided注意力的可解释性
5. **训练曲线**: wandb中的loss曲线截图
