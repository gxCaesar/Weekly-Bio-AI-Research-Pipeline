"""Sub-modules for CellGRN-Former.

Implements the four key components:
1. Expression-Aware Continuous Tokenizer (EACT)
2. GRN-Guided Sparse Attention (GGSA)
3. Hierarchical Contrastive Head (for HCCL)
4. Task-Adaptive Prompt Tuning (TAPT)
"""

import math
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class ExpressionAwareContinuousTokenizer(nn.Module):
    """Expression-Aware Continuous Tokenization (EACT).

    Converts gene expression values into rich embeddings by combining:
    - Gene identity embedding (learnable per gene)
    - Expression value projection (MLP: scalar -> d_model)
    - Gene property embedding (linear projection of gene properties)

    Args:
        num_genes: Total number of genes in vocabulary.
        d_model: Model hidden dimension.
        expr_proj_hidden: Hidden dimension for expression MLP.
        gene_property_dim: Dimension for gene property embedding.
        num_gene_properties: Number of gene property features.
        dropout: Dropout rate.
    """

    def __init__(
        self,
        num_genes: int,
        d_model: int,
        expr_proj_hidden: int = 256,
        gene_property_dim: int = 64,
        num_gene_properties: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.num_genes = num_genes
        self.d_model = d_model

        self.gene_embedding = nn.Embedding(num_genes, d_model)

        self.expr_projection = nn.Sequential(
            nn.Linear(1, expr_proj_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(expr_proj_hidden, d_model),
        )

        self.gene_property_projection = nn.Linear(num_gene_properties, gene_property_dim)
        self.property_to_model = nn.Linear(gene_property_dim, d_model)

        self.layer_norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

        self._init_weights()

    def _init_weights(self) -> None:
        """Initialize weights with Xavier uniform."""
        nn.init.xavier_uniform_(self.gene_embedding.weight)
        for module in [self.expr_projection, self.gene_property_projection, self.property_to_model]:
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                nn.init.zeros_(module.bias)
            elif isinstance(module, nn.Sequential):
                for submod in module:
                    if isinstance(submod, nn.Linear):
                        nn.init.xavier_uniform_(submod.weight)
                        nn.init.zeros_(submod.bias)

    def forward(
        self,
        expression: torch.Tensor,
        gene_properties: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Tokenize gene expression values.

        Args:
            expression: Gene expression values (batch_size, num_genes).
            gene_properties: Gene property features (num_genes, num_properties).
                Can be None if gene properties are not available.

        Returns:
            Token embeddings of shape (batch_size, num_genes, d_model).
        """
        batch_size = expression.shape[0]

        gene_ids = torch.arange(self.num_genes, device=expression.device)
        gene_emb = self.gene_embedding(gene_ids)
        gene_emb = gene_emb.unsqueeze(0).expand(batch_size, -1, -1)

        expr_values = expression.unsqueeze(-1)
        expr_emb = self.expr_projection(expr_values)

        h = gene_emb + expr_emb

        if gene_properties is not None:
            prop_emb = self.gene_property_projection(gene_properties)
            prop_emb = self.property_to_model(prop_emb)
            prop_emb = prop_emb.unsqueeze(0).expand(batch_size, -1, -1)
            h = h + prop_emb

        h = self.layer_norm(h)
        h = self.dropout(h)

        return h


class GRNGuidedSparseAttention(nn.Module):
    """GRN-Guided Sparse Attention (GGSA).

    Multi-head attention where most heads use sparse attention patterns
    guided by the Gene Regulatory Network, and a few heads use global
    (full) attention for discovering novel interactions.

    Args:
        d_model: Model hidden dimension.
        num_heads: Total number of attention heads.
        num_global_heads: Number of heads using full attention.
        dropout: Attention dropout rate.
    """

    def __init__(
        self,
        d_model: int,
        num_heads: int,
        num_global_heads: int = 2,
        dropout: float = 0.05,
    ):
        super().__init__()
        assert d_model % num_heads == 0, f"d_model ({d_model}) must be divisible by num_heads ({num_heads})"

        self.d_model = d_model
        self.num_heads = num_heads
        self.num_global_heads = num_global_heads
        self.num_sparse_heads = num_heads - num_global_heads
        self.head_dim = d_model // num_heads
        self.scale = math.sqrt(self.head_dim)

        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.o_proj = nn.Linear(d_model, d_model)

        self.attn_dropout = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,
        grn_mask: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Forward pass with GRN-guided sparse attention.

        Args:
            x: Input tensor (batch_size, seq_len, d_model).
            grn_mask: Boolean GRN adjacency mask (seq_len, seq_len) or
                (batch_size, seq_len, seq_len). True = allow attention.
            attention_mask: Padding mask (batch_size, seq_len). 1 = valid, 0 = pad.

        Returns:
            Output tensor (batch_size, seq_len, d_model).
        """
        batch_size, seq_len, _ = x.shape

        q = self.q_proj(x).view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)

        attn_scores = torch.matmul(q, k.transpose(-2, -1)) / self.scale

        if attention_mask is not None:
            pad_mask = attention_mask.unsqueeze(1).unsqueeze(2)
            attn_scores = attn_scores.masked_fill(pad_mask == 0, float("-inf"))

        if grn_mask is not None and self.num_sparse_heads > 0:
            if grn_mask.dim() == 2:
                grn_mask_expanded = grn_mask.unsqueeze(0).unsqueeze(0)
            else:
                grn_mask_expanded = grn_mask.unsqueeze(1)

            sparse_mask = grn_mask_expanded.expand(batch_size, self.num_sparse_heads, seq_len, seq_len)

            global_start = 0
            global_end = self.num_global_heads
            sparse_start = self.num_global_heads
            sparse_end = self.num_heads

            sparse_scores = attn_scores[:, sparse_start:sparse_end, :, :]
            sparse_scores = sparse_scores.masked_fill(sparse_mask == 0, float("-inf"))
            attn_scores = torch.cat(
                [attn_scores[:, global_start:global_end, :, :], sparse_scores],
                dim=1,
            )

        attn_weights = F.softmax(attn_scores, dim=-1)
        attn_weights = self.attn_dropout(attn_weights)

        attn_output = torch.matmul(attn_weights, v)

        attn_output = attn_output.transpose(1, 2).contiguous().view(batch_size, seq_len, self.d_model)
        output = self.o_proj(attn_output)

        return output


class TransformerBlock(nn.Module):
    """Single Transformer block with GGSA attention.

    Args:
        d_model: Model hidden dimension.
        num_heads: Number of attention heads.
        num_global_heads: Number of global attention heads.
        ff_dim: Feed-forward hidden dimension.
        dropout: Dropout rate.
        attention_dropout: Attention-specific dropout rate.
        activation: Activation function name.
    """

    def __init__(
        self,
        d_model: int,
        num_heads: int,
        num_global_heads: int = 2,
        ff_dim: Optional[int] = None,
        dropout: float = 0.1,
        attention_dropout: float = 0.05,
        activation: str = "gelu",
    ):
        super().__init__()

        if ff_dim is None:
            ff_dim = 4 * d_model

        self.attention = GRNGuidedSparseAttention(
            d_model=d_model,
            num_heads=num_heads,
            num_global_heads=num_global_heads,
            dropout=attention_dropout,
        )
        self.attn_norm = nn.LayerNorm(d_model)
        self.ff_norm = nn.LayerNorm(d_model)

        act_fn = nn.GELU() if activation == "gelu" else nn.ReLU()
        self.feed_forward = nn.Sequential(
            nn.Linear(d_model, ff_dim),
            act_fn,
            nn.Dropout(dropout),
            nn.Linear(ff_dim, d_model),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        x: torch.Tensor,
        grn_mask: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Forward pass with pre-norm residual connections.

        Args:
            x: Input (batch_size, seq_len, d_model).
            grn_mask: GRN attention mask.
            attention_mask: Padding mask.

        Returns:
            Output (batch_size, seq_len, d_model).
        """
        normed = self.attn_norm(x)
        attn_out = self.attention(normed, grn_mask=grn_mask, attention_mask=attention_mask)
        x = x + attn_out

        normed = self.ff_norm(x)
        ff_out = self.feed_forward(normed)
        x = x + ff_out

        return x


class HierarchicalContrastiveHead(nn.Module):
    """Projection head for hierarchical contrastive learning.

    Projects cell representations to a lower-dimensional space for
    computing contrastive loss at multiple hierarchy levels.

    Args:
        d_model: Input dimension.
        proj_dim: Projection dimension for contrastive space.
        n_levels: Number of hierarchy levels.
    """

    def __init__(self, d_model: int, proj_dim: int = 128, n_levels: int = 3):
        super().__init__()
        self.n_levels = n_levels

        self.projectors = nn.ModuleList([
            nn.Sequential(
                nn.Linear(d_model, d_model),
                nn.GELU(),
                nn.Linear(d_model, proj_dim),
            )
            for _ in range(n_levels)
        ])

    def forward(self, cell_repr: torch.Tensor) -> List[torch.Tensor]:
        """Project cell representation for each hierarchy level.

        Args:
            cell_repr: Cell representation (batch_size, d_model).

        Returns:
            List of projected representations, one per level.
            Each is (batch_size, proj_dim) and L2-normalized.
        """
        projections = []
        for projector in self.projectors:
            proj = projector(cell_repr)
            proj = F.normalize(proj, dim=-1)
            projections.append(proj)
        return projections


class TaskAdaptivePromptTuning(nn.Module):
    """Task-Adaptive Prompt Tuning (TAPT).

    Adds learnable task-specific prompt tokens to the input sequence.
    Only prompt parameters and the task head are trainable during fine-tuning.

    Args:
        d_model: Model hidden dimension.
        num_prompt_tokens: Number of prompt tokens per task.
        num_tasks: Number of different task types.
        task_output_dims: Dict mapping task name to output dimension.
        dropout: Dropout rate for prompt.
    """

    def __init__(
        self,
        d_model: int,
        num_prompt_tokens: int = 16,
        num_tasks: int = 4,
        task_output_dims: Optional[Dict[str, int]] = None,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.d_model = d_model
        self.num_prompt_tokens = num_prompt_tokens

        if task_output_dims is None:
            task_output_dims = {
                "annotation": 100,
                "perturbation": 4000,
                "integration": 128,
                "trajectory": 1,
            }

        self.task_prompts = nn.ParameterDict({
            task_name: nn.Parameter(torch.randn(num_prompt_tokens, d_model) * 0.02)
            for task_name in task_output_dims
        })

        self.task_type_embedding = nn.Embedding(num_tasks, d_model)

        self.task_heads = nn.ModuleDict({
            task_name: nn.Sequential(
                nn.LayerNorm(d_model),
                nn.Linear(d_model, d_model // 2),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(d_model // 2, output_dim),
            )
            for task_name, output_dim in task_output_dims.items()
        })

        self.task_name_to_id = {name: i for i, name in enumerate(task_output_dims)}

    def get_prompt(self, task_name: str, batch_size: int) -> torch.Tensor:
        """Get prompt tokens for a specific task.

        Args:
            task_name: Name of the task.
            batch_size: Current batch size.

        Returns:
            Prompt tokens (batch_size, num_prompt_tokens, d_model).
        """
        prompt = self.task_prompts[task_name]
        task_id = torch.tensor(self.task_name_to_id[task_name], device=prompt.device)
        task_emb = self.task_type_embedding(task_id)
        prompt = prompt + task_emb.unsqueeze(0)
        return prompt.unsqueeze(0).expand(batch_size, -1, -1)

    def forward(
        self,
        cell_repr: torch.Tensor,
        task_name: str,
    ) -> torch.Tensor:
        """Apply task head to cell representation.

        Args:
            cell_repr: Cell representation (batch_size, d_model).
            task_name: Name of the downstream task.

        Returns:
            Task-specific output logits/values.
        """
        return self.task_heads[task_name](cell_repr)
