"""Full evaluation pipeline for CellGRN-Former.

Runs evaluation across multiple tasks and aggregates results.
"""

import json
import logging
import os
from typing import Any, Dict, List, Optional, Tuple

import anndata as ad
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from data.dataset import SingleCellDataset, PerturbationDataset
from data.collator import SingleCellCollator
from evaluation.metrics import (
    compute_annotation_metrics,
    compute_clustering_metrics,
    compute_integration_metrics,
    compute_perturbation_metrics,
)

logger = logging.getLogger(__name__)


class Evaluator:
    """Multi-task evaluator for CellGRN-Former.

    Args:
        model: The trained CellGRN-Former model.
        device: Device to run evaluation on.
        config: Model/evaluation configuration.
        grn_mask: GRN attention mask tensor.
        gene_properties: Gene property features tensor.
    """

    def __init__(
        self,
        model: nn.Module,
        device: torch.device,
        config: Dict[str, Any],
        grn_mask: Optional[torch.Tensor] = None,
        gene_properties: Optional[torch.Tensor] = None,
    ):
        self.model = model.to(device)
        self.model.eval()
        self.device = device
        self.config = config
        self.grn_mask = grn_mask.to(device) if grn_mask is not None else None
        self.gene_properties = gene_properties.to(device) if gene_properties is not None else None

    @torch.no_grad()
    def extract_embeddings(
        self,
        dataloader: DataLoader,
        task_name: Optional[str] = None,
    ) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """Extract cell embeddings from the model.

        Args:
            dataloader: DataLoader for the evaluation data.
            task_name: Optional task name for TAPT prompts.

        Returns:
            Tuple of (embeddings, labels) where labels may be None.
        """
        all_embeddings = []
        all_labels = []

        for batch in dataloader:
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}

            expression = batch.get("expression", batch.get("masked_expression"))
            outputs = self.model.encode(
                expression,
                grn_mask=self.grn_mask,
                gene_properties=self.gene_properties,
                task_name=task_name,
            )
            cell_emb = outputs[0]
            all_embeddings.append(cell_emb.cpu().numpy())

            if "cell_type" in batch:
                all_labels.append(batch["cell_type"].cpu().numpy())

        embeddings = np.concatenate(all_embeddings, axis=0)
        labels = np.concatenate(all_labels, axis=0) if all_labels else None

        return embeddings, labels

    def evaluate_annotation(
        self,
        dataloader: DataLoader,
    ) -> Dict[str, float]:
        """Evaluate cell type annotation.

        Args:
            dataloader: DataLoader with cell type labels.

        Returns:
            Annotation metrics.
        """
        all_preds = []
        all_labels = []

        for batch in dataloader:
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
            batch["grn_mask"] = self.grn_mask
            batch["gene_properties"] = self.gene_properties
            batch["task_name"] = "annotation"

            outputs = self.model(**batch)
            logits = outputs.logits
            preds = logits.argmax(dim=-1)

            all_preds.append(preds.cpu().numpy())
            all_labels.append(batch["cell_type"].cpu().numpy())

        y_pred = np.concatenate(all_preds)
        y_true = np.concatenate(all_labels)

        return compute_annotation_metrics(y_true, y_pred)

    def evaluate_clustering(
        self,
        dataloader: DataLoader,
        n_clusters: Optional[int] = None,
    ) -> Dict[str, float]:
        """Evaluate clustering quality of learned embeddings.

        Args:
            dataloader: DataLoader with cell type labels for reference.
            n_clusters: Number of clusters. If None, uses unique labels count.

        Returns:
            Clustering metrics.
        """
        from sklearn.cluster import KMeans

        embeddings, labels = self.extract_embeddings(dataloader)

        if labels is None:
            logger.warning("No labels for clustering evaluation")
            return {}

        if n_clusters is None:
            n_clusters = len(np.unique(labels))

        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        pred_clusters = kmeans.fit_predict(embeddings)

        return compute_clustering_metrics(labels, pred_clusters, embeddings)

    def evaluate_integration(
        self,
        dataloader: DataLoader,
        batch_key: str = "batch",
    ) -> Dict[str, float]:
        """Evaluate batch integration quality.

        Args:
            dataloader: DataLoader with batch and cell type labels.
            batch_key: Key for batch labels in dataset.

        Returns:
            Integration metrics.
        """
        embeddings, cell_labels = self.extract_embeddings(dataloader)

        all_batch_labels = []
        for batch in dataloader:
            if batch_key in batch:
                all_batch_labels.append(batch[batch_key].numpy())

        if not all_batch_labels:
            logger.warning("No batch labels for integration evaluation")
            return {}

        batch_labels = np.concatenate(all_batch_labels)

        if cell_labels is None:
            logger.warning("No cell type labels for integration evaluation")
            return {}

        return compute_integration_metrics(embeddings, batch_labels, cell_labels)

    def evaluate_perturbation(
        self,
        dataloader: DataLoader,
    ) -> Dict[str, float]:
        """Evaluate perturbation prediction.

        Args:
            dataloader: DataLoader from PerturbationDataset.

        Returns:
            Perturbation prediction metrics.
        """
        all_preds = []
        all_targets = []

        for batch in dataloader:
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
            batch["grn_mask"] = self.grn_mask
            batch["gene_properties"] = self.gene_properties
            batch["task_name"] = "perturbation"
            batch["expression"] = batch["control_expression"]

            outputs = self.model(**batch)
            all_preds.append(outputs.logits.cpu().numpy())
            all_targets.append(batch["target_expression"].cpu().numpy())

        y_pred = np.concatenate(all_preds)
        y_true = np.concatenate(all_targets)

        return compute_perturbation_metrics(y_true, y_pred)

    def evaluate_all(
        self,
        dataloaders: Dict[str, DataLoader],
        tasks: Optional[List[str]] = None,
        output_dir: Optional[str] = None,
    ) -> Dict[str, Dict[str, float]]:
        """Run all evaluation tasks.

        Args:
            dataloaders: Dict mapping task name to DataLoader.
            tasks: List of tasks to evaluate. None = all available.
            output_dir: Directory to save results.

        Returns:
            Nested dict: {task_name: {metric_name: value}}.
        """
        if tasks is None:
            tasks = list(dataloaders.keys())

        results: Dict[str, Dict[str, float]] = {}

        for task in tasks:
            if task not in dataloaders:
                logger.warning(f"No dataloader for task: {task}")
                continue

            logger.info(f"\nEvaluating: {task}")
            if task == "annotation":
                results[task] = self.evaluate_annotation(dataloaders[task])
            elif task == "clustering":
                results[task] = self.evaluate_clustering(dataloaders[task])
            elif task == "integration":
                results[task] = self.evaluate_integration(dataloaders[task])
            elif task == "perturbation":
                results[task] = self.evaluate_perturbation(dataloaders[task])

        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            results_path = os.path.join(output_dir, "eval_results.json")
            with open(results_path, "w") as f:
                json.dump(results, f, indent=2)
            logger.info(f"Results saved to {results_path}")

        return results
