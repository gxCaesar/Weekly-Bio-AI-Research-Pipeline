#!/bin/bash
# CellGRN-Former: Complete experiment pipeline
# Downloads data, preprocesses, trains, evaluates, and runs ablations.
set -e

echo "============================================"
echo " CellGRN-Former Full Pipeline"
echo "============================================"

PROJECT_DIR=$(cd "$(dirname "$0")/.." && pwd)
cd "$PROJECT_DIR"

DATA_RAW="data/raw"
DATA_PROCESSED="data/processed"
OUTPUT_DIR="outputs"
NUM_GPUS=${1:-2}

echo "[Step 1/6] Downloading datasets..."
python data/download.py --dataset cellxgene_census --output_dir "$DATA_RAW" --max_cells 5000000
python data/download.py --dataset tabula_sapiens --output_dir "$DATA_RAW"
python data/download.py --dataset zheng68k --output_dir "$DATA_RAW"
python data/download.py --dataset pancreas --output_dir "$DATA_RAW"
python data/download.py --dataset norman_perturb --output_dir "$DATA_RAW"
python data/download.py --dataset grn --output_dir "$DATA_RAW"

echo "[Step 2/6] Preprocessing data..."
python data/preprocess.py \
    --input_dir "$DATA_RAW" \
    --output_dir "$DATA_PROCESSED" \
    --n_hvg 4000 \
    --grn_path "$DATA_RAW/grn/dorothea_grn.npz"

echo "[Step 3/6] Pre-training CellGRN-Former..."
bash scripts/train.sh configs/default.yaml "$OUTPUT_DIR/pretrain" "$NUM_GPUS"

echo "[Step 4/6] Running baselines..."
bash scripts/run_baselines.sh

echo "[Step 5/6] Running ablation studies..."
bash scripts/run_ablation.sh

echo "[Step 6/6] Final evaluation..."
bash scripts/eval.sh "$OUTPUT_DIR/pretrain/best_model.pt"

echo "============================================"
echo " Pipeline Complete!"
echo " Results in: $OUTPUT_DIR/"
echo "============================================"
