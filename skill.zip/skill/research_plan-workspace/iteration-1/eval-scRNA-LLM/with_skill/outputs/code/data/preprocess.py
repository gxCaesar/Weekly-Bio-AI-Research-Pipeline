"""Data preprocessing pipeline for CellGRN-Former.

Implements quality control, normalization, HVG selection, and gene ID mapping.
"""

import argparse
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def quality_control(
    adata: ad.AnnData,
    min_genes: int = 200,
    max_genes: int = 8000,
    max_mito_pct: float = 20.0,
    min_cells_per_gene: int = 10,
) -> ad.AnnData:
    """Apply quality control filters to scRNA-seq data.

    Args:
        adata: AnnData object with raw counts.
        min_genes: Minimum number of genes per cell.
        max_genes: Maximum number of genes per cell.
        max_mito_pct: Maximum mitochondrial gene percentage.
        min_cells_per_gene: Minimum number of cells expressing a gene.

    Returns:
        Filtered AnnData object.
    """
    n_cells_before = adata.n_obs
    n_genes_before = adata.n_vars

    adata.var["mt"] = adata.var_names.str.startswith(("MT-", "mt-"))
    sc.pp.calculate_qc_metrics(adata, qc_vars=["mt"], percent_top=None, log1p=False, inplace=True)

    cell_mask = (
        (adata.obs["n_genes_by_counts"] >= min_genes)
        & (adata.obs["n_genes_by_counts"] <= max_genes)
        & (adata.obs["pct_counts_mt"] <= max_mito_pct)
    )
    adata = adata[cell_mask].copy()

    sc.pp.filter_genes(adata, min_cells=min_cells_per_gene)

    logger.info(
        f"QC: {n_cells_before} -> {adata.n_obs} cells, "
        f"{n_genes_before} -> {adata.n_vars} genes"
    )
    return adata


def normalize_adata(
    adata: ad.AnnData,
    target_sum: float = 1e4,
) -> ad.AnnData:
    """Normalize gene expression data.

    Applies library size normalization and log1p transformation.

    Args:
        adata: AnnData object (filtered).
        target_sum: Target total counts per cell.

    Returns:
        Normalized AnnData object with raw counts in adata.layers['counts'].
    """
    if sparse.issparse(adata.X):
        adata.layers["counts"] = adata.X.copy()
    else:
        adata.layers["counts"] = sparse.csr_matrix(adata.X.copy())

    sc.pp.normalize_total(adata, target_sum=target_sum)
    sc.pp.log1p(adata)

    logger.info(f"Normalized {adata.n_obs} cells (target_sum={target_sum})")
    return adata


def select_hvg(
    adata: ad.AnnData,
    n_top_genes: int = 4000,
    flavor: str = "seurat_v3",
    subset: bool = False,
) -> ad.AnnData:
    """Select highly variable genes.

    Args:
        adata: Normalized AnnData object.
        n_top_genes: Number of HVGs to select.
        flavor: HVG selection method.
        subset: Whether to subset to HVGs only.

    Returns:
        AnnData with HVG annotations.
    """
    if flavor == "seurat_v3":
        sc.pp.highly_variable_genes(
            adata,
            n_top_genes=n_top_genes,
            flavor="seurat_v3",
            layer="counts",
        )
    else:
        sc.pp.highly_variable_genes(
            adata,
            n_top_genes=n_top_genes,
            flavor=flavor,
        )

    if subset:
        adata = adata[:, adata.var["highly_variable"]].copy()

    n_hvg = adata.var["highly_variable"].sum()
    logger.info(f"Selected {n_hvg} highly variable genes (flavor={flavor})")
    return adata


def compute_gene_properties(adata: ad.AnnData) -> pd.DataFrame:
    """Compute gene-level properties for gene property embeddings.

    Properties computed:
    - mean_expression: Mean log-normalized expression across cells.
    - detection_rate: Fraction of cells expressing the gene.
    - expression_variance: Variance of expression across cells.
    - gene_length_proxy: Estimated from total UMI counts (proxy).

    Args:
        adata: Normalized AnnData object.

    Returns:
        DataFrame with gene properties indexed by gene name.
    """
    if sparse.issparse(adata.X):
        X_dense = adata.X.toarray()
    else:
        X_dense = adata.X

    mean_expr = np.mean(X_dense, axis=0)
    detection_rate = np.mean(X_dense > 0, axis=0)
    expr_variance = np.var(X_dense, axis=0)
    total_umi = np.sum(X_dense, axis=0)

    properties = pd.DataFrame(
        {
            "mean_expression": mean_expr,
            "detection_rate": detection_rate,
            "expression_variance": expr_variance,
            "total_umi_proxy": total_umi,
        },
        index=adata.var_names,
    )

    for col in properties.columns:
        col_vals = properties[col].values
        col_min = col_vals.min()
        col_max = col_vals.max()
        if col_max > col_min:
            properties[col] = (col_vals - col_min) / (col_max - col_min)
        else:
            properties[col] = 0.0

    logger.info(f"Computed gene properties for {len(properties)} genes")
    return properties


def build_grn_mask(
    gene_names: List[str],
    grn_path: str,
    random_ratio: float = 0.05,
    seed: int = 42,
) -> np.ndarray:
    """Build GRN-guided attention mask.

    Args:
        gene_names: List of gene names (in order of the model's gene vocabulary).
        grn_path: Path to the GRN adjacency .npz file.
        random_ratio: Fraction of random connections to add.
        seed: Random seed for reproducibility.

    Returns:
        Boolean attention mask of shape (n_genes, n_genes).
    """
    grn_data = np.load(grn_path, allow_pickle=True)
    grn_adj = grn_data["adjacency"]
    grn_genes = grn_data["gene_names"].tolist()

    grn_gene_to_idx = {g: i for i, g in enumerate(grn_genes)}
    n_genes = len(gene_names)

    mask = np.eye(n_genes, dtype=np.float32)

    mapped_count = 0
    for i, gene_i in enumerate(gene_names):
        if gene_i not in grn_gene_to_idx:
            continue
        grn_i = grn_gene_to_idx[gene_i]
        for j, gene_j in enumerate(gene_names):
            if gene_j not in grn_gene_to_idx:
                continue
            grn_j = grn_gene_to_idx[gene_j]
            if grn_adj[grn_i, grn_j] > 0 or grn_adj[grn_j, grn_i] > 0:
                mask[i, j] = 1.0
                mask[j, i] = 1.0
                mapped_count += 1

    rng = np.random.RandomState(seed)
    n_random = int(n_genes * n_genes * random_ratio)
    random_i = rng.randint(0, n_genes, size=n_random)
    random_j = rng.randint(0, n_genes, size=n_random)
    mask[random_i, random_j] = 1.0

    density = mask.sum() / (n_genes * n_genes) * 100
    logger.info(
        f"GRN mask: {n_genes} genes, {mapped_count} GRN edges mapped, "
        f"{n_random} random edges, density={density:.2f}%"
    )
    return mask


def preprocess_adata(
    adata: ad.AnnData,
    min_genes: int = 200,
    max_genes: int = 8000,
    max_mito_pct: float = 20.0,
    target_sum: float = 1e4,
    n_hvg: int = 4000,
) -> ad.AnnData:
    """Full preprocessing pipeline.

    Args:
        adata: Raw AnnData object.
        min_genes: Min genes per cell for QC.
        max_genes: Max genes per cell for QC.
        max_mito_pct: Max mitochondrial gene percentage.
        target_sum: Normalization target sum.
        n_hvg: Number of HVGs to select.

    Returns:
        Preprocessed AnnData object.
    """
    adata = quality_control(adata, min_genes=min_genes, max_genes=max_genes, max_mito_pct=max_mito_pct)
    adata = normalize_adata(adata, target_sum=target_sum)
    adata = select_hvg(adata, n_top_genes=n_hvg)
    return adata


def main() -> None:
    """Main entry point for data preprocessing."""
    parser = argparse.ArgumentParser(description="Preprocess scRNA-seq data for CellGRN-Former")
    parser.add_argument("--input_dir", type=str, required=True, help="Input directory with h5ad files")
    parser.add_argument("--output_dir", type=str, required=True, help="Output directory")
    parser.add_argument("--n_hvg", type=int, default=4000, help="Number of HVGs")
    parser.add_argument("--min_genes", type=int, default=200, help="Min genes per cell")
    parser.add_argument("--max_genes", type=int, default=8000, help="Max genes per cell")
    parser.add_argument("--max_mito_pct", type=float, default=20.0, help="Max mitochondrial %")
    parser.add_argument("--target_sum", type=float, default=1e4, help="Normalization target")
    parser.add_argument("--grn_path", type=str, default=None, help="Path to GRN npz file")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    input_dir = Path(args.input_dir)

    for h5ad_file in sorted(input_dir.glob("*.h5ad")):
        logger.info(f"\nProcessing: {h5ad_file.name}")
        adata = ad.read_h5ad(h5ad_file)
        logger.info(f"Loaded: {adata.n_obs} cells x {adata.n_vars} genes")

        adata = preprocess_adata(
            adata,
            min_genes=args.min_genes,
            max_genes=args.max_genes,
            max_mito_pct=args.max_mito_pct,
            target_sum=args.target_sum,
            n_hvg=args.n_hvg,
        )

        gene_props = compute_gene_properties(adata)
        gene_props.to_csv(os.path.join(args.output_dir, f"{h5ad_file.stem}_gene_properties.csv"))

        output_path = os.path.join(args.output_dir, h5ad_file.name)
        adata.write_h5ad(output_path)
        logger.info(f"Saved preprocessed data to {output_path}")

    if args.grn_path and os.path.exists(args.grn_path):
        sample_adata = ad.read_h5ad(output_path)
        hvg_names = sample_adata.var_names[sample_adata.var["highly_variable"]].tolist()
        grn_mask = build_grn_mask(hvg_names, args.grn_path)
        mask_path = os.path.join(args.output_dir, "grn_attention_mask.npy")
        np.save(mask_path, grn_mask)
        logger.info(f"Saved GRN attention mask to {mask_path}")


if __name__ == "__main__":
    main()
