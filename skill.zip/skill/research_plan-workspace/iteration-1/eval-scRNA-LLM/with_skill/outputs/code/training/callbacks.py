"""Training callbacks for CellGRN-Former.

Implements checkpointing, early stopping, and logging.
"""

import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, Optional

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


class CheckpointCallback:
    """Saves model checkpoints periodically and for best performance.

    Args:
        output_dir: Directory to save checkpoints.
        save_every: Save every N epochs.
        save_best: Whether to save the best model.
        metric_name: Metric to monitor for best model.
        mode: 'max' if higher metric is better, 'min' if lower.
    """

    def __init__(
        self,
        output_dir: str,
        save_every: int = 1,
        save_best: bool = True,
        metric_name: str = "accuracy",
        mode: str = "max",
    ):
        self.output_dir = output_dir
        self.save_every = save_every
        self.save_best = save_best
        self.metric_name = metric_name
        self.mode = mode
        self.best_metric = float("-inf") if mode == "max" else float("inf")

        os.makedirs(output_dir, exist_ok=True)

    def _is_better(self, current: float) -> bool:
        if self.mode == "max":
            return current > self.best_metric
        return current < self.best_metric

    def save_checkpoint(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any,
        epoch: int,
        metrics: Dict[str, float],
        config: Dict[str, Any],
    ) -> None:
        """Save a training checkpoint.

        Args:
            model: The model to save.
            optimizer: The optimizer state to save.
            scheduler: The scheduler state to save.
            epoch: Current epoch number.
            metrics: Current evaluation metrics.
            config: Training configuration.
        """
        checkpoint = {
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "scheduler_state_dict": scheduler.state_dict() if scheduler else None,
            "metrics": metrics,
            "config": config,
        }

        last_path = os.path.join(self.output_dir, "last.pt")
        torch.save(checkpoint, last_path)

        if (epoch + 1) % self.save_every == 0:
            epoch_path = os.path.join(self.output_dir, f"checkpoint_epoch_{epoch + 1}.pt")
            torch.save(checkpoint, epoch_path)
            logger.info(f"Saved checkpoint at epoch {epoch + 1}")

        if self.save_best and self.metric_name in metrics:
            current = metrics[self.metric_name]
            if self._is_better(current):
                self.best_metric = current
                best_path = os.path.join(self.output_dir, "best_model.pt")
                torch.save(checkpoint, best_path)
                logger.info(
                    f"New best model! {self.metric_name}={current:.4f} "
                    f"(previous={self.best_metric:.4f})"
                )


class EarlyStoppingCallback:
    """Early stopping based on validation metric.

    Args:
        patience: Number of epochs without improvement before stopping.
        metric_name: Metric to monitor.
        mode: 'max' or 'min'.
        min_delta: Minimum change to qualify as improvement.
    """

    def __init__(
        self,
        patience: int = 10,
        metric_name: str = "accuracy",
        mode: str = "max",
        min_delta: float = 1e-4,
    ):
        self.patience = patience
        self.metric_name = metric_name
        self.mode = mode
        self.min_delta = min_delta
        self.counter = 0
        self.best_metric = float("-inf") if mode == "max" else float("inf")

    def _is_better(self, current: float) -> bool:
        if self.mode == "max":
            return current > self.best_metric + self.min_delta
        return current < self.best_metric - self.min_delta

    def should_stop(self, metrics: Dict[str, float]) -> bool:
        """Check if training should stop.

        Args:
            metrics: Current evaluation metrics.

        Returns:
            True if training should stop.
        """
        if self.metric_name not in metrics:
            return False

        current = metrics[self.metric_name]
        if self._is_better(current):
            self.best_metric = current
            self.counter = 0
        else:
            self.counter += 1
            logger.info(
                f"EarlyStopping: {self.counter}/{self.patience} "
                f"(best {self.metric_name}={self.best_metric:.4f})"
            )

        return self.counter >= self.patience


class WandbLogger:
    """Weights & Biases logging wrapper.

    Args:
        project: W&B project name.
        run_name: Run name.
        config: Configuration to log.
        entity: W&B entity/team.
    """

    def __init__(
        self,
        project: str = "cellgrn-former",
        run_name: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        entity: Optional[str] = None,
    ):
        self.enabled = True
        try:
            import wandb

            self.wandb = wandb
            wandb.init(
                project=project,
                name=run_name,
                config=config,
                entity=entity,
            )
            logger.info(f"W&B initialized: project={project}, run={run_name}")
        except ImportError:
            logger.warning("wandb not installed, logging disabled")
            self.enabled = False
        except Exception as e:
            logger.warning(f"wandb init failed: {e}, logging disabled")
            self.enabled = False

    def log(self, metrics: Dict[str, Any], step: Optional[int] = None) -> None:
        """Log metrics to W&B.

        Args:
            metrics: Dictionary of metric name -> value.
            step: Global step number.
        """
        if self.enabled:
            self.wandb.log(metrics, step=step)

    def finish(self) -> None:
        """Close W&B run."""
        if self.enabled:
            self.wandb.finish()


class MetricTracker:
    """Tracks training and evaluation metrics over time.

    Args:
        log_dir: Directory to save metric logs.
    """

    def __init__(self, log_dir: str = "./logs"):
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)
        self.history: Dict[str, list] = {}
        self.start_time = time.time()

    def update(self, metrics: Dict[str, float], epoch: int) -> None:
        """Record metrics for an epoch.

        Args:
            metrics: Metric values.
            epoch: Epoch number.
        """
        for key, value in metrics.items():
            if key not in self.history:
                self.history[key] = []
            self.history[key].append({"epoch": epoch, "value": value})

    def save(self) -> None:
        """Save metric history to JSON."""
        elapsed = time.time() - self.start_time
        output = {
            "history": self.history,
            "total_time_seconds": elapsed,
        }
        path = os.path.join(self.log_dir, "metrics.json")
        with open(path, "w") as f:
            json.dump(output, f, indent=2)
        logger.info(f"Metrics saved to {path}")
