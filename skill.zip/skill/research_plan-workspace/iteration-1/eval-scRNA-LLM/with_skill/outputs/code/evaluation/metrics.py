"""Evaluation metrics for CellGRN-Former.

Implements metrics for cell annotation, clustering, integration,
perturbation prediction, and GRN inference tasks.
"""

import logging
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.stats import pearsonr
from sklearn.metrics import (
    accuracy_score,
    adjusted_rand_score,
    confusion_matrix,
    f1_score,
    normalized_mutual_info_score,
    roc_auc_score,
    average_precision_score,
    silhouette_score,
)

logger = logging.getLogger(__name__)


def compute_annotation_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> Dict[str, float]:
    """Compute cell type annotation metrics.

    Args:
        y_true: True cell type labels (n_cells,).
        y_pred: Predicted cell type labels (n_cells,).

    Returns:
        Dictionary with accuracy, macro_f1, weighted_f1.
    """
    acc = accuracy_score(y_true, y_pred)
    macro_f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)
    weighted_f1 = f1_score(y_true, y_pred, average="weighted", zero_division=0)

    metrics = {
        "accuracy": acc,
        "macro_f1": macro_f1,
        "weighted_f1": weighted_f1,
    }

    logger.info(
        f"Annotation: Acc={acc:.4f}, Macro-F1={macro_f1:.4f}, "
        f"Weighted-F1={weighted_f1:.4f}"
    )
    return metrics


def compute_clustering_metrics(
    labels_true: np.ndarray,
    labels_pred: np.ndarray,
    embeddings: Optional[np.ndarray] = None,
) -> Dict[str, float]:
    """Compute clustering quality metrics.

    Args:
        labels_true: True cluster labels.
        labels_pred: Predicted cluster labels.
        embeddings: Cell embeddings for silhouette score.

    Returns:
        Dictionary with ARI, NMI, and optionally ASW.
    """
    ari = adjusted_rand_score(labels_true, labels_pred)
    nmi = normalized_mutual_info_score(labels_true, labels_pred, average_method="arithmetic")

    metrics = {
        "ari": ari,
        "nmi": nmi,
    }

    if embeddings is not None and len(np.unique(labels_pred)) > 1:
        n_samples = min(len(embeddings), 50000)
        if n_samples < len(embeddings):
            idx = np.random.choice(len(embeddings), n_samples, replace=False)
            asw = silhouette_score(embeddings[idx], labels_pred[idx])
        else:
            asw = silhouette_score(embeddings, labels_pred)
        metrics["asw"] = asw

    logger.info(f"Clustering: ARI={ari:.4f}, NMI={nmi:.4f}")
    return metrics


def compute_integration_metrics(
    embeddings: np.ndarray,
    batch_labels: np.ndarray,
    cell_type_labels: np.ndarray,
    n_neighbors: int = 30,
) -> Dict[str, float]:
    """Compute data integration metrics (iLISI, cLISI, ASW).

    Uses Local Inverse Simpson's Index (LISI) to measure batch mixing
    and cell type separation in the embedding space.

    Args:
        embeddings: Cell embeddings (n_cells, dim).
        batch_labels: Batch/dataset labels (n_cells,).
        cell_type_labels: Cell type labels (n_cells,).
        n_neighbors: Number of neighbors for LISI computation.

    Returns:
        Dictionary with ilisi, clisi, asw_batch, asw_celltype.
    """
    from sklearn.neighbors import NearestNeighbors

    n_samples = min(len(embeddings), 50000)
    if n_samples < len(embeddings):
        idx = np.random.choice(len(embeddings), n_samples, replace=False)
        embeddings = embeddings[idx]
        batch_labels = batch_labels[idx]
        cell_type_labels = cell_type_labels[idx]

    nn_model = NearestNeighbors(n_neighbors=n_neighbors, algorithm="ball_tree")
    nn_model.fit(embeddings)
    _, indices = nn_model.kneighbors(embeddings)

    batch_lisi = _compute_lisi(indices, batch_labels)
    celltype_lisi = _compute_lisi(indices, cell_type_labels)

    ilisi = np.median(batch_lisi)
    clisi = np.median(celltype_lisi)

    unique_batches = np.unique(batch_labels)
    if len(unique_batches) > 1:
        asw_batch = silhouette_score(embeddings, batch_labels)
    else:
        asw_batch = 0.0

    unique_types = np.unique(cell_type_labels)
    if len(unique_types) > 1:
        asw_celltype = silhouette_score(embeddings, cell_type_labels)
    else:
        asw_celltype = 0.0

    metrics = {
        "ilisi": ilisi,
        "clisi": clisi,
        "asw_batch": asw_batch,
        "asw_celltype": asw_celltype,
    }

    logger.info(
        f"Integration: iLISI={ilisi:.4f}, cLISI={clisi:.4f}, "
        f"ASW_batch={asw_batch:.4f}, ASW_celltype={asw_celltype:.4f}"
    )
    return metrics


def _compute_lisi(
    nn_indices: np.ndarray,
    labels: np.ndarray,
) -> np.ndarray:
    """Compute LISI scores for each cell.

    Args:
        nn_indices: Nearest neighbor indices (n_cells, n_neighbors).
        labels: Category labels (n_cells,).

    Returns:
        LISI scores (n_cells,).
    """
    n_cells = nn_indices.shape[0]
    lisi_scores = np.zeros(n_cells)

    for i in range(n_cells):
        neighbor_labels = labels[nn_indices[i]]
        unique, counts = np.unique(neighbor_labels, return_counts=True)
        freqs = counts / counts.sum()
        simpson = np.sum(freqs ** 2)
        lisi_scores[i] = 1.0 / simpson

    return lisi_scores


def compute_perturbation_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    gene_names: Optional[List[str]] = None,
    top_k: int = 20,
) -> Dict[str, float]:
    """Compute perturbation prediction metrics.

    Args:
        y_true: True post-perturbation expression (n_cells, n_genes).
        y_pred: Predicted expression (n_cells, n_genes).
        gene_names: Gene names for per-gene analysis.
        top_k: Number of top DE genes to evaluate.

    Returns:
        Dictionary with Pearson r, MSE, and top-k metrics.
    """
    all_pearson = []
    for i in range(len(y_true)):
        r, _ = pearsonr(y_true[i], y_pred[i])
        if not np.isnan(r):
            all_pearson.append(r)

    mean_pearson = np.mean(all_pearson) if all_pearson else 0.0
    mse = np.mean((y_true - y_pred) ** 2)

    de_magnitude = np.mean(np.abs(y_true), axis=0)
    top_de_idx = np.argsort(de_magnitude)[-top_k:]

    top_k_pearson_list = []
    for i in range(len(y_true)):
        r, _ = pearsonr(y_true[i, top_de_idx], y_pred[i, top_de_idx])
        if not np.isnan(r):
            top_k_pearson_list.append(r)

    top_k_pearson = np.mean(top_k_pearson_list) if top_k_pearson_list else 0.0

    metrics = {
        "pearson_r": mean_pearson,
        "mse": mse,
        f"pearson_r_top{top_k}": top_k_pearson,
    }

    logger.info(
        f"Perturbation: Pearson_r={mean_pearson:.4f}, MSE={mse:.4f}, "
        f"Top-{top_k} Pearson={top_k_pearson:.4f}"
    )
    return metrics


def compute_grn_inference_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> Dict[str, float]:
    """Compute GRN inference metrics.

    Args:
        y_true: True GRN adjacency (n_genes, n_genes) binary.
        y_pred: Predicted GRN scores (n_genes, n_genes) continuous.

    Returns:
        Dictionary with AUROC and AUPRC.
    """
    y_true_flat = y_true.flatten()
    y_pred_flat = y_pred.flatten()

    mask = ~np.eye(len(y_true), dtype=bool)
    y_true_flat = y_true[mask].flatten()
    y_pred_flat = y_pred[mask].flatten()

    if len(np.unique(y_true_flat)) < 2:
        logger.warning("Only one class in GRN ground truth, cannot compute AUROC/AUPRC")
        return {"auroc": 0.0, "auprc": 0.0}

    auroc = roc_auc_score(y_true_flat, y_pred_flat)
    auprc = average_precision_score(y_true_flat, y_pred_flat)

    metrics = {
        "auroc": auroc,
        "auprc": auprc,
    }

    logger.info(f"GRN Inference: AUROC={auroc:.4f}, AUPRC={auprc:.4f}")
    return metrics
