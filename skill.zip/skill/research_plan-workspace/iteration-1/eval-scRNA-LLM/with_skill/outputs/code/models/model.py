"""Main CellGRN-Former model architecture.

Combines EACT tokenizer, GGSA transformer layers, HCCL head, and TAPT
into a unified foundation model for single-cell RNA-seq analysis.
"""

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from models.modules import (
    ExpressionAwareContinuousTokenizer,
    HierarchicalContrastiveHead,
    TaskAdaptivePromptTuning,
    TransformerBlock,
)

logger = logging.getLogger(__name__)


@dataclass
class CellGRNFormerOutput:
    """Output container for CellGRNFormer forward pass.

    Attributes:
        loss: Total training loss (if targets provided).
        mgep_loss: Masked gene expression prediction loss.
        hccl_loss: Hierarchical contrastive loss.
        cell_embeddings: Cell-level representations (batch_size, d_model).
        gene_embeddings: Gene-level representations (batch_size, num_genes, d_model).
        logits: Task-specific output logits (if task specified).
        attention_weights: Attention weight matrices (optional, for analysis).
    """

    loss: Optional[torch.Tensor] = None
    mgep_loss: Optional[torch.Tensor] = None
    hccl_loss: Optional[torch.Tensor] = None
    cell_embeddings: Optional[torch.Tensor] = None
    gene_embeddings: Optional[torch.Tensor] = None
    logits: Optional[torch.Tensor] = None
    attention_weights: Optional[List[torch.Tensor]] = None


class CellGRNFormer(nn.Module):
    """CellGRN-Former: GRN-Guided Hierarchical Foundation Model for scRNA-seq.

    A Transformer-based foundation model that integrates:
    1. EACT: Expression-aware continuous tokenization preserving expression values.
    2. GGSA: GRN-guided sparse attention for biologically informed interactions.
    3. HCCL: Hierarchical cell-type contrastive learning during pre-training.
    4. TAPT: Task-adaptive prompt tuning for efficient downstream adaptation.

    Args:
        config: Model configuration dictionary.
    """

    def __init__(self, config: Dict[str, Any]):
        super().__init__()
        self.config = config
        model_cfg = config.get("model", config)

        self.num_genes = model_cfg.get("num_genes", 4000)
        self.d_model = model_cfg.get("hidden_dim", 768)
        self.num_layers = model_cfg.get("num_layers", 12)
        self.num_heads = model_cfg.get("num_heads", 12)
        self.num_global_heads = model_cfg.get("num_global_heads", 2)
        self.dropout = model_cfg.get("dropout", 0.1)
        self.use_gradient_checkpointing = model_cfg.get("use_gradient_checkpointing", True)

        self.tokenizer = ExpressionAwareContinuousTokenizer(
            num_genes=self.num_genes,
            d_model=self.d_model,
            expr_proj_hidden=model_cfg.get("expr_proj_hidden", 256),
            gene_property_dim=model_cfg.get("gene_property_dim", 64),
            num_gene_properties=model_cfg.get("num_gene_properties", 4),
            dropout=self.dropout,
        )

        self.transformer_blocks = nn.ModuleList([
            TransformerBlock(
                d_model=self.d_model,
                num_heads=self.num_heads,
                num_global_heads=self.num_global_heads,
                dropout=self.dropout,
                attention_dropout=model_cfg.get("attention_dropout", 0.05),
                activation=model_cfg.get("activation", "gelu"),
            )
            for _ in range(self.num_layers)
        ])

        self.final_norm = nn.LayerNorm(self.d_model)

        self.expression_decoder = nn.Sequential(
            nn.Linear(self.d_model, self.d_model),
            nn.GELU(),
            nn.LayerNorm(self.d_model),
            nn.Linear(self.d_model, 1),
        )

        pretrain_cfg = config.get("pretraining", {})
        hccl_levels = pretrain_cfg.get("hccl_levels", 3)
        if hccl_levels > 0:
            self.hccl_head = HierarchicalContrastiveHead(
                d_model=self.d_model,
                proj_dim=128,
                n_levels=hccl_levels,
            )
        else:
            self.hccl_head = None

        finetune_cfg = config.get("finetuning", {})
        num_prompt_tokens = finetune_cfg.get("num_prompt_tokens", 16)
        if num_prompt_tokens > 0:
            task_types = finetune_cfg.get("task_types", ["annotation", "perturbation", "integration", "trajectory"])
            task_output_dims = {}
            for task in task_types:
                if task == "annotation":
                    task_output_dims[task] = 100
                elif task == "perturbation":
                    task_output_dims[task] = self.num_genes
                elif task == "integration":
                    task_output_dims[task] = 128
                elif task == "trajectory":
                    task_output_dims[task] = 1
            self.tapt = TaskAdaptivePromptTuning(
                d_model=self.d_model,
                num_prompt_tokens=num_prompt_tokens,
                num_tasks=len(task_types),
                task_output_dims=task_output_dims,
                dropout=finetune_cfg.get("prompt_dropout", 0.1),
            )
        else:
            self.tapt = None

        n_params = sum(p.numel() for p in self.parameters())
        n_trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        logger.info(
            f"CellGRNFormer initialized: {n_params / 1e6:.1f}M params "
            f"({n_trainable / 1e6:.1f}M trainable), "
            f"{self.num_layers} layers, d={self.d_model}, h={self.num_heads}"
        )

    def encode(
        self,
        expression: torch.Tensor,
        grn_mask: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        gene_properties: Optional[torch.Tensor] = None,
        task_name: Optional[str] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Encode gene expression into cell and gene representations.

        Args:
            expression: Gene expression values (batch_size, num_genes).
            grn_mask: GRN attention mask (num_genes, num_genes).
            attention_mask: Padding mask (batch_size, num_genes).
            gene_properties: Gene properties (num_genes, n_props).
            task_name: Task name for TAPT prompt injection.

        Returns:
            Tuple of:
            - cell_embeddings: (batch_size, d_model)
            - gene_embeddings: (batch_size, seq_len, d_model)
        """
        h = self.tokenizer(expression, gene_properties=gene_properties)

        if task_name is not None and self.tapt is not None:
            batch_size = h.shape[0]
            prompt = self.tapt.get_prompt(task_name, batch_size)
            h = torch.cat([prompt, h], dim=1)

            if attention_mask is not None:
                prompt_mask = torch.ones(
                    batch_size, prompt.shape[1],
                    device=attention_mask.device, dtype=attention_mask.dtype
                )
                attention_mask = torch.cat([prompt_mask, attention_mask], dim=1)

            if grn_mask is not None:
                n_prompt = prompt.shape[1]
                n_total = h.shape[1]
                expanded_grn = torch.ones(n_total, n_total, device=grn_mask.device, dtype=grn_mask.dtype)
                expanded_grn[n_prompt:, n_prompt:] = grn_mask
                grn_mask = expanded_grn

        for i, block in enumerate(self.transformer_blocks):
            if self.use_gradient_checkpointing and self.training:
                h = checkpoint(
                    block,
                    h,
                    grn_mask,
                    attention_mask,
                    use_reentrant=False,
                )
            else:
                h = block(h, grn_mask=grn_mask, attention_mask=attention_mask)

        h = self.final_norm(h)

        if task_name is not None and self.tapt is not None:
            n_prompt = self.tapt.num_prompt_tokens
            prompt_repr = h[:, :n_prompt, :]
            gene_embeddings = h[:, n_prompt:, :]
            cell_embeddings = prompt_repr.mean(dim=1)
        else:
            gene_embeddings = h
            if attention_mask is not None:
                mask_expanded = attention_mask.unsqueeze(-1)
                cell_embeddings = (h * mask_expanded).sum(dim=1) / mask_expanded.sum(dim=1).clamp(min=1)
            else:
                cell_embeddings = h.mean(dim=1)

        return cell_embeddings, gene_embeddings

    def forward(
        self,
        expression: Optional[torch.Tensor] = None,
        masked_expression: Optional[torch.Tensor] = None,
        target_expression: Optional[torch.Tensor] = None,
        mask: Optional[torch.Tensor] = None,
        grn_mask: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        gene_properties: Optional[torch.Tensor] = None,
        cell_type: Optional[torch.Tensor] = None,
        hierarchy_labels: Optional[torch.Tensor] = None,
        task_name: Optional[str] = None,
        control_expression: Optional[torch.Tensor] = None,
        perturbation_mask: Optional[torch.Tensor] = None,
        **kwargs: Any,
    ) -> CellGRNFormerOutput:
        """Forward pass for pre-training or fine-tuning.

        In pre-training mode (mask is not None):
        - Predicts masked gene expression values (MGEP loss)
        - Computes hierarchical contrastive loss (HCCL loss)

        In fine-tuning mode (task_name is not None):
        - Uses TAPT prompt tokens
        - Applies task-specific head

        Args:
            expression: Full expression (batch_size, num_genes). Used for HCCL.
            masked_expression: Masked expression input (batch_size, num_genes).
            target_expression: Target for MGEP (batch_size, num_genes).
            mask: Boolean mask (batch_size, num_genes). True = masked.
            grn_mask: GRN attention mask (num_genes, num_genes).
            attention_mask: Padding mask (batch_size, num_genes).
            gene_properties: Gene properties (num_genes, n_properties).
            cell_type: Cell type labels (batch_size,).
            hierarchy_labels: Hierarchical labels (batch_size, n_levels).
            task_name: Downstream task name for TAPT.
            control_expression: Control expression for perturbation (batch_size, num_genes).
            perturbation_mask: Perturbation gene mask (batch_size, num_genes).

        Returns:
            CellGRNFormerOutput with losses, embeddings, and logits.
        """
        input_expr = masked_expression if masked_expression is not None else expression
        if input_expr is None:
            raise ValueError("Either expression or masked_expression must be provided")

        cell_emb, gene_emb = self.encode(
            input_expr,
            grn_mask=grn_mask,
            attention_mask=attention_mask,
            gene_properties=gene_properties,
            task_name=task_name,
        )

        output = CellGRNFormerOutput(
            cell_embeddings=cell_emb,
            gene_embeddings=gene_emb,
        )

        total_loss = torch.tensor(0.0, device=input_expr.device)
        has_loss = False

        if mask is not None and target_expression is not None:
            pred_expr = self.expression_decoder(gene_emb).squeeze(-1)

            masked_pred = pred_expr[mask]
            masked_target = target_expression[mask]

            pretrain_cfg = self.config.get("pretraining", {})
            loss_type = pretrain_cfg.get("mgep_loss", "mse")
            if loss_type == "huber":
                mgep_loss = F.huber_loss(masked_pred, masked_target, reduction="mean")
            else:
                mgep_loss = F.mse_loss(masked_pred, masked_target, reduction="mean")

            output.mgep_loss = mgep_loss
            total_loss = total_loss + mgep_loss
            has_loss = True

        if (
            self.hccl_head is not None
            and hierarchy_labels is not None
            and self.training
        ):
            projections = self.hccl_head(cell_emb)
            pretrain_cfg = self.config.get("pretraining", {})
            level_weights = pretrain_cfg.get("hccl_level_weights", [0.2, 0.3, 0.5])
            temperatures = pretrain_cfg.get("hccl_temperatures", [0.1, 0.07, 0.05])
            hccl_weight = pretrain_cfg.get("hccl_weight", 0.3)

            hccl_loss = torch.tensor(0.0, device=input_expr.device)
            for level_idx, (proj, alpha, tau) in enumerate(
                zip(projections, level_weights, temperatures)
            ):
                if level_idx < hierarchy_labels.shape[1]:
                    level_labels = hierarchy_labels[:, level_idx]
                    level_loss = self._supervised_contrastive_loss(proj, level_labels, tau)
                    hccl_loss = hccl_loss + alpha * level_loss

            output.hccl_loss = hccl_loss
            total_loss = total_loss + hccl_weight * hccl_loss
            has_loss = True

        if task_name is not None and self.tapt is not None:
            logits = self.tapt(cell_emb, task_name)
            output.logits = logits

            if task_name == "annotation" and cell_type is not None:
                task_loss = F.cross_entropy(logits, cell_type)
                total_loss = total_loss + task_loss
                has_loss = True

            elif task_name == "perturbation" and target_expression is not None:
                task_loss = F.mse_loss(logits, target_expression)
                total_loss = total_loss + task_loss
                has_loss = True

        if has_loss:
            output.loss = total_loss

        return output

    def _supervised_contrastive_loss(
        self,
        features: torch.Tensor,
        labels: torch.Tensor,
        temperature: float = 0.07,
    ) -> torch.Tensor:
        """Compute supervised contrastive loss.

        Args:
            features: L2-normalized features (batch_size, proj_dim).
            labels: Class labels (batch_size,).
            temperature: Temperature scaling factor.

        Returns:
            Scalar contrastive loss.
        """
        batch_size = features.shape[0]
        if batch_size <= 1:
            return torch.tensor(0.0, device=features.device)

        sim_matrix = torch.matmul(features, features.T) / temperature

        label_matrix = labels.unsqueeze(0) == labels.unsqueeze(1)
        label_matrix = label_matrix.float()
        self_mask = ~torch.eye(batch_size, dtype=torch.bool, device=features.device)
        label_matrix = label_matrix * self_mask.float()

        num_positives = label_matrix.sum(dim=1)
        has_positive = num_positives > 0

        if not has_positive.any():
            return torch.tensor(0.0, device=features.device)

        sim_matrix = sim_matrix - sim_matrix.max(dim=1, keepdim=True)[0].detach()

        exp_sim = torch.exp(sim_matrix) * self_mask.float()
        log_prob = sim_matrix - torch.log(exp_sim.sum(dim=1, keepdim=True) + 1e-8)

        mean_log_prob_pos = (label_matrix * log_prob).sum(dim=1) / num_positives.clamp(min=1)

        loss = -mean_log_prob_pos[has_positive].mean()
        return loss

    def freeze_backbone(self) -> None:
        """Freeze all parameters except TAPT module for fine-tuning."""
        for param in self.parameters():
            param.requires_grad = False

        if self.tapt is not None:
            for param in self.tapt.parameters():
                param.requires_grad = True

        n_trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        n_total = sum(p.numel() for p in self.parameters())
        logger.info(
            f"Backbone frozen. Trainable: {n_trainable / 1e6:.2f}M / "
            f"{n_total / 1e6:.1f}M ({n_trainable / n_total * 100:.2f}%)"
        )

    def get_cell_embeddings(
        self,
        expression: torch.Tensor,
        grn_mask: Optional[torch.Tensor] = None,
        gene_properties: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Extract cell embeddings for downstream analysis.

        Args:
            expression: Gene expression (batch_size, num_genes).
            grn_mask: GRN attention mask.
            gene_properties: Gene property features.

        Returns:
            Cell embeddings (batch_size, d_model).
        """
        self.eval()
        with torch.no_grad():
            cell_emb, _ = self.encode(
                expression,
                grn_mask=grn_mask,
                gene_properties=gene_properties,
            )
        return cell_emb

    def update_annotation_head(self, num_classes: int) -> None:
        """Update the annotation task head for a specific number of classes.

        Args:
            num_classes: Number of cell type classes.
        """
        if self.tapt is not None and "annotation" in self.tapt.task_heads:
            old_head = self.tapt.task_heads["annotation"]
            device = next(old_head.parameters()).device

            self.tapt.task_heads["annotation"] = nn.Sequential(
                nn.LayerNorm(self.d_model),
                nn.Linear(self.d_model, self.d_model // 2),
                nn.GELU(),
                nn.Dropout(self.dropout),
                nn.Linear(self.d_model // 2, num_classes),
            ).to(device)

            logger.info(f"Updated annotation head to {num_classes} classes")
