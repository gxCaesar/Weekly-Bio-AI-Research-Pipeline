"""Optimizer and learning rate scheduler factories for CellGRN-Former.

Provides standard optimizer and scheduler configurations with
support for parameter group differentiation.
"""

import logging
import math
from typing import Any, Dict, Iterator, Optional, Tuple

import torch
import torch.nn as nn
from torch.optim import AdamW, Optimizer
from torch.optim.lr_scheduler import CosineAnnealingLR, LambdaLR, _LRScheduler

logger = logging.getLogger(__name__)


def build_optimizer(
    model: nn.Module,
    config: Dict[str, Any],
) -> AdamW:
    """Build AdamW optimizer with optional weight decay exclusion.

    Excludes bias, LayerNorm, and embedding parameters from weight decay.

    Args:
        model: The model to optimize.
        config: Training configuration dictionary.

    Returns:
        Configured AdamW optimizer.
    """
    training_cfg = config.get("training", config)
    lr = training_cfg.get("learning_rate", 1e-4)
    weight_decay = training_cfg.get("weight_decay", 0.01)

    decay_params = []
    no_decay_params = []

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if "bias" in name or "norm" in name or "embedding" in name:
            no_decay_params.append(param)
        else:
            decay_params.append(param)

    param_groups = [
        {"params": decay_params, "weight_decay": weight_decay},
        {"params": no_decay_params, "weight_decay": 0.0},
    ]

    optimizer = AdamW(param_groups, lr=lr, betas=(0.9, 0.999), eps=1e-8)

    n_decay = sum(p.numel() for p in decay_params)
    n_no_decay = sum(p.numel() for p in no_decay_params)
    logger.info(
        f"Optimizer: AdamW, lr={lr}, weight_decay={weight_decay}, "
        f"decay_params={n_decay / 1e6:.2f}M, no_decay_params={n_no_decay / 1e6:.2f}M"
    )

    return optimizer


def build_scheduler(
    optimizer: Optimizer,
    config: Dict[str, Any],
    num_training_steps: int,
) -> _LRScheduler:
    """Build learning rate scheduler with linear warmup and cosine decay.

    Args:
        optimizer: The optimizer.
        config: Training configuration dictionary.
        num_training_steps: Total number of training steps.

    Returns:
        Learning rate scheduler.
    """
    training_cfg = config.get("training", config)
    warmup_ratio = training_cfg.get("warmup_ratio", 0.05)
    num_warmup_steps = int(num_training_steps * warmup_ratio)

    def lr_lambda(current_step: int) -> float:
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1, num_warmup_steps))
        progress = float(current_step - num_warmup_steps) / float(
            max(1, num_training_steps - num_warmup_steps)
        )
        return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))

    scheduler = LambdaLR(optimizer, lr_lambda)

    logger.info(
        f"Scheduler: Linear warmup ({num_warmup_steps} steps) + "
        f"Cosine decay ({num_training_steps - num_warmup_steps} steps), "
        f"total={num_training_steps} steps"
    )

    return scheduler
