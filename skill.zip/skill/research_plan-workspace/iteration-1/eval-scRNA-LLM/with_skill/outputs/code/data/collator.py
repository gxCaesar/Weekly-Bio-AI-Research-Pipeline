"""Custom data collation functions for batching single-cell data.

Handles variable-length gene sets and padding.
"""

import logging
from typing import Any, Dict, List

import torch

logger = logging.getLogger(__name__)


class SingleCellCollator:
    """Collator for batching single-cell expression data.

    Handles padding and stacking of variable-sized tensors from
    SingleCellDataset and PerturbationDataset.

    Args:
        pad_value: Value to use for padding (default 0.0).
        include_gene_properties: Whether gene properties are present.
    """

    def __init__(
        self,
        pad_value: float = 0.0,
        include_gene_properties: bool = False,
    ):
        self.pad_value = pad_value
        self.include_gene_properties = include_gene_properties

    def __call__(self, batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """Collate a batch of samples.

        Args:
            batch: List of sample dictionaries from Dataset.__getitem__.

        Returns:
            Collated batch dictionary with stacked tensors.
        """
        collated: Dict[str, torch.Tensor] = {}

        keys = batch[0].keys()

        for key in keys:
            values = [sample[key] for sample in batch]

            if values[0].dim() == 0:
                collated[key] = torch.stack(values)
            elif values[0].dim() == 1:
                collated[key] = torch.stack(values)
            elif values[0].dim() == 2:
                collated[key] = torch.stack(values)
            else:
                collated[key] = torch.stack(values)

        return collated


class PretrainingCollator(SingleCellCollator):
    """Collator specifically for pre-training with masking.

    Ensures consistent masking across the batch and adds
    attention mask tensors.

    Args:
        pad_value: Value for padding.
        mask_ratio: Ratio of genes to mask (overrides dataset default).
    """

    def __init__(
        self,
        pad_value: float = 0.0,
        mask_ratio: float = 0.15,
    ):
        super().__init__(pad_value=pad_value)
        self.mask_ratio = mask_ratio

    def __call__(self, batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """Collate with additional attention masks.

        Returns:
            Collated batch with added 'attention_mask' field indicating
            non-zero expression positions.
        """
        collated = super().__call__(batch)

        expression = collated.get("expression", collated.get("masked_expression"))
        if expression is not None:
            attention_mask = (expression != 0).float()
            collated["attention_mask"] = attention_mask

        return collated
