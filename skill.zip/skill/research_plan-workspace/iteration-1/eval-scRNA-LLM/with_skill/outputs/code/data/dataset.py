"""PyTorch Dataset classes for CellGRN-Former.

Provides datasets for pre-training and downstream fine-tuning tasks.
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import anndata as ad
import numpy as np
import pandas as pd
import torch
from scipy import sparse
from torch.utils.data import Dataset

logger = logging.getLogger(__name__)


class SingleCellDataset(Dataset):
    """Dataset for single-cell RNA-seq pre-training and cell annotation.

    Each sample is a single cell's gene expression vector, optionally with
    cell type labels and hierarchy information.

    Args:
        adata: AnnData object with preprocessed data.
        gene_names: Ordered list of gene names (model vocabulary).
        gene_properties: DataFrame of gene-level properties (optional).
        cell_type_col: Column name for cell type labels in adata.obs.
        hierarchy_map: Dict mapping cell types to hierarchy levels (optional).
        mask_ratio: Ratio of genes to mask for pre-training (0 for fine-tuning).
        max_genes: Maximum number of genes to use per cell.
        return_raw_counts: Whether to also return raw counts.
    """

    def __init__(
        self,
        adata: ad.AnnData,
        gene_names: List[str],
        gene_properties: Optional[pd.DataFrame] = None,
        cell_type_col: str = "cell_type",
        hierarchy_map: Optional[Dict[str, Dict[str, int]]] = None,
        mask_ratio: float = 0.15,
        max_genes: int = 4000,
        return_raw_counts: bool = False,
    ):
        super().__init__()
        self.gene_names = gene_names
        self.n_genes = len(gene_names)
        self.mask_ratio = mask_ratio
        self.max_genes = max_genes
        self.return_raw_counts = return_raw_counts

        gene_set = set(gene_names)
        common_genes = [g for g in adata.var_names if g in gene_set]
        gene_idx = [gene_names.index(g) for g in common_genes]
        self.gene_idx_map = np.array(gene_idx)

        if sparse.issparse(adata.X):
            self.expression_data = adata[:, common_genes].X.toarray().astype(np.float32)
        else:
            self.expression_data = adata[:, common_genes].X.astype(np.float32)

        if return_raw_counts and "counts" in adata.layers:
            if sparse.issparse(adata.layers["counts"]):
                self.raw_counts = adata[:, common_genes].layers["counts"].toarray().astype(np.float32)
            else:
                self.raw_counts = adata[:, common_genes].layers["counts"].astype(np.float32)
        else:
            self.raw_counts = None

        self.cell_types = None
        self.cell_type_to_id = {}
        if cell_type_col in adata.obs.columns:
            unique_types = sorted(adata.obs[cell_type_col].unique())
            self.cell_type_to_id = {ct: i for i, ct in enumerate(unique_types)}
            self.cell_types = np.array(
                [self.cell_type_to_id[ct] for ct in adata.obs[cell_type_col]]
            )

        self.hierarchy_labels = None
        if hierarchy_map is not None and self.cell_types is not None:
            inverse_ct_map = {v: k for k, v in self.cell_type_to_id.items()}
            n_levels = len(list(hierarchy_map.values())[0]) if hierarchy_map else 0
            self.hierarchy_labels = np.zeros((len(adata), n_levels), dtype=np.int64)
            for idx in range(len(adata)):
                ct_name = inverse_ct_map[self.cell_types[idx]]
                if ct_name in hierarchy_map:
                    for level, level_label in enumerate(hierarchy_map[ct_name].values()):
                        self.hierarchy_labels[idx, level] = level_label

        self.gene_property_tensor = None
        if gene_properties is not None:
            prop_values = np.zeros((self.n_genes, gene_properties.shape[1]), dtype=np.float32)
            for i, gene in enumerate(gene_names):
                if gene in gene_properties.index:
                    prop_values[i] = gene_properties.loc[gene].values
            self.gene_property_tensor = torch.from_numpy(prop_values)

        self.n_cells = self.expression_data.shape[0]
        logger.info(
            f"SingleCellDataset: {self.n_cells} cells, {self.n_genes} genes "
            f"({len(common_genes)} mapped), mask_ratio={mask_ratio}"
        )

    def __len__(self) -> int:
        return self.n_cells

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """Get a single cell sample.

        Returns:
            Dictionary with:
            - expression: Gene expression values (n_genes,).
            - gene_ids: Gene indices in vocabulary (n_mapped_genes,).
            - mask: Boolean mask indicating which genes are masked (n_genes,).
            - cell_type: Cell type label (scalar) if available.
            - hierarchy_labels: Hierarchical labels (n_levels,) if available.
        """
        expr_mapped = self.expression_data[idx]

        expression = np.zeros(self.n_genes, dtype=np.float32)
        expression[self.gene_idx_map] = expr_mapped

        mask = np.zeros(self.n_genes, dtype=np.bool_)
        if self.mask_ratio > 0:
            nonzero_idx = np.where(expression > 0)[0]
            n_mask = max(1, int(len(nonzero_idx) * self.mask_ratio))
            if len(nonzero_idx) > 0:
                mask_idx = np.random.choice(nonzero_idx, size=n_mask, replace=False)
                mask[mask_idx] = True

        result: Dict[str, torch.Tensor] = {
            "expression": torch.from_numpy(expression),
            "gene_ids": torch.from_numpy(self.gene_idx_map),
            "mask": torch.from_numpy(mask),
        }

        if self.mask_ratio > 0:
            target = expression.copy()
            masked_expression = expression.copy()
            masked_expression[mask] = 0.0
            result["masked_expression"] = torch.from_numpy(masked_expression)
            result["target_expression"] = torch.from_numpy(target)

        if self.cell_types is not None:
            result["cell_type"] = torch.tensor(self.cell_types[idx], dtype=torch.long)

        if self.hierarchy_labels is not None:
            result["hierarchy_labels"] = torch.from_numpy(self.hierarchy_labels[idx])

        if self.raw_counts is not None:
            raw = np.zeros(self.n_genes, dtype=np.float32)
            raw[self.gene_idx_map] = self.raw_counts[idx]
            result["raw_counts"] = torch.from_numpy(raw)

        return result


class PerturbationDataset(Dataset):
    """Dataset for gene perturbation prediction.

    Each sample contains a control cell expression and a perturbation condition,
    with the target being the post-perturbation expression.

    Args:
        adata: AnnData with perturbation data.
        gene_names: Ordered list of gene names.
        perturbation_col: Column in adata.obs indicating perturbation.
        control_label: Label for control (unperturbed) cells.
    """

    def __init__(
        self,
        adata: ad.AnnData,
        gene_names: List[str],
        perturbation_col: str = "condition",
        control_label: str = "ctrl",
    ):
        super().__init__()
        self.gene_names = gene_names
        self.n_genes = len(gene_names)

        gene_set = set(gene_names)
        common_genes = [g for g in adata.var_names if g in gene_set]
        gene_idx = [gene_names.index(g) for g in common_genes]
        self.gene_idx_map = np.array(gene_idx)

        ctrl_mask = adata.obs[perturbation_col] == control_label
        pert_mask = ~ctrl_mask

        if sparse.issparse(adata.X):
            ctrl_expr = adata[ctrl_mask][:, common_genes].X.toarray().astype(np.float32)
            pert_expr = adata[pert_mask][:, common_genes].X.toarray().astype(np.float32)
        else:
            ctrl_expr = adata[ctrl_mask][:, common_genes].X.astype(np.float32)
            pert_expr = adata[pert_mask][:, common_genes].X.astype(np.float32)

        self.ctrl_mean = ctrl_expr.mean(axis=0)

        pert_conditions = adata.obs.loc[pert_mask, perturbation_col].values
        unique_conditions = sorted(set(pert_conditions))
        self.condition_to_id = {c: i for i, c in enumerate(unique_conditions)}

        self.samples = []
        for i in range(len(pert_expr)):
            cond = pert_conditions[i]
            self.samples.append({
                "pert_expression": pert_expr[i],
                "condition_id": self.condition_to_id[cond],
                "condition_name": cond,
            })

        self.perturbation_genes = {}
        for cond in unique_conditions:
            pert_gene_names = [g.strip() for g in cond.split("+") if g.strip() != control_label]
            pert_gene_ids = []
            for g in pert_gene_names:
                if g in gene_names:
                    pert_gene_ids.append(gene_names.index(g))
            self.perturbation_genes[self.condition_to_id[cond]] = pert_gene_ids

        logger.info(
            f"PerturbationDataset: {len(self.samples)} perturbed cells, "
            f"{len(unique_conditions)} conditions, control mean from {ctrl_expr.shape[0]} cells"
        )

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """Get a perturbation sample.

        Returns:
            Dictionary with:
            - control_expression: Mean control expression (n_genes,).
            - perturbation_mask: Binary mask of perturbed genes (n_genes,).
            - target_expression: Post-perturbation expression (n_genes,).
            - condition_id: Perturbation condition ID (scalar).
        """
        sample = self.samples[idx]

        ctrl_full = np.zeros(self.n_genes, dtype=np.float32)
        ctrl_full[self.gene_idx_map] = self.ctrl_mean

        pert_full = np.zeros(self.n_genes, dtype=np.float32)
        pert_full[self.gene_idx_map] = sample["pert_expression"]

        pert_mask = np.zeros(self.n_genes, dtype=np.float32)
        cond_id = sample["condition_id"]
        for gene_id in self.perturbation_genes.get(cond_id, []):
            pert_mask[gene_id] = 1.0

        return {
            "control_expression": torch.from_numpy(ctrl_full),
            "perturbation_mask": torch.from_numpy(pert_mask),
            "target_expression": torch.from_numpy(pert_full),
            "condition_id": torch.tensor(cond_id, dtype=torch.long),
        }
