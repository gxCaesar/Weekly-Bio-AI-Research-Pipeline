#!/bin/bash
# Run all baseline methods for comparison
set -e

echo "============================================"
echo " Running Baseline Experiments"
echo "============================================"

BASELINE_DIR="outputs/baselines"
mkdir -p "$BASELINE_DIR"

echo "[1/3] Running scGPT baseline..."
python main.py \
    --config configs/baseline_scgpt.yaml \
    --mode train_eval \
    --output_dir "$BASELINE_DIR/scgpt" \
    2>&1 | tee "$BASELINE_DIR/scgpt/log.txt"

echo "[2/3] Running Geneformer baseline..."
python main.py \
    --config configs/baseline_geneformer.yaml \
    --mode train_eval \
    --output_dir "$BASELINE_DIR/geneformer" \
    2>&1 | tee "$BASELINE_DIR/geneformer/log.txt"

echo "[3/3] Running scVI baseline..."
python main.py \
    --config configs/baseline_scvi.yaml \
    --mode train_eval \
    --output_dir "$BASELINE_DIR/scvi" \
    2>&1 | tee "$BASELINE_DIR/scvi/log.txt"

echo "============================================"
echo " Baselines complete. Results in: $BASELINE_DIR/"
echo "============================================"
