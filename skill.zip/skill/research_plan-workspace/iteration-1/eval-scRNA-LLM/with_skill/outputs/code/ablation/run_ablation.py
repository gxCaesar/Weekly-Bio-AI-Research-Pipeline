"""Ablation study orchestrator for CellGRN-Former.

Runs all ablation experiments defined in configs/ablation_*.yaml
and collects results for comparison.
"""

import argparse
import json
import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

import yaml

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


ABLATION_CONFIGS = {
    "full_model": "configs/default.yaml",
    "no_ggsa": "configs/ablation_no_ggsa.yaml",
    "no_hccl": "configs/ablation_no_hccl.yaml",
    "no_tapt": "configs/ablation_no_tapt.yaml",
    "binning_tokenization": "configs/ablation_binning_tokenization.yaml",
}


def run_single_ablation(
    config_path: str,
    output_dir: str,
    mode: str = "train_eval",
    checkpoint: str = None,
) -> Dict[str, Any]:
    """Run a single ablation experiment.

    Args:
        config_path: Path to the ablation config YAML file.
        output_dir: Output directory for this ablation run.
        mode: Training mode (train, eval, train_eval).
        checkpoint: Optional checkpoint to resume from.

    Returns:
        Results dictionary from the experiment.
    """
    logger.info(f"\n{'='*60}")
    logger.info(f"Running ablation: {config_path}")
    logger.info(f"Output: {output_dir}")
    logger.info(f"{'='*60}")

    cmd = [
        sys.executable, "main.py",
        "--config", config_path,
        "--mode", mode,
        "--output_dir", output_dir,
    ]
    if checkpoint:
        cmd.extend(["--checkpoint", checkpoint])

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        logger.error(f"Ablation failed: {config_path}")
        logger.error(f"STDERR: {result.stderr}")
        return {"status": "failed", "error": result.stderr}

    results_path = os.path.join(output_dir, "eval_results.json")
    if os.path.exists(results_path):
        with open(results_path) as f:
            results = json.load(f)
    else:
        results = {"status": "completed", "note": "no eval_results.json found"}

    logger.info(f"Ablation completed: {config_path}")
    return results


def run_all_ablations(
    base_output_dir: str = "./outputs/ablation",
    mode: str = "train_eval",
    pretrained_checkpoint: str = None,
) -> Dict[str, Dict[str, Any]]:
    """Run all ablation experiments and collect results.

    Args:
        base_output_dir: Base directory for all ablation outputs.
        mode: Training mode.
        pretrained_checkpoint: Pre-trained model checkpoint for fine-tuning ablations.

    Returns:
        Dictionary mapping ablation name to results.
    """
    all_results: Dict[str, Dict[str, Any]] = {}

    for ablation_name, config_path in ABLATION_CONFIGS.items():
        output_dir = os.path.join(base_output_dir, ablation_name)
        os.makedirs(output_dir, exist_ok=True)

        results = run_single_ablation(
            config_path=config_path,
            output_dir=output_dir,
            mode=mode,
            checkpoint=pretrained_checkpoint,
        )

        all_results[ablation_name] = results

    summary_path = os.path.join(base_output_dir, "ablation_summary.json")
    with open(summary_path, "w") as f:
        json.dump(all_results, f, indent=2)
    logger.info(f"\nAblation summary saved to {summary_path}")

    print_ablation_table(all_results)

    return all_results


def print_ablation_table(results: Dict[str, Dict[str, Any]]) -> None:
    """Print a formatted table of ablation results.

    Args:
        results: Dictionary of ablation results.
    """
    logger.info("\n" + "=" * 80)
    logger.info("ABLATION STUDY RESULTS")
    logger.info("=" * 80)

    header = f"{'Configuration':<30} {'Accuracy':<12} {'Macro-F1':<12} {'Pearson r':<12}"
    logger.info(header)
    logger.info("-" * 80)

    for name, result in results.items():
        if isinstance(result, dict):
            annotation = result.get("annotation", {})
            perturbation = result.get("perturbation", {})
            acc = annotation.get("accuracy", "N/A")
            f1 = annotation.get("macro_f1", "N/A")
            pearson = perturbation.get("pearson_r", "N/A")

            acc_str = f"{acc:.4f}" if isinstance(acc, float) else str(acc)
            f1_str = f"{f1:.4f}" if isinstance(f1, float) else str(f1)
            pearson_str = f"{pearson:.4f}" if isinstance(pearson, float) else str(pearson)

            logger.info(f"{name:<30} {acc_str:<12} {f1_str:<12} {pearson_str:<12}")

    logger.info("=" * 80)


def main() -> None:
    """Main entry point for ablation studies."""
    parser = argparse.ArgumentParser(description="Run CellGRN-Former ablation studies")
    parser.add_argument(
        "--output_dir", type=str, default="./outputs/ablation",
        help="Base output directory for ablation results",
    )
    parser.add_argument(
        "--mode", type=str, default="train_eval",
        choices=["train", "eval", "train_eval"],
        help="Training mode",
    )
    parser.add_argument(
        "--checkpoint", type=str, default=None,
        help="Pre-trained checkpoint for fine-tuning ablations",
    )
    parser.add_argument(
        "--ablation", type=str, default=None,
        choices=list(ABLATION_CONFIGS.keys()),
        help="Run a specific ablation only",
    )
    args = parser.parse_args()

    if args.ablation:
        config_path = ABLATION_CONFIGS[args.ablation]
        output_dir = os.path.join(args.output_dir, args.ablation)
        os.makedirs(output_dir, exist_ok=True)
        run_single_ablation(config_path, output_dir, args.mode, args.checkpoint)
    else:
        run_all_ablations(args.output_dir, args.mode, args.checkpoint)


if __name__ == "__main__":
    main()
