"""Download and extract datasets for CellGRN-Former.

Supports downloading from CellXGene Census, GEO, and other public repositories.
"""

import argparse
import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

import anndata as ad
import numpy as np
import scanpy as sc

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def download_cellxgene_census(
    output_dir: str,
    organism: str = "homo_sapiens",
    max_cells: Optional[int] = None,
    census_version: str = "stable",
) -> str:
    """Download scRNA-seq data from CellXGene Census.

    Args:
        output_dir: Directory to save the downloaded data.
        organism: Organism name (homo_sapiens or mus_musculus).
        max_cells: Maximum number of cells to download. None for all.
        census_version: Census version to use.

    Returns:
        Path to the saved h5ad file.
    """
    import cellxgene_census

    logger.info(f"Opening CellXGene Census (version={census_version})...")
    os.makedirs(output_dir, exist_ok=True)

    with cellxgene_census.open_soma(census_version=census_version) as census:
        logger.info(f"Querying {organism} data...")

        query_kwargs = {}
        if max_cells is not None:
            obs_filter = f"is_primary_data == True"
            query_kwargs["obs_value_filter"] = obs_filter

        adata = cellxgene_census.get_anndata(
            census,
            organism=organism,
            obs_value_filter="is_primary_data == True",
        )

        if max_cells is not None and adata.n_obs > max_cells:
            logger.info(f"Subsampling from {adata.n_obs} to {max_cells} cells...")
            rng = np.random.RandomState(42)
            indices = rng.choice(adata.n_obs, max_cells, replace=False)
            adata = adata[indices].copy()

        output_path = os.path.join(output_dir, f"cellxgene_{organism}.h5ad")
        logger.info(f"Saving to {output_path}...")
        adata.write_h5ad(output_path)
        logger.info(f"Saved {adata.n_obs} cells x {adata.n_vars} genes")

    return output_path


def download_tabula_sapiens(output_dir: str) -> str:
    """Download Tabula Sapiens dataset.

    Args:
        output_dir: Directory to save the downloaded data.

    Returns:
        Path to the saved h5ad file.
    """
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "tabula_sapiens.h5ad")

    if os.path.exists(output_path):
        logger.info(f"Tabula Sapiens already exists at {output_path}")
        return output_path

    url = "https://figshare.com/ndownloader/files/34702101"
    logger.info(f"Downloading Tabula Sapiens from {url}...")
    subprocess.run(["wget", "-O", output_path, url], check=True)
    logger.info(f"Saved to {output_path}")
    return output_path


def download_zheng68k(output_dir: str) -> str:
    """Download Zheng68K PBMC dataset using scanpy.

    Args:
        output_dir: Directory to save the downloaded data.

    Returns:
        Path to the saved h5ad file.
    """
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "zheng68k_pbmc.h5ad")

    if os.path.exists(output_path):
        logger.info(f"Zheng68K already exists at {output_path}")
        return output_path

    logger.info("Downloading Zheng68K PBMC dataset via scanpy...")
    adata = sc.datasets.pbmc68k_reduced()
    adata.write_h5ad(output_path)
    logger.info(f"Saved {adata.n_obs} cells to {output_path}")
    return output_path


def download_pancreas(output_dir: str) -> str:
    """Download pancreas multi-batch dataset for integration evaluation.

    Args:
        output_dir: Directory to save the downloaded data.

    Returns:
        Path to the saved h5ad file.
    """
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "pancreas.h5ad")

    if os.path.exists(output_path):
        logger.info(f"Pancreas dataset already exists at {output_path}")
        return output_path

    logger.info("Downloading pancreas dataset via scvi-tools...")
    import scvi

    adata = scvi.data.pancreas()
    adata.write_h5ad(output_path)
    logger.info(f"Saved {adata.n_obs} cells to {output_path}")
    return output_path


def download_norman_perturb(output_dir: str) -> str:
    """Download Norman et al. Perturb-seq dataset.

    Args:
        output_dir: Directory to save the downloaded data.

    Returns:
        Path to the saved h5ad file.
    """
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "norman_perturb.h5ad")

    if os.path.exists(output_path):
        logger.info(f"Norman Perturb-seq already exists at {output_path}")
        return output_path

    logger.info("Downloading Norman Perturb-seq dataset...")
    url = (
        "https://dataverse.harvard.edu/api/access/datafile/"
        ":persistentId?persistentId=doi:10.7910/DVN/GMYNWP/K6KBZM"
    )
    subprocess.run(["wget", "-O", output_path, url], check=True)
    logger.info(f"Saved to {output_path}")
    return output_path


def download_grn_data(output_dir: str) -> str:
    """Download Gene Regulatory Network data from Dorothea/OmniPath.

    Args:
        output_dir: Directory to save the GRN data.

    Returns:
        Path to the saved GRN adjacency file.
    """
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "dorothea_grn.npz")

    if os.path.exists(output_path):
        logger.info(f"GRN data already exists at {output_path}")
        return output_path

    logger.info("Downloading Dorothea regulons via decoupler...")
    import decoupler as dc

    net = dc.get_dorothea(organism="human", levels=["A", "B", "C"])
    logger.info(f"Retrieved {len(net)} regulatory interactions")

    source_genes = net["source"].unique().tolist()
    target_genes = net["target"].unique().tolist()
    all_genes = sorted(set(source_genes + target_genes))
    gene_to_idx = {g: i for i, g in enumerate(all_genes)}

    n_genes = len(all_genes)
    adj_matrix = np.zeros((n_genes, n_genes), dtype=np.float32)

    for _, row in net.iterrows():
        src = row["source"]
        tgt = row["target"]
        if src in gene_to_idx and tgt in gene_to_idx:
            adj_matrix[gene_to_idx[src], gene_to_idx[tgt]] = 1.0

    np.savez(
        output_path,
        adjacency=adj_matrix,
        gene_names=np.array(all_genes),
    )
    logger.info(f"Saved GRN adjacency ({n_genes} genes, {int(adj_matrix.sum())} edges) to {output_path}")
    return output_path


DATASET_REGISTRY = {
    "cellxgene_census": download_cellxgene_census,
    "tabula_sapiens": download_tabula_sapiens,
    "zheng68k": download_zheng68k,
    "pancreas": download_pancreas,
    "norman_perturb": download_norman_perturb,
    "grn": download_grn_data,
}


def main() -> None:
    """Main entry point for data download."""
    parser = argparse.ArgumentParser(description="Download datasets for CellGRN-Former")
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        choices=list(DATASET_REGISTRY.keys()) + ["all"],
        help="Dataset to download",
    )
    parser.add_argument("--output_dir", type=str, default="./data/raw", help="Output directory")
    parser.add_argument(
        "--max_cells",
        type=int,
        default=None,
        help="Max cells for CellXGene (None=all)",
    )
    args = parser.parse_args()

    if args.dataset == "all":
        for name, download_fn in DATASET_REGISTRY.items():
            logger.info(f"\n{'='*60}\nDownloading: {name}\n{'='*60}")
            if name == "cellxgene_census":
                download_fn(args.output_dir, max_cells=args.max_cells)
            elif name == "grn":
                download_fn(os.path.join(args.output_dir, "grn"))
            else:
                download_fn(args.output_dir)
    else:
        download_fn = DATASET_REGISTRY[args.dataset]
        if args.dataset == "cellxgene_census":
            download_fn(args.output_dir, max_cells=args.max_cells)
        elif args.dataset == "grn":
            download_fn(os.path.join(args.output_dir, "grn"))
        else:
            download_fn(args.output_dir)


if __name__ == "__main__":
    main()
