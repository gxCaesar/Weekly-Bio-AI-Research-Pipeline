#!/bin/bash
# Run all ablation studies
set -e

echo "============================================"
echo " Running Ablation Studies"
echo "============================================"

ABLATION_DIR="outputs/ablation"
PRETRAINED_CKPT=${1:-outputs/pretrain/best_model.pt}

mkdir -p "$ABLATION_DIR"

python ablation/run_ablation.py \
    --output_dir "$ABLATION_DIR" \
    --mode train_eval \
    --checkpoint "$PRETRAINED_CKPT"

echo "============================================"
echo " Ablation studies complete."
echo " Summary: $ABLATION_DIR/ablation_summary.json"
echo "============================================"
