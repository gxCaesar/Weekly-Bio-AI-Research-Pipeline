"""Custom loss functions for CellGRN-Former.

Implements:
- Masked Expression Prediction loss (MGEP)
- Hierarchical Contrastive Loss (HCCL)
- Perturbation Prediction loss
"""

from typing import List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class MaskedExpressionLoss(nn.Module):
    """Loss for masked gene expression prediction.

    Supports MSE and Huber loss, computed only on masked positions.

    Args:
        loss_type: Type of loss ('mse' or 'huber').
        huber_delta: Delta parameter for Huber loss.
    """

    def __init__(self, loss_type: str = "mse", huber_delta: float = 1.0):
        super().__init__()
        self.loss_type = loss_type
        self.huber_delta = huber_delta

    def forward(
        self,
        predictions: torch.Tensor,
        targets: torch.Tensor,
        mask: torch.Tensor,
    ) -> torch.Tensor:
        """Compute masked expression prediction loss.

        Args:
            predictions: Predicted expression (batch_size, num_genes).
            targets: Target expression (batch_size, num_genes).
            mask: Boolean mask (batch_size, num_genes). True = compute loss.

        Returns:
            Scalar loss value.
        """
        masked_pred = predictions[mask]
        masked_target = targets[mask]

        if masked_pred.numel() == 0:
            return torch.tensor(0.0, device=predictions.device, requires_grad=True)

        if self.loss_type == "huber":
            loss = F.huber_loss(masked_pred, masked_target, delta=self.huber_delta, reduction="mean")
        else:
            loss = F.mse_loss(masked_pred, masked_target, reduction="mean")

        return loss


class HierarchicalContrastiveLoss(nn.Module):
    """Hierarchical Cell-Type Contrastive Loss (HCCL).

    Computes supervised contrastive loss at multiple hierarchy levels,
    weighted by level-specific coefficients.

    Args:
        n_levels: Number of hierarchy levels.
        level_weights: Weight for each level (alpha_l).
        temperatures: Temperature for each level (tau_l).
    """

    def __init__(
        self,
        n_levels: int = 3,
        level_weights: Optional[List[float]] = None,
        temperatures: Optional[List[float]] = None,
    ):
        super().__init__()
        self.n_levels = n_levels
        self.level_weights = level_weights or [0.2, 0.3, 0.5]
        self.temperatures = temperatures or [0.1, 0.07, 0.05]

        assert len(self.level_weights) == n_levels
        assert len(self.temperatures) == n_levels

    def forward(
        self,
        projections: List[torch.Tensor],
        hierarchy_labels: torch.Tensor,
    ) -> torch.Tensor:
        """Compute hierarchical contrastive loss.

        Args:
            projections: List of L2-normalized projections per level.
                Each is (batch_size, proj_dim).
            hierarchy_labels: Labels at each level (batch_size, n_levels).

        Returns:
            Weighted sum of contrastive losses across levels.
        """
        total_loss = torch.tensor(0.0, device=projections[0].device)

        for level_idx in range(self.n_levels):
            if level_idx >= hierarchy_labels.shape[1]:
                break

            proj = projections[level_idx]
            labels = hierarchy_labels[:, level_idx]
            tau = self.temperatures[level_idx]
            alpha = self.level_weights[level_idx]

            level_loss = self._supervised_contrastive(proj, labels, tau)
            total_loss = total_loss + alpha * level_loss

        return total_loss

    def _supervised_contrastive(
        self,
        features: torch.Tensor,
        labels: torch.Tensor,
        temperature: float,
    ) -> torch.Tensor:
        """Compute supervised contrastive loss for one hierarchy level.

        Args:
            features: L2-normalized features (batch_size, dim).
            labels: Class labels (batch_size,).
            temperature: Temperature parameter.

        Returns:
            Scalar loss.
        """
        batch_size = features.shape[0]
        if batch_size <= 1:
            return torch.tensor(0.0, device=features.device, requires_grad=True)

        sim = torch.matmul(features, features.T) / temperature
        sim = sim - sim.max(dim=1, keepdim=True)[0].detach()

        pos_mask = (labels.unsqueeze(0) == labels.unsqueeze(1)).float()
        self_mask = (~torch.eye(batch_size, dtype=torch.bool, device=features.device)).float()
        pos_mask = pos_mask * self_mask

        num_pos = pos_mask.sum(dim=1)
        has_pos = num_pos > 0

        if not has_pos.any():
            return torch.tensor(0.0, device=features.device, requires_grad=True)

        exp_sim = torch.exp(sim) * self_mask
        log_prob = sim - torch.log(exp_sim.sum(dim=1, keepdim=True) + 1e-8)

        mean_log_prob = (pos_mask * log_prob).sum(dim=1) / num_pos.clamp(min=1)
        loss = -mean_log_prob[has_pos].mean()

        return loss


class PerturbationLoss(nn.Module):
    """Loss for gene perturbation prediction.

    Combines MSE loss on all genes with an additional weighted loss
    on the perturbed genes.

    Args:
        perturbed_gene_weight: Extra weight for perturbed genes.
    """

    def __init__(self, perturbed_gene_weight: float = 5.0):
        super().__init__()
        self.perturbed_gene_weight = perturbed_gene_weight

    def forward(
        self,
        predictions: torch.Tensor,
        targets: torch.Tensor,
        perturbation_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Compute perturbation prediction loss.

        Args:
            predictions: Predicted post-perturbation expression (batch, genes).
            targets: True post-perturbation expression (batch, genes).
            perturbation_mask: Binary mask of perturbed genes (batch, genes).

        Returns:
            Scalar loss value.
        """
        base_loss = F.mse_loss(predictions, targets, reduction="mean")

        if perturbation_mask is not None and perturbation_mask.sum() > 0:
            pert_pred = predictions[perturbation_mask.bool()]
            pert_target = targets[perturbation_mask.bool()]
            pert_loss = F.mse_loss(pert_pred, pert_target, reduction="mean")
            total_loss = base_loss + self.perturbed_gene_weight * pert_loss
        else:
            total_loss = base_loss

        return total_loss
