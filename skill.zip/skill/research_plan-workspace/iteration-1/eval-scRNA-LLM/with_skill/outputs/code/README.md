# CellGRN-Former

**GRN-Guided Hierarchical Foundation Model for Single-Cell RNA-seq Analysis**

CellGRN-Former is a Transformer-based foundation model for single-cell RNA-seq data that integrates Gene Regulatory Network (GRN) priors into the attention mechanism, uses hierarchical contrastive learning during pre-training, and employs task-adaptive prompt tuning for efficient downstream adaptation.

## Key Features

- **GRN-Guided Sparse Attention (GGSA)**: Biologically-informed sparse attention using GRN adjacency structure
- **Hierarchical Cell-Type Contrastive Learning (HCCL)**: Multi-level contrastive pre-training with Cell Ontology hierarchy
- **Task-Adaptive Prompt Tuning (TAPT)**: Efficient fine-tuning with <1% additional parameters
- **Expression-Aware Continuous Tokenization (EACT)**: Preserves continuous expression values without discretization

## Setup

```bash
conda create -n cellgrn python=3.10 -y
conda activate cellgrn
pip install -r requirements.txt
```

## Quick Start

### 1. Download Data
```bash
python data/download.py --dataset cellxgene_census --output_dir data/raw --max_cells 1000000
python data/download.py --dataset grn --output_dir data/raw
```

### 2. Preprocess
```bash
python data/preprocess.py --input_dir data/raw --output_dir data/processed --grn_path data/raw/grn/dorothea_grn.npz
```

### 3. Pre-train
```bash
python main.py --config configs/default.yaml --mode train --output_dir outputs/pretrain
```

### 4. Fine-tune
```bash
python main.py --config configs/default.yaml --mode train_eval --checkpoint outputs/pretrain/best_model.pt --task annotation --output_dir outputs/finetune
```

### 5. Run Baselines
```bash
bash scripts/run_baselines.sh
```

### 6. Run Ablations
```bash
bash scripts/run_ablation.sh
```

## Project Structure

```
code/
├── configs/          # YAML configuration files
├── data/             # Data loading and preprocessing
├── models/           # Model architecture (GGSA, HCCL, TAPT, EACT)
├── baselines/        # Baseline method wrappers
├── training/         # Training loop, optimizer, callbacks
├── evaluation/       # Metrics, evaluation pipeline, visualization
├── scripts/          # Shell scripts for running experiments
├── ablation/         # Ablation study orchestrator
├── main.py           # Main entry point
└── requirements.txt  # Dependencies
```

## Hardware Requirements

- GPU: 1-2x NVIDIA A100 80GB
- RAM: 128GB+ recommended
- Storage: 500GB+ for datasets

## Citation

```bibtex
@inproceedings{cellgrnformer2026,
  title={CellGRN-Former: GRN-Guided Hierarchical Foundation Model for Single-Cell Transcriptomics},
  author={Anonymous},
  booktitle={NeurIPS},
  year={2026}
}
```
