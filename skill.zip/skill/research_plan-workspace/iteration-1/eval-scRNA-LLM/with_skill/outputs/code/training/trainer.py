"""Training loop for CellGRN-Former.

Supports mixed-precision training, gradient accumulation, distributed training,
checkpointing, and evaluation scheduling.
"""

import logging
import os
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.distributed as dist
import torch.nn as nn
from torch.cuda.amp import GradScaler, autocast
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler

from training.callbacks import (
    CheckpointCallback,
    EarlyStoppingCallback,
    MetricTracker,
    WandbLogger,
)
from training.optimizer import build_optimizer, build_scheduler

logger = logging.getLogger(__name__)


class Trainer:
    """Training loop with mixed-precision, gradient accumulation, and DDP.

    Args:
        model: CellGRNFormer model.
        train_loader: Training data loader.
        val_loader: Validation data loader.
        config: Full configuration dictionary.
        device: Target device.
        output_dir: Directory for checkpoints and logs.
        grn_mask: GRN attention mask tensor.
        gene_properties: Gene property features tensor.
    """

    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader],
        config: Dict[str, Any],
        device: torch.device,
        output_dir: str = "./outputs",
        grn_mask: Optional[torch.Tensor] = None,
        gene_properties: Optional[torch.Tensor] = None,
    ):
        self.config = config
        self.device = device
        self.output_dir = output_dir
        self.train_loader = train_loader
        self.val_loader = val_loader

        training_cfg = config.get("training", {})
        self.epochs = training_cfg.get("epochs", 10)
        self.grad_accum_steps = training_cfg.get("gradient_accumulation_steps", 4)
        self.max_grad_norm = training_cfg.get("max_grad_norm", 1.0)
        self.use_bf16 = training_cfg.get("bf16", True)
        self.use_fp16 = training_cfg.get("fp16", False)
        self.use_amp = self.use_bf16 or self.use_fp16

        eval_cfg = config.get("evaluation", {})
        self.eval_every = eval_cfg.get("eval_every", 1)

        log_cfg = config.get("logging", {})
        self.log_every = log_cfg.get("log_every", 100)

        self.model = model.to(device)

        hardware_cfg = config.get("hardware", {})
        num_gpus = hardware_cfg.get("num_gpus", 1)
        if num_gpus > 1 and dist.is_initialized():
            local_rank = dist.get_rank()
            self.model = DDP(self.model, device_ids=[local_rank])
            self.is_distributed = True
        else:
            self.is_distributed = False

        self.optimizer = build_optimizer(self.model, config)

        num_training_steps = (
            len(train_loader) // self.grad_accum_steps * self.epochs
        )
        self.scheduler = build_scheduler(self.optimizer, config, num_training_steps)

        amp_dtype = torch.bfloat16 if self.use_bf16 else torch.float16
        self.amp_dtype = amp_dtype
        self.scaler = GradScaler(enabled=self.use_fp16)

        self.grn_mask = grn_mask.to(device) if grn_mask is not None else None
        self.gene_properties = gene_properties.to(device) if gene_properties is not None else None

        self.checkpoint_cb = CheckpointCallback(
            output_dir=output_dir,
            save_every=log_cfg.get("save_every", 1),
            save_best=log_cfg.get("save_best", True),
        )

        self.wandb_logger = WandbLogger(
            project=log_cfg.get("wandb_project", "cellgrn-former"),
            run_name=log_cfg.get("wandb_run_name", None),
            config=config,
            entity=log_cfg.get("wandb_entity", None),
        )

        self.metric_tracker = MetricTracker(log_dir=os.path.join(output_dir, "logs"))

        self.global_step = 0
        self.best_metric = 0.0

        os.makedirs(output_dir, exist_ok=True)

    def train(self) -> Dict[str, float]:
        """Run the full training loop.

        Returns:
            Dictionary of final evaluation metrics.
        """
        logger.info(f"Starting training for {self.epochs} epochs")
        start_time = time.time()

        for epoch in range(self.epochs):
            if self.is_distributed and isinstance(self.train_loader.sampler, DistributedSampler):
                self.train_loader.sampler.set_epoch(epoch)

            train_metrics = self._train_epoch(epoch)

            eval_metrics = {}
            if self.val_loader is not None and (epoch + 1) % self.eval_every == 0:
                eval_metrics = self._evaluate(epoch)

            all_metrics = {**train_metrics, **eval_metrics}
            self.metric_tracker.update(all_metrics, epoch)
            self.wandb_logger.log(all_metrics, step=self.global_step)

            self.checkpoint_cb.save_checkpoint(
                model=self._unwrap_model(),
                optimizer=self.optimizer,
                scheduler=self.scheduler,
                epoch=epoch,
                metrics=all_metrics,
                config=self.config,
            )

            logger.info(
                f"Epoch {epoch + 1}/{self.epochs} | "
                f"Train Loss: {train_metrics.get('train/loss', 0):.4f} | "
                + " | ".join(f"{k}: {v:.4f}" for k, v in eval_metrics.items())
            )

        elapsed = time.time() - start_time
        logger.info(f"Training completed in {elapsed / 3600:.1f} hours")

        self.metric_tracker.save()
        self.wandb_logger.finish()

        return all_metrics

    def _train_epoch(self, epoch: int) -> Dict[str, float]:
        """Train for one epoch.

        Args:
            epoch: Current epoch number.

        Returns:
            Training metrics.
        """
        self.model.train()
        total_loss = 0.0
        total_mgep_loss = 0.0
        total_hccl_loss = 0.0
        num_batches = 0

        self.optimizer.zero_grad()

        for step, batch in enumerate(self.train_loader):
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}

            batch["grn_mask"] = self.grn_mask
            batch["gene_properties"] = self.gene_properties

            with autocast(dtype=self.amp_dtype, enabled=self.use_amp):
                outputs = self.model(**batch)
                loss = outputs.loss / self.grad_accum_steps

            if self.use_fp16:
                self.scaler.scale(loss).backward()
            else:
                loss.backward()

            if (step + 1) % self.grad_accum_steps == 0:
                if self.use_fp16:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                else:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.optimizer.step()

                self.scheduler.step()
                self.optimizer.zero_grad()
                self.global_step += 1

                if self.global_step % self.log_every == 0:
                    lr = self.scheduler.get_last_lr()[0]
                    self.wandb_logger.log({
                        "train/loss_step": outputs.loss.item(),
                        "train/lr": lr,
                        "train/epoch": epoch,
                    }, step=self.global_step)

            total_loss += outputs.loss.item()
            if outputs.mgep_loss is not None:
                total_mgep_loss += outputs.mgep_loss.item()
            if outputs.hccl_loss is not None:
                total_hccl_loss += outputs.hccl_loss.item()
            num_batches += 1

        metrics = {
            "train/loss": total_loss / max(num_batches, 1),
            "train/mgep_loss": total_mgep_loss / max(num_batches, 1),
            "train/hccl_loss": total_hccl_loss / max(num_batches, 1),
        }
        return metrics

    @torch.no_grad()
    def _evaluate(self, epoch: int) -> Dict[str, float]:
        """Evaluate on validation set.

        Args:
            epoch: Current epoch number.

        Returns:
            Evaluation metrics.
        """
        self.model.eval()
        total_loss = 0.0
        num_batches = 0

        for batch in self.val_loader:
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
            batch["grn_mask"] = self.grn_mask
            batch["gene_properties"] = self.gene_properties

            with autocast(dtype=self.amp_dtype, enabled=self.use_amp):
                outputs = self.model(**batch)

            if outputs.loss is not None:
                total_loss += outputs.loss.item()
            num_batches += 1

        metrics = {
            "eval/loss": total_loss / max(num_batches, 1),
        }
        return metrics

    def _unwrap_model(self) -> nn.Module:
        """Get the underlying model (unwrap DDP if needed)."""
        if isinstance(self.model, DDP):
            return self.model.module
        return self.model

    def load_checkpoint(self, checkpoint_path: str) -> int:
        """Load a training checkpoint.

        Args:
            checkpoint_path: Path to checkpoint file.

        Returns:
            The epoch number from the checkpoint.
        """
        logger.info(f"Loading checkpoint from {checkpoint_path}")
        checkpoint = torch.load(checkpoint_path, map_location=self.device)

        self._unwrap_model().load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

        if checkpoint.get("scheduler_state_dict") is not None:
            self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])

        epoch = checkpoint.get("epoch", 0)
        logger.info(f"Resumed from epoch {epoch + 1}")
        return epoch


class FineTuneTrainer(Trainer):
    """Fine-tuning trainer with TAPT and early stopping.

    Extends the base Trainer with task-specific fine-tuning logic.

    Args:
        task_name: Name of the downstream task.
        num_classes: Number of classes (for annotation task).
        Additional args: Same as Trainer.
    """

    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader],
        config: Dict[str, Any],
        device: torch.device,
        output_dir: str = "./outputs",
        grn_mask: Optional[torch.Tensor] = None,
        gene_properties: Optional[torch.Tensor] = None,
        task_name: str = "annotation",
        num_classes: int = 100,
    ):
        finetune_cfg = config.get("finetuning", {})
        config_copy = dict(config)
        config_copy["training"] = {
            **config.get("training", {}),
            "epochs": finetune_cfg.get("epochs", 50),
            "learning_rate": finetune_cfg.get("learning_rate", 5e-4),
            "batch_size": finetune_cfg.get("batch_size", 64),
        }

        super().__init__(
            model=model,
            train_loader=train_loader,
            val_loader=val_loader,
            config=config_copy,
            device=device,
            output_dir=output_dir,
            grn_mask=grn_mask,
            gene_properties=gene_properties,
        )

        self.task_name = task_name
        self.num_classes = num_classes

        if finetune_cfg.get("freeze_backbone", True):
            self._unwrap_model().freeze_backbone()

        if task_name == "annotation":
            self._unwrap_model().update_annotation_head(num_classes)

        self.optimizer = build_optimizer(self._unwrap_model(), config_copy)

        patience = finetune_cfg.get("patience", 10)
        self.early_stopping = EarlyStoppingCallback(
            patience=patience,
            metric_name="eval/loss",
            mode="min",
        )

    def _train_epoch(self, epoch: int) -> Dict[str, float]:
        """Train one fine-tuning epoch with task prompts."""
        self.model.train()
        total_loss = 0.0
        num_batches = 0

        self.optimizer.zero_grad()

        for step, batch in enumerate(self.train_loader):
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
            batch["grn_mask"] = self.grn_mask
            batch["gene_properties"] = self.gene_properties
            batch["task_name"] = self.task_name

            with autocast(dtype=self.amp_dtype, enabled=self.use_amp):
                outputs = self.model(**batch)
                loss = outputs.loss / self.grad_accum_steps

            loss.backward()

            if (step + 1) % self.grad_accum_steps == 0:
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                self.optimizer.step()
                self.scheduler.step()
                self.optimizer.zero_grad()
                self.global_step += 1

            total_loss += outputs.loss.item()
            num_batches += 1

        return {"train/loss": total_loss / max(num_batches, 1)}

    def train(self) -> Dict[str, float]:
        """Run fine-tuning with early stopping."""
        logger.info(f"Starting fine-tuning for task: {self.task_name}")
        all_metrics = {}

        for epoch in range(self.epochs):
            train_metrics = self._train_epoch(epoch)

            eval_metrics = {}
            if self.val_loader is not None:
                eval_metrics = self._evaluate(epoch)

            all_metrics = {**train_metrics, **eval_metrics}
            self.metric_tracker.update(all_metrics, epoch)
            self.wandb_logger.log(all_metrics, step=self.global_step)

            self.checkpoint_cb.save_checkpoint(
                model=self._unwrap_model(),
                optimizer=self.optimizer,
                scheduler=self.scheduler,
                epoch=epoch,
                metrics=all_metrics,
                config=self.config,
            )

            logger.info(
                f"FT Epoch {epoch + 1}/{self.epochs} | "
                + " | ".join(f"{k}: {v:.4f}" for k, v in all_metrics.items())
            )

            if self.early_stopping.should_stop(all_metrics):
                logger.info(f"Early stopping triggered at epoch {epoch + 1}")
                break

        self.metric_tracker.save()
        self.wandb_logger.finish()
        return all_metrics
