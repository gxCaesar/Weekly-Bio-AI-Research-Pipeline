"""Main entry point for CellGRN-Former.

Supports pre-training, fine-tuning, and evaluation modes.
"""

import argparse
import json
import logging
import os
import random
import sys
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader, random_split

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("CellGRNFormer")


def set_seed(seed: int) -> None:
    """Set random seed for reproducibility.

    Args:
        seed: Random seed value.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_config(path: str) -> Dict[str, Any]:
    """Load YAML configuration file.

    Args:
        path: Path to YAML config file.

    Returns:
        Configuration dictionary.
    """
    with open(path) as f:
        config = yaml.safe_load(f)

    default_path = os.path.join(os.path.dirname(path), "default.yaml")
    if os.path.exists(default_path) and path != default_path:
        with open(default_path) as f:
            default_config = yaml.safe_load(f)

        merged = _deep_merge(default_config, config)
        return merged

    return config


def _deep_merge(base: Dict, override: Dict) -> Dict:
    """Deep merge two dictionaries, with override taking precedence.

    Args:
        base: Base dictionary.
        override: Override dictionary.

    Returns:
        Merged dictionary.
    """
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def setup_distributed() -> Optional[int]:
    """Set up distributed training if applicable.

    Returns:
        Local rank if distributed, None otherwise.
    """
    if "LOCAL_RANK" in os.environ:
        local_rank = int(os.environ["LOCAL_RANK"])
        torch.distributed.init_process_group(backend="nccl")
        torch.cuda.set_device(local_rank)
        return local_rank
    return None


def build_dataloaders(
    config: Dict[str, Any],
    mode: str = "train_eval",
) -> Dict[str, DataLoader]:
    """Build data loaders for training and evaluation.

    Args:
        config: Configuration dictionary.
        mode: Operating mode (train, eval, train_eval).

    Returns:
        Dictionary of DataLoaders keyed by split name.
    """
    import anndata as ad
    from data.dataset import SingleCellDataset
    from data.collator import PretrainingCollator, SingleCellCollator
    from data.preprocess import preprocess_adata, compute_gene_properties

    data_cfg = config.get("data", {})
    training_cfg = config.get("training", {})
    data_dir = data_cfg.get("data_dir", "./data/processed")

    h5ad_files = list(Path(data_dir).glob("*.h5ad"))
    if not h5ad_files:
        logger.error(f"No h5ad files found in {data_dir}")
        logger.info("Run data/download.py and data/preprocess.py first")
        sys.exit(1)

    adata = ad.read_h5ad(h5ad_files[0])
    logger.info(f"Loaded: {adata.n_obs} cells x {adata.n_vars} genes from {h5ad_files[0].name}")

    if "highly_variable" in adata.var.columns:
        hvg_genes = adata.var_names[adata.var["highly_variable"]].tolist()
    else:
        hvg_genes = adata.var_names[:data_cfg.get("num_hvg", 4000)].tolist()

    gene_props_path = list(Path(data_dir).glob("*_gene_properties.csv"))
    gene_properties = None
    if gene_props_path:
        import pandas as pd
        gene_properties = pd.read_csv(gene_props_path[0], index_col=0)

    pretrain_cfg = config.get("pretraining", {})
    mask_ratio = pretrain_cfg.get("mask_ratio", 0.15)

    dataset = SingleCellDataset(
        adata=adata,
        gene_names=hvg_genes,
        gene_properties=gene_properties,
        mask_ratio=mask_ratio if mode in ("train", "train_eval") else 0.0,
        max_genes=data_cfg.get("num_hvg", 4000),
    )

    dataloaders = {}
    batch_size = training_cfg.get("batch_size", 32)

    if mode in ("train", "train_eval"):
        n_total = len(dataset)
        n_val = int(n_total * 0.1)
        n_train = n_total - n_val
        train_dataset, val_dataset = random_split(
            dataset,
            [n_train, n_val],
            generator=torch.Generator().manual_seed(training_cfg.get("seed", 42)),
        )

        collator = PretrainingCollator(mask_ratio=mask_ratio)

        dataloaders["train"] = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=data_cfg.get("num_workers", 4),
            pin_memory=data_cfg.get("pin_memory", True),
            collate_fn=collator,
            drop_last=True,
        )
        dataloaders["val"] = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=data_cfg.get("num_workers", 4),
            pin_memory=data_cfg.get("pin_memory", True),
            collate_fn=collator,
        )

    if mode in ("eval", "train_eval"):
        eval_collator = SingleCellCollator()
        eval_dataset = SingleCellDataset(
            adata=adata,
            gene_names=hvg_genes,
            gene_properties=gene_properties,
            mask_ratio=0.0,
        )
        dataloaders["test"] = DataLoader(
            eval_dataset,
            batch_size=batch_size * 2,
            shuffle=False,
            num_workers=data_cfg.get("num_workers", 4),
            collate_fn=eval_collator,
        )

    return dataloaders


def main() -> None:
    """Main training/evaluation pipeline."""
    parser = argparse.ArgumentParser(description="CellGRN-Former: scRNA-seq Foundation Model")
    parser.add_argument("--config", type=str, required=True, help="Path to config YAML")
    parser.add_argument(
        "--mode",
        choices=["train", "eval", "train_eval"],
        default="train_eval",
        help="Operation mode",
    )
    parser.add_argument("--checkpoint", type=str, default=None, help="Checkpoint to resume/evaluate")
    parser.add_argument("--output_dir", type=str, default="./outputs", help="Output directory")
    parser.add_argument("--task", type=str, default=None, help="Fine-tuning task name")
    args = parser.parse_args()

    config = load_config(args.config)

    training_cfg = config.get("training", {})
    seed = training_cfg.get("seed", 42)
    set_seed(seed)

    local_rank = setup_distributed()
    if local_rank is not None:
        device = torch.device(f"cuda:{local_rank}")
    elif torch.cuda.is_available():
        device = torch.device("cuda:0")
    else:
        device = torch.device("cpu")
    logger.info(f"Using device: {device}")

    os.makedirs(args.output_dir, exist_ok=True)

    config_save_path = os.path.join(args.output_dir, "config.yaml")
    with open(config_save_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False)

    from models.model import CellGRNFormer

    model = CellGRNFormer(config)
    logger.info(f"Model created: {sum(p.numel() for p in model.parameters()) / 1e6:.1f}M parameters")

    dataloaders = build_dataloaders(config, mode=args.mode)

    grn_mask = None
    grn_mask_path = os.path.join(config["data"]["data_dir"], "grn_attention_mask.npy")
    if os.path.exists(grn_mask_path):
        grn_mask = torch.from_numpy(np.load(grn_mask_path))
        logger.info(f"Loaded GRN mask: {grn_mask.shape}")

    gene_properties = None
    data_dir = config["data"]["data_dir"]
    gene_props_files = list(Path(data_dir).glob("*_gene_properties.csv"))
    if gene_props_files:
        import pandas as pd
        props_df = pd.read_csv(gene_props_files[0], index_col=0)
        gene_properties = torch.from_numpy(props_df.values.astype(np.float32))
        logger.info(f"Loaded gene properties: {gene_properties.shape}")

    if args.checkpoint:
        logger.info(f"Loading checkpoint: {args.checkpoint}")
        checkpoint = torch.load(args.checkpoint, map_location=device)
        model.load_state_dict(checkpoint["model_state_dict"], strict=False)

    if args.mode in ("train", "train_eval"):
        if args.task:
            from training.trainer import FineTuneTrainer

            trainer = FineTuneTrainer(
                model=model,
                train_loader=dataloaders["train"],
                val_loader=dataloaders.get("val"),
                config=config,
                device=device,
                output_dir=args.output_dir,
                grn_mask=grn_mask,
                gene_properties=gene_properties,
                task_name=args.task,
            )
        else:
            from training.trainer import Trainer

            trainer = Trainer(
                model=model,
                train_loader=dataloaders["train"],
                val_loader=dataloaders.get("val"),
                config=config,
                device=device,
                output_dir=args.output_dir,
                grn_mask=grn_mask,
                gene_properties=gene_properties,
            )

        metrics = trainer.train()
        logger.info(f"Training complete. Final metrics: {metrics}")

    if args.mode in ("eval", "train_eval"):
        from evaluation.evaluate import Evaluator

        evaluator = Evaluator(
            model=model,
            device=device,
            config=config,
            grn_mask=grn_mask,
            gene_properties=gene_properties,
        )

        eval_dataloaders = {}
        if "test" in dataloaders:
            eval_dataloaders["annotation"] = dataloaders["test"]
            eval_dataloaders["clustering"] = dataloaders["test"]

        results = evaluator.evaluate_all(
            dataloaders=eval_dataloaders,
            output_dir=args.output_dir,
        )

        logger.info("\n" + "=" * 60)
        logger.info("EVALUATION RESULTS")
        logger.info("=" * 60)
        for task, task_results in results.items():
            logger.info(f"\n{task}:")
            for metric, value in task_results.items():
                logger.info(f"  {metric}: {value:.4f}")

    logger.info("Done.")


if __name__ == "__main__":
    main()
