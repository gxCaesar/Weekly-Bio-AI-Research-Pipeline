"""scVI baseline wrapper for evaluation.

Uses the scvi-tools package for data integration evaluation.
Reference: Lopez et al., Nature Methods 2018.
GitHub: https://github.com/scverse/scvi-tools
"""

import logging
import os
from typing import Any, Dict, List, Optional

import anndata as ad
import numpy as np

logger = logging.getLogger(__name__)


class ScVIBaseline:
    """Wrapper for running scVI as a baseline.

    Uses the scvi-tools package for training and evaluation
    on data integration tasks.

    Args:
        config: Baseline configuration.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.model = None

    def train(
        self,
        adata: ad.AnnData,
        batch_key: str = "batch",
        n_latent: int = 30,
        n_layers: int = 2,
        n_hidden: int = 256,
        dropout_rate: float = 0.1,
        gene_likelihood: str = "zinb",
        epochs: int = 400,
        batch_size: int = 128,
        learning_rate: float = 1e-3,
    ) -> Dict[str, float]:
        """Train scVI model for data integration.

        Args:
            adata: AnnData with batch labels.
            batch_key: Column name for batch information.
            n_latent: Latent space dimension.
            n_layers: Number of neural network layers.
            n_hidden: Hidden layer size.
            dropout_rate: Dropout rate.
            gene_likelihood: Likelihood model (zinb, nb, poisson).
            epochs: Training epochs.
            batch_size: Batch size.
            learning_rate: Learning rate.

        Returns:
            Training metrics.
        """
        import scvi

        logger.info(f"Training scVI: n_latent={n_latent}, epochs={epochs}")

        scvi.model.SCVI.setup_anndata(adata, batch_key=batch_key)

        self.model = scvi.model.SCVI(
            adata,
            n_latent=n_latent,
            n_layers=n_layers,
            n_hidden=n_hidden,
            dropout_rate=dropout_rate,
            gene_likelihood=gene_likelihood,
        )

        self.model.train(
            max_epochs=epochs,
            batch_size=batch_size,
            plan_kwargs={"lr": learning_rate},
            early_stopping=True,
            early_stopping_patience=30,
        )

        train_loss = self.model.history["elbo_train"].iloc[-1].item()
        val_loss = self.model.history["elbo_validation"].iloc[-1].item()

        logger.info(f"scVI training complete: train_loss={train_loss:.4f}, val_loss={val_loss:.4f}")
        return {"train_loss": train_loss, "val_loss": val_loss}

    def extract_embeddings(self, adata: ad.AnnData) -> np.ndarray:
        """Extract latent embeddings from trained scVI model.

        Args:
            adata: AnnData object (same as training or new).

        Returns:
            Latent embeddings (n_cells, n_latent).
        """
        if self.model is None:
            raise ValueError("Model not trained. Call train() first.")

        embeddings = self.model.get_latent_representation(adata)
        logger.info(f"Extracted scVI embeddings: {embeddings.shape}")
        return embeddings

    def get_normalized_expression(self, adata: ad.AnnData) -> np.ndarray:
        """Get denoised/normalized expression from scVI.

        Args:
            adata: AnnData object.

        Returns:
            Denoised expression matrix (n_cells, n_genes).
        """
        if self.model is None:
            raise ValueError("Model not trained. Call train() first.")

        denoised = self.model.get_normalized_expression(adata, return_numpy=True)
        return denoised

    def save_model(self, save_dir: str) -> None:
        """Save trained scVI model.

        Args:
            save_dir: Directory to save model.
        """
        if self.model is None:
            raise ValueError("No model to save.")
        self.model.save(save_dir)
        logger.info(f"scVI model saved to {save_dir}")

    def load_model(self, save_dir: str, adata: ad.AnnData) -> None:
        """Load a previously trained scVI model.

        Args:
            save_dir: Directory containing saved model.
            adata: AnnData used for model setup.
        """
        import scvi

        self.model = scvi.model.SCVI.load(save_dir, adata=adata)
        logger.info(f"scVI model loaded from {save_dir}")
