"""Visualization utilities for CellGRN-Former evaluation results.

Generates publication-quality figures for UMAP embeddings, metric comparisons,
confusion matrices, and attention weight analysis.
"""

import logging
import os
from typing import Any, Dict, List, Optional, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap

logger = logging.getLogger(__name__)

FIGURE_DPI = 300
FONT_SIZE = 12
TICK_SIZE = 10


def setup_plot_style() -> None:
    """Configure matplotlib for publication-quality figures."""
    plt.rcParams.update({
        "font.size": FONT_SIZE,
        "axes.labelsize": FONT_SIZE,
        "axes.titlesize": FONT_SIZE + 2,
        "xtick.labelsize": TICK_SIZE,
        "ytick.labelsize": TICK_SIZE,
        "legend.fontsize": TICK_SIZE,
        "figure.dpi": FIGURE_DPI,
        "savefig.dpi": FIGURE_DPI,
        "savefig.bbox": "tight",
        "font.family": "sans-serif",
    })


def plot_umap(
    embeddings: np.ndarray,
    labels: np.ndarray,
    label_names: Optional[Dict[int, str]] = None,
    title: str = "UMAP Visualization",
    output_path: str = "umap.png",
    figsize: Tuple[int, int] = (10, 8),
    point_size: float = 1.0,
    alpha: float = 0.6,
) -> str:
    """Generate UMAP plot of cell embeddings.

    Args:
        embeddings: Cell embeddings (n_cells, dim).
        labels: Cell type labels (n_cells,).
        label_names: Optional mapping from label ID to name.
        title: Plot title.
        output_path: Path to save figure.
        figsize: Figure dimensions.
        point_size: Scatter point size.
        alpha: Point transparency.

    Returns:
        Path to saved figure.
    """
    import umap

    setup_plot_style()

    reducer = umap.UMAP(n_components=2, random_state=42, n_neighbors=30, min_dist=0.3)
    embedding_2d = reducer.fit_transform(embeddings)

    fig, ax = plt.subplots(figsize=figsize)

    unique_labels = np.unique(labels)
    n_colors = len(unique_labels)
    cmap = plt.cm.get_cmap("tab20", n_colors) if n_colors <= 20 else plt.cm.get_cmap("gist_ncar", n_colors)

    for i, label in enumerate(unique_labels):
        mask = labels == label
        name = label_names[label] if label_names and label in label_names else str(label)
        ax.scatter(
            embedding_2d[mask, 0],
            embedding_2d[mask, 1],
            s=point_size,
            alpha=alpha,
            c=[cmap(i)],
            label=name,
            rasterized=True,
        )

    ax.set_title(title)
    ax.set_xlabel("UMAP 1")
    ax.set_ylabel("UMAP 2")

    if n_colors <= 20:
        ax.legend(
            loc="center left",
            bbox_to_anchor=(1.0, 0.5),
            markerscale=5,
            frameon=False,
        )

    ax.set_xticks([])
    ax.set_yticks([])

    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    fig.savefig(output_path, dpi=FIGURE_DPI, bbox_inches="tight")
    plt.close(fig)

    logger.info(f"UMAP plot saved to {output_path}")
    return output_path


def plot_metrics_comparison(
    results: Dict[str, Dict[str, float]],
    metric_name: str,
    title: str = "Method Comparison",
    output_path: str = "comparison.png",
    figsize: Tuple[int, int] = (10, 6),
) -> str:
    """Bar chart comparing methods on a specific metric.

    Args:
        results: Dict of {method_name: {metric: value}}.
        metric_name: Which metric to plot.
        title: Plot title.
        output_path: Save path.
        figsize: Figure size.

    Returns:
        Path to saved figure.
    """
    setup_plot_style()

    methods = list(results.keys())
    values = [results[m].get(metric_name, 0) for m in methods]

    fig, ax = plt.subplots(figsize=figsize)

    colors = ["#3b82f6"] * len(methods)
    if "CellGRNFormer" in methods or "Ours" in methods:
        our_idx = methods.index("CellGRNFormer") if "CellGRNFormer" in methods else methods.index("Ours")
        colors[our_idx] = "#ef4444"

    bars = ax.bar(methods, values, color=colors, edgecolor="white", linewidth=0.5)

    for bar, val in zip(bars, values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.005,
            f"{val:.3f}",
            ha="center",
            va="bottom",
            fontsize=TICK_SIZE,
        )

    ax.set_ylabel(metric_name)
    ax.set_title(title)
    ax.set_xticklabels(methods, rotation=30, ha="right")

    y_min = min(values) * 0.9 if min(values) > 0 else 0
    ax.set_ylim(y_min, max(values) * 1.08)

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    fig.savefig(output_path, dpi=FIGURE_DPI, bbox_inches="tight")
    plt.close(fig)

    logger.info(f"Comparison plot saved to {output_path}")
    return output_path


def plot_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Optional[List[str]] = None,
    title: str = "Confusion Matrix",
    output_path: str = "confusion_matrix.png",
    figsize: Tuple[int, int] = (12, 10),
    normalize: bool = True,
) -> str:
    """Plot confusion matrix heatmap.

    Args:
        y_true: True labels.
        y_pred: Predicted labels.
        class_names: Names for each class.
        title: Plot title.
        output_path: Save path.
        figsize: Figure size.
        normalize: Whether to normalize by row (true class).

    Returns:
        Path to saved figure.
    """
    from sklearn.metrics import confusion_matrix as sk_confusion_matrix

    setup_plot_style()

    cm = sk_confusion_matrix(y_true, y_pred)
    if normalize:
        cm = cm.astype(np.float64) / cm.sum(axis=1, keepdims=True)
        cm = np.nan_to_num(cm)

    fig, ax = plt.subplots(figsize=figsize)

    fmt = ".2f" if normalize else "d"
    sns.heatmap(
        cm,
        annot=True if cm.shape[0] <= 15 else False,
        fmt=fmt,
        cmap="Blues",
        xticklabels=class_names if class_names else "auto",
        yticklabels=class_names if class_names else "auto",
        ax=ax,
    )

    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(title)

    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    fig.savefig(output_path, dpi=FIGURE_DPI, bbox_inches="tight")
    plt.close(fig)

    logger.info(f"Confusion matrix saved to {output_path}")
    return output_path


def plot_ablation_heatmap(
    ablation_results: Dict[str, Dict[str, float]],
    metrics: List[str],
    title: str = "Ablation Study",
    output_path: str = "ablation.png",
    figsize: Tuple[int, int] = (10, 6),
) -> str:
    """Plot ablation study results as heatmap.

    Args:
        ablation_results: {config_name: {metric: value}}.
        metrics: List of metric names to show.
        title: Plot title.
        output_path: Save path.
        figsize: Figure size.

    Returns:
        Path to saved figure.
    """
    setup_plot_style()

    configs = list(ablation_results.keys())
    data = np.zeros((len(metrics), len(configs)))

    for j, config in enumerate(configs):
        for i, metric in enumerate(metrics):
            data[i, j] = ablation_results[config].get(metric, 0)

    fig, ax = plt.subplots(figsize=figsize)

    sns.heatmap(
        data,
        annot=True,
        fmt=".3f",
        cmap="YlOrRd",
        xticklabels=configs,
        yticklabels=metrics,
        ax=ax,
    )

    ax.set_title(title)
    ax.set_xticklabels(configs, rotation=45, ha="right")

    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    fig.savefig(output_path, dpi=FIGURE_DPI, bbox_inches="tight")
    plt.close(fig)

    logger.info(f"Ablation heatmap saved to {output_path}")
    return output_path
