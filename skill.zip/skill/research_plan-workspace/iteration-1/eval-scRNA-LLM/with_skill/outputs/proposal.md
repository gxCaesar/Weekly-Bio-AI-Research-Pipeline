# CellGRN-Former 研究方案

## 1. 研究问题与动机

### 1.1 问题定义

单细胞RNA-seq基础模型在多个下游任务上展现了巨大潜力，但现有方法存在三个核心技术瓶颈：(1) 标准Transformer注意力机制在处理~20,000个基因时计算成本过高，且缺乏生物学先验引导；(2) 预训练目标仅关注基因表达重建，忽略了细胞类型的层次化结构信息；(3) 下游任务适配缺乏统一且高效的机制。本研究旨在设计一个融合基因调控网络先验的层次化单细胞基础模型 CellGRN-Former，同时解决上述三个问题。

### 1.2 研究动机

当前最先进的scRNA-seq基础模型（如scGPT, Geneformer, scFoundation）虽然在多个benchmark上取得了优异成绩，但仍然面临以下关键局限：

**注意力效率与生物学意义的矛盾**: scGPT和Geneformer使用标准的全连接注意力或简化的注意力机制。标准注意力的O(n^2)复杂度在n≈20,000基因时极其昂贵，而简单截断基因数量（如只保留Top 2000 HVG）会丢失重要的生物学信号。已有研究表明，基因间的相互作用遵循稀疏的网络结构（基因调控网络中每个基因平均只调控/被调控数十个靶基因），这一先验信息尚未被有效利用。

**预训练信号不足**: 现有方法的预训练目标（masked expression prediction或autoregressive generation）仅利用了基因表达层面的信号，忽略了丰富的细胞类型层次结构信息。Cell Ontology定义了数千种细胞类型及其层次关系，这些信息可以在预训练中引导模型学习更具生物学意义的表征。

**下游适配效率低**: 大多数模型需要全参数微调来适配下游任务，在标注数据有限的场景（如罕见细胞类型标注、新组织类型分析）中表现不佳。

### 1.3 目标

1. 设计一个计算高效且生物学可解释的注意力机制，将计算复杂度从O(n^2)降低到O(n·k)（k<<n），同时保持或提升模型性能
2. 提出层次化预训练策略，在预训练中同时学习基因表达模式和细胞类型层次结构
3. 开发高效的任务适配机制，使用不到1%的额外参数实现多任务适配
4. 在至少6个标准benchmark任务上达到或超过现有SOTA方法

---

## 2. 创新点

### 创新点1: GRN-Guided Sparse Attention (GGSA)

- **描述**: 利用已知的基因调控网络（Gene Regulatory Network, GRN）定义Transformer注意力层的稀疏连接模式。每个基因token的注意力范围被限制为其GRN邻居（上游调控因子 + 下游靶基因）加上少量可学习的global attention slots。具体实现中，从SCENIC/Dorothea等数据库提取GRN邻接矩阵，将其作为注意力的mask模板。同时引入少量（如5%）的random attention connections，使模型能够发现GRN数据库中未收录的新调控关系。

- **解决的问题**: 解决了标准注意力在大基因集上的计算瓶颈（O(n^2)→O(n·k)），同时使注意力权重具有可解释的生物学意义——高权重的注意力连接对应真实的基因调控关系。

- **与现有工作的区别**: scBERT使用Performer近似注意力降低复杂度但没有利用生物学先验; TOSICA使用pathway信息但仅限于encoder输入层而非注意力机制本身; GeneCompass融合了先验知识但没有在注意力稀疏模式上进行显式约束。本工作首次将GRN结构直接嵌入注意力的稀疏模式中。

- **技术依据**: Flash Attention和Block Sparse Attention的成功表明，适当设计的稀疏注意力可以同时降低计算成本和提升模型质量（Dao et al., 2022; Zaheer et al., 2020）。生物学上，基因调控网络的稀疏性（平均度数约30-50）为稀疏注意力提供了天然的生物学依据。

### 创新点2: Hierarchical Cell-Type Contrastive Learning (HCCL)

- **描述**: 在预训练阶段引入基于Cell Ontology层次结构的多粒度对比学习目标。具体地，利用Cell Ontology的树状结构定义不同层级的正样本对：同一细胞亚型为强正样本，同一大类下的不同亚型为弱正样本。对比学习的损失函数设计为多层级的加权组合：L_hier = Σ_l α_l · L_contrastive(level=l)，其中l索引层次级别，α_l为该层级的权重。这使得模型在预训练中自动学习到反映生物学分类体系的层次化细胞表征。

- **解决的问题**: 现有预训练方法仅通过表达值重建学习基因层面的表征，忽略了细胞层面的组织结构。HCCL在预训练阶段就注入了细胞类型的层次知识，使学到的表征在细胞类型标注、聚类等任务上更具判别力。

- **与现有工作的区别**: UCE和SCimilarity使用对比学习但没有利用层次结构; scGPT和scFoundation不使用对比学习; SATURN虽然学习细胞表征但目标是跨物种对齐。本工作首次在scRNA-seq基础模型预训练中引入基于Cell Ontology的层次化对比学习。

- **技术依据**: 层次化对比学习在计算机视觉领域已有成功应用（如Hierarchical Contrastive Learning, CVPR 2022），表明利用标签层次结构可以显著提升表征质量。Cell Ontology提供了成熟的细胞类型层次体系，是天然适合的层次知识来源。

### 创新点3: Task-Adaptive Prompt Tuning (TAPT)

- **描述**: 设计针对scRNA-seq不同下游任务的prompt tuning策略。为每种任务类型（细胞类型标注、基因扰动预测、数据整合、轨迹推断）设计专门的task prompt tokens，这些prompt作为额外的token前缀插入模型输入。每个task prompt包含：(1) task type embedding标识任务类型；(2) 可学习的soft prompt tokens（每个任务8-16个token）；(3) 任务特定的output projection head。微调时冻结预训练模型参数，仅训练prompt tokens和projection head（约0.5-1%的额外参数）。

- **解决的问题**: 解决了全参数微调的高计算成本和少样本场景下的过拟合问题。TAPT使得模型可以在少量标注数据（如每类50-100个细胞）上高效适配，同时避免灾难性遗忘。

- **与现有工作的区别**: 现有scRNA-seq基础模型通常使用全参数微调或简单的linear probing，缺乏针对不同任务特性的适配设计。本工作引入task-specific prompt设计，可以在极少额外参数下实现多任务高效适配。

- **技术依据**: Prompt Tuning（Lester et al., 2021）和Visual Prompt Tuning（Jia et al., 2022）已在NLP和CV领域证明了其在少样本学习和多任务适配上的有效性。

### 创新点4: Expression-Aware Continuous Tokenization (EACT)

- **描述**: 设计一种保留连续表达值信息的tokenization方案。不同于scGPT的binning或Geneformer的rank-based编码，我们使用可学习的非线性投影将每个基因的连续表达值映射到embedding空间，同时利用基因的固有属性（如基因长度、GC含量、平均表达水平）作为辅助特征。具体地，每个基因token的embedding = GeneIDEmb(g) + ExprValueProj(x_g) + GenePropertyEmb(p_g)，其中ExprValueProj是一个小型MLP将标量表达值映射到d维空间。

- **解决的问题**: 解决了现有方法将连续表达值离散化导致的信息损失问题。特别是在基因扰动预测等需要精确表达值的任务中，连续tokenization可以保留更多信息。

- **与现有工作的区别**: scGPT将表达值离散化为bin tokens; Geneformer完全丢弃表达量信息只保留rank; scFoundation使用简单的linear projection。本工作通过非线性投影和辅助基因属性信息，实现了更丰富的连续表达值编码。

---

## 3. 方法概述

### 3.1 整体框架

CellGRN-Former采用两阶段训练策略：

**预训练阶段**: 在大规模scRNA-seq数据（CellXGene Census, ~33M细胞）上进行自监督预训练，使用两个预训练目标的组合：(1) Masked Gene Expression Prediction (MGEP): 随机mask 15%的基因表达值，预测被mask的值；(2) Hierarchical Cell-Type Contrastive Learning (HCCL): 利用Cell Ontology层次结构进行多粒度对比学习。

**微调阶段**: 冻结预训练权重，仅通过Task-Adaptive Prompt Tuning (TAPT)适配下游任务。针对每种任务类型设计专用的prompt tokens和output head。

### 3.2 模型架构

#### ASCII架构图

```
                          CellGRN-Former Architecture
                          ===========================

[Gene Expression Vector]    [GRN Adjacency Matrix]    [Cell Ontology Tree]
        x ∈ R^G                  A ∈ {0,1}^{G×G}           T (tree)
          |                          |                        |
          v                          v                        |
+-------------------+    +---------------------+              |
| Expression-Aware  |    | GRN Sparsity Mask   |              |
| Continuous Token-  |    | Generator           |              |
| ization (EACT)    |    |                     |              |
+-------------------+    +---------------------+              |
          |                          |                        |
          v                          v                        |
    H_0 ∈ R^{G×d}        M ∈ {0,1}^{G×G}                    |
          |                          |                        |
          +----------+  +-----------+                        |
                     |  |                                     |
                     v  v                                     |
            +------------------+                              |
            | GRN-Guided       |                              |
            | Sparse Attention | ×L layers                    |
            | (GGSA)           |                              |
            +------------------+                              |
                     |                                        |
                     v                                        v
              H_L ∈ R^{G×d}                    +-------------------+
                     |                          | Hierarchical Cell |
                     +------ Cell Repr -------->| Contrastive Loss  |
                     |       (pooling)          | (HCCL)            |
                     |                          +-------------------+
                     v
            +------------------+
            | Task-Adaptive    |   <-- [Task Prompt Tokens]
            | Prompt Tuning    |       τ ∈ R^{K×d}
            | (TAPT)           |
            +------------------+
                     |
          +----------+----------+----------+
          |          |          |          |
          v          v          v          v
    [Cell Type] [Perturbation] [Batch]  [Trajectory]
    [Annotation] [Prediction] [Integration] [Inference]
```

#### 架构详细说明

**输入层 (EACT)**:
- 输入: 细胞的基因表达向量 x ∈ R^G (G ≈ 20,000)
- 基因ID嵌入: E_gene ∈ R^{G×d}，可学习的基因身份嵌入
- 表达值投影: f_expr: R → R^d，两层MLP将标量表达值映射到d维空间
- 基因属性嵌入: E_prop ∈ R^{G×d_p}，编码基因长度、GC含量等固有属性
- 输出: H_0 = E_gene + f_expr(x) + W_prop · E_prop，H_0 ∈ R^{G×d}

**GRN-Guided Sparse Attention (GGSA)**:
- 从GRN数据库提取邻接矩阵 A ∈ {0,1}^{G×G}
- 定义注意力mask M = A + A^T + I + M_random，其中M_random为随机稀疏mask（密度5%）
- 在每个attention head中: Attention(Q,K,V) = softmax(QK^T/√d · M + (1-M)·(-∞)) · V
- 使用Flash Attention的block sparse实现加速计算
- 共L=12层，每层h=12个头，其中2个头使用global attention，10个头使用GGSA

**层次化对比学习 (HCCL)**:
- 细胞表征: c = MeanPool(H_L) 或 [CLS] token
- 利用Cell Ontology定义层次正样本: Level 1 (大类), Level 2 (亚类), Level 3 (细分亚型)
- 多层级对比损失: L_HCCL = Σ_{l=1}^{3} α_l · SupCon(c, y_l)
- 权重: α_1=0.2, α_2=0.3, α_3=0.5（细粒度层级权重更高）

**任务适配 (TAPT)**:
- 每个任务类型定义K=16个可学习prompt tokens
- 微调时输入序列: [TASK_PROMPT_1, ..., TASK_PROMPT_K, gene_1, ..., gene_G]
- 仅训练prompt tokens + task-specific output head（约5M参数，< 1% of total）

### 3.3 训练策略

**预训练**:
- 数据: CellXGene Census, ~33M细胞
- 目标: L_pretrain = L_MGEP + λ · L_HCCL (λ=0.3)
- 优化器: AdamW (lr=1e-4, weight_decay=0.01)
- 调度: Linear warmup (5%) + cosine decay
- Batch size: 256 (per GPU) × 4 gradient accumulation × 2 GPUs = 2048 effective
- Mixed precision: BF16
- 总epochs: 10 (on full dataset)

**微调**:
- 冻结预训练参数，仅训练TAPT模块
- 优化器: AdamW (lr=5e-4, weight_decay=0.01)
- Batch size: 64
- Epochs: 50 (with early stopping, patience=10)

### 3.4 关键技术细节

**GGSA伪代码**:
```
Algorithm: GRN-Guided Sparse Attention
Input: H ∈ R^{G×d}, GRN adjacency A ∈ {0,1}^{G×G}
Output: H' ∈ R^{G×d}

1. Q, K, V = H·W_Q, H·W_K, H·W_V  // 线性投影
2. M_sparse = A + A^T + I           // 对称化 + 自连接
3. M_random = BernoulliSample(G, G, p=0.05)  // 随机连接
4. M = M_sparse | M_random          // 合并mask
5. For head i in [1..h]:
6.   if i <= 2:  // Global attention heads
7.     attn_i = softmax(Q_i K_i^T / sqrt(d_k))
8.   else:       // Sparse attention heads
9.     attn_i = softmax(Q_i K_i^T / sqrt(d_k) · M + (1-M)·(-inf))
10.  O_i = attn_i · V_i
11. H' = Concat(O_1,...,O_h) · W_O + H  // 残差连接
```

**HCCL损失函数**:
```
L_HCCL = Σ_{l=1}^{L} α_l · (-1/|P_l(i)|) Σ_{p∈P_l(i)} log(
    exp(sim(z_i, z_p)/τ_l) / Σ_{a∈A(i)} exp(sim(z_i, z_a)/τ_l)
)
```
其中P_l(i)是样本i在层级l的正样本集合，A(i)是所有其他样本，τ_l是层级l的温度参数。

---

## 4. 数据集

| 数据集 | 来源 | 规模 | 用途 | 下载方式 | 预处理方法 |
|-------|------|------|------|---------|-----------|
| CellXGene Census | CZI | ~33M细胞 | 预训练 | cellxgene-census Python包 | 标准化+HVG选择 |
| Tabula Sapiens | HCA | ~500K细胞, 24组织 | 标注评估 | Portal下载 | Scanpy标准流程 |
| Zheng68K PBMC | 10x Genomics | ~68K细胞 | 标注评估 | 10x Genomics官网 | Scanpy标准流程 |
| Pancreas (4批次) | GEO | ~15K细胞 | 整合评估 | scIB工具下载 | 按scIB协议 |
| Multiple Sclerosis | GEO | ~27K细胞 | 标注评估 | GEO下载 | Scanpy标准流程 |
| Norman Perturb-seq | GEO | ~100K细胞 | 扰动预测 | scPerturb包 | 按scGPT协议 |
| Adamson Perturb-seq | GEO | ~90K细胞 | 扰动预测 | scPerturb包 | 按scGPT协议 |
| SCENIC GRN | SCENIC/pySCENIC | - | GRN先验 | pySCENIC运行 | 标准SCENIC流程 |
| Dorothea Regulons | OmniPath | - | GRN先验 | decoupler-py包 | 直接使用 |

### 4.1 数据预处理流程

1. **质控过滤**: 过滤低质量细胞（基因数<200或>8000, 线粒体基因比例>20%）和低表达基因（至少在10个细胞中表达）
2. **归一化**: Library size normalization (每细胞总counts归一化到10,000) + log1p变换
3. **高变基因选择**: 选取Top 4000 HVG（预训练），或使用全基因集（推理时）
4. **基因ID统一**: 将所有数据集的基因ID统一映射到Ensembl Gene ID
5. **批次信息记录**: 保留数据集来源、技术平台等批次变量信息

### 4.2 数据划分

- 预训练数据: CellXGene Census按80/10/10划分（train/valid/test）
- 下游评估: 按各benchmark数据集的标准划分方式
- 细胞类型标注: 5-fold交叉验证
- 扰动预测: 按基因/条件划分（unseen perturbation设置）

---

## 5. 基线方法

| 基线方法 | 论文 | 年份 | 开源代码链接 | 关键指标 |
|---------|------|------|-------------|---------|
| scGPT | Cui et al., Nature Methods | 2024 | https://github.com/bowang-lab/scGPT | Cell annotation Acc, Perturbation Pearson r |
| Geneformer | Theodoris et al., Nature | 2023 | https://huggingface.co/ctheodoris/Geneformer | Cell annotation Acc, Gene network prediction |
| scFoundation | Hao et al., Nature Methods | 2024 | https://github.com/biomap-research/scFoundation | Multi-task performance |
| UCE | Rosen et al., ICLR | 2024 | https://github.com/snap-stanford/UCE | Zero-shot annotation Acc |
| scVI | Lopez et al., Nature Methods | 2018 | https://github.com/scverse/scvi-tools | Integration (iLISI, cLISI) |
| scBERT | Yang et al., Nature MI | 2022 | https://github.com/TencentAILabHealthcare/scBERT | Cell annotation Acc, Macro-F1 |
| CellPLM | Wen et al., ICLR | 2024 | https://github.com/OmicsML/CellPLM | Multi-task |
| Scanpy+Seurat (traditional) | Wolf/Satija et al. | 2018/2015 | scanpy/Seurat | 作为传统方法基线 |

### 各基线简述

- **scGPT**: 使用GPT架构的生成式预训练模型，通过masked和autoregressive token prediction预训练，支持多任务微调
- **Geneformer**: 基于BERT架构，将基因按表达rank编码为token，在30M细胞上预训练
- **scFoundation**: 100M参数的基础模型，使用asymmetric encoder-decoder架构，覆盖全部~20,000基因
- **UCE**: 利用蛋白质语言模型生成基因嵌入，结合对比学习进行预训练，支持跨物种零样本标注
- **scVI**: 变分自编码器框架，概率建模基因表达和批次效应，是数据整合的经典基线
- **scBERT**: BERT架构+Performer attention用于细胞类型标注
- **CellPLM**: 同时建模细胞和基因的双向Transformer，支持空间转录组

---

## 6. 评估指标

| 指标名称 | 数学定义 | 评估维度 | 备注 |
|---------|---------|---------|------|
| Accuracy | 正确预测数/总数 | 细胞标注 | 全局准确率 |
| Macro-F1 | 各类F1的宏平均 | 细胞标注 | 不平衡数据更公平 |
| Weighted-F1 | 加权F1 | 细胞标注 | 考虑类别频率 |
| ARI (Adjusted Rand Index) | 调整后兰德指数 | 聚类 | [-1,1], 1为完美 |
| NMI (Normalized Mutual Information) | 归一化互信息 | 聚类 | [0,1], 1为完美 |
| iLISI (integration LISI) | 积分混合度分数 | 数据整合 | 值越高整合越好 |
| cLISI (cell-type LISI) | 细胞类型混合度分数 | 数据整合 | 值越低保持生物差异越好 |
| ASW (Average Silhouette Width) | 平均轮廓系数 | 聚类/整合 | [-1,1] |
| Pearson r | 皮尔逊相关系数 | 扰动预测 | 预测与真实表达变化的相关性 |
| MSE (Mean Squared Error) | 均方误差 | 扰动预测 | 值越低越好 |
| AUROC | ROC曲线下面积 | GRN推断 | [0,1] |
| AUPRC | PR曲线下面积 | GRN推断 | [0,1] |

---

## 7. 消融实验设计

| 实验编号 | 消融对象 | 具体做法 | 验证目的 |
|---------|---------|---------|---------|
| A1 | GRN-Guided Sparse Attention | 替换为标准Full Attention | 验证GRN先验引导的注意力机制贡献 |
| A2 | GRN-Guided Sparse Attention | 替换为Random Sparse Attention（保持相同稀疏度） | 验证GRN结构（而非单纯稀疏性）的贡献 |
| A3 | Hierarchical Contrastive Loss | 移除HCCL预训练目标，仅保留MGEP | 验证层次化对比学习的贡献 |
| A4 | Hierarchical → Flat Contrastive | 将层次化对比学习替换为普通（非层次化）对比学习 | 验证层次结构（而非对比学习本身）的贡献 |
| A5 | Task-Adaptive Prompt Tuning | 替换为标准Full Fine-Tuning | 对比TAPT与全参数微调的效率和性能 |
| A6 | Task-Adaptive Prompt Tuning | 替换为Linear Probing（仅训练最后一层） | 验证TAPT相比简单适配的优势 |
| A7 | Expression-Aware Continuous Tokenization | 替换为Binning Tokenization（类似scGPT） | 验证连续tokenization的贡献 |
| A8 | Global Attention Heads | 移除2个global attention heads，全部使用GGSA | 验证global attention的必要性 |
| A9 | Random Attention Connections | 移除5%的random attention connections | 验证random connections在发现新关系中的作用 |
| A10 | Gene Property Embedding | 从EACT中移除基因属性嵌入 | 验证基因固有属性信息的贡献 |

---

## 8. 计算资源评估

### 8.1 GPU显存估算

- 模型参数量: ~150M parameters (12 layers, d=768, h=12)
- 基因嵌入表: 20,000 × 768 = ~15M parameters
- 单样本序列长度: ~4,000 tokens (Top 4000 HVG in pre-training)
- Batch size per GPU: 32 (with gradient checkpointing)
- 峰值显存估算:
  - 模型参数 (BF16): ~300 MB
  - 优化器状态 (AdamW FP32): ~1.2 GB
  - 激活值 (with gradient checkpointing): ~15 GB
  - 注意力计算 (sparse): ~8 GB
  - 总计: ~25 GB per GPU (远低于80 GB上限)
- 不使用gradient checkpointing时: ~45 GB per GPU

### 8.2 训练时间估算

- 预训练数据: ~33M细胞
- 单epoch样本数: 33M
- 每步throughput: ~2048 cells/sec (2x A100, effective batch 2048)
- 单epoch时间: ~4.5 hours (2x A100)
- 总epoch数: 10
- 预训练总时间: ~45 hours / ~2 days (2x A100)
- 下游微调: 每个任务 ~2-4 hours
- 全部实验（含基线复现和消融）: ~5 days

### 8.3 推理时间估算

- 单细胞推理: ~0.5 ms (batch=1, A100)
- 批量推理 (batch=256): ~50 ms
- 评估10万细胞: ~3 minutes

---

## 9. 基于的论文和开源代码

| 参考论文 | 使用方式 | GitHub链接 | 许可证 |
|---------|---------|-----------|--------|
| scGPT (Cui et al., 2024) | 参考模型架构设计和数据预处理流程 | https://github.com/bowang-lab/scGPT | BSD |
| Flash Attention (Dao et al., 2022) | 使用其高效注意力实现作为GGSA的计算后端 | https://github.com/Dao-AILab/flash-attention | BSD |
| Geneformer (Theodoris et al., 2023) | 参考预训练策略和基因编码方式 | https://huggingface.co/ctheodoris/Geneformer | Apache 2.0 |
| scvi-tools (Lopez et al., 2018) | 使用其数据加载和预处理工具 | https://github.com/scverse/scvi-tools | BSD |
| Scanpy (Wolf et al., 2018) | 使用其标准预处理流程和评估工具 | https://github.com/scverse/scanpy | BSD |

### 9.1 代码复用计划

- **数据预处理**: 直接使用scanpy和cellxgene-census的标准API加载和预处理数据
- **模型架构**: 参考scGPT的基因嵌入设计，但自行实现GGSA和HCCL模块
- **注意力实现**: 基于Flash Attention的block sparse API实现GGSA
- **评估指标**: 使用scib和scikit-learn的标准实现
- **需要自行实现的核心模块**: GGSA注意力层、HCCL损失函数、TAPT适配模块、EACT编码器

---

## 10. 风险评估与备选方案

| 风险 | 可能性 | 影响 | 备选方案 |
|------|--------|------|---------|
| GRN数据质量不足/噪声大 | 中 | 高 | 使用多个GRN数据库的交集作为高置信度网络；增加random attention比例到10-15% |
| 预训练数据下载/处理时间超预期 | 中 | 中 | 使用CellXGene子集（如~5M细胞）进行快速验证，确认有效后再扩展到全集 |
| HCCL的Cell Ontology标注覆盖不全 | 低 | 中 | 使用自动化的cell type标注工具(CellTypist)补充缺失标注 |
| 稀疏注意力在某些基因组合上表现差 | 中 | 中 | 增加global attention heads数量（从2增到4） |
| 性能未显著超过现有SOTA | 中 | 高 | 聚焦于效率优势（更少参数、更快推理）和可解释性优势，调整论文叙事 |
| A100 GPU资源不足 | 低 | 高 | 使用QLoRA在单张A100上训练，或使用GCP/AWS的临时实例 |

---

## 11. 时间规划

| 阶段 | 任务 | 时间 | 产出 |
|------|------|------|------|
| 第1-2周 | 环境搭建 + 数据下载/预处理 + GRN数据准备 | 2周 | 数据就绪、预处理流程验证 |
| 第3-4周 | 模型实现(GGSA+EACT) + 预训练(小规模验证) | 2周 | 模型代码完成、小规模实验验证可行性 |
| 第5周 | 全规模预训练 | 1周 | 预训练模型checkpoint |
| 第6周 | 基线复现 + 下游微调实验 | 1周 | 基线结果、主实验结果 |
| 第7周 | 消融实验 + 分析实验 | 1周 | 消融结果、可视化分析 |
| 第8周 | 论文撰写 + 图表制作 | 1周 | 完整论文初稿 |
