const PptxGenJS = require("pptxgenjs");

const pptx = new PptxGenJS();
pptx.layout = "LAYOUT_WIDE"; // 13.33 x 7.5

// Color palette - Midnight Executive / Ocean theme for genomics
const C = {
  navy: "1E2761",
  deepBlue: "065A82",
  teal: "1C7293",
  ice: "CADCFC",
  white: "FFFFFF",
  offWhite: "F0F4F8",
  lightGray: "E8ECF1",
  darkText: "1A1A2E",
  midGray: "6B7280",
  accent: "00A896",
  accentDark: "028090",
  red: "E63946",
  gold: "F4A261",
};

// Font choices
const TITLE_FONT = "Georgia";
const BODY_FONT = "Calibri";

// Helper: add dark slide background
function darkBg(slide) {
  slide.background = { color: C.navy };
}

// Helper: add light slide background
function lightBg(slide) {
  slide.background = { color: C.offWhite };
}

// Helper: add slide number
function addSlideNum(slide, num, dark = false) {
  slide.addText(`${num} / 20`, {
    x: 12.0, y: 7.0, w: 1.2, h: 0.4,
    fontSize: 9, fontFace: BODY_FONT,
    color: dark ? "8899AA" : C.midGray,
    align: "right",
  });
}

// Helper: add section title bar at top for light slides
function addTitleBar(slide, title, num) {
  slide.addShape(pptx.shapes.RECTANGLE, {
    x: 0, y: 0, w: 13.33, h: 1.1,
    fill: { color: C.navy },
  });
  slide.addText(title, {
    x: 0.7, y: 0.15, w: 11.0, h: 0.8,
    fontSize: 28, fontFace: TITLE_FONT, bold: true,
    color: C.white,
  });
  addSlideNum(slide, num, true);
}

// Helper: add a colored card/box
function addCard(slide, x, y, w, h, fillColor) {
  slide.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x, y, w, h,
    fill: { color: fillColor },
    rectRadius: 0.1,
    shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.15 },
  });
}

// ============================================================
// SLIDE 1: Title
// ============================================================
let slide = pptx.addSlide();
darkBg(slide);

// Accent line at top
slide.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.06,
  fill: { color: C.accent },
});

slide.addText("CeLLM", {
  x: 1.0, y: 1.5, w: 11.33, h: 1.2,
  fontSize: 60, fontFace: TITLE_FONT, bold: true,
  color: C.white,
  align: "left",
});

slide.addText("An Efficient Foundation Model Bridging\nSingle-Cell Genomics and Natural Language", {
  x: 1.0, y: 2.8, w: 11.33, h: 1.2,
  fontSize: 26, fontFace: BODY_FONT,
  color: C.ice,
  align: "left",
  lineSpacingMultiple: 1.3,
});

slide.addShape(pptx.shapes.RECTANGLE, {
  x: 1.0, y: 4.3, w: 2.5, h: 0.04,
  fill: { color: C.accent },
});

slide.addText("Target Venue: NeurIPS 2026 / Nature Methods", {
  x: 1.0, y: 4.6, w: 6.0, h: 0.5,
  fontSize: 16, fontFace: BODY_FONT,
  color: C.gold, italic: true,
});

slide.addText("Research Plan & Technical Overview", {
  x: 1.0, y: 5.3, w: 6.0, h: 0.5,
  fontSize: 14, fontFace: BODY_FONT,
  color: C.midGray,
});

slide.addText("April 2026", {
  x: 1.0, y: 6.5, w: 3.0, h: 0.4,
  fontSize: 12, fontFace: BODY_FONT,
  color: "667788",
});

addSlideNum(slide, 1, true);

// ============================================================
// SLIDE 2: Motivation
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Motivation: The Single-Cell Revolution", 2);

// Left column: stats
addCard(slide, 0.7, 1.5, 5.5, 5.3, C.white);

slide.addText("The Data Explosion", {
  x: 1.0, y: 1.7, w: 5.0, h: 0.5,
  fontSize: 18, fontFace: TITLE_FONT, bold: true,
  color: C.navy,
});

const motivBullets = [
  "100M+ cells profiled in public atlases (CellxGene, HCA)",
  "Thousands of datasets across tissues, diseases, species",
  "Standard tools (Scanpy, Seurat) lack cross-dataset generalization",
  "Foundation model paradigm: pre-train once, fine-tune for many tasks",
  "Success of LLMs in NLP inspires analogous approaches for genomics",
];
slide.addText(motivBullets.map(t => ({ text: t, options: { bullet: { code: "25CF", color: C.teal }, indentLevel: 0 } })), {
  x: 1.0, y: 2.3, w: 4.8, h: 4.0,
  fontSize: 14, fontFace: BODY_FONT,
  color: C.darkText,
  lineSpacingMultiple: 1.6,
  paraSpaceAfter: 6,
  valign: "top",
});

// Right column: key stats callouts
addCard(slide, 7.0, 1.5, 5.6, 2.4, C.navy);
slide.addText("100M+", {
  x: 7.3, y: 1.6, w: 2.3, h: 0.9,
  fontSize: 44, fontFace: TITLE_FONT, bold: true, color: C.accent,
});
slide.addText("cells in public atlases", {
  x: 7.3, y: 2.4, w: 2.3, h: 0.5,
  fontSize: 12, fontFace: BODY_FONT, color: C.ice,
});
slide.addText("500+", {
  x: 9.8, y: 1.6, w: 2.3, h: 0.9,
  fontSize: 44, fontFace: TITLE_FONT, bold: true, color: C.gold,
});
slide.addText("distinct cell types", {
  x: 9.8, y: 2.4, w: 2.3, h: 0.5,
  fontSize: 12, fontFace: BODY_FONT, color: C.ice,
});
slide.addText("20,000", {
  x: 7.3, y: 3.0, w: 2.3, h: 0.7,
  fontSize: 36, fontFace: TITLE_FONT, bold: true, color: C.accent,
});
slide.addText("genes per cell", {
  x: 7.3, y: 3.5, w: 2.3, h: 0.5,
  fontSize: 12, fontFace: BODY_FONT, color: C.ice,
});
slide.addText("15+", {
  x: 9.8, y: 3.0, w: 2.3, h: 0.7,
  fontSize: 36, fontFace: TITLE_FONT, bold: true, color: C.gold,
});
slide.addText("tissue types", {
  x: 9.8, y: 3.5, w: 2.3, h: 0.5,
  fontSize: 12, fontFace: BODY_FONT, color: C.ice,
});

addCard(slide, 7.0, 4.2, 5.6, 2.6, C.white);
slide.addText("Key Insight", {
  x: 7.3, y: 4.4, w: 5.0, h: 0.4,
  fontSize: 16, fontFace: TITLE_FONT, bold: true, color: C.navy,
});
slide.addText("Genes are analogous to tokens in a vocabulary.\nA cell's expression profile is a \"sentence\" of gene tokens.\nThis analogy enables transformer/LLM architectures for single-cell data.", {
  x: 7.3, y: 4.9, w: 5.0, h: 1.6,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.5, italic: true,
});

// ============================================================
// SLIDE 3: Problem Statement
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Problem: Three Critical Limitations", 3);

const problems = [
  { num: "1", title: "Computational Bottleneck", color: C.red,
    desc: "Transformer attention is O(n\u00B2) with ~20,000 genes\nMost models subsample to <3,000 genes\nFull-genome modeling requires linear architectures" },
  { num: "2", title: "No Biological Grounding", color: C.gold,
    desc: "Learned embeddings lack connection to known biology\nGO, KEGG, PPI knowledge is not incorporated\nAttention maps rarely align with validated pathways" },
  { num: "3", title: "No Language Interface", color: C.teal,
    desc: "Outputs are numerical embeddings only\nNo natural language querying capability\nBiologists need specialized pipelines for interpretation" },
];

problems.forEach((p, i) => {
  const x = 0.7 + i * 4.1;
  addCard(slide, x, 1.5, 3.8, 5.2, C.white);

  // Number circle
  slide.addShape(pptx.shapes.OVAL, {
    x: x + 0.2, y: 1.7, w: 0.6, h: 0.6,
    fill: { color: p.color },
  });
  slide.addText(p.num, {
    x: x + 0.2, y: 1.72, w: 0.6, h: 0.6,
    fontSize: 22, fontFace: TITLE_FONT, bold: true,
    color: C.white, align: "center", valign: "middle",
  });

  slide.addText(p.title, {
    x: x + 1.0, y: 1.75, w: 2.6, h: 0.5,
    fontSize: 17, fontFace: TITLE_FONT, bold: true,
    color: C.navy,
  });

  slide.addText(p.desc, {
    x: x + 0.3, y: 2.6, w: 3.2, h: 3.8,
    fontSize: 13, fontFace: BODY_FONT,
    color: C.darkText,
    lineSpacingMultiple: 1.6,
    valign: "top",
    bullet: { code: "2013", color: p.color },
  });
});

// ============================================================
// SLIDE 4: Related Work
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Related Work: Existing Foundation Models", 4);

// Table
const tableRows = [
  [
    { text: "Model", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Params", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Cells", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Tokenization", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Complexity", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Multi-omics", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "NL Interface", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
  ],
  ["scBERT (2022)", "10M", "1M", "Binned", "O(n\u00B2)", "No", "No"],
  ["Geneformer (2023)", "10M", "30M", "Rank-value", "O(n\u00B2)", "No", "No"],
  ["scGPT (2024)", "50M", "33M", "Gene+value", "O(n\u00B2)", "Yes", "No"],
  ["scFoundation (2024)", "100M", "50M", "Binned", "O(n\u00B2)", "No", "No"],
  ["UCE (2024)", "650M+", "36M", "ESM embed.", "O(n\u00B2)", "No", "No"],
  ["Cell2Sentence (2023)", "124M", "~1M", "Text conv.", "O(n\u00B2)", "No", "Partial"],
  [
    { text: "CeLLM (Ours)", options: { bold: true, color: C.navy, fontSize: 12, fontFace: BODY_FONT } },
    { text: "52M", options: { bold: true, color: C.navy, fontSize: 12, fontFace: BODY_FONT } },
    { text: "50M+", options: { bold: true, color: C.navy, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Hybrid", options: { bold: true, color: C.navy, fontSize: 12, fontFace: BODY_FONT } },
    { text: "O(n)", options: { bold: true, color: C.accent, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Planned", options: { bold: true, color: C.navy, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Yes", options: { bold: true, color: C.accent, fontSize: 12, fontFace: BODY_FONT } },
  ],
];

slide.addTable(tableRows, {
  x: 0.7, y: 1.5, w: 11.9,
  fontSize: 12, fontFace: BODY_FONT,
  color: C.darkText,
  border: { type: "solid", pt: 0.5, color: C.lightGray },
  rowH: [0.45, 0.4, 0.4, 0.4, 0.4, 0.4, 0.4, 0.45],
  colW: [2.0, 1.0, 1.0, 1.5, 1.2, 1.2, 1.2],
  align: "center",
  valign: "middle",
  autoPage: false,
});

slide.addText("Gap: No existing model combines O(n) complexity, knowledge grounding, AND natural language interface", {
  x: 0.7, y: 5.6, w: 11.9, h: 0.6,
  fontSize: 15, fontFace: BODY_FONT, bold: true, italic: true,
  color: C.deepBlue, align: "center",
});

// ============================================================
// SLIDE 5: Architecture Overview
// ============================================================
slide = pptx.addSlide();
darkBg(slide);

slide.addText("CeLLM Architecture", {
  x: 0.7, y: 0.3, w: 12.0, h: 0.8,
  fontSize: 32, fontFace: TITLE_FONT, bold: true,
  color: C.white,
});
addSlideNum(slide, 5, true);

// Three module boxes
const modules = [
  { title: "Module 1", subtitle: "Mamba-SSM\nGene Encoder", color: C.deepBlue,
    desc: "Linear-time O(n)\nFull 20K genes\n12 Mamba blocks\nSSM state propagation" },
  { title: "Module 2", subtitle: "Knowledge\nIntegration (KIM)", color: C.teal,
    desc: "GO/KEGG/PPI graph\n3-layer GAT\nGated cross-attention\nBiology-grounded" },
  { title: "Module 3", subtitle: "Language\nAlignment (LAM)", color: C.accent,
    desc: "CLIP-style contrast\nPubMedBERT text enc.\nZero-shot annotation\nNL querying" },
];

modules.forEach((m, i) => {
  const x = 0.7 + i * 4.1;
  addCard(slide, x, 1.5, 3.8, 5.0, "1A2255");

  // Module label
  slide.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: x + 0.3, y: 1.7, w: 1.5, h: 0.4,
    fill: { color: m.color }, rectRadius: 0.05,
  });
  slide.addText(m.title, {
    x: x + 0.3, y: 1.7, w: 1.5, h: 0.4,
    fontSize: 11, fontFace: BODY_FONT, bold: true,
    color: C.white, align: "center", valign: "middle",
  });

  slide.addText(m.subtitle, {
    x: x + 0.3, y: 2.3, w: 3.2, h: 0.9,
    fontSize: 20, fontFace: TITLE_FONT, bold: true,
    color: C.white, lineSpacingMultiple: 1.2,
  });

  slide.addShape(pptx.shapes.RECTANGLE, {
    x: x + 0.3, y: 3.3, w: 1.5, h: 0.03,
    fill: { color: m.color },
  });

  slide.addText(m.desc, {
    x: x + 0.3, y: 3.6, w: 3.2, h: 2.6,
    fontSize: 14, fontFace: BODY_FONT,
    color: C.ice,
    lineSpacingMultiple: 1.6,
    bullet: { code: "25B8", color: m.color },
  });
});

// Arrows between boxes
slide.addText("\u27A1", { x: 4.55, y: 3.6, w: 0.6, h: 0.6, fontSize: 24, color: C.gold, align: "center" });
slide.addText("\u27A1", { x: 8.65, y: 3.6, w: 0.6, h: 0.6, fontSize: 24, color: C.gold, align: "center" });

// ============================================================
// SLIDE 6: Mamba Encoder
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Module 1: Mamba-SSM Gene Expression Encoder", 6);

// Left column
addCard(slide, 0.7, 1.5, 6.0, 5.3, C.white);
slide.addText("Selective State-Space Model", {
  x: 1.0, y: 1.7, w: 5.4, h: 0.5,
  fontSize: 18, fontFace: TITLE_FONT, bold: true, color: C.navy,
});

const mambaPoints = [
  "Input-dependent discretization parameters",
  "Content-aware selective scanning",
  "State propagation captures long-range gene dependencies",
  "12 stacked Mamba blocks, d=512, state_dim=16",
  "Processes ALL ~20,000 genes without subsampling",
  "39x fewer FLOPs than standard self-attention",
];
slide.addText(mambaPoints.map(t => ({ text: t, options: { bullet: { code: "25CF", color: C.deepBlue } } })), {
  x: 1.0, y: 2.3, w: 5.4, h: 4.0,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.7, paraSpaceAfter: 4, valign: "top",
});

// Right column - formula/comparison
addCard(slide, 7.2, 1.5, 5.4, 2.4, C.navy);
slide.addText("SSM Equations", {
  x: 7.5, y: 1.65, w: 4.8, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.accent,
});
slide.addText("s(t) = A * s(t-1) + B * x(t)\ny(t) = C * s(t) + D * x(t)\n\nA, B, C are input-dependent (selective)", {
  x: 7.5, y: 2.1, w: 4.8, h: 1.6,
  fontSize: 13, fontFace: "Consolas", color: C.ice,
  lineSpacingMultiple: 1.4,
});

addCard(slide, 7.2, 4.2, 5.4, 2.6, C.white);
slide.addText("Complexity Comparison", {
  x: 7.5, y: 4.4, w: 4.8, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.navy,
});

const compRows = [
  [
    { text: "Architecture", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 11, fontFace: BODY_FONT } },
    { text: "Time", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 11, fontFace: BODY_FONT } },
    { text: "20K Genes", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 11, fontFace: BODY_FONT } },
  ],
  ["Transformer", "O(n\u00B2d)", "82 GFLOPs"],
  ["Linear Attn", "O(nd\u00B2)", "10 GFLOPs"],
  [
    { text: "Mamba (Ours)", options: { bold: true, color: C.accent, fontSize: 11 } },
    { text: "O(nd)", options: { bold: true, color: C.accent, fontSize: 11 } },
    { text: "2.1 GFLOPs", options: { bold: true, color: C.accent, fontSize: 11 } },
  ],
];
slide.addTable(compRows, {
  x: 7.5, y: 4.9, w: 4.8,
  fontSize: 11, fontFace: BODY_FONT, color: C.darkText,
  border: { type: "solid", pt: 0.5, color: C.lightGray },
  rowH: [0.35, 0.35, 0.35, 0.35],
  align: "center", valign: "middle", autoPage: false,
});

// ============================================================
// SLIDE 7: Hybrid Tokenization
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Hybrid Continuous-Discrete Tokenization", 7);

addCard(slide, 0.7, 1.5, 11.9, 1.2, C.white);
slide.addText("h_i = W_g * Embed(gene_i) + W_b * Embed(bin_i) + W_r * residual_i + p_chr(i)", {
  x: 1.0, y: 1.65, w: 11.3, h: 0.5,
  fontSize: 15, fontFace: "Consolas", color: C.navy, align: "center",
});
slide.addText("Combined gene embedding = gene identity + expression bin + continuous residual + chromosomal position", {
  x: 1.0, y: 2.15, w: 11.3, h: 0.4,
  fontSize: 11, fontFace: BODY_FONT, color: C.midGray, align: "center", italic: true,
});

// Four component cards
const tokenParts = [
  { title: "Gene Identity", desc: "Learned embedding\nfor each of ~20K genes\nUnique gene token", color: C.deepBlue },
  { title: "Discrete Bin", desc: "Expression level\nbinned into 51 levels\n0 = not expressed", color: C.teal },
  { title: "Continuous Residual", desc: "log1p(count) minus\nbin center value\nPreserves quantitative info", color: C.accent },
  { title: "Chr. Position", desc: "Chromosomal coordinate\nencoding, not arbitrary\nBiologically meaningful order", color: C.gold },
];

tokenParts.forEach((tp, i) => {
  const x = 0.7 + i * 3.08;
  addCard(slide, x, 3.0, 2.85, 3.6, C.white);
  slide.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: x + 0.2, y: 3.2, w: 2.45, h: 0.4,
    fill: { color: tp.color }, rectRadius: 0.05,
  });
  slide.addText(tp.title, {
    x: x + 0.2, y: 3.2, w: 2.45, h: 0.4,
    fontSize: 13, fontFace: BODY_FONT, bold: true,
    color: C.white, align: "center", valign: "middle",
  });
  slide.addText(tp.desc, {
    x: x + 0.3, y: 3.8, w: 2.3, h: 2.5,
    fontSize: 13, fontFace: BODY_FONT,
    color: C.darkText, lineSpacingMultiple: 1.5,
    valign: "top",
  });
});

// ============================================================
// SLIDE 8: KIM
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Module 2: Knowledge Integration Module (KIM)", 8);

// Left column
addCard(slide, 0.7, 1.5, 5.8, 5.3, C.white);
slide.addText("Graph Attention over Gene-Pathway Network", {
  x: 1.0, y: 1.7, w: 5.2, h: 0.5,
  fontSize: 16, fontFace: TITLE_FONT, bold: true, color: C.navy,
});

const kimPoints = [
  "Heterogeneous graph with gene + pathway nodes",
  "Gene Ontology (GO): biological process, molecular function",
  "KEGG pathways: metabolic and signaling pathways",
  "Protein-protein interactions (PPI) from STRING",
  "3-layer GAT with 4 attention heads",
  "Gated cross-attention fusion with Mamba output",
  "Learned gate alpha controls knowledge influence",
];
slide.addText(kimPoints.map(t => ({ text: t, options: { bullet: { code: "25CF", color: C.teal } } })), {
  x: 1.0, y: 2.3, w: 5.2, h: 4.0,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.5, paraSpaceAfter: 3, valign: "top",
});

// Right column - fusion diagram
addCard(slide, 7.0, 1.5, 5.6, 2.5, C.navy);
slide.addText("Gated Fusion", {
  x: 7.3, y: 1.65, w: 5.0, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.accent,
});
slide.addText("h_fused = h_mamba + alpha * CrossAttn(h_mamba, Z_KIM)\n\nalpha = sigmoid(W * [h_mamba; attn_out])\n\nLearned gating balances encoder vs knowledge", {
  x: 7.3, y: 2.1, w: 5.0, h: 1.7,
  fontSize: 13, fontFace: "Consolas", color: C.ice,
  lineSpacingMultiple: 1.4,
});

addCard(slide, 7.0, 4.3, 5.6, 2.5, C.white);
slide.addText("Why Knowledge Grounding?", {
  x: 7.3, y: 4.5, w: 5.0, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.navy,
});
slide.addText("Genes in the same pathway SHOULD have related embeddings\nDecades of curated biological knowledge available\nImproves interpretability: attention aligns with known biology\nAblation shows +1.6% F1 improvement", {
  x: 7.3, y: 5.0, w: 5.0, h: 1.5,
  fontSize: 12, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.5, bullet: { code: "2713", color: C.accent },
});

// ============================================================
// SLIDE 9: LAM
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Module 3: Language Alignment Module (LAM)", 9);

addCard(slide, 0.7, 1.5, 5.8, 5.3, C.white);
slide.addText("CLIP-Style Cell-Text Alignment", {
  x: 1.0, y: 1.7, w: 5.2, h: 0.5,
  fontSize: 16, fontFace: TITLE_FONT, bold: true, color: C.navy,
});

const lamPoints = [
  "Cell embeddings projected to shared alignment space",
  "Text descriptions encoded by frozen PubMedBERT",
  "Symmetric contrastive loss (InfoNCE)",
  "Learnable temperature parameter",
  "~500K cell-text pairs for training",
];
slide.addText(lamPoints.map(t => ({ text: t, options: { bullet: { code: "25CF", color: C.accent } } })), {
  x: 1.0, y: 2.3, w: 5.2, h: 2.5,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.6, paraSpaceAfter: 3, valign: "top",
});

slide.addText("Cell-Text Pair Sources", {
  x: 1.0, y: 4.8, w: 5.2, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.navy,
});
const pairSources = [
  "Cell Ontology (CL) definitions",
  "Marker gene descriptions (LLM-generated)",
  "Publication abstracts linked to datasets",
  "Pathway enrichment summaries (GSEA)",
];
slide.addText(pairSources.map(t => ({ text: t, options: { bullet: { code: "25B8", color: C.teal } } })), {
  x: 1.0, y: 5.2, w: 5.2, h: 1.3,
  fontSize: 12, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.5,
});

// Right column - zero-shot
addCard(slide, 7.0, 1.5, 5.6, 5.3, C.navy);
slide.addText("Zero-Shot Cell Type Annotation", {
  x: 7.3, y: 1.7, w: 5.0, h: 0.5,
  fontSize: 16, fontFace: TITLE_FONT, bold: true, color: C.accent,
});
slide.addText("No labeled training data required!", {
  x: 7.3, y: 2.2, w: 5.0, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, color: C.gold, italic: true,
});

slide.addText(
  "1. Describe candidate cell types in natural language\n\n" +
  '   "T cell: CD3+ lymphocyte in adaptive immunity"\n' +
  '   "B cell: CD19+ antibody-producing lymphocyte"\n' +
  '   "Macrophage: CD68+ tissue phagocyte"\n\n' +
  "2. Encode descriptions with PubMedBERT\n\n" +
  "3. Find highest cosine similarity for each cell\n\n" +
  "4. Assign cell type with confidence score", {
  x: 7.3, y: 2.8, w: 5.0, h: 3.8,
  fontSize: 12, fontFace: BODY_FONT, color: C.ice,
  lineSpacingMultiple: 1.3, valign: "top",
});

// ============================================================
// SLIDE 10: Pre-training Strategy
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Pre-training Strategy: Four Objectives", 10);

const objectives = [
  { title: "MGEP", full: "Masked Gene Expression Prediction",
    desc: "Mask 15% of genes\nPredict bin class + residual\nPrimary reconstruction loss", color: C.deepBlue, weight: "1.0" },
  { title: "GPCL", full: "Gene Program Contrastive Learning",
    desc: "Cells with similar gene programs\nshould have similar embeddings\nNMF-based program extraction", color: C.teal, weight: "0.5" },
  { title: "KGR", full: "Knowledge-Grounded Regularization",
    desc: "Same-pathway genes pulled closer\nTriplet margin formulation\nAligns with GO/KEGG structure", color: C.accent, weight: "0.3" },
  { title: "CTA", full: "Cell-Text Alignment",
    desc: "Contrastive cell-text loss\nSymmetric InfoNCE\nEnables zero-shot capability", color: C.gold, weight: "0.5" },
];

objectives.forEach((obj, i) => {
  const x = 0.5 + i * 3.15;
  addCard(slide, x, 1.5, 2.95, 5.3, C.white);

  slide.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: x + 0.15, y: 1.7, w: 1.0, h: 0.5,
    fill: { color: obj.color }, rectRadius: 0.05,
  });
  slide.addText(obj.title, {
    x: x + 0.15, y: 1.7, w: 1.0, h: 0.5,
    fontSize: 14, fontFace: BODY_FONT, bold: true,
    color: C.white, align: "center", valign: "middle",
  });

  slide.addText(obj.full, {
    x: x + 0.2, y: 2.4, w: 2.55, h: 0.6,
    fontSize: 12, fontFace: BODY_FONT, bold: true, color: C.navy,
    lineSpacingMultiple: 1.1,
  });

  slide.addText(obj.desc, {
    x: x + 0.2, y: 3.1, w: 2.55, h: 2.5,
    fontSize: 12, fontFace: BODY_FONT, color: C.darkText,
    lineSpacingMultiple: 1.5, valign: "top",
  });

  // Weight badge
  slide.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x: x + 0.15, y: 5.9, w: 2.65, h: 0.4,
    fill: { color: C.lightGray }, rectRadius: 0.05,
  });
  slide.addText(`Weight: \u03B2 = ${obj.weight}`, {
    x: x + 0.15, y: 5.9, w: 2.65, h: 0.4,
    fontSize: 11, fontFace: BODY_FONT, color: C.darkText, align: "center", valign: "middle",
  });
});

// ============================================================
// SLIDE 11: Pre-training Data
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Pre-training Data: CellxGene Census", 11);

addCard(slide, 0.7, 1.5, 5.8, 5.3, C.white);
slide.addText("15 Tissue Types", {
  x: 1.0, y: 1.7, w: 5.2, h: 0.4,
  fontSize: 16, fontFace: TITLE_FONT, bold: true, color: C.navy,
});

const tissues = [
  "Brain, Blood, Lung, Heart, Liver",
  "Kidney, Intestine, Skin, Bone Marrow",
  "Pancreas, Eye, Breast, Prostate",
  "Stomach, Spleen",
];
slide.addText(tissues.map(t => ({ text: t, options: { bullet: { code: "25CF", color: C.teal } } })), {
  x: 1.0, y: 2.2, w: 5.2, h: 1.5,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.5,
});

slide.addText("Preprocessing Pipeline", {
  x: 1.0, y: 3.9, w: 5.2, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.navy,
});
const prepSteps = [
  "Quality control: min 200 genes, <20% mito reads",
  "Normalize to 10,000 counts per cell",
  "Log1p transformation",
  "Filter to 19,264 protein-coding genes",
  "Healthy (non-disease) samples only",
];
slide.addText(prepSteps.map(t => ({ text: t, options: { bullet: { code: "25B8", color: C.deepBlue } } })), {
  x: 1.0, y: 4.3, w: 5.2, h: 2.2,
  fontSize: 12, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.5,
});

// Right: stats
addCard(slide, 7.0, 1.5, 5.6, 5.3, C.navy);
slide.addText("Data Statistics", {
  x: 7.3, y: 1.7, w: 5.0, h: 0.5,
  fontSize: 16, fontFace: TITLE_FONT, bold: true, color: C.white,
});

const dataStats = [
  { label: "Total cells", value: "50M+", color: C.accent },
  { label: "Genes (vocabulary)", value: "19,264", color: C.accent },
  { label: "Datasets", value: "~500", color: C.gold },
  { label: "Tissue types", value: "15", color: C.gold },
  { label: "Cell types", value: "500+", color: C.accent },
  { label: "Data source", value: "CellxGene Census", color: C.gold },
];
dataStats.forEach((s, i) => {
  const y = 2.4 + i * 0.7;
  slide.addText(s.value, {
    x: 7.5, y: y, w: 2.5, h: 0.5,
    fontSize: 28, fontFace: TITLE_FONT, bold: true, color: s.color,
  });
  slide.addText(s.label, {
    x: 10.2, y: y + 0.05, w: 2.0, h: 0.4,
    fontSize: 13, fontFace: BODY_FONT, color: C.ice,
  });
});

// ============================================================
// SLIDE 12: Training Infrastructure
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Training Infrastructure", 12);

const infraItems = [
  { icon: "GPU", title: "8x A100 80GB", desc: "NVIDIA A100 GPUs with NVLink interconnect", color: C.deepBlue },
  { icon: "BF16", title: "bf16 Mixed Precision", desc: "Bfloat16 for faster training with stability", color: C.teal },
  { icon: "4K", title: "Batch Size 4,096", desc: "64 per GPU x 8 GPUs x 8 grad accum steps", color: C.accent },
  { icon: "200K", title: "200,000 Steps", desc: "~6 days total training time", color: C.gold },
];

infraItems.forEach((item, i) => {
  const x = 0.5 + i * 3.15;
  addCard(slide, x, 1.5, 2.95, 3.5, C.white);

  slide.addShape(pptx.shapes.OVAL, {
    x: x + 0.95, y: 1.8, w: 1.0, h: 1.0,
    fill: { color: item.color },
  });
  slide.addText(item.icon, {
    x: x + 0.95, y: 1.8, w: 1.0, h: 1.0,
    fontSize: 14, fontFace: BODY_FONT, bold: true,
    color: C.white, align: "center", valign: "middle",
  });

  slide.addText(item.title, {
    x: x + 0.2, y: 3.0, w: 2.55, h: 0.4,
    fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.navy, align: "center",
  });
  slide.addText(item.desc, {
    x: x + 0.2, y: 3.4, w: 2.55, h: 1.0,
    fontSize: 11, fontFace: BODY_FONT, color: C.midGray, align: "center",
    lineSpacingMultiple: 1.3,
  });
});

// Additional training details
addCard(slide, 0.7, 5.3, 11.9, 1.5, C.white);
slide.addText("Optimization: AdamW (lr=1e-4, wd=0.01) | Warmup: 2,000 steps | Schedule: Cosine decay | Grad norm: 1.0 | Framework: PyTorch 2.x + Mamba CUDA kernels", {
  x: 1.0, y: 5.5, w: 11.3, h: 0.5,
  fontSize: 12, fontFace: BODY_FONT, color: C.darkText, align: "center",
});
slide.addText("Logging: WandB | Checkpoints: every 10K steps | Evaluation: every 5K steps | Total parameters: ~52M", {
  x: 1.0, y: 6.1, w: 11.3, h: 0.5,
  fontSize: 12, fontFace: BODY_FONT, color: C.midGray, align: "center",
});

// ============================================================
// SLIDE 13: Annotation Results
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Results: Cell Type Annotation", 13);

const annotRows = [
  [
    { text: "Dataset", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "scGPT", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Geneformer", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "scFoundation", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "UCE", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "CeLLM", options: { bold: true, color: C.white, fill: { color: C.accent }, fontSize: 12, fontFace: BODY_FONT } },
  ],
  ["Zheng68K", "0.842", "0.811", "0.836", "0.795", { text: "0.871", options: { bold: true, color: C.accent } }],
  ["PBMC Multi-donor", "0.876", "0.858", "0.881", "0.834", { text: "0.893", options: { bold: true, color: C.accent } }],
  ["Pancreas", "0.921", "0.905", "0.918", "0.889", { text: "0.935", options: { bold: true, color: C.accent } }],
];
slide.addTable(annotRows, {
  x: 0.7, y: 1.5, w: 11.9,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  border: { type: "solid", pt: 0.5, color: C.lightGray },
  rowH: [0.5, 0.45, 0.45, 0.45],
  align: "center", valign: "middle", autoPage: false,
});

slide.addText("Metric: Macro-F1 (higher is better)", {
  x: 0.7, y: 3.5, w: 11.9, h: 0.4,
  fontSize: 11, fontFace: BODY_FONT, color: C.midGray, italic: true, align: "center",
});

// Highlight stats
addCard(slide, 0.7, 4.2, 3.8, 2.5, C.navy);
slide.addText("+2.9%", {
  x: 0.9, y: 4.4, w: 3.4, h: 0.8,
  fontSize: 42, fontFace: TITLE_FONT, bold: true, color: C.accent, align: "center",
});
slide.addText("avg. improvement over scGPT", {
  x: 0.9, y: 5.2, w: 3.4, h: 0.4,
  fontSize: 12, fontFace: BODY_FONT, color: C.ice, align: "center",
});
slide.addText("Across all 3 benchmark datasets", {
  x: 0.9, y: 5.7, w: 3.4, h: 0.4,
  fontSize: 11, fontFace: BODY_FONT, color: "667788", align: "center",
});

addCard(slide, 5.0, 4.2, 3.8, 2.5, C.white);
slide.addText("Key Findings", {
  x: 5.3, y: 4.4, w: 3.2, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.navy,
});
slide.addText("Consistent gains across all datasets\nLargest gain on diverse Zheng68K (+3.4%)\nFull-genome modeling captures rare cell types better", {
  x: 5.3, y: 4.9, w: 3.2, h: 1.5,
  fontSize: 11, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.5, bullet: { code: "2713", color: C.accent },
});

addCard(slide, 9.3, 4.2, 3.3, 2.5, C.white);
slide.addText("vs. Best Baseline", {
  x: 9.5, y: 4.4, w: 2.9, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.navy,
});
slide.addText("Zheng68K: +2.9% vs scGPT\nPBMC: +1.2% vs scFoundation\nPancreas: +1.4% vs scGPT", {
  x: 9.5, y: 4.9, w: 2.9, h: 1.5,
  fontSize: 11, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.5,
});

// ============================================================
// SLIDE 14: Integration Results
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Results: Batch Integration", 14);

const integRows = [
  [
    { text: "Dataset", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "scGPT", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Geneformer", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "scFoundation", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "UCE", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "CeLLM", options: { bold: true, color: C.white, fill: { color: C.accent }, fontSize: 12, fontFace: BODY_FONT } },
  ],
  ["PBMC Multi-batch", "0.782", "0.745", "0.791", "0.768", { text: "0.812", options: { bold: true, color: C.accent } }],
  ["Lung Atlas", "0.756", "0.721", "0.749", "0.733", { text: "0.778", options: { bold: true, color: C.accent } }],
];
slide.addTable(integRows, {
  x: 0.7, y: 1.5, w: 11.9,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  border: { type: "solid", pt: 0.5, color: C.lightGray },
  rowH: [0.5, 0.45, 0.45],
  align: "center", valign: "middle", autoPage: false,
});

slide.addText("Metric: Overall score = avg(ASW_celltype, ASW_batch, AMI) (higher is better)", {
  x: 0.7, y: 3.0, w: 11.9, h: 0.4,
  fontSize: 11, fontFace: BODY_FONT, color: C.midGray, italic: true, align: "center",
});

addCard(slide, 0.7, 3.7, 5.8, 3.1, C.white);
slide.addText("What This Measures", {
  x: 1.0, y: 3.9, w: 5.2, h: 0.4,
  fontSize: 16, fontFace: BODY_FONT, bold: true, color: C.navy,
});
slide.addText(
  "Batch mixing: Are technical batch effects removed?\n" +
  "Bio conservation: Are real biological differences preserved?\n" +
  "CeLLM's knowledge grounding helps distinguish technical vs biological variation", {
  x: 1.0, y: 4.4, w: 5.2, h: 2.0,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.6, bullet: { code: "25CF", color: C.teal },
});

addCard(slide, 7.0, 3.7, 5.6, 3.1, C.navy);
slide.addText("+3.0%", {
  x: 7.2, y: 4.0, w: 5.2, h: 1.0,
  fontSize: 48, fontFace: TITLE_FONT, bold: true, color: C.accent, align: "center",
});
slide.addText("average improvement over scGPT\nacross integration benchmarks", {
  x: 7.2, y: 5.1, w: 5.2, h: 0.8,
  fontSize: 14, fontFace: BODY_FONT, color: C.ice, align: "center",
  lineSpacingMultiple: 1.3,
});

// ============================================================
// SLIDE 15: Perturbation Results
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Results: Perturbation Prediction", 15);

const pertRows = [
  [
    { text: "Dataset", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "scGPT", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Geneformer", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "scFoundation", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "CeLLM", options: { bold: true, color: C.white, fill: { color: C.accent }, fontSize: 12, fontFace: BODY_FONT } },
  ],
  ["Norman CRISPR", "0.892", "0.845", "0.878", { text: "0.911", options: { bold: true, color: C.accent } }],
  ["Replogle K562", "0.834", "0.801", "0.841", { text: "0.858", options: { bold: true, color: C.accent } }],
];
slide.addTable(pertRows, {
  x: 0.7, y: 1.5, w: 11.9,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  border: { type: "solid", pt: 0.5, color: C.lightGray },
  rowH: [0.5, 0.45, 0.45],
  align: "center", valign: "middle", autoPage: false,
});

slide.addText("Metric: Pearson correlation r (higher is better)", {
  x: 0.7, y: 3.0, w: 11.9, h: 0.4,
  fontSize: 11, fontFace: BODY_FONT, color: C.midGray, italic: true, align: "center",
});

addCard(slide, 0.7, 3.7, 5.8, 3.1, C.white);
slide.addText("Why KIM Helps Perturbation Prediction", {
  x: 1.0, y: 3.9, w: 5.2, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.navy,
});
slide.addText(
  "Perturbing gene X affects downstream pathway members\n" +
  "KIM encodes gene-pathway relationships explicitly\n" +
  "Model learns to propagate perturbation effects through known networks\n" +
  "Full-genome context captures indirect effects missed by gene subsampling", {
  x: 1.0, y: 4.4, w: 5.2, h: 2.0,
  fontSize: 12, fontFace: BODY_FONT, color: C.darkText,
  lineSpacingMultiple: 1.5, bullet: { code: "25CF", color: C.deepBlue },
});

addCard(slide, 7.0, 3.7, 5.6, 3.1, C.navy);
slide.addText("0.911", {
  x: 7.2, y: 3.9, w: 5.2, h: 1.2,
  fontSize: 56, fontFace: TITLE_FONT, bold: true, color: C.accent, align: "center",
});
slide.addText("Pearson r on Norman CRISPR\n(+1.9% over scGPT)", {
  x: 7.2, y: 5.1, w: 5.2, h: 0.8,
  fontSize: 14, fontFace: BODY_FONT, color: C.ice, align: "center",
  lineSpacingMultiple: 1.3,
});

// ============================================================
// SLIDE 16: Zero-Shot
// ============================================================
slide = pptx.addSlide();
darkBg(slide);

slide.addText("Zero-Shot Cell Type Discovery", {
  x: 0.7, y: 0.3, w: 12.0, h: 0.8,
  fontSize: 32, fontFace: TITLE_FONT, bold: true, color: C.white,
});
slide.addText("A Novel Capability -- No Other Foundation Model Can Do This", {
  x: 0.7, y: 1.0, w: 12.0, h: 0.5,
  fontSize: 16, fontFace: BODY_FONT, color: C.gold, italic: true,
});
addSlideNum(slide, 16, true);

addCard(slide, 0.7, 1.8, 5.8, 4.8, "1A2255");
slide.addText("How It Works", {
  x: 1.0, y: 2.0, w: 5.2, h: 0.4,
  fontSize: 16, fontFace: BODY_FONT, bold: true, color: C.accent,
});
slide.addText(
  "1. Biologist writes natural language descriptions\n" +
  "   of expected cell types\n\n" +
  "2. LAM encodes descriptions into shared space\n\n" +
  "3. Each cell is matched to closest description\n" +
  "   by cosine similarity\n\n" +
  "4. No labeled training data required!\n\n" +
  "5. Works on completely new tissues and organisms", {
  x: 1.0, y: 2.5, w: 5.2, h: 3.8,
  fontSize: 13, fontFace: BODY_FONT, color: C.ice,
  lineSpacingMultiple: 1.3, valign: "top",
});

addCard(slide, 7.0, 1.8, 5.6, 2.2, C.accent);
slide.addText("68.4%", {
  x: 7.2, y: 1.9, w: 5.2, h: 1.2,
  fontSize: 60, fontFace: TITLE_FONT, bold: true, color: C.white, align: "center",
});
slide.addText("Accuracy@1 on held-out novel tissues\nCompetitive with supervised methods on related datasets", {
  x: 7.2, y: 3.0, w: 5.2, h: 0.8,
  fontSize: 12, fontFace: BODY_FONT, color: C.white, align: "center",
  lineSpacingMultiple: 1.3,
});

addCard(slide, 7.0, 4.3, 5.6, 2.3, "1A2255");
slide.addText("Impact", {
  x: 7.3, y: 4.5, w: 5.0, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.gold,
});
slide.addText(
  "Democratizes single-cell analysis\n" +
  "No computational expertise required\n" +
  "Enables rapid exploration of new datasets\n" +
  "Paradigm shift from supervised to zero-shot", {
  x: 7.3, y: 5.0, w: 5.0, h: 1.3,
  fontSize: 12, fontFace: BODY_FONT, color: C.ice,
  lineSpacingMultiple: 1.4, bullet: { code: "2713", color: C.accent },
});

// ============================================================
// SLIDE 17: Computational Efficiency
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Computational Efficiency", 17);

const effRows = [
  [
    { text: "Model", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Genes Input", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Time/Step", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Memory", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
    { text: "Full Genome?", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 12, fontFace: BODY_FONT } },
  ],
  ["scGPT", "3,000", "142 ms", "24.3 GB", "No"],
  ["Geneformer", "2,048", "89 ms", "12.1 GB", "No"],
  ["scFoundation", "19,264", "387 ms", "62.4 GB", "Yes"],
  [
    { text: "CeLLM", options: { bold: true, color: C.accent } },
    { text: "19,264", options: { bold: true, color: C.accent } },
    { text: "98 ms", options: { bold: true, color: C.accent } },
    { text: "18.7 GB", options: { bold: true, color: C.accent } },
    { text: "Yes", options: { bold: true, color: C.accent } },
  ],
];
slide.addTable(effRows, {
  x: 0.7, y: 1.5, w: 11.9,
  fontSize: 13, fontFace: BODY_FONT, color: C.darkText,
  border: { type: "solid", pt: 0.5, color: C.lightGray },
  rowH: [0.5, 0.45, 0.45, 0.45, 0.5],
  align: "center", valign: "middle", autoPage: false,
});

slide.addText("Measured on A100 80GB with batch size 64", {
  x: 0.7, y: 4.0, w: 11.9, h: 0.3,
  fontSize: 10, fontFace: BODY_FONT, color: C.midGray, italic: true, align: "center",
});

// Highlight stats
const effStats = [
  { value: "3.9x", label: "Faster than\nscFoundation", color: C.deepBlue },
  { value: "3.3x", label: "Less memory\nthan scFoundation", color: C.teal },
  { value: "100%", label: "Full genome\nprocessing", color: C.accent },
];
effStats.forEach((s, i) => {
  const x = 0.7 + i * 4.2;
  addCard(slide, x, 4.6, 3.8, 2.3, C.white);
  slide.addText(s.value, {
    x: x + 0.1, y: 4.7, w: 3.6, h: 1.0,
    fontSize: 42, fontFace: TITLE_FONT, bold: true, color: s.color, align: "center",
  });
  slide.addText(s.label, {
    x: x + 0.1, y: 5.7, w: 3.6, h: 0.8,
    fontSize: 13, fontFace: BODY_FONT, color: C.darkText, align: "center",
    lineSpacingMultiple: 1.3,
  });
});

// ============================================================
// SLIDE 18: Ablations
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Ablation Studies", 18);

const ablRows = [
  [
    { text: "Variant", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 11, fontFace: BODY_FONT } },
    { text: "Annot. F1", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 11, fontFace: BODY_FONT } },
    { text: "Integration", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 11, fontFace: BODY_FONT } },
    { text: "Params", options: { bold: true, color: C.white, fill: { color: C.navy }, fontSize: 11, fontFace: BODY_FONT } },
  ],
  [{ text: "CeLLM (full)", options: { bold: true } }, { text: "0.871", options: { bold: true, color: C.accent } }, { text: "0.812", options: { bold: true, color: C.accent } }, "52M"],
  ["  - KIM", "0.855", "0.798", "45M"],
  ["  - LAM", "0.862", "0.805", "48M"],
  ["  - KIM - LAM", "0.848", "0.791", "42M"],
  ["Transformer backbone", "0.859", "0.801", "58M"],
  ["Linear Attention", "0.851", "0.795", "50M"],
  ["Binned tokenization", "0.843", "0.788", "52M"],
  ["Rank-value tokenization", "0.839", "0.785", "52M"],
  ["Random gene order", "0.856", "0.794", "52M"],
  ["10M pre-train cells", "0.831", "0.772", "52M"],
  ["30M pre-train cells", "0.858", "0.799", "52M"],
];
slide.addTable(ablRows, {
  x: 0.7, y: 1.4, w: 7.5,
  fontSize: 11, fontFace: BODY_FONT, color: C.darkText,
  border: { type: "solid", pt: 0.5, color: C.lightGray },
  rowH: [0.38, 0.38, 0.35, 0.35, 0.35, 0.35, 0.35, 0.35, 0.35, 0.35, 0.35, 0.35],
  colW: [2.5, 1.5, 1.5, 1.0],
  align: "center", valign: "middle", autoPage: false,
});

// Key takeaways
addCard(slide, 8.6, 1.4, 4.0, 5.4, C.navy);
slide.addText("Key Takeaways", {
  x: 8.9, y: 1.6, w: 3.4, h: 0.4,
  fontSize: 16, fontFace: BODY_FONT, bold: true, color: C.accent,
});
const takeaways = [
  "Mamba > Transformer (+1.2%) with fewer params and 4x less compute",
  "KIM adds +1.6% F1 via knowledge grounding",
  "Hybrid tokenization beats binned (+2.8%) and rank (+3.2%)",
  "Chromosomal ordering gives +1.5% over random",
  "Performance scales log-linearly with data (10M -> 50M)",
  "Each component contributes meaningful improvement",
];
slide.addText(takeaways.map(t => ({ text: t, options: { bullet: { code: "25B8", color: C.accent } } })), {
  x: 8.9, y: 2.1, w: 3.4, h: 4.5,
  fontSize: 11, fontFace: BODY_FONT, color: C.ice,
  lineSpacingMultiple: 1.4, paraSpaceAfter: 6, valign: "top",
});

// ============================================================
// SLIDE 19: Timeline
// ============================================================
slide = pptx.addSlide();
lightBg(slide);
addTitleBar(slide, "Project Timeline & Resources", 19);

const phases = [
  { name: "Data & Infra", months: "M1-2", color: C.deepBlue },
  { name: "Architecture", months: "M2-4", color: C.teal },
  { name: "Pre-training", months: "M4-6", color: C.accent },
  { name: "LAM Dev", months: "M5-7", color: C.gold },
  { name: "Evaluation", months: "M7-9", color: C.deepBlue },
  { name: "Paper", months: "M9-11", color: C.teal },
  { name: "Submit", months: "M11-12", color: C.red },
];

// Timeline bar chart
const barY = 1.8;
const barH = 0.5;
const monthWidth = 0.88; // 12 months across ~10.5 inches
const startX = 1.5;

// Month labels
for (let m = 1; m <= 12; m++) {
  slide.addText(`M${m}`, {
    x: startX + (m - 1) * monthWidth, y: 1.4, w: monthWidth, h: 0.3,
    fontSize: 9, fontFace: BODY_FONT, color: C.midGray, align: "center",
  });
}

phases.forEach((phase, i) => {
  const startMonth = parseInt(phase.months.split("-")[0].replace("M", ""));
  const endMonth = parseInt(phase.months.split("-")[1]);
  const x = startX + (startMonth - 1) * monthWidth;
  const w = (endMonth - startMonth + 1) * monthWidth;
  const y = barY + i * 0.6;

  slide.addShape(pptx.shapes.ROUNDED_RECTANGLE, {
    x, y, w, h: barH,
    fill: { color: phase.color }, rectRadius: 0.08,
  });
  slide.addText(phase.name, {
    x, y, w, h: barH,
    fontSize: 10, fontFace: BODY_FONT, bold: true,
    color: C.white, align: "center", valign: "middle",
  });
});

// Budget section
addCard(slide, 0.7, 6.0, 11.9, 1.2, C.white);
slide.addText("Estimated Budget", {
  x: 1.0, y: 6.1, w: 2.0, h: 0.4,
  fontSize: 14, fontFace: BODY_FONT, bold: true, color: C.navy,
});

const budgetItems = [
  "Compute (8xA100, 3mo): $30-50K",
  "Storage (5TB): $1.5K",
  "API costs (text gen): $2-5K",
  "Total: ~$40-60K",
];
slide.addText(budgetItems.join("  |  "), {
  x: 1.0, y: 6.5, w: 11.3, h: 0.4,
  fontSize: 12, fontFace: BODY_FONT, color: C.darkText, align: "center",
});

// ============================================================
// SLIDE 20: Conclusion
// ============================================================
slide = pptx.addSlide();
darkBg(slide);

slide.addShape(pptx.shapes.RECTANGLE, {
  x: 0, y: 0, w: 13.33, h: 0.06,
  fill: { color: C.accent },
});

slide.addText("Conclusion & Next Steps", {
  x: 0.7, y: 0.4, w: 12.0, h: 0.8,
  fontSize: 34, fontFace: TITLE_FONT, bold: true, color: C.white,
});
addSlideNum(slide, 20, true);

// Key contributions
addCard(slide, 0.7, 1.5, 5.8, 3.0, "1A2255");
slide.addText("Key Contributions", {
  x: 1.0, y: 1.7, w: 5.2, h: 0.4,
  fontSize: 16, fontFace: BODY_FONT, bold: true, color: C.accent,
});
const contribs = [
  "First SSM/Mamba architecture for single-cell genomics",
  "Knowledge-grounded pre-training (GO/KEGG/PPI)",
  "Zero-shot cell type annotation via natural language",
  "Hybrid continuous-discrete tokenization",
  "Comprehensive 7-task benchmark suite",
];
slide.addText(contribs.map(t => ({ text: t, options: { bullet: { code: "2713", color: C.accent } } })), {
  x: 1.0, y: 2.2, w: 5.2, h: 2.1,
  fontSize: 12, fontFace: BODY_FONT, color: C.ice,
  lineSpacingMultiple: 1.4, paraSpaceAfter: 3,
});

// Next steps
addCard(slide, 7.0, 1.5, 5.6, 3.0, "1A2255");
slide.addText("Next Steps", {
  x: 7.3, y: 1.7, w: 5.0, h: 0.4,
  fontSize: 16, fontFace: BODY_FONT, bold: true, color: C.gold,
});
const nextSteps = [
  "Multi-omics integration (ATAC-seq, spatial)",
  "Cross-species pre-training (mouse, zebrafish)",
  "Scale to 100M+ cells",
  "Interactive NL querying interface for biologists",
  "Clinical applications (disease cell type discovery)",
];
slide.addText(nextSteps.map(t => ({ text: t, options: { bullet: { code: "25B8", color: C.gold } } })), {
  x: 7.3, y: 2.2, w: 5.0, h: 2.1,
  fontSize: 12, fontFace: BODY_FONT, color: C.ice,
  lineSpacingMultiple: 1.4, paraSpaceAfter: 3,
});

// Open source
addCard(slide, 0.7, 4.8, 11.9, 1.0, C.accent);
slide.addText("Open Source Release: github.com/cellm-project/cellm", {
  x: 1.0, y: 4.9, w: 11.3, h: 0.4,
  fontSize: 18, fontFace: BODY_FONT, bold: true, color: C.white, align: "center",
});
slide.addText("Code, pre-trained models, tokenizer, benchmark suite, and training scripts", {
  x: 1.0, y: 5.3, w: 11.3, h: 0.4,
  fontSize: 12, fontFace: BODY_FONT, color: C.white, align: "center",
});

// Bottom message
slide.addText("Thank you!", {
  x: 0.7, y: 6.2, w: 11.9, h: 0.6,
  fontSize: 28, fontFace: TITLE_FONT, bold: true, color: C.ice, align: "center",
});

// ============================================================
// Save
// ============================================================
const outPath = "/Users/cgxmac/Desktop/skill/research_plan-workspace/iteration-1/eval-scRNA-LLM/without_skill/outputs/presentation/CeLLM_presentation.pptx";
pptx.writeFile({ fileName: outPath })
  .then(() => console.log(`Presentation saved to ${outPath}`))
  .catch(err => console.error("Error:", err));
