#!/usr/bin/env python3
"""Generate CeLLM research presentation using python-pptx."""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
import os

# Colors
NAVY = RGBColor(0x1E, 0x27, 0x61)
DEEP_BLUE = RGBColor(0x06, 0x5A, 0x82)
TEAL = RGBColor(0x1C, 0x72, 0x93)
ICE = RGBColor(0xCA, 0xDC, 0xFC)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
OFF_WHITE = RGBColor(0xF0, 0xF4, 0xF8)
DARK_TEXT = RGBColor(0x1A, 0x1A, 0x2E)
MID_GRAY = RGBColor(0x6B, 0x72, 0x80)
ACCENT = RGBColor(0x00, 0xA8, 0x96)
GOLD = RGBColor(0xF4, 0xA2, 0x61)
RED = RGBColor(0xE6, 0x39, 0x46)
LIGHT_GRAY = RGBColor(0xE8, 0xEC, 0xF1)
DARK_BG = RGBColor(0x1A, 0x22, 0x55)

prs = Presentation()
prs.slide_width = Inches(13.33)
prs.slide_height = Inches(7.5)

# Use blank layout
blank_layout = prs.slide_layouts[6]


def add_rect(slide, left, top, width, height, fill_color):
    shape = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, left, top, width, height
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    shape.line.fill.background()
    return shape


def add_rounded_rect(slide, left, top, width, height, fill_color):
    shape = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    shape.line.fill.background()
    return shape


def add_text_box(slide, left, top, width, height, text, font_size=14,
                 font_color=DARK_TEXT, bold=False, italic=False,
                 alignment=PP_ALIGN.LEFT, font_name="Calibri",
                 anchor=MSO_ANCHOR.TOP):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = font_color
    p.font.bold = bold
    p.font.italic = italic
    p.font.name = font_name
    p.alignment = alignment
    tf.auto_size = None
    return txBox


def add_bullet_text(slide, left, top, width, height, items, font_size=13,
                    font_color=DARK_TEXT, bullet_char="\u2022", font_name="Calibri",
                    line_spacing=1.5):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = f"{bullet_char} {item}"
        p.font.size = Pt(font_size)
        p.font.color.rgb = font_color
        p.font.name = font_name
        p.space_after = Pt(4)
    return txBox


def dark_bg(slide):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = NAVY


def light_bg(slide):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = OFF_WHITE


def add_title_bar(slide, title_text):
    add_rect(slide, Inches(0), Inches(0), Inches(13.33), Inches(1.1), NAVY)
    add_text_box(slide, Inches(0.7), Inches(0.15), Inches(11.0), Inches(0.8),
                 title_text, font_size=28, font_color=WHITE, bold=True, font_name="Georgia")


# ============================================================
# SLIDE 1: Title
# ============================================================
slide = prs.slides.add_slide(blank_layout)
dark_bg(slide)
add_rect(slide, Inches(0), Inches(0), Inches(13.33), Inches(0.06), ACCENT)

add_text_box(slide, Inches(1.0), Inches(1.5), Inches(11.33), Inches(1.2),
             "CeLLM", font_size=60, font_color=WHITE, bold=True, font_name="Georgia")
add_text_box(slide, Inches(1.0), Inches(2.8), Inches(11.33), Inches(1.2),
             "An Efficient Foundation Model Bridging\nSingle-Cell Genomics and Natural Language",
             font_size=26, font_color=ICE, font_name="Calibri")
add_rect(slide, Inches(1.0), Inches(4.3), Inches(2.5), Inches(0.04), ACCENT)
add_text_box(slide, Inches(1.0), Inches(4.6), Inches(6.0), Inches(0.5),
             "Target Venue: NeurIPS 2026 / Nature Methods",
             font_size=16, font_color=GOLD, italic=True)
add_text_box(slide, Inches(1.0), Inches(5.3), Inches(6.0), Inches(0.5),
             "Research Plan & Technical Overview",
             font_size=14, font_color=MID_GRAY)
add_text_box(slide, Inches(1.0), Inches(6.5), Inches(3.0), Inches(0.4),
             "April 2026", font_size=12, font_color=MID_GRAY)

# ============================================================
# SLIDE 2: Motivation
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Motivation: The Single-Cell Revolution")

add_rounded_rect(slide, Inches(0.7), Inches(1.5), Inches(5.5), Inches(5.3), WHITE)
add_text_box(slide, Inches(1.0), Inches(1.7), Inches(5.0), Inches(0.5),
             "The Data Explosion", font_size=18, font_color=NAVY, bold=True, font_name="Georgia")
add_bullet_text(slide, Inches(1.0), Inches(2.3), Inches(4.8), Inches(4.0), [
    "100M+ cells profiled in public atlases (CellxGene, HCA)",
    "Thousands of datasets across tissues, diseases, species",
    "Standard tools (Scanpy, Seurat) lack cross-dataset generalization",
    "Foundation model paradigm: pre-train once, fine-tune for many tasks",
    "Success of LLMs in NLP inspires analogous approaches for genomics",
], font_size=13)

# Stats box
add_rounded_rect(slide, Inches(7.0), Inches(1.5), Inches(5.6), Inches(2.4), NAVY)
add_text_box(slide, Inches(7.3), Inches(1.6), Inches(2.3), Inches(0.9),
             "100M+", font_size=44, font_color=ACCENT, bold=True, font_name="Georgia")
add_text_box(slide, Inches(7.3), Inches(2.4), Inches(2.3), Inches(0.5),
             "cells in public atlases", font_size=12, font_color=ICE)
add_text_box(slide, Inches(9.8), Inches(1.6), Inches(2.3), Inches(0.9),
             "500+", font_size=44, font_color=GOLD, bold=True, font_name="Georgia")
add_text_box(slide, Inches(9.8), Inches(2.4), Inches(2.3), Inches(0.5),
             "distinct cell types", font_size=12, font_color=ICE)

add_rounded_rect(slide, Inches(7.0), Inches(4.2), Inches(5.6), Inches(2.6), WHITE)
add_text_box(slide, Inches(7.3), Inches(4.4), Inches(5.0), Inches(0.4),
             "Key Insight", font_size=16, font_color=NAVY, bold=True, font_name="Georgia")
add_text_box(slide, Inches(7.3), Inches(4.9), Inches(5.0), Inches(1.6),
             "Genes are analogous to tokens in a vocabulary. A cell's expression profile is a \"sentence\" of gene tokens. This analogy enables transformer/LLM architectures for single-cell data.",
             font_size=13, font_color=DARK_TEXT, italic=True)

# ============================================================
# SLIDE 3: Problem Statement
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Problem: Three Critical Limitations")

problems = [
    ("1", "Computational Bottleneck", RED,
     "Transformer attention is O(n^2) with ~20,000 genes. Most models subsample to <3,000 genes. Full-genome modeling requires linear architectures."),
    ("2", "No Biological Grounding", GOLD,
     "Learned embeddings lack connection to known biology. GO, KEGG, PPI knowledge is not incorporated. Attention maps rarely align with validated pathways."),
    ("3", "No Language Interface", TEAL,
     "Outputs are numerical embeddings only. No natural language querying capability. Biologists need specialized pipelines for interpretation."),
]

for i, (num, title, color, desc) in enumerate(problems):
    x = Inches(0.7 + i * 4.1)
    add_rounded_rect(slide, x, Inches(1.5), Inches(3.8), Inches(5.2), WHITE)

    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, x + Inches(0.2), Inches(1.7), Inches(0.6), Inches(0.6))
    circle.fill.solid()
    circle.fill.fore_color.rgb = color
    circle.line.fill.background()
    add_text_box(slide, x + Inches(0.2), Inches(1.72), Inches(0.6), Inches(0.6),
                 num, font_size=22, font_color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    add_text_box(slide, x + Inches(1.0), Inches(1.75), Inches(2.6), Inches(0.5),
                 title, font_size=17, font_color=NAVY, bold=True, font_name="Georgia")
    add_text_box(slide, x + Inches(0.3), Inches(2.6), Inches(3.2), Inches(3.8),
                 desc, font_size=13, font_color=DARK_TEXT)

# ============================================================
# SLIDE 4: Related Work
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Related Work: Existing Foundation Models")

# Simple text-based table representation
table_data = [
    ["Model", "Params", "Cells", "Tokenization", "Complexity", "NL Interface"],
    ["scBERT (2022)", "10M", "1M", "Binned", "O(n^2)", "No"],
    ["Geneformer (2023)", "10M", "30M", "Rank-value", "O(n^2)", "No"],
    ["scGPT (2024)", "50M", "33M", "Gene+value", "O(n^2)", "No"],
    ["scFoundation (2024)", "100M", "50M", "Binned", "O(n^2)", "No"],
    ["UCE (2024)", "650M+", "36M", "ESM embed.", "O(n^2)", "No"],
    ["Cell2Sentence", "124M", "~1M", "Text conv.", "O(n^2)", "Partial"],
    ["CeLLM (Ours)", "52M", "50M+", "Hybrid", "O(n)", "Yes"],
]

rows, cols = len(table_data), len(table_data[0])
table = slide.shapes.add_table(rows, cols, Inches(0.7), Inches(1.5), Inches(11.9), Inches(3.5)).table

col_widths = [Inches(2.2), Inches(1.2), Inches(1.2), Inches(1.8), Inches(1.5), Inches(1.5)]
for i, w in enumerate(col_widths):
    table.columns[i].width = w

for r in range(rows):
    for c in range(cols):
        cell = table.cell(r, c)
        cell.text = table_data[r][c]
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(11)
        p.font.name = "Calibri"
        p.alignment = PP_ALIGN.CENTER
        if r == 0:
            p.font.bold = True
            p.font.color.rgb = WHITE
            cell.fill.solid()
            cell.fill.fore_color.rgb = NAVY
        elif r == rows - 1:
            p.font.bold = True
            p.font.color.rgb = ACCENT
        else:
            p.font.color.rgb = DARK_TEXT

add_text_box(slide, Inches(0.7), Inches(5.3), Inches(11.9), Inches(0.6),
             "Gap: No existing model combines O(n) complexity, knowledge grounding, AND natural language interface",
             font_size=15, font_color=DEEP_BLUE, bold=True, italic=True, alignment=PP_ALIGN.CENTER)

# ============================================================
# SLIDE 5: Architecture Overview
# ============================================================
slide = prs.slides.add_slide(blank_layout)
dark_bg(slide)
add_text_box(slide, Inches(0.7), Inches(0.3), Inches(12.0), Inches(0.8),
             "CeLLM Architecture Overview", font_size=32, font_color=WHITE, bold=True, font_name="Georgia")

modules = [
    ("Module 1", "Mamba-SSM\nGene Encoder", DEEP_BLUE,
     "\u25B8 Linear-time O(n)\n\u25B8 Full 20K genes\n\u25B8 12 Mamba blocks\n\u25B8 SSM state propagation"),
    ("Module 2", "Knowledge\nIntegration (KIM)", TEAL,
     "\u25B8 GO/KEGG/PPI graph\n\u25B8 3-layer GAT\n\u25B8 Gated cross-attention\n\u25B8 Biology-grounded"),
    ("Module 3", "Language\nAlignment (LAM)", ACCENT,
     "\u25B8 CLIP-style contrast\n\u25B8 PubMedBERT text enc.\n\u25B8 Zero-shot annotation\n\u25B8 NL querying"),
]

for i, (label, name, color, desc) in enumerate(modules):
    x = Inches(0.7 + i * 4.1)
    add_rounded_rect(slide, x, Inches(1.5), Inches(3.8), Inches(5.0), DARK_BG)

    tag = add_rounded_rect(slide, x + Inches(0.3), Inches(1.7), Inches(1.5), Inches(0.4), color)
    add_text_box(slide, x + Inches(0.3), Inches(1.7), Inches(1.5), Inches(0.4),
                 label, font_size=11, font_color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    add_text_box(slide, x + Inches(0.3), Inches(2.3), Inches(3.2), Inches(0.9),
                 name, font_size=20, font_color=WHITE, bold=True, font_name="Georgia")

    add_rect(slide, x + Inches(0.3), Inches(3.3), Inches(1.5), Inches(0.03), color)

    add_text_box(slide, x + Inches(0.3), Inches(3.6), Inches(3.2), Inches(2.6),
                 desc, font_size=14, font_color=ICE)

# Arrows
add_text_box(slide, Inches(4.55), Inches(3.6), Inches(0.6), Inches(0.6),
             "\u27A1", font_size=24, font_color=GOLD, alignment=PP_ALIGN.CENTER)
add_text_box(slide, Inches(8.65), Inches(3.6), Inches(0.6), Inches(0.6),
             "\u27A1", font_size=24, font_color=GOLD, alignment=PP_ALIGN.CENTER)

# ============================================================
# SLIDE 6: Mamba Encoder
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Module 1: Mamba-SSM Gene Expression Encoder")

add_rounded_rect(slide, Inches(0.7), Inches(1.5), Inches(6.0), Inches(5.3), WHITE)
add_text_box(slide, Inches(1.0), Inches(1.7), Inches(5.4), Inches(0.5),
             "Selective State-Space Model", font_size=18, font_color=NAVY, bold=True, font_name="Georgia")
add_bullet_text(slide, Inches(1.0), Inches(2.3), Inches(5.4), Inches(4.0), [
    "Input-dependent discretization parameters",
    "Content-aware selective scanning",
    "State propagation captures long-range gene dependencies",
    "12 stacked Mamba blocks, d=512, state_dim=16",
    "Processes ALL ~20,000 genes without subsampling",
    "39x fewer FLOPs than standard self-attention",
], font_size=13)

add_rounded_rect(slide, Inches(7.2), Inches(1.5), Inches(5.4), Inches(2.4), NAVY)
add_text_box(slide, Inches(7.5), Inches(1.65), Inches(4.8), Inches(0.4),
             "SSM Equations", font_size=14, font_color=ACCENT, bold=True)
add_text_box(slide, Inches(7.5), Inches(2.1), Inches(4.8), Inches(1.6),
             "s(t) = A * s(t-1) + B * x(t)\ny(t) = C * s(t) + D * x(t)\n\nA, B, C are input-dependent (selective)",
             font_size=13, font_color=ICE, font_name="Consolas")

# Complexity table
add_rounded_rect(slide, Inches(7.2), Inches(4.2), Inches(5.4), Inches(2.6), WHITE)
add_text_box(slide, Inches(7.5), Inches(4.4), Inches(4.8), Inches(0.4),
             "Complexity Comparison", font_size=14, font_color=NAVY, bold=True)

comp_data = [
    ["Architecture", "Time", "20K Genes"],
    ["Transformer", "O(n^2 d)", "82 GFLOPs"],
    ["Linear Attention", "O(n d^2)", "10 GFLOPs"],
    ["Mamba (Ours)", "O(n d)", "2.1 GFLOPs"],
]
comp_table = slide.shapes.add_table(4, 3, Inches(7.5), Inches(4.9), Inches(4.8), Inches(1.6)).table
for r in range(4):
    for c in range(3):
        cell = comp_table.cell(r, c)
        cell.text = comp_data[r][c]
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(11)
        p.font.name = "Calibri"
        p.alignment = PP_ALIGN.CENTER
        if r == 0:
            p.font.bold = True
            p.font.color.rgb = WHITE
            cell.fill.solid()
            cell.fill.fore_color.rgb = NAVY
        elif r == 3:
            p.font.bold = True
            p.font.color.rgb = ACCENT
        else:
            p.font.color.rgb = DARK_TEXT

# ============================================================
# SLIDE 7: Hybrid Tokenization
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Hybrid Continuous-Discrete Tokenization")

add_rounded_rect(slide, Inches(0.7), Inches(1.5), Inches(11.9), Inches(1.2), WHITE)
add_text_box(slide, Inches(1.0), Inches(1.65), Inches(11.3), Inches(0.5),
             "h_i = W_g * Embed(gene_i) + W_b * Embed(bin_i) + W_r * residual_i + p_chr(i)",
             font_size=15, font_color=NAVY, font_name="Consolas", alignment=PP_ALIGN.CENTER)
add_text_box(slide, Inches(1.0), Inches(2.15), Inches(11.3), Inches(0.4),
             "Combined gene embedding = gene identity + expression bin + continuous residual + chromosomal position",
             font_size=11, font_color=MID_GRAY, italic=True, alignment=PP_ALIGN.CENTER)

parts = [
    ("Gene Identity", "Learned embedding for each of ~20K genes. Unique gene token.", DEEP_BLUE),
    ("Discrete Bin", "Expression level binned into 51 levels. 0 = not expressed.", TEAL),
    ("Continuous Residual", "log1p(count) minus bin center. Preserves quantitative info.", ACCENT),
    ("Chr. Position", "Chromosomal coordinate encoding. Biologically meaningful order.", GOLD),
]
for i, (title, desc, color) in enumerate(parts):
    x = Inches(0.7 + i * 3.08)
    add_rounded_rect(slide, x, Inches(3.0), Inches(2.85), Inches(3.6), WHITE)
    tag = add_rounded_rect(slide, x + Inches(0.2), Inches(3.2), Inches(2.45), Inches(0.4), color)
    add_text_box(slide, x + Inches(0.2), Inches(3.2), Inches(2.45), Inches(0.4),
                 title, font_size=13, font_color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    add_text_box(slide, x + Inches(0.3), Inches(3.8), Inches(2.3), Inches(2.5),
                 desc, font_size=13, font_color=DARK_TEXT)

# ============================================================
# SLIDE 8: KIM
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Module 2: Knowledge Integration Module (KIM)")

add_rounded_rect(slide, Inches(0.7), Inches(1.5), Inches(5.8), Inches(5.3), WHITE)
add_text_box(slide, Inches(1.0), Inches(1.7), Inches(5.2), Inches(0.5),
             "Graph Attention over Gene-Pathway Network",
             font_size=16, font_color=NAVY, bold=True, font_name="Georgia")
add_bullet_text(slide, Inches(1.0), Inches(2.3), Inches(5.2), Inches(4.0), [
    "Heterogeneous graph with gene + pathway nodes",
    "Gene Ontology (GO): biological process, molecular function",
    "KEGG pathways: metabolic and signaling pathways",
    "Protein-protein interactions (PPI) from STRING",
    "3-layer GAT with 4 attention heads",
    "Gated cross-attention fusion with Mamba output",
    "Learned gate alpha controls knowledge influence",
], font_size=13)

add_rounded_rect(slide, Inches(7.0), Inches(1.5), Inches(5.6), Inches(2.5), NAVY)
add_text_box(slide, Inches(7.3), Inches(1.65), Inches(5.0), Inches(0.4),
             "Gated Fusion", font_size=14, font_color=ACCENT, bold=True)
add_text_box(slide, Inches(7.3), Inches(2.1), Inches(5.0), Inches(1.7),
             "h_fused = h_mamba + alpha * CrossAttn(h_mamba, Z_KIM)\nalpha = sigmoid(W * [h_mamba; attn_out])\nLearned gating balances encoder vs knowledge",
             font_size=13, font_color=ICE, font_name="Consolas")

add_rounded_rect(slide, Inches(7.0), Inches(4.3), Inches(5.6), Inches(2.5), WHITE)
add_text_box(slide, Inches(7.3), Inches(4.5), Inches(5.0), Inches(0.4),
             "Why Knowledge Grounding?", font_size=14, font_color=NAVY, bold=True)
add_bullet_text(slide, Inches(7.3), Inches(5.0), Inches(5.0), Inches(1.5), [
    "Genes in the same pathway SHOULD have related embeddings",
    "Decades of curated biological knowledge available",
    "Improves interpretability and performance (+1.6% F1)",
], font_size=12, bullet_char="\u2713")

# ============================================================
# SLIDE 9: LAM
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Module 3: Language Alignment Module (LAM)")

add_rounded_rect(slide, Inches(0.7), Inches(1.5), Inches(5.8), Inches(5.3), WHITE)
add_text_box(slide, Inches(1.0), Inches(1.7), Inches(5.2), Inches(0.5),
             "CLIP-Style Cell-Text Alignment",
             font_size=16, font_color=NAVY, bold=True, font_name="Georgia")
add_bullet_text(slide, Inches(1.0), Inches(2.3), Inches(5.2), Inches(2.5), [
    "Cell embeddings projected to shared alignment space",
    "Text descriptions encoded by frozen PubMedBERT",
    "Symmetric contrastive loss (InfoNCE)",
    "Learnable temperature parameter",
    "~500K cell-text pairs for training",
], font_size=13)

add_text_box(slide, Inches(1.0), Inches(4.8), Inches(5.2), Inches(0.4),
             "Cell-Text Pair Sources", font_size=14, font_color=NAVY, bold=True)
add_bullet_text(slide, Inches(1.0), Inches(5.2), Inches(5.2), Inches(1.3), [
    "Cell Ontology (CL) definitions",
    "Marker gene descriptions (LLM-generated)",
    "Publication abstracts linked to datasets",
    "Pathway enrichment summaries (GSEA)",
], font_size=12, bullet_char="\u25B8")

add_rounded_rect(slide, Inches(7.0), Inches(1.5), Inches(5.6), Inches(5.3), NAVY)
add_text_box(slide, Inches(7.3), Inches(1.7), Inches(5.0), Inches(0.5),
             "Zero-Shot Cell Type Annotation",
             font_size=16, font_color=ACCENT, bold=True, font_name="Georgia")
add_text_box(slide, Inches(7.3), Inches(2.2), Inches(5.0), Inches(0.4),
             "No labeled training data required!", font_size=14, font_color=GOLD, italic=True)
add_text_box(slide, Inches(7.3), Inches(2.8), Inches(5.0), Inches(3.8),
             '1. Describe candidate cell types in natural language\n\n'
             '   "T cell: CD3+ lymphocyte in adaptive immunity"\n'
             '   "B cell: CD19+ antibody-producing lymphocyte"\n\n'
             '2. Encode descriptions with PubMedBERT\n\n'
             '3. Find highest cosine similarity for each cell\n\n'
             '4. Assign cell type with confidence score',
             font_size=12, font_color=ICE)

# ============================================================
# SLIDE 10: Pre-training Strategy
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Pre-training Strategy: Four Objectives")

objectives = [
    ("MGEP", "Masked Gene Expression Prediction", DEEP_BLUE,
     "Mask 15% of genes. Predict bin class + residual. Primary reconstruction loss.", "1.0"),
    ("GPCL", "Gene Program Contrastive Learning", TEAL,
     "Cells with similar gene programs should have similar embeddings.", "0.5"),
    ("KGR", "Knowledge-Grounded Regularization", ACCENT,
     "Same-pathway genes pulled closer. Triplet margin formulation.", "0.3"),
    ("CTA", "Cell-Text Alignment", GOLD,
     "Contrastive cell-text loss. Symmetric InfoNCE. Enables zero-shot.", "0.5"),
]

for i, (abbr, full_name, color, desc, weight) in enumerate(objectives):
    x = Inches(0.5 + i * 3.15)
    add_rounded_rect(slide, x, Inches(1.5), Inches(2.95), Inches(5.3), WHITE)
    tag = add_rounded_rect(slide, x + Inches(0.15), Inches(1.7), Inches(1.0), Inches(0.5), color)
    add_text_box(slide, x + Inches(0.15), Inches(1.7), Inches(1.0), Inches(0.5),
                 abbr, font_size=14, font_color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    add_text_box(slide, x + Inches(0.2), Inches(2.4), Inches(2.55), Inches(0.6),
                 full_name, font_size=12, font_color=NAVY, bold=True)
    add_text_box(slide, x + Inches(0.2), Inches(3.1), Inches(2.55), Inches(2.5),
                 desc, font_size=12, font_color=DARK_TEXT)
    add_rounded_rect(slide, x + Inches(0.15), Inches(5.9), Inches(2.65), Inches(0.4), LIGHT_GRAY)
    add_text_box(slide, x + Inches(0.15), Inches(5.9), Inches(2.65), Inches(0.4),
                 f"Weight: \u03B2 = {weight}", font_size=11, font_color=DARK_TEXT, alignment=PP_ALIGN.CENTER)

# ============================================================
# SLIDE 11: Pre-training Data
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Pre-training Data: CellxGene Census")

add_rounded_rect(slide, Inches(0.7), Inches(1.5), Inches(5.8), Inches(5.3), WHITE)
add_text_box(slide, Inches(1.0), Inches(1.7), Inches(5.2), Inches(0.4),
             "15 Tissue Types", font_size=16, font_color=NAVY, bold=True, font_name="Georgia")
add_bullet_text(slide, Inches(1.0), Inches(2.2), Inches(5.2), Inches(1.5), [
    "Brain, Blood, Lung, Heart, Liver",
    "Kidney, Intestine, Skin, Bone Marrow",
    "Pancreas, Eye, Breast, Prostate, Stomach, Spleen",
], font_size=13)
add_text_box(slide, Inches(1.0), Inches(3.9), Inches(5.2), Inches(0.4),
             "Preprocessing Pipeline", font_size=14, font_color=NAVY, bold=True)
add_bullet_text(slide, Inches(1.0), Inches(4.3), Inches(5.2), Inches(2.2), [
    "Quality control: min 200 genes, <20% mito reads",
    "Normalize to 10,000 counts per cell",
    "Log1p transformation",
    "Filter to 19,264 protein-coding genes",
    "Healthy (non-disease) samples only",
], font_size=12, bullet_char="\u25B8")

add_rounded_rect(slide, Inches(7.0), Inches(1.5), Inches(5.6), Inches(5.3), NAVY)
add_text_box(slide, Inches(7.3), Inches(1.7), Inches(5.0), Inches(0.5),
             "Data Statistics", font_size=16, font_color=WHITE, bold=True, font_name="Georgia")

stats = [("50M+", "Total cells", ACCENT), ("19,264", "Genes (vocabulary)", ACCENT),
         ("~500", "Datasets", GOLD), ("15", "Tissue types", GOLD),
         ("500+", "Cell types", ACCENT)]
for i, (val, label, color) in enumerate(stats):
    y = Inches(2.4 + i * 0.7)
    add_text_box(slide, Inches(7.5), y, Inches(2.5), Inches(0.5),
                 val, font_size=28, font_color=color, bold=True, font_name="Georgia")
    add_text_box(slide, Inches(10.2), y + Inches(0.05), Inches(2.0), Inches(0.4),
                 label, font_size=13, font_color=ICE)

# ============================================================
# SLIDE 12: Training Infrastructure
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Training Infrastructure")

infra = [
    ("GPU", "8x A100 80GB", "NVIDIA A100 GPUs\nwith NVLink", DEEP_BLUE),
    ("BF16", "Mixed Precision", "Bfloat16 for faster\ntraining with stability", TEAL),
    ("4K", "Batch Size 4,096", "64/GPU x 8 GPUs\nx 8 grad accum", ACCENT),
    ("6d", "~6 Days Training", "200,000 steps\ntotal pre-training", GOLD),
]
for i, (icon, title, desc, color) in enumerate(infra):
    x = Inches(0.5 + i * 3.15)
    add_rounded_rect(slide, x, Inches(1.5), Inches(2.95), Inches(3.5), WHITE)
    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, x + Inches(0.95), Inches(1.8), Inches(1.0), Inches(1.0))
    circle.fill.solid()
    circle.fill.fore_color.rgb = color
    circle.line.fill.background()
    add_text_box(slide, x + Inches(0.95), Inches(1.8), Inches(1.0), Inches(1.0),
                 icon, font_size=14, font_color=WHITE, bold=True, alignment=PP_ALIGN.CENTER,
                 anchor=MSO_ANCHOR.MIDDLE)
    add_text_box(slide, x + Inches(0.2), Inches(3.0), Inches(2.55), Inches(0.4),
                 title, font_size=14, font_color=NAVY, bold=True, alignment=PP_ALIGN.CENTER)
    add_text_box(slide, x + Inches(0.2), Inches(3.4), Inches(2.55), Inches(1.0),
                 desc, font_size=11, font_color=MID_GRAY, alignment=PP_ALIGN.CENTER)

add_rounded_rect(slide, Inches(0.7), Inches(5.3), Inches(11.9), Inches(1.5), WHITE)
add_text_box(slide, Inches(1.0), Inches(5.5), Inches(11.3), Inches(0.5),
             "Optimization: AdamW (lr=1e-4, wd=0.01) | Warmup: 2,000 steps | Schedule: Cosine decay",
             font_size=12, font_color=DARK_TEXT, alignment=PP_ALIGN.CENTER)
add_text_box(slide, Inches(1.0), Inches(6.1), Inches(11.3), Inches(0.5),
             "Framework: PyTorch 2.x + Mamba CUDA kernels | Logging: WandB | Total params: ~52M",
             font_size=12, font_color=MID_GRAY, alignment=PP_ALIGN.CENTER)

# ============================================================
# SLIDE 13: Annotation Results
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Results: Cell Type Annotation")

annot_data = [
    ["Dataset", "scGPT", "Geneformer", "scFoundation", "UCE", "CeLLM"],
    ["Zheng68K", "0.842", "0.811", "0.836", "0.795", "0.871"],
    ["PBMC Multi-donor", "0.876", "0.858", "0.881", "0.834", "0.893"],
    ["Pancreas", "0.921", "0.905", "0.918", "0.889", "0.935"],
]
table = slide.shapes.add_table(4, 6, Inches(0.7), Inches(1.5), Inches(11.9), Inches(2.0)).table
for r in range(4):
    for c in range(6):
        cell = table.cell(r, c)
        cell.text = annot_data[r][c]
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(12)
        p.font.name = "Calibri"
        p.alignment = PP_ALIGN.CENTER
        if r == 0:
            p.font.bold = True
            p.font.color.rgb = WHITE
            cell.fill.solid()
            cell.fill.fore_color.rgb = NAVY if c < 5 else ACCENT
        elif c == 5:
            p.font.bold = True
            p.font.color.rgb = ACCENT
        else:
            p.font.color.rgb = DARK_TEXT

add_text_box(slide, Inches(0.7), Inches(3.6), Inches(11.9), Inches(0.4),
             "Metric: Macro-F1 (higher is better)", font_size=11, font_color=MID_GRAY,
             italic=True, alignment=PP_ALIGN.CENTER)

add_rounded_rect(slide, Inches(0.7), Inches(4.2), Inches(3.8), Inches(2.5), NAVY)
add_text_box(slide, Inches(0.9), Inches(4.4), Inches(3.4), Inches(0.8),
             "+2.9%", font_size=42, font_color=ACCENT, bold=True, font_name="Georgia",
             alignment=PP_ALIGN.CENTER)
add_text_box(slide, Inches(0.9), Inches(5.2), Inches(3.4), Inches(0.4),
             "avg. improvement over scGPT", font_size=12, font_color=ICE, alignment=PP_ALIGN.CENTER)

add_rounded_rect(slide, Inches(5.0), Inches(4.2), Inches(7.6), Inches(2.5), WHITE)
add_text_box(slide, Inches(5.3), Inches(4.4), Inches(7.0), Inches(0.4),
             "Key Findings", font_size=14, font_color=NAVY, bold=True)
add_bullet_text(slide, Inches(5.3), Inches(4.9), Inches(7.0), Inches(1.5), [
    "Consistent gains across all datasets",
    "Largest gain on diverse Zheng68K (+3.4%)",
    "Full-genome modeling captures rare cell types better",
    "State-of-the-art on all 3 benchmarks",
], font_size=12, bullet_char="\u2713")

# ============================================================
# SLIDE 14: Integration Results
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Results: Batch Integration")

integ_data = [
    ["Dataset", "scGPT", "Geneformer", "scFoundation", "UCE", "CeLLM"],
    ["PBMC Multi-batch", "0.782", "0.745", "0.791", "0.768", "0.812"],
    ["Lung Atlas", "0.756", "0.721", "0.749", "0.733", "0.778"],
]
table = slide.shapes.add_table(3, 6, Inches(0.7), Inches(1.5), Inches(11.9), Inches(1.5)).table
for r in range(3):
    for c in range(6):
        cell = table.cell(r, c)
        cell.text = integ_data[r][c]
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(12)
        p.font.name = "Calibri"
        p.alignment = PP_ALIGN.CENTER
        if r == 0:
            p.font.bold = True
            p.font.color.rgb = WHITE
            cell.fill.solid()
            cell.fill.fore_color.rgb = NAVY if c < 5 else ACCENT
        elif c == 5:
            p.font.bold = True
            p.font.color.rgb = ACCENT
        else:
            p.font.color.rgb = DARK_TEXT

add_text_box(slide, Inches(0.7), Inches(3.2), Inches(11.9), Inches(0.4),
             "Metric: Overall score = avg(ASW_celltype, ASW_batch, AMI) (higher is better)",
             font_size=11, font_color=MID_GRAY, italic=True, alignment=PP_ALIGN.CENTER)

add_rounded_rect(slide, Inches(0.7), Inches(3.9), Inches(5.8), Inches(2.9), WHITE)
add_text_box(slide, Inches(1.0), Inches(4.1), Inches(5.2), Inches(0.4),
             "What This Measures", font_size=16, font_color=NAVY, bold=True)
add_bullet_text(slide, Inches(1.0), Inches(4.6), Inches(5.2), Inches(2.0), [
    "Batch mixing: Are technical batch effects removed?",
    "Bio conservation: Are real biological differences preserved?",
    "KIM helps distinguish technical vs biological variation",
], font_size=13)

add_rounded_rect(slide, Inches(7.0), Inches(3.9), Inches(5.6), Inches(2.9), NAVY)
add_text_box(slide, Inches(7.2), Inches(4.2), Inches(5.2), Inches(1.0),
             "+3.0%", font_size=48, font_color=ACCENT, bold=True, font_name="Georgia",
             alignment=PP_ALIGN.CENTER)
add_text_box(slide, Inches(7.2), Inches(5.2), Inches(5.2), Inches(0.8),
             "average improvement over scGPT\nacross integration benchmarks",
             font_size=14, font_color=ICE, alignment=PP_ALIGN.CENTER)

# ============================================================
# SLIDE 15: Perturbation Results
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Results: Perturbation Prediction")

pert_data = [
    ["Dataset", "scGPT", "Geneformer", "scFoundation", "CeLLM"],
    ["Norman CRISPR", "0.892", "0.845", "0.878", "0.911"],
    ["Replogle K562", "0.834", "0.801", "0.841", "0.858"],
]
table = slide.shapes.add_table(3, 5, Inches(0.7), Inches(1.5), Inches(11.9), Inches(1.5)).table
for r in range(3):
    for c in range(5):
        cell = table.cell(r, c)
        cell.text = pert_data[r][c]
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(12)
        p.font.name = "Calibri"
        p.alignment = PP_ALIGN.CENTER
        if r == 0:
            p.font.bold = True
            p.font.color.rgb = WHITE
            cell.fill.solid()
            cell.fill.fore_color.rgb = NAVY if c < 4 else ACCENT
        elif c == 4:
            p.font.bold = True
            p.font.color.rgb = ACCENT
        else:
            p.font.color.rgb = DARK_TEXT

add_text_box(slide, Inches(0.7), Inches(3.2), Inches(11.9), Inches(0.4),
             "Metric: Pearson correlation r (higher is better)",
             font_size=11, font_color=MID_GRAY, italic=True, alignment=PP_ALIGN.CENTER)

add_rounded_rect(slide, Inches(0.7), Inches(3.9), Inches(5.8), Inches(2.9), WHITE)
add_text_box(slide, Inches(1.0), Inches(4.1), Inches(5.2), Inches(0.4),
             "Why KIM Helps Perturbation Prediction", font_size=14, font_color=NAVY, bold=True)
add_bullet_text(slide, Inches(1.0), Inches(4.6), Inches(5.2), Inches(2.0), [
    "Perturbing gene X affects downstream pathway members",
    "KIM encodes gene-pathway relationships explicitly",
    "Model propagates effects through known networks",
    "Full-genome context captures indirect effects",
], font_size=12)

add_rounded_rect(slide, Inches(7.0), Inches(3.9), Inches(5.6), Inches(2.9), NAVY)
add_text_box(slide, Inches(7.2), Inches(4.1), Inches(5.2), Inches(1.2),
             "0.911", font_size=56, font_color=ACCENT, bold=True, font_name="Georgia",
             alignment=PP_ALIGN.CENTER)
add_text_box(slide, Inches(7.2), Inches(5.3), Inches(5.2), Inches(0.8),
             "Pearson r on Norman CRISPR\n(+1.9% over scGPT)",
             font_size=14, font_color=ICE, alignment=PP_ALIGN.CENTER)

# ============================================================
# SLIDE 16: Zero-Shot
# ============================================================
slide = prs.slides.add_slide(blank_layout)
dark_bg(slide)
add_text_box(slide, Inches(0.7), Inches(0.3), Inches(12.0), Inches(0.8),
             "Zero-Shot Cell Type Discovery", font_size=32, font_color=WHITE, bold=True, font_name="Georgia")
add_text_box(slide, Inches(0.7), Inches(1.0), Inches(12.0), Inches(0.5),
             "A Novel Capability -- No Other Foundation Model Can Do This",
             font_size=16, font_color=GOLD, italic=True)

add_rounded_rect(slide, Inches(0.7), Inches(1.8), Inches(5.8), Inches(4.8), DARK_BG)
add_text_box(slide, Inches(1.0), Inches(2.0), Inches(5.2), Inches(0.4),
             "How It Works", font_size=16, font_color=ACCENT, bold=True)
add_text_box(slide, Inches(1.0), Inches(2.5), Inches(5.2), Inches(3.8),
             "1. Biologist writes natural language descriptions\n   of expected cell types\n\n"
             "2. LAM encodes descriptions into shared space\n\n"
             "3. Each cell is matched to closest description\n   by cosine similarity\n\n"
             "4. No labeled training data required!\n\n"
             "5. Works on completely new tissues and organisms",
             font_size=13, font_color=ICE)

add_rounded_rect(slide, Inches(7.0), Inches(1.8), Inches(5.6), Inches(2.2), ACCENT)
add_text_box(slide, Inches(7.2), Inches(1.9), Inches(5.2), Inches(1.2),
             "68.4%", font_size=60, font_color=WHITE, bold=True, font_name="Georgia",
             alignment=PP_ALIGN.CENTER)
add_text_box(slide, Inches(7.2), Inches(3.0), Inches(5.2), Inches(0.8),
             "Accuracy@1 on held-out novel tissues\nCompetitive with supervised methods",
             font_size=12, font_color=WHITE, alignment=PP_ALIGN.CENTER)

add_rounded_rect(slide, Inches(7.0), Inches(4.3), Inches(5.6), Inches(2.3), DARK_BG)
add_text_box(slide, Inches(7.3), Inches(4.5), Inches(5.0), Inches(0.4),
             "Impact", font_size=14, font_color=GOLD, bold=True)
add_bullet_text(slide, Inches(7.3), Inches(5.0), Inches(5.0), Inches(1.3), [
    "Democratizes single-cell analysis",
    "No computational expertise required",
    "Enables rapid exploration of new datasets",
    "Paradigm shift from supervised to zero-shot",
], font_size=12, font_color=ICE, bullet_char="\u2713")

# ============================================================
# SLIDE 17: Efficiency
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Computational Efficiency")

eff_data = [
    ["Model", "Genes Input", "Time/Step", "Memory", "Full Genome?"],
    ["scGPT", "3,000", "142 ms", "24.3 GB", "No"],
    ["Geneformer", "2,048", "89 ms", "12.1 GB", "No"],
    ["scFoundation", "19,264", "387 ms", "62.4 GB", "Yes"],
    ["CeLLM", "19,264", "98 ms", "18.7 GB", "Yes"],
]
table = slide.shapes.add_table(5, 5, Inches(0.7), Inches(1.5), Inches(11.9), Inches(2.5)).table
for r in range(5):
    for c in range(5):
        cell = table.cell(r, c)
        cell.text = eff_data[r][c]
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(12)
        p.font.name = "Calibri"
        p.alignment = PP_ALIGN.CENTER
        if r == 0:
            p.font.bold = True
            p.font.color.rgb = WHITE
            cell.fill.solid()
            cell.fill.fore_color.rgb = NAVY
        elif r == 4:
            p.font.bold = True
            p.font.color.rgb = ACCENT
        else:
            p.font.color.rgb = DARK_TEXT

add_text_box(slide, Inches(0.7), Inches(4.2), Inches(11.9), Inches(0.3),
             "Measured on A100 80GB with batch size 64", font_size=10, font_color=MID_GRAY,
             italic=True, alignment=PP_ALIGN.CENTER)

eff_stats = [("3.9x", "Faster than\nscFoundation", DEEP_BLUE),
             ("3.3x", "Less memory\nthan scFoundation", TEAL),
             ("100%", "Full genome\nprocessing", ACCENT)]
for i, (val, label, color) in enumerate(eff_stats):
    x = Inches(0.7 + i * 4.2)
    add_rounded_rect(slide, x, Inches(4.8), Inches(3.8), Inches(2.2), WHITE)
    add_text_box(slide, x + Inches(0.1), Inches(4.9), Inches(3.6), Inches(1.0),
                 val, font_size=42, font_color=color, bold=True, font_name="Georgia",
                 alignment=PP_ALIGN.CENTER)
    add_text_box(slide, x + Inches(0.1), Inches(5.9), Inches(3.6), Inches(0.8),
                 label, font_size=13, font_color=DARK_TEXT, alignment=PP_ALIGN.CENTER)

# ============================================================
# SLIDE 18: Ablation Studies
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Ablation Studies")

abl_data = [
    ["Variant", "Annot. F1", "Integration", "Params"],
    ["CeLLM (full)", "0.871", "0.812", "52M"],
    ["  - KIM", "0.855", "0.798", "45M"],
    ["  - LAM", "0.862", "0.805", "48M"],
    ["  - KIM - LAM", "0.848", "0.791", "42M"],
    ["Transformer backbone", "0.859", "0.801", "58M"],
    ["Linear Attention", "0.851", "0.795", "50M"],
    ["Binned tokenization", "0.843", "0.788", "52M"],
    ["Rank-value tokenization", "0.839", "0.785", "52M"],
    ["Random gene order", "0.856", "0.794", "52M"],
    ["10M pre-train cells", "0.831", "0.772", "52M"],
    ["30M pre-train cells", "0.858", "0.799", "52M"],
]
table = slide.shapes.add_table(12, 4, Inches(0.7), Inches(1.4), Inches(7.5), Inches(5.0)).table
table.columns[0].width = Inches(2.8)
table.columns[1].width = Inches(1.5)
table.columns[2].width = Inches(1.5)
table.columns[3].width = Inches(1.0)
for r in range(12):
    for c in range(4):
        cell = table.cell(r, c)
        cell.text = abl_data[r][c]
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(10)
        p.font.name = "Calibri"
        p.alignment = PP_ALIGN.CENTER
        if r == 0:
            p.font.bold = True
            p.font.color.rgb = WHITE
            cell.fill.solid()
            cell.fill.fore_color.rgb = NAVY
        elif r == 1:
            p.font.bold = True
            p.font.color.rgb = ACCENT
        else:
            p.font.color.rgb = DARK_TEXT

add_rounded_rect(slide, Inches(8.6), Inches(1.4), Inches(4.0), Inches(5.4), NAVY)
add_text_box(slide, Inches(8.9), Inches(1.6), Inches(3.4), Inches(0.4),
             "Key Takeaways", font_size=16, font_color=ACCENT, bold=True)
add_bullet_text(slide, Inches(8.9), Inches(2.1), Inches(3.4), Inches(4.5), [
    "Mamba > Transformer (+1.2%) with fewer params",
    "KIM adds +1.6% F1 via knowledge grounding",
    "Hybrid tokenization beats binned (+2.8%)",
    "Chromosomal ordering gives +1.5%",
    "Performance scales log-linearly with data",
    "Each component contributes meaningful gain",
], font_size=11, font_color=ICE, bullet_char="\u25B8")

# ============================================================
# SLIDE 19: Timeline
# ============================================================
slide = prs.slides.add_slide(blank_layout)
light_bg(slide)
add_title_bar(slide, "Project Timeline & Resources")

# Timeline bars
phases = [
    ("Data & Infra", 1, 2, DEEP_BLUE),
    ("Architecture", 2, 4, TEAL),
    ("Pre-training", 4, 6, ACCENT),
    ("LAM Dev", 5, 7, GOLD),
    ("Evaluation", 7, 9, DEEP_BLUE),
    ("Paper", 9, 11, TEAL),
    ("Submit", 11, 12, RED),
]

month_width = Inches(0.88)
start_x = Inches(1.5)
bar_y = Inches(1.8)
bar_h = Inches(0.45)

for m in range(1, 13):
    add_text_box(slide, start_x + (m - 1) * month_width, Inches(1.4), month_width, Inches(0.3),
                 f"M{m}", font_size=9, font_color=MID_GRAY, alignment=PP_ALIGN.CENTER)

for i, (name, start, end, color) in enumerate(phases):
    x = start_x + (start - 1) * month_width
    w = (end - start + 1) * month_width
    y = bar_y + Inches(i * 0.55)
    bar = add_rounded_rect(slide, x, y, w, bar_h, color)
    add_text_box(slide, x, y, w, bar_h,
                 name, font_size=10, font_color=WHITE, bold=True, alignment=PP_ALIGN.CENTER,
                 anchor=MSO_ANCHOR.MIDDLE)

# Budget
add_rounded_rect(slide, Inches(0.7), Inches(6.0), Inches(11.9), Inches(1.0), WHITE)
add_text_box(slide, Inches(1.0), Inches(6.1), Inches(2.0), Inches(0.4),
             "Estimated Budget", font_size=14, font_color=NAVY, bold=True)
add_text_box(slide, Inches(1.0), Inches(6.5), Inches(11.3), Inches(0.4),
             "Compute (8xA100, 3mo): $30-50K  |  Storage (5TB): $1.5K  |  API costs: $2-5K  |  Total: ~$40-60K",
             font_size=12, font_color=DARK_TEXT, alignment=PP_ALIGN.CENTER)

# ============================================================
# SLIDE 20: Conclusion
# ============================================================
slide = prs.slides.add_slide(blank_layout)
dark_bg(slide)
add_rect(slide, Inches(0), Inches(0), Inches(13.33), Inches(0.06), ACCENT)

add_text_box(slide, Inches(0.7), Inches(0.4), Inches(12.0), Inches(0.8),
             "Conclusion & Next Steps", font_size=34, font_color=WHITE, bold=True, font_name="Georgia")

add_rounded_rect(slide, Inches(0.7), Inches(1.5), Inches(5.8), Inches(3.0), DARK_BG)
add_text_box(slide, Inches(1.0), Inches(1.7), Inches(5.2), Inches(0.4),
             "Key Contributions", font_size=16, font_color=ACCENT, bold=True)
add_bullet_text(slide, Inches(1.0), Inches(2.2), Inches(5.2), Inches(2.1), [
    "First SSM/Mamba architecture for single-cell genomics",
    "Knowledge-grounded pre-training (GO/KEGG/PPI)",
    "Zero-shot cell type annotation via natural language",
    "Hybrid continuous-discrete tokenization",
    "Comprehensive 7-task benchmark suite",
], font_size=12, font_color=ICE, bullet_char="\u2713")

add_rounded_rect(slide, Inches(7.0), Inches(1.5), Inches(5.6), Inches(3.0), DARK_BG)
add_text_box(slide, Inches(7.3), Inches(1.7), Inches(5.0), Inches(0.4),
             "Next Steps", font_size=16, font_color=GOLD, bold=True)
add_bullet_text(slide, Inches(7.3), Inches(2.2), Inches(5.0), Inches(2.1), [
    "Multi-omics integration (ATAC-seq, spatial)",
    "Cross-species pre-training (mouse, zebrafish)",
    "Scale to 100M+ cells",
    "Interactive NL querying interface",
    "Clinical applications (disease cell type discovery)",
], font_size=12, font_color=ICE, bullet_char="\u25B8")

add_rounded_rect(slide, Inches(0.7), Inches(4.8), Inches(11.9), Inches(1.0), ACCENT)
add_text_box(slide, Inches(1.0), Inches(4.9), Inches(11.3), Inches(0.4),
             "Open Source Release: github.com/cellm-project/cellm",
             font_size=18, font_color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
add_text_box(slide, Inches(1.0), Inches(5.3), Inches(11.3), Inches(0.4),
             "Code, pre-trained models, tokenizer, benchmark suite, and training scripts",
             font_size=12, font_color=WHITE, alignment=PP_ALIGN.CENTER)

add_text_box(slide, Inches(0.7), Inches(6.2), Inches(11.9), Inches(0.6),
             "Thank you!", font_size=28, font_color=ICE, bold=True, font_name="Georgia",
             alignment=PP_ALIGN.CENTER)

# ============================================================
# Save
# ============================================================
out_path = "/Users/cgxmac/Desktop/skill/research_plan-workspace/iteration-1/eval-scRNA-LLM/without_skill/outputs/presentation/CeLLM_presentation.pptx"
os.makedirs(os.path.dirname(out_path), exist_ok=True)
prs.save(out_path)
print(f"Presentation saved to {out_path}")
