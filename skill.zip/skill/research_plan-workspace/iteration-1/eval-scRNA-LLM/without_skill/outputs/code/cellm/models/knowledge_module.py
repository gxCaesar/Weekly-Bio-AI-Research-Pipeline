"""
Knowledge Integration Module (KIM)

Encodes gene ontology (GO), KEGG pathway, and protein-protein interaction (PPI)
graphs using a Graph Attention Network, then fuses the resulting knowledge-aware
gene representations with the Mamba encoder output via cross-attention gating.

This module grounds the learned representations in validated biological knowledge,
improving both performance and interpretability.

Architecture:
    Gene-Pathway Graph -> GAT layers -> Knowledge embeddings
    Knowledge embeddings + Mamba output -> Cross-Attention Fusion -> Fused output
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


@dataclass
class KIMConfig:
    """Configuration for the Knowledge Integration Module."""

    # Graph structure
    num_genes: int = 20000
    num_pathways: int = 5000  # GO terms + KEGG pathways
    max_edges: int = 500000

    # GAT parameters
    gat_hidden_dim: int = 256
    gat_num_heads: int = 4
    gat_num_layers: int = 3
    gat_dropout: float = 0.1

    # Fusion parameters
    hidden_dim: int = 512  # Must match MambaEncoderConfig.hidden_dim
    num_cross_attn_heads: int = 8
    fusion_dropout: float = 0.1

    # Gating
    use_learned_gate: bool = True


class GraphAttentionLayer(nn.Module):
    """
    Multi-head graph attention layer.

    Computes attention coefficients between connected nodes in the
    gene-pathway graph, then aggregates neighbor features.

    Pure PyTorch implementation (no torch_geometric dependency for portability).
    For large graphs, use torch_geometric.nn.GATConv instead.
    """

    def __init__(
        self,
        in_dim: int,
        out_dim: int,
        num_heads: int = 4,
        dropout: float = 0.1,
        concat: bool = True,
    ):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = out_dim // num_heads
        self.concat = concat
        self.dropout = dropout

        self.W = nn.Linear(in_dim, out_dim, bias=False)
        self.a_src = nn.Parameter(torch.zeros(num_heads, self.head_dim))
        self.a_dst = nn.Parameter(torch.zeros(num_heads, self.head_dim))

        nn.init.xavier_uniform_(self.W.weight)
        nn.init.xavier_uniform_(self.a_src.unsqueeze(0))
        nn.init.xavier_uniform_(self.a_dst.unsqueeze(0))

        self.leaky_relu = nn.LeakyReLU(0.2)
        self.layer_norm = nn.LayerNorm(out_dim)

    def forward(
        self,
        x: torch.Tensor,  # (num_nodes, in_dim)
        edge_index: torch.Tensor,  # (2, num_edges)
    ) -> torch.Tensor:
        """
        Args:
            x: Node features (num_nodes, in_dim)
            edge_index: Edge connectivity (2, num_edges) - [source, target] rows

        Returns:
            Updated node features (num_nodes, out_dim)
        """
        num_nodes = x.size(0)

        # Linear transformation
        h = self.W(x)  # (N, out_dim)
        h = h.view(num_nodes, self.num_heads, self.head_dim)  # (N, H, D)

        # Compute attention scores
        src, dst = edge_index  # Each (num_edges,)

        # Source and destination attention scores
        e_src = (h[src] * self.a_src.unsqueeze(0)).sum(-1)  # (E, H)
        e_dst = (h[dst] * self.a_dst.unsqueeze(0)).sum(-1)  # (E, H)
        e = self.leaky_relu(e_src + e_dst)  # (E, H)

        # Softmax over neighbors (sparse)
        # For efficiency, we use scatter operations
        e_max = torch.zeros(num_nodes, self.num_heads, device=x.device)
        e_max.scatter_reduce_(0, dst.unsqueeze(-1).expand_as(e), e, reduce="amax")
        e = torch.exp(e - e_max[dst])
        e_sum = torch.zeros(num_nodes, self.num_heads, device=x.device)
        e_sum.scatter_add_(0, dst.unsqueeze(-1).expand_as(e), e)
        alpha = e / (e_sum[dst] + 1e-8)  # (E, H)

        # Dropout on attention
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)

        # Aggregate messages
        msg = h[src] * alpha.unsqueeze(-1)  # (E, H, D)
        out = torch.zeros(num_nodes, self.num_heads, self.head_dim, device=x.device)
        out.scatter_add_(
            0,
            dst.unsqueeze(-1).unsqueeze(-1).expand_as(msg),
            msg,
        )

        # Reshape
        if self.concat:
            out = out.view(num_nodes, -1)  # (N, H*D = out_dim)
        else:
            out = out.mean(dim=1)  # (N, D)

        return self.layer_norm(out)


class KnowledgeIntegrationModule(nn.Module):
    """
    Knowledge Integration Module (KIM).

    Processes a heterogeneous gene-pathway graph through GAT layers,
    then fuses the knowledge-aware gene embeddings with Mamba encoder
    output via gated cross-attention.

    Usage:
        kim = KnowledgeIntegrationModule(config)
        kim.set_graph(edge_index, node_types)  # Set graph structure
        fused = kim(mamba_output, gene_ids)     # Fuse with encoder output
    """

    def __init__(self, config: KIMConfig):
        super().__init__()
        self.config = config

        # Node embeddings (genes + pathways)
        total_nodes = config.num_genes + config.num_pathways
        self.node_embedding = nn.Embedding(total_nodes, config.gat_hidden_dim)

        # GAT layers
        self.gat_layers = nn.ModuleList()
        for i in range(config.gat_num_layers):
            in_dim = config.gat_hidden_dim
            out_dim = config.gat_hidden_dim
            self.gat_layers.append(
                GraphAttentionLayer(
                    in_dim, out_dim, config.gat_num_heads, config.gat_dropout
                )
            )

        # Projection to match Mamba hidden dim
        self.knowledge_proj = nn.Linear(config.gat_hidden_dim, config.hidden_dim)

        # Cross-attention fusion
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=config.hidden_dim,
            num_heads=config.num_cross_attn_heads,
            dropout=config.fusion_dropout,
            batch_first=True,
        )

        # Learned gating parameter
        if config.use_learned_gate:
            self.gate = nn.Sequential(
                nn.Linear(config.hidden_dim * 2, config.hidden_dim),
                nn.Sigmoid(),
            )
        else:
            self.gate_value = nn.Parameter(torch.tensor(0.1))

        self.layer_norm = nn.LayerNorm(config.hidden_dim)
        self.dropout = nn.Dropout(config.fusion_dropout)

        # Graph structure (set after initialization)
        self._edge_index: torch.Tensor | None = None
        self._knowledge_embeddings: torch.Tensor | None = None

    def set_graph(
        self,
        edge_index: torch.Tensor,
        node_features: torch.Tensor | None = None,
    ) -> None:
        """
        Set the gene-pathway graph structure.

        Args:
            edge_index: (2, num_edges) edge connectivity
            node_features: Optional (num_nodes, feat_dim) initial node features
        """
        self._edge_index = edge_index
        if node_features is not None:
            with torch.no_grad():
                self.node_embedding.weight[:node_features.size(0)] = node_features

    def _compute_knowledge_embeddings(self) -> torch.Tensor:
        """Run GAT over the gene-pathway graph to get knowledge-aware gene embeddings."""
        if self._edge_index is None:
            raise RuntimeError("Graph not set. Call set_graph() first.")

        x = self.node_embedding.weight  # (total_nodes, gat_hidden_dim)
        edge_index = self._edge_index.to(x.device)

        for gat_layer in self.gat_layers:
            x = gat_layer(x, edge_index)
            x = F.elu(x)

        # Extract only gene node embeddings (first num_genes nodes)
        gene_embeddings = x[:self.config.num_genes]  # (num_genes, gat_hidden_dim)

        # Project to Mamba hidden dim
        gene_embeddings = self.knowledge_proj(gene_embeddings)  # (num_genes, hidden_dim)

        return gene_embeddings

    def forward(
        self,
        mamba_output: torch.Tensor,  # (batch, seq_len, hidden_dim)
        gene_ids: torch.Tensor,  # (batch, seq_len) gene identity tokens
        attention_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Fuse Mamba encoder output with knowledge graph embeddings.

        Args:
            mamba_output: Gene representations from Mamba encoder
            gene_ids: Gene identity tokens (used to look up knowledge embeddings)
            attention_mask: Padding mask

        Returns:
            Fused representations (batch, seq_len, hidden_dim)
        """
        # Compute or retrieve knowledge embeddings
        knowledge_emb = self._compute_knowledge_embeddings()  # (num_genes, hidden_dim)

        # Look up knowledge for each gene in the batch
        # Clamp gene_ids to valid range (special tokens map to index 0)
        valid_ids = gene_ids.clamp(0, self.config.num_genes - 1)
        batch_knowledge = knowledge_emb[valid_ids]  # (batch, seq_len, hidden_dim)

        # Cross-attention: Mamba output attends to knowledge
        key_padding_mask = None
        if attention_mask is not None:
            key_padding_mask = attention_mask == 0

        attn_output, _ = self.cross_attn(
            query=mamba_output,
            key=batch_knowledge,
            value=batch_knowledge,
            key_padding_mask=key_padding_mask,
        )

        # Gated fusion
        if self.config.use_learned_gate:
            gate_input = torch.cat([mamba_output, attn_output], dim=-1)
            alpha = self.gate(gate_input)
        else:
            alpha = self.gate_value

        fused = mamba_output + alpha * self.dropout(attn_output)
        fused = self.layer_norm(fused)

        return fused
