"""
CeLLM: Cell Language-Linked Model

The full CeLLM model integrating all three modules:
    1. Mamba-SSM Gene Expression Encoder
    2. Knowledge Integration Module (KIM)
    3. Language Alignment Module (LAM)

Supports multiple modes:
    - Pre-training: MGEP + GPCL + KGR + CTA objectives
    - Fine-tuning: Task-specific heads (annotation, perturbation, etc.)
    - Inference: Cell embedding, zero-shot classification, NL querying
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from safetensors.torch import load_file, save_file

from cellm.models.mamba_encoder import MambaGeneEncoder, MambaEncoderConfig
from cellm.models.knowledge_module import KnowledgeIntegrationModule, KIMConfig
from cellm.models.language_alignment import LanguageAlignmentModule, LAMConfig

logger = logging.getLogger(__name__)


@dataclass
class CeLLMConfig:
    """Full configuration for the CeLLM model."""

    # Sub-module configs
    encoder: MambaEncoderConfig = field(default_factory=MambaEncoderConfig)
    kim: KIMConfig = field(default_factory=KIMConfig)
    lam: LAMConfig = field(default_factory=LAMConfig)

    # Training mode
    use_kim: bool = True
    use_lam: bool = True

    # Loss weights
    mgep_weight: float = 1.0  # Masked gene expression prediction
    gpcl_weight: float = 0.5  # Gene program contrastive learning
    kgr_weight: float = 0.3   # Knowledge-grounded regularization
    cta_weight: float = 0.5   # Cell-text alignment
    residual_weight: float = 0.1  # Residual prediction weight within MGEP

    # Fine-tuning
    num_cell_types: int = 0  # Set > 0 to add classification head


class CeLLM(nn.Module):
    """
    CeLLM: Cell Language-Linked Model

    A foundation model for single-cell RNA-seq that combines:
    - Efficient full-genome modeling via Mamba SSM
    - Knowledge-grounded representations via GO/KEGG/PPI graph integration
    - Natural language alignment for zero-shot cell type discovery

    Example usage:
        config = CeLLMConfig()
        model = CeLLM(config)

        # Pre-training
        outputs = model(
            gene_ids=batch["gene_ids"],
            bin_ids=batch["bin_ids"],
            residuals=batch["residuals"],
            attention_mask=batch["attention_mask"],
        )
        loss = outputs["total_loss"]

        # Zero-shot classification
        predictions = model.zero_shot_classify(
            gene_ids, bin_ids, residuals, attention_mask,
            candidate_descriptions=["T cell", "B cell", "Macrophage"]
        )
    """

    def __init__(self, config: CeLLMConfig):
        super().__init__()
        self.config = config

        # Module 1: Mamba Gene Expression Encoder
        self.encoder = MambaGeneEncoder(config.encoder)

        # Module 2: Knowledge Integration Module
        self.kim = None
        if config.use_kim:
            self.kim = KnowledgeIntegrationModule(config.kim)

        # Module 3: Language Alignment Module
        self.lam = None
        if config.use_lam:
            self.lam = LanguageAlignmentModule(config.lam)

        # Optional classification head for fine-tuning
        self.classifier = None
        if config.num_cell_types > 0:
            self.classifier = nn.Sequential(
                nn.Linear(config.encoder.hidden_dim, config.encoder.hidden_dim),
                nn.LayerNorm(config.encoder.hidden_dim),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(config.encoder.hidden_dim, config.num_cell_types),
            )

        logger.info(
            f"CeLLM initialized: {self.num_parameters / 1e6:.1f}M parameters, "
            f"KIM={'ON' if config.use_kim else 'OFF'}, "
            f"LAM={'ON' if config.use_lam else 'OFF'}"
        )

    def forward(
        self,
        gene_ids: torch.Tensor,
        bin_ids: torch.Tensor,
        residuals: torch.Tensor | None = None,
        attention_mask: torch.Tensor | None = None,
        chr_positions: torch.Tensor | None = None,
        # For MGEP loss
        mask_indices: torch.Tensor | None = None,
        original_bin_ids: torch.Tensor | None = None,
        original_residuals: torch.Tensor | None = None,
        # For LAM
        text_input_ids: torch.Tensor | None = None,
        text_attention_mask: torch.Tensor | None = None,
        text_embeddings: torch.Tensor | None = None,
        # For classification
        cell_type_id: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        """
        Full forward pass through CeLLM.

        Returns dictionary with:
            - cell_embedding: (batch, hidden_dim)
            - total_loss: scalar (sum of all active losses)
            - mgep_loss: masked gene expression prediction loss
            - kgr_loss: knowledge regularization loss (if KIM active)
            - cta_loss: cell-text alignment loss (if LAM active)
            - bin_logits: (batch, seq_len, num_bins)
            - classification_logits: (batch, num_cell_types) if classifier is present
        """
        # Step 1: Encode through Mamba
        encoder_output = self.encoder(
            gene_ids=gene_ids,
            bin_ids=bin_ids,
            residuals=residuals,
            attention_mask=attention_mask,
            chr_positions=chr_positions,
            return_gene_embeddings=True,
        )

        gene_embeddings = encoder_output["gene_embeddings"]
        cell_embedding = encoder_output["cell_embedding"]

        # Step 2: Knowledge Integration (if enabled)
        if self.kim is not None:
            try:
                gene_embeddings = self.kim(gene_embeddings, gene_ids, attention_mask)
                # Re-compute cell embedding from fused gene embeddings
                if self.config.encoder.pooling == "mean":
                    if attention_mask is not None:
                        mask = attention_mask.unsqueeze(-1).float()
                        cell_embedding = (gene_embeddings * mask).sum(1) / mask.sum(1).clamp(min=1)
                    else:
                        cell_embedding = gene_embeddings.mean(1)
                else:
                    cell_embedding = gene_embeddings[:, 0, :]
            except RuntimeError as e:
                logger.warning(f"KIM forward failed (graph may not be set): {e}")

        result = {
            "cell_embedding": cell_embedding,
            "gene_embeddings": gene_embeddings,
            "bin_logits": encoder_output["bin_logits"],
            "residual_pred": encoder_output["residual_pred"],
        }

        # Step 3: Compute losses
        total_loss = torch.tensor(0.0, device=gene_ids.device, requires_grad=True)

        # MGEP Loss
        if mask_indices is not None and original_bin_ids is not None:
            mgep_loss = self._compute_mgep_loss(
                encoder_output["bin_logits"],
                encoder_output["residual_pred"],
                original_bin_ids,
                original_residuals,
                mask_indices,
            )
            result["mgep_loss"] = mgep_loss
            total_loss = total_loss + self.config.mgep_weight * mgep_loss

        # KGR Loss (knowledge-grounded regularization)
        if self.kim is not None:
            kgr_loss = self._compute_kgr_loss(gene_embeddings, gene_ids)
            result["kgr_loss"] = kgr_loss
            total_loss = total_loss + self.config.kgr_weight * kgr_loss

        # CTA Loss (cell-text alignment)
        if self.lam is not None and (text_input_ids is not None or text_embeddings is not None):
            lam_output = self.lam(
                cell_embeddings=cell_embedding,
                text_input_ids=text_input_ids,
                text_attention_mask=text_attention_mask,
                text_embeddings=text_embeddings,
            )
            result["cta_loss"] = lam_output["loss"]
            result["c2t_accuracy"] = lam_output["c2t_accuracy"]
            result["t2c_accuracy"] = lam_output["t2c_accuracy"]
            total_loss = total_loss + self.config.cta_weight * lam_output["loss"]

        # Classification loss (fine-tuning)
        if self.classifier is not None and cell_type_id is not None:
            logits = self.classifier(cell_embedding)
            valid_mask = cell_type_id >= 0
            if valid_mask.any():
                cls_loss = F.cross_entropy(logits[valid_mask], cell_type_id[valid_mask])
                result["classification_loss"] = cls_loss
                result["classification_logits"] = logits
                total_loss = total_loss + cls_loss

        result["total_loss"] = total_loss
        return result

    def _compute_mgep_loss(
        self,
        bin_logits: torch.Tensor,
        residual_pred: torch.Tensor,
        original_bin_ids: torch.Tensor,
        original_residuals: torch.Tensor | None,
        mask_indices: torch.Tensor,
    ) -> torch.Tensor:
        """Compute masked gene expression prediction loss."""
        # Only compute loss on masked positions
        mask = mask_indices.bool()

        # Bin classification loss
        masked_logits = bin_logits[mask]  # (num_masked, num_bins)
        masked_targets = original_bin_ids[mask]  # (num_masked,)
        bin_loss = F.cross_entropy(masked_logits, masked_targets)

        # Residual regression loss
        if original_residuals is not None:
            masked_pred = residual_pred[mask]
            masked_true = original_residuals[mask]
            residual_loss = F.mse_loss(masked_pred, masked_true)
            return bin_loss + self.config.residual_weight * residual_loss

        return bin_loss

    def _compute_kgr_loss(
        self,
        gene_embeddings: torch.Tensor,
        gene_ids: torch.Tensor,
    ) -> torch.Tensor:
        """
        Knowledge-grounded regularization loss.

        Encourages genes in the same pathway to have similar embeddings.
        Uses a triplet-margin formulation.
        """
        # Simplified: use L2 regularization on embedding norms as proxy
        # Full implementation requires pathway membership information at runtime
        return gene_embeddings.norm(dim=-1).mean() * 0.01

    def zero_shot_classify(
        self,
        gene_ids: torch.Tensor,
        bin_ids: torch.Tensor,
        residuals: torch.Tensor | None = None,
        attention_mask: torch.Tensor | None = None,
        chr_positions: torch.Tensor | None = None,
        candidate_descriptions: list[str] | None = None,
    ) -> dict[str, torch.Tensor]:
        """
        Zero-shot cell type classification using natural language.

        Args:
            gene_ids, bin_ids, residuals, attention_mask: Cell expression inputs
            candidate_descriptions: List of cell type descriptions in natural language

        Returns:
            predicted_ids, similarities, top1_scores
        """
        if self.lam is None:
            raise RuntimeError("LAM module not enabled in this model")

        # Get cell embeddings
        with torch.no_grad():
            encoder_output = self.encoder(
                gene_ids=gene_ids,
                bin_ids=bin_ids,
                residuals=residuals,
                attention_mask=attention_mask,
                chr_positions=chr_positions,
            )
            cell_embedding = encoder_output["cell_embedding"]

        return self.lam.zero_shot_classify(cell_embedding, candidate_descriptions)

    def get_cell_embeddings(
        self,
        gene_ids: torch.Tensor,
        bin_ids: torch.Tensor,
        residuals: torch.Tensor | None = None,
        attention_mask: torch.Tensor | None = None,
        chr_positions: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Extract cell embeddings for downstream analysis."""
        with torch.no_grad():
            output = self.encoder(
                gene_ids=gene_ids,
                bin_ids=bin_ids,
                residuals=residuals,
                attention_mask=attention_mask,
                chr_positions=chr_positions,
            )
            if self.kim is not None:
                try:
                    gene_emb = self.encoder(
                        gene_ids=gene_ids,
                        bin_ids=bin_ids,
                        residuals=residuals,
                        attention_mask=attention_mask,
                        chr_positions=chr_positions,
                        return_gene_embeddings=True,
                    )["gene_embeddings"]
                    gene_emb = self.kim(gene_emb, gene_ids, attention_mask)
                    if attention_mask is not None:
                        mask = attention_mask.unsqueeze(-1).float()
                        return (gene_emb * mask).sum(1) / mask.sum(1).clamp(min=1)
                    return gene_emb.mean(1)
                except RuntimeError:
                    pass
            return output["cell_embedding"]

    @property
    def num_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def save_pretrained(self, path: str | Path) -> None:
        """Save model weights and config."""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        # Save weights
        save_file(self.state_dict(), str(path / "model.safetensors"))

        # Save config
        import json
        config_dict = {
            "encoder": self.config.encoder.__dict__,
            "kim": self.config.kim.__dict__ if self.config.use_kim else None,
            "lam": self.config.lam.__dict__ if self.config.use_lam else None,
            "use_kim": self.config.use_kim,
            "use_lam": self.config.use_lam,
            "num_cell_types": self.config.num_cell_types,
        }
        with open(path / "config.json", "w") as f:
            json.dump(config_dict, f, indent=2)

        logger.info(f"Model saved to {path}")

    @classmethod
    def from_pretrained(cls, path: str | Path) -> "CeLLM":
        """Load model from saved weights and config."""
        path = Path(path)

        import json
        with open(path / "config.json") as f:
            config_dict = json.load(f)

        config = CeLLMConfig(
            encoder=MambaEncoderConfig(**config_dict["encoder"]),
            use_kim=config_dict["use_kim"],
            use_lam=config_dict["use_lam"],
            num_cell_types=config_dict.get("num_cell_types", 0),
        )
        if config_dict.get("kim"):
            config.kim = KIMConfig(**config_dict["kim"])
        if config_dict.get("lam"):
            config.lam = LAMConfig(**config_dict["lam"])

        model = cls(config)
        state_dict = load_file(str(path / "model.safetensors"))
        model.load_state_dict(state_dict, strict=False)

        logger.info(f"Model loaded from {path}")
        return model
