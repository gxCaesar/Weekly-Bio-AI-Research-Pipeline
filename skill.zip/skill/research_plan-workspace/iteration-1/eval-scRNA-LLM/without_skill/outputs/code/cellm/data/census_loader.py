"""
CellxGene Census data loader for large-scale pre-training.

Provides streaming access to the CellxGene Census dataset (50M+ cells)
without loading the entire dataset into memory.
"""

from __future__ import annotations

import logging
from typing import Optional

import anndata as ad
import numpy as np

logger = logging.getLogger(__name__)


class CensusDataLoader:
    """
    Streaming data loader for CellxGene Census.

    Downloads and processes cells in chunks from the Census API,
    supporting filtering by organism, tissue, disease, and assay.
    """

    def __init__(
        self,
        organism: str = "homo_sapiens",
        census_version: str = "stable",
        chunk_size: int = 10000,
        max_cells: int | None = None,
    ):
        """
        Args:
            organism: Species to load ("homo_sapiens" or "mus_musculus")
            census_version: Census version string
            chunk_size: Number of cells per chunk
            max_cells: Maximum total cells to load
        """
        self.organism = organism
        self.census_version = census_version
        self.chunk_size = chunk_size
        self.max_cells = max_cells

    def load_filtered(
        self,
        tissue: str | None = None,
        cell_type: str | None = None,
        disease: str | None = None,
        assay: str | None = None,
        dataset_id: str | None = None,
    ) -> ad.AnnData:
        """
        Load cells matching the specified filters.

        Args:
            tissue: Filter by tissue (e.g., "brain", "lung")
            cell_type: Filter by cell type
            disease: Filter by disease state ("normal" for healthy)
            assay: Filter by sequencing assay (e.g., "10x 3' v3")
            dataset_id: Filter by specific dataset

        Returns:
            AnnData object with filtered cells
        """
        try:
            import cellxgene_census

            # Build value filter string
            filters = []
            if tissue:
                filters.append(f"tissue_general == '{tissue}'")
            if cell_type:
                filters.append(f"cell_type == '{cell_type}'")
            if disease:
                filters.append(f"disease == '{disease}'")
            if assay:
                filters.append(f"assay == '{assay}'")
            if dataset_id:
                filters.append(f"dataset_id == '{dataset_id}'")

            value_filter = " and ".join(filters) if filters else None

            logger.info(f"Loading from Census with filter: {value_filter}")

            with cellxgene_census.open_soma(census_version=self.census_version) as census:
                adata = cellxgene_census.get_anndata(
                    census,
                    organism=self.organism,
                    obs_value_filter=value_filter,
                    column_names={
                        "obs": [
                            "cell_type",
                            "tissue_general",
                            "disease",
                            "assay",
                            "dataset_id",
                            "donor_id",
                        ]
                    },
                )

            if self.max_cells and adata.n_obs > self.max_cells:
                indices = np.random.choice(adata.n_obs, self.max_cells, replace=False)
                adata = adata[indices].copy()

            logger.info(f"Loaded {adata.n_obs} cells, {adata.n_vars} genes")
            return adata

        except ImportError:
            logger.error(
                "cellxgene-census not installed. Install with: pip install cellxgene-census"
            )
            raise
        except Exception as e:
            logger.error(f"Failed to load Census data: {e}")
            raise

    def load_pretraining_corpus(
        self,
        tissues: list[str] | None = None,
        max_cells_per_tissue: int = 100000,
    ) -> ad.AnnData:
        """
        Load a diverse pre-training corpus from Census.

        Args:
            tissues: List of tissues to include (None for all)
            max_cells_per_tissue: Maximum cells per tissue type

        Returns:
            Combined AnnData object
        """
        if tissues is None:
            tissues = [
                "brain", "blood", "lung", "heart", "liver",
                "kidney", "intestine", "skin", "bone marrow", "pancreas",
                "eye", "breast", "prostate", "stomach", "spleen",
            ]

        all_adatas = []
        total_cells = 0

        for tissue in tissues:
            if self.max_cells and total_cells >= self.max_cells:
                break

            try:
                remaining = (self.max_cells - total_cells) if self.max_cells else max_cells_per_tissue
                n_cells = min(max_cells_per_tissue, remaining)

                loader = CensusDataLoader(
                    organism=self.organism,
                    census_version=self.census_version,
                    max_cells=n_cells,
                )
                adata = loader.load_filtered(tissue=tissue, disease="normal")
                all_adatas.append(adata)
                total_cells += adata.n_obs
                logger.info(f"Loaded {adata.n_obs} cells from {tissue} (total: {total_cells})")

            except Exception as e:
                logger.warning(f"Failed to load tissue '{tissue}': {e}")
                continue

        if not all_adatas:
            raise RuntimeError("Failed to load any data from Census")

        combined = ad.concat(all_adatas, join="inner")
        logger.info(f"Pre-training corpus: {combined.n_obs} cells, {combined.n_vars} genes")
        return combined
