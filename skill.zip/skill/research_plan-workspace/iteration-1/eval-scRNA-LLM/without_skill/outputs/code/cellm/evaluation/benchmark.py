"""
Comprehensive Benchmark Suite for CeLLM evaluation.

Provides standardized evaluation across 7 tasks:
    1. Cell type annotation
    2. Batch integration
    3. Perturbation prediction
    4. Trajectory inference
    5. Zero-shot cell type discovery
    6. Cross-species transfer
    7. Gene network inference

Each task uses standardized datasets and metrics for fair comparison.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import numpy as np

from cellm.evaluation.metrics import (
    compute_annotation_metrics,
    compute_integration_metrics,
    compute_perturbation_metrics,
)

logger = logging.getLogger(__name__)


@dataclass
class BenchmarkTask:
    """Definition of a single benchmark task."""

    name: str
    description: str
    datasets: list[str]
    metrics: list[str]
    primary_metric: str


# Standard benchmark tasks
BENCHMARK_TASKS = {
    "annotation": BenchmarkTask(
        name="Cell Type Annotation",
        description="Classify cells into known cell types using labeled training data",
        datasets=["zheng68k", "pbmc_multidonor", "pancreas_baron", "lung_atlas"],
        metrics=["accuracy", "macro_f1", "weighted_f1", "min_class_f1"],
        primary_metric="macro_f1",
    ),
    "integration": BenchmarkTask(
        name="Batch Integration",
        description="Remove batch effects while preserving biological variation",
        datasets=["pbmc_multibatch", "lung_atlas_multibatch", "immune_atlas"],
        metrics=["asw_cell_type", "asw_batch", "ami", "overall"],
        primary_metric="overall",
    ),
    "perturbation": BenchmarkTask(
        name="Perturbation Prediction",
        description="Predict gene expression after genetic perturbations",
        datasets=["norman_crispr", "replogle_k562", "adamson"],
        metrics=["pearson_mean", "mse", "cosine_similarity", "top20_overlap"],
        primary_metric="pearson_mean",
    ),
    "trajectory": BenchmarkTask(
        name="Trajectory Inference",
        description="Infer pseudotemporal ordering of cells along developmental trajectories",
        datasets=["dentate_gyrus", "pancreas_development", "hematopoiesis"],
        metrics=["kendall_tau", "spearman_r"],
        primary_metric="kendall_tau",
    ),
    "zero_shot": BenchmarkTask(
        name="Zero-Shot Cell Type Discovery",
        description="Identify cell types using natural language descriptions without labeled examples",
        datasets=["novel_tissue_holdout", "rare_cell_type_set"],
        metrics=["accuracy_at_1", "accuracy_at_5", "mrr"],
        primary_metric="accuracy_at_1",
    ),
    "cross_species": BenchmarkTask(
        name="Cross-Species Transfer",
        description="Transfer cell type annotations from one species to another",
        datasets=["mouse_to_human_brain", "human_to_mouse_immune"],
        metrics=["accuracy", "ami"],
        primary_metric="accuracy",
    ),
    "grn_inference": BenchmarkTask(
        name="Gene Regulatory Network Inference",
        description="Infer gene-gene regulatory relationships from expression data",
        datasets=["beeline_synthetic", "beeline_curated"],
        metrics=["auprc", "auroc"],
        primary_metric="auprc",
    ),
}


class BenchmarkSuite:
    """
    Orchestrates evaluation across all benchmark tasks.

    Usage:
        suite = BenchmarkSuite(tasks=["annotation", "integration"])
        results = suite.run(model, data_dir="./benchmark_data")
        suite.save_results(results, "results.json")
    """

    def __init__(
        self,
        tasks: list[str] | None = None,
        data_dir: str = "./benchmark_data",
    ):
        """
        Args:
            tasks: List of task names to evaluate. None = all tasks.
            data_dir: Directory containing benchmark datasets.
        """
        if tasks is None:
            tasks = list(BENCHMARK_TASKS.keys())

        self.tasks = {name: BENCHMARK_TASKS[name] for name in tasks if name in BENCHMARK_TASKS}
        self.data_dir = Path(data_dir)

        logger.info(f"BenchmarkSuite initialized with {len(self.tasks)} tasks: {list(self.tasks.keys())}")

    def run(self, model: Any, device: str = "cuda") -> dict[str, dict]:
        """
        Run all benchmark tasks on the given model.

        Args:
            model: CeLLM model instance
            device: Device to run evaluation on

        Returns:
            Nested dictionary: {task_name: {dataset_name: {metric_name: value}}}
        """
        results = {}

        for task_name, task in self.tasks.items():
            logger.info(f"Running benchmark: {task.name}")
            task_results = {}

            for dataset_name in task.datasets:
                try:
                    dataset_results = self._run_single_task(
                        model, task_name, dataset_name, device
                    )
                    task_results[dataset_name] = dataset_results
                    logger.info(f"  {dataset_name}: {dataset_results}")
                except FileNotFoundError:
                    logger.warning(f"  Dataset {dataset_name} not found, skipping")
                except Exception as e:
                    logger.error(f"  Error on {dataset_name}: {e}")

            # Compute average across datasets
            if task_results:
                avg_metrics = {}
                for metric in task.metrics:
                    values = [
                        r[metric]
                        for r in task_results.values()
                        if metric in r
                    ]
                    if values:
                        avg_metrics[metric] = float(np.mean(values))
                task_results["average"] = avg_metrics

            results[task_name] = task_results

        return results

    def _run_single_task(
        self,
        model: Any,
        task_name: str,
        dataset_name: str,
        device: str,
    ) -> dict[str, float]:
        """Run a single benchmark task on a specific dataset."""
        # Load dataset
        data_path = self.data_dir / task_name / f"{dataset_name}.h5ad"
        if not data_path.exists():
            raise FileNotFoundError(f"Dataset not found: {data_path}")

        import anndata as ad
        adata = ad.read_h5ad(data_path)

        if task_name == "annotation":
            return self._eval_annotation(model, adata, device)
        elif task_name == "integration":
            return self._eval_integration(model, adata, device)
        elif task_name == "perturbation":
            return self._eval_perturbation(model, adata, device)
        else:
            logger.warning(f"Task {task_name} evaluation not yet implemented")
            return {}

    def _eval_annotation(self, model, adata, device) -> dict[str, float]:
        """Evaluate cell type annotation."""
        import torch
        from cellm.data.tokenizer import GeneExpressionTokenizer

        # This is a template - in practice, you would:
        # 1. Split adata into train/test
        # 2. Fine-tune or zero-shot classify
        # 3. Compute metrics

        logger.info(f"Annotation eval: {adata.n_obs} cells, {adata.n_vars} genes")
        # Placeholder - replace with actual evaluation logic
        return {"accuracy": 0.0, "macro_f1": 0.0}

    def _eval_integration(self, model, adata, device) -> dict[str, float]:
        """Evaluate batch integration."""
        import torch

        logger.info(f"Integration eval: {adata.n_obs} cells")
        return {"asw_cell_type": 0.0, "asw_batch": 0.0, "overall": 0.0}

    def _eval_perturbation(self, model, adata, device) -> dict[str, float]:
        """Evaluate perturbation prediction."""
        logger.info(f"Perturbation eval: {adata.n_obs} cells")
        return {"pearson_mean": 0.0, "mse": 0.0}

    def save_results(self, results: dict, path: str) -> None:
        """Save benchmark results to JSON."""
        output_path = Path(path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w") as f:
            json.dump(results, f, indent=2)

        logger.info(f"Results saved to {output_path}")

    def print_summary(self, results: dict) -> None:
        """Print a formatted summary of benchmark results."""
        print("\n" + "=" * 70)
        print("CeLLM Benchmark Results Summary")
        print("=" * 70)

        for task_name, task_results in results.items():
            task = self.tasks.get(task_name)
            if not task or "average" not in task_results:
                continue

            print(f"\n{task.name}")
            print("-" * 40)

            avg = task_results["average"]
            for metric, value in avg.items():
                marker = " *" if metric == task.primary_metric else ""
                print(f"  {metric}: {value:.4f}{marker}")

        print("\n" + "=" * 70)
        print("* = primary metric")


def main():
    """Run benchmark evaluation from command line."""
    import argparse

    parser = argparse.ArgumentParser(description="CeLLM Benchmark Evaluation")
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--data_dir", type=str, default="./benchmark_data")
    parser.add_argument("--tasks", nargs="+", default=None)
    parser.add_argument("--output", type=str, default="benchmark_results.json")
    args = parser.parse_args()

    from cellm.models.cellm_model import CeLLM

    model = CeLLM.from_pretrained(args.model_path)
    suite = BenchmarkSuite(tasks=args.tasks, data_dir=args.data_dir)
    results = suite.run(model)
    suite.print_summary(results)
    suite.save_results(results, args.output)


if __name__ == "__main__":
    main()
