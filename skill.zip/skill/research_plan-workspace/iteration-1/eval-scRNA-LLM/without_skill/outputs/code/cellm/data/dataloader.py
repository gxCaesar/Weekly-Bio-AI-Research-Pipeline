"""
DataLoader utilities for CeLLM training.

Provides efficient data loading with:
    - Multi-worker prefetching
    - Dynamic batching by sequence length
    - Distributed training support
"""

from __future__ import annotations

import logging
from typing import Optional

import torch
from torch.utils.data import DataLoader, DistributedSampler, RandomSampler

from cellm.data.dataset import CellDataset, CellTextDataset

logger = logging.getLogger(__name__)


def build_dataloader(
    dataset: CellDataset | CellTextDataset,
    batch_size: int = 64,
    num_workers: int = 4,
    shuffle: bool = True,
    distributed: bool = False,
    drop_last: bool = True,
    pin_memory: bool = True,
    seed: int = 42,
) -> DataLoader:
    """
    Build a DataLoader for CeLLM training.

    Args:
        dataset: CellDataset or CellTextDataset
        batch_size: Number of cells per batch
        num_workers: Number of data loading workers
        shuffle: Whether to shuffle data
        distributed: Whether to use DistributedSampler for multi-GPU training
        drop_last: Drop last incomplete batch
        pin_memory: Pin memory for faster GPU transfer
        seed: Random seed for reproducibility

    Returns:
        PyTorch DataLoader
    """
    if distributed:
        sampler = DistributedSampler(dataset, shuffle=shuffle, seed=seed)
        shuffle = False  # Sampler handles shuffling
    elif shuffle:
        sampler = RandomSampler(dataset)
    else:
        sampler = None

    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        sampler=sampler,
        shuffle=(shuffle and sampler is None),
        num_workers=num_workers,
        drop_last=drop_last,
        pin_memory=pin_memory,
        collate_fn=_collate_fn,
        persistent_workers=num_workers > 0,
    )

    logger.info(
        f"DataLoader built: batch_size={batch_size}, "
        f"num_workers={num_workers}, distributed={distributed}"
    )

    return dataloader


def _collate_fn(batch: list[dict[str, torch.Tensor]]) -> dict[str, torch.Tensor]:
    """Custom collate function that handles variable-length sequences and mixed types."""
    collated = {}
    for key in batch[0].keys():
        if key == "text_raw":
            # Keep raw text as list of strings
            collated[key] = [sample[key] for sample in batch]
        elif isinstance(batch[0][key], torch.Tensor):
            collated[key] = torch.stack([sample[key] for sample in batch])
        else:
            collated[key] = [sample[key] for sample in batch]
    return collated
