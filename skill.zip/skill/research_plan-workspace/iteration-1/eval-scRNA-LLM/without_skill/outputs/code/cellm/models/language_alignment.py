"""
Language Alignment Module (LAM)

CLIP-style contrastive alignment between cell embeddings and natural language
descriptions. Enables:
    - Zero-shot cell type annotation via text queries
    - Natural language querying of single-cell datasets
    - Grounded cell type discovery

Architecture:
    Cell Embedding (from Mamba+KIM) -> Cell Projection -> Shared Space
    Text Description -> Text Encoder (PubMedBERT) -> Text Projection -> Shared Space

    Contrastive loss aligns matching cell-text pairs in shared space.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


@dataclass
class LAMConfig:
    """Configuration for Language Alignment Module."""

    # Dimensions
    cell_embed_dim: int = 512  # Must match Mamba hidden_dim
    text_embed_dim: int = 768  # PubMedBERT hidden dim
    projection_dim: int = 256  # Shared alignment space dimension

    # Text encoder
    text_model_name: str = "microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract"
    freeze_text_encoder: bool = True  # Freeze text encoder weights
    text_pooling: str = "cls"  # "cls" or "mean"

    # Contrastive learning
    temperature: float = 0.07  # Initial temperature (learnable)
    max_temperature: float = 100.0
    min_temperature: float = 0.01

    # MLP projector
    projector_hidden_dim: int = 512
    projector_num_layers: int = 2
    projector_dropout: float = 0.1


class MLPProjector(nn.Module):
    """MLP projection head for mapping embeddings to shared alignment space."""

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: int,
        num_layers: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        layers = []
        current_dim = input_dim
        for i in range(num_layers - 1):
            layers.extend([
                nn.Linear(current_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(dropout),
            ])
            current_dim = hidden_dim
        layers.append(nn.Linear(current_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class LanguageAlignmentModule(nn.Module):
    """
    Language Alignment Module for cell-text contrastive learning.

    Aligns cell embeddings (from Mamba encoder + KIM) with natural language
    descriptions in a shared embedding space using CLIP-style contrastive loss.
    """

    def __init__(self, config: LAMConfig):
        super().__init__()
        self.config = config

        # Cell projection (cell_embed_dim -> projection_dim)
        self.cell_projector = MLPProjector(
            input_dim=config.cell_embed_dim,
            hidden_dim=config.projector_hidden_dim,
            output_dim=config.projection_dim,
            num_layers=config.projector_num_layers,
            dropout=config.projector_dropout,
        )

        # Text projection (text_embed_dim -> projection_dim)
        self.text_projector = MLPProjector(
            input_dim=config.text_embed_dim,
            hidden_dim=config.projector_hidden_dim,
            output_dim=config.projection_dim,
            num_layers=config.projector_num_layers,
            dropout=config.projector_dropout,
        )

        # Learnable temperature parameter
        self.log_temperature = nn.Parameter(
            torch.tensor(1.0 / config.temperature).log()
        )

        # Text encoder (loaded separately to avoid import issues)
        self._text_encoder = None
        self._text_tokenizer = None

    def load_text_encoder(self) -> None:
        """Load the pre-trained text encoder (PubMedBERT)."""
        try:
            from transformers import AutoModel, AutoTokenizer

            logger.info(f"Loading text encoder: {self.config.text_model_name}")
            self._text_encoder = AutoModel.from_pretrained(self.config.text_model_name)
            self._text_tokenizer = AutoTokenizer.from_pretrained(
                self.config.text_model_name
            )

            if self.config.freeze_text_encoder:
                for param in self._text_encoder.parameters():
                    param.requires_grad = False
                logger.info("Text encoder weights frozen")

        except ImportError:
            logger.error("transformers library not found. Install: pip install transformers")
            raise

    @property
    def temperature(self) -> torch.Tensor:
        """Get clamped temperature value."""
        return self.log_temperature.exp().clamp(
            self.config.min_temperature, self.config.max_temperature
        )

    def encode_cells(self, cell_embeddings: torch.Tensor) -> torch.Tensor:
        """
        Project cell embeddings to shared alignment space.

        Args:
            cell_embeddings: (batch, cell_embed_dim)

        Returns:
            Normalized projections (batch, projection_dim)
        """
        projected = self.cell_projector(cell_embeddings)
        return F.normalize(projected, dim=-1)

    def encode_text(
        self,
        text_input_ids: torch.Tensor | None = None,
        text_attention_mask: torch.Tensor | None = None,
        text_embeddings: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Encode text descriptions to shared alignment space.

        Either provide pre-computed text_embeddings or raw token IDs.

        Args:
            text_input_ids: (batch, text_len) token IDs
            text_attention_mask: (batch, text_len) attention mask
            text_embeddings: (batch, text_embed_dim) pre-computed embeddings

        Returns:
            Normalized projections (batch, projection_dim)
        """
        if text_embeddings is None:
            if self._text_encoder is None:
                raise RuntimeError("Text encoder not loaded. Call load_text_encoder() first.")

            with torch.no_grad() if self.config.freeze_text_encoder else torch.enable_grad():
                outputs = self._text_encoder(
                    input_ids=text_input_ids,
                    attention_mask=text_attention_mask,
                )

                if self.config.text_pooling == "cls":
                    text_embeddings = outputs.last_hidden_state[:, 0]
                else:
                    # Mean pooling
                    mask = text_attention_mask.unsqueeze(-1).float()
                    text_embeddings = (outputs.last_hidden_state * mask).sum(1) / mask.sum(1).clamp(min=1)

        projected = self.text_projector(text_embeddings)
        return F.normalize(projected, dim=-1)

    def compute_contrastive_loss(
        self,
        cell_projections: torch.Tensor,  # (batch, projection_dim)
        text_projections: torch.Tensor,  # (batch, projection_dim)
    ) -> dict[str, torch.Tensor]:
        """
        Compute symmetric CLIP-style contrastive loss.

        Args:
            cell_projections: Normalized cell projections
            text_projections: Normalized text projections

        Returns:
            Dictionary with loss, cell-to-text accuracy, text-to-cell accuracy
        """
        # Compute similarity matrix
        temp = self.temperature
        logits = cell_projections @ text_projections.T * temp  # (B, B)

        # Labels: diagonal is positive
        batch_size = logits.shape[0]
        labels = torch.arange(batch_size, device=logits.device)

        # Symmetric cross-entropy loss
        loss_c2t = F.cross_entropy(logits, labels)
        loss_t2c = F.cross_entropy(logits.T, labels)
        loss = (loss_c2t + loss_t2c) / 2

        # Accuracy
        with torch.no_grad():
            c2t_acc = (logits.argmax(dim=-1) == labels).float().mean()
            t2c_acc = (logits.T.argmax(dim=-1) == labels).float().mean()

        return {
            "loss": loss,
            "c2t_accuracy": c2t_acc,
            "t2c_accuracy": t2c_acc,
            "temperature": temp.detach(),
        }

    def forward(
        self,
        cell_embeddings: torch.Tensor,
        text_input_ids: torch.Tensor | None = None,
        text_attention_mask: torch.Tensor | None = None,
        text_embeddings: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        """
        Full forward pass: project both modalities and compute contrastive loss.

        Returns:
            Dictionary with loss, accuracies, and projections
        """
        cell_proj = self.encode_cells(cell_embeddings)
        text_proj = self.encode_text(text_input_ids, text_attention_mask, text_embeddings)

        result = self.compute_contrastive_loss(cell_proj, text_proj)
        result["cell_projections"] = cell_proj
        result["text_projections"] = text_proj

        return result

    def zero_shot_classify(
        self,
        cell_embeddings: torch.Tensor,  # (num_cells, cell_embed_dim)
        candidate_descriptions: list[str],  # List of cell type descriptions
    ) -> dict[str, torch.Tensor]:
        """
        Zero-shot cell type classification using natural language descriptions.

        Args:
            cell_embeddings: Cell embeddings from the encoder
            candidate_descriptions: Text descriptions of candidate cell types

        Returns:
            Dictionary with predicted labels and similarity scores
        """
        if self._text_tokenizer is None:
            raise RuntimeError("Text encoder not loaded. Call load_text_encoder() first.")

        # Encode candidate descriptions
        text_inputs = self._text_tokenizer(
            candidate_descriptions,
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors="pt",
        ).to(cell_embeddings.device)

        text_proj = self.encode_text(
            text_input_ids=text_inputs["input_ids"],
            text_attention_mask=text_inputs["attention_mask"],
        )  # (num_candidates, projection_dim)

        # Encode cells
        cell_proj = self.encode_cells(cell_embeddings)  # (num_cells, projection_dim)

        # Compute similarities
        similarities = cell_proj @ text_proj.T  # (num_cells, num_candidates)

        # Get predictions
        predicted_ids = similarities.argmax(dim=-1)

        return {
            "predicted_ids": predicted_ids,
            "similarities": similarities,
            "top1_scores": similarities.max(dim=-1).values,
        }
