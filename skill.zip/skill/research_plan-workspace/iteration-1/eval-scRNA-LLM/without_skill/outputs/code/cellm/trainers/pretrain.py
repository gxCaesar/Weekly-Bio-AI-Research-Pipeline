"""
Pre-training trainer for CeLLM.

Handles the multi-objective pre-training loop:
    1. Masked Gene Expression Prediction (MGEP)
    2. Gene Program Contrastive Learning (GPCL)
    3. Knowledge-Grounded Regularization (KGR)
    4. Cell-Text Alignment (CTA)

Supports:
    - Mixed precision training (bf16/fp16)
    - Multi-GPU via PyTorch DDP
    - Gradient accumulation
    - WandB logging
    - Checkpoint saving/resuming
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import torch
import torch.nn as nn
from torch.cuda.amp import GradScaler, autocast
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts, LinearLR, SequentialLR
from torch.utils.data import DataLoader

from cellm.models.cellm_model import CeLLM, CeLLMConfig

logger = logging.getLogger(__name__)


@dataclass
class PreTrainConfig:
    """Configuration for pre-training."""

    # Optimization
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    adam_beta1: float = 0.9
    adam_beta2: float = 0.999
    adam_epsilon: float = 1e-8
    max_grad_norm: float = 1.0

    # Schedule
    warmup_steps: int = 2000
    max_steps: int = 200000
    cosine_period: int = 50000

    # Batch
    batch_size: int = 64
    gradient_accumulation_steps: int = 8  # Effective batch = 64 * 8 = 512

    # Precision
    mixed_precision: str = "bf16"  # "bf16", "fp16", or "no"

    # Logging
    log_every: int = 100
    eval_every: int = 5000
    save_every: int = 10000

    # Checkpointing
    output_dir: str = "./checkpoints"
    resume_from: str | None = None
    max_checkpoints: int = 5

    # WandB
    use_wandb: bool = True
    wandb_project: str = "cellm-pretrain"
    wandb_run_name: str | None = None

    # Distributed
    distributed: bool = False
    local_rank: int = 0

    # Seed
    seed: int = 42


class PreTrainer:
    """
    Pre-training loop for CeLLM.

    Usage:
        model = CeLLM(model_config)
        trainer = PreTrainer(model, train_config)
        trainer.train(train_dataloader, eval_dataloader)
    """

    def __init__(
        self,
        model: CeLLM,
        config: PreTrainConfig,
    ):
        self.model = model
        self.config = config
        self.device = torch.device(
            f"cuda:{config.local_rank}" if torch.cuda.is_available() else "cpu"
        )

        # Move model to device
        self.model = self.model.to(self.device)

        # DDP wrapper
        if config.distributed:
            self.model = DDP(
                self.model,
                device_ids=[config.local_rank],
                output_device=config.local_rank,
            )

        # Optimizer
        self.optimizer = self._create_optimizer()

        # LR Scheduler
        self.scheduler = self._create_scheduler()

        # Mixed precision
        self.scaler = None
        if config.mixed_precision == "fp16":
            self.scaler = GradScaler()

        # State
        self.global_step = 0
        self.best_eval_loss = float("inf")

        # WandB
        self._wandb_run = None

    def _create_optimizer(self) -> AdamW:
        """Create AdamW optimizer with weight decay on non-bias/norm parameters."""
        decay_params = []
        no_decay_params = []

        for name, param in self.model.named_parameters():
            if not param.requires_grad:
                continue
            if "bias" in name or "norm" in name or "layer_norm" in name:
                no_decay_params.append(param)
            else:
                decay_params.append(param)

        param_groups = [
            {"params": decay_params, "weight_decay": self.config.weight_decay},
            {"params": no_decay_params, "weight_decay": 0.0},
        ]

        return AdamW(
            param_groups,
            lr=self.config.learning_rate,
            betas=(self.config.adam_beta1, self.config.adam_beta2),
            eps=self.config.adam_epsilon,
        )

    def _create_scheduler(self):
        """Create learning rate scheduler with warmup + cosine decay."""
        warmup = LinearLR(
            self.optimizer,
            start_factor=0.01,
            end_factor=1.0,
            total_iters=self.config.warmup_steps,
        )
        cosine = CosineAnnealingWarmRestarts(
            self.optimizer,
            T_0=self.config.cosine_period,
            T_mult=2,
        )
        return SequentialLR(
            self.optimizer,
            schedulers=[warmup, cosine],
            milestones=[self.config.warmup_steps],
        )

    def train(
        self,
        train_dataloader: DataLoader,
        eval_dataloader: DataLoader | None = None,
    ) -> None:
        """
        Run the pre-training loop.

        Args:
            train_dataloader: Training data loader
            eval_dataloader: Optional evaluation data loader
        """
        # Initialize wandb
        if self.config.use_wandb and self.config.local_rank == 0:
            try:
                import wandb
                self._wandb_run = wandb.init(
                    project=self.config.wandb_project,
                    name=self.config.wandb_run_name,
                    config={
                        "train": self.config.__dict__,
                        "model_params": self.model.module.num_parameters
                        if hasattr(self.model, "module")
                        else self.model.num_parameters,
                    },
                )
            except ImportError:
                logger.warning("wandb not installed, skipping logging")

        # Resume if needed
        if self.config.resume_from:
            self._load_checkpoint(self.config.resume_from)

        logger.info(f"Starting pre-training from step {self.global_step}")
        logger.info(f"Device: {self.device}, Mixed precision: {self.config.mixed_precision}")

        self.model.train()
        self.optimizer.zero_grad()

        accumulation_loss = 0.0
        start_time = time.time()

        while self.global_step < self.config.max_steps:
            for batch in train_dataloader:
                if self.global_step >= self.config.max_steps:
                    break

                # Move batch to device
                batch = {
                    k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                    for k, v in batch.items()
                }

                # Forward pass with mixed precision
                use_amp = self.config.mixed_precision in ("fp16", "bf16")
                dtype = torch.bfloat16 if self.config.mixed_precision == "bf16" else torch.float16

                with autocast(enabled=use_amp, dtype=dtype):
                    outputs = self.model(**batch) if not isinstance(self.model, DDP) else self.model.module(**batch)
                    loss = outputs["total_loss"] / self.config.gradient_accumulation_steps

                # Backward pass
                if self.scaler:
                    self.scaler.scale(loss).backward()
                else:
                    loss.backward()

                accumulation_loss += loss.item()

                # Optimizer step after accumulation
                if (self.global_step + 1) % self.config.gradient_accumulation_steps == 0:
                    if self.scaler:
                        self.scaler.unscale_(self.optimizer)
                        nn.utils.clip_grad_norm_(
                            self.model.parameters(), self.config.max_grad_norm
                        )
                        self.scaler.step(self.optimizer)
                        self.scaler.update()
                    else:
                        nn.utils.clip_grad_norm_(
                            self.model.parameters(), self.config.max_grad_norm
                        )
                        self.optimizer.step()

                    self.scheduler.step()
                    self.optimizer.zero_grad()

                    # Logging
                    if self.global_step % self.config.log_every == 0:
                        elapsed = time.time() - start_time
                        lr = self.scheduler.get_last_lr()[0]
                        log_dict = {
                            "train/loss": accumulation_loss,
                            "train/learning_rate": lr,
                            "train/step": self.global_step,
                            "train/steps_per_sec": self.config.log_every / elapsed,
                        }

                        # Add individual losses
                        for key in ["mgep_loss", "kgr_loss", "cta_loss"]:
                            if key in outputs:
                                log_dict[f"train/{key}"] = outputs[key].item()

                        logger.info(
                            f"Step {self.global_step}: loss={accumulation_loss:.4f}, "
                            f"lr={lr:.2e}, steps/s={self.config.log_every / elapsed:.1f}"
                        )

                        if self._wandb_run:
                            import wandb
                            wandb.log(log_dict, step=self.global_step)

                        accumulation_loss = 0.0
                        start_time = time.time()

                    # Evaluation
                    if eval_dataloader and self.global_step % self.config.eval_every == 0:
                        eval_loss = self._evaluate(eval_dataloader)
                        if eval_loss < self.best_eval_loss:
                            self.best_eval_loss = eval_loss
                            self._save_checkpoint("best")
                        self.model.train()

                    # Save checkpoint
                    if self.global_step % self.config.save_every == 0:
                        self._save_checkpoint(f"step_{self.global_step}")

                self.global_step += 1

        # Final save
        self._save_checkpoint("final")
        logger.info("Pre-training complete!")

        if self._wandb_run:
            import wandb
            wandb.finish()

    @torch.no_grad()
    def _evaluate(self, eval_dataloader: DataLoader) -> float:
        """Run evaluation and return average loss."""
        self.model.eval()
        total_loss = 0.0
        num_batches = 0

        for batch in eval_dataloader:
            batch = {
                k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                for k, v in batch.items()
            }

            outputs = self.model(**batch) if not isinstance(self.model, DDP) else self.model.module(**batch)
            total_loss += outputs["total_loss"].item()
            num_batches += 1

            if num_batches >= 100:  # Limit eval steps
                break

        avg_loss = total_loss / max(num_batches, 1)
        logger.info(f"Eval loss at step {self.global_step}: {avg_loss:.4f}")

        if self._wandb_run:
            import wandb
            wandb.log({"eval/loss": avg_loss}, step=self.global_step)

        return avg_loss

    def _save_checkpoint(self, name: str) -> None:
        """Save training checkpoint."""
        if self.config.local_rank != 0:
            return

        path = Path(self.config.output_dir) / name
        path.mkdir(parents=True, exist_ok=True)

        model_to_save = self.model.module if isinstance(self.model, DDP) else self.model
        model_to_save.save_pretrained(path)

        # Save optimizer and scheduler state
        torch.save(
            {
                "optimizer": self.optimizer.state_dict(),
                "scheduler": self.scheduler.state_dict(),
                "global_step": self.global_step,
                "best_eval_loss": self.best_eval_loss,
            },
            path / "trainer_state.pt",
        )

        logger.info(f"Checkpoint saved: {path}")

    def _load_checkpoint(self, path: str) -> None:
        """Load training checkpoint."""
        path = Path(path)

        model_to_load = self.model.module if isinstance(self.model, DDP) else self.model
        model_to_load = CeLLM.from_pretrained(path)

        state = torch.load(path / "trainer_state.pt", map_location=self.device)
        self.optimizer.load_state_dict(state["optimizer"])
        self.scheduler.load_state_dict(state["scheduler"])
        self.global_step = state["global_step"]
        self.best_eval_loss = state["best_eval_loss"]

        logger.info(f"Resumed from {path} at step {self.global_step}")


def main():
    """Entry point for pre-training script."""
    import argparse

    parser = argparse.ArgumentParser(description="CeLLM Pre-training")
    parser.add_argument("--config", type=str, default=None, help="Path to config YAML")
    parser.add_argument("--output_dir", type=str, default="./checkpoints")
    parser.add_argument("--max_steps", type=int, default=200000)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--learning_rate", type=float, default=1e-4)
    parser.add_argument("--local_rank", type=int, default=0)
    args = parser.parse_args()

    # Build config
    model_config = CeLLMConfig()
    train_config = PreTrainConfig(
        output_dir=args.output_dir,
        max_steps=args.max_steps,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        local_rank=args.local_rank,
    )

    # Build model
    model = CeLLM(model_config)
    logger.info(f"Model parameters: {model.num_parameters / 1e6:.1f}M")

    # Build data (placeholder - replace with actual data loading)
    logger.info("Please provide training data via CensusDataLoader or AnnData files")

    # Train
    trainer = PreTrainer(model, train_config)
    # trainer.train(train_dataloader, eval_dataloader)


if __name__ == "__main__":
    main()
