"""
Mamba-SSM Gene Expression Encoder

The core backbone of CeLLM. Uses selective state-space models (Mamba)
to process all ~20,000 human genes in linear time O(n*d).

Architecture:
    Input -> Gene Embedding + Expression Embedding + Chr Position Encoding
          -> Stack of L Mamba Blocks
          -> Cell-level pooling -> Cell Embedding

Key advantages over Transformer-based encoders (scGPT, scBERT):
    - O(n) complexity vs O(n^2) for self-attention
    - No gene subsampling needed
    - Captures long-range gene dependencies via state propagation
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


@dataclass
class MambaEncoderConfig:
    """Configuration for the Mamba Gene Expression Encoder."""

    # Gene vocabulary
    num_genes: int = 20000
    special_tokens: int = 3  # PAD, MASK, CLS
    vocab_size: int = 20003  # num_genes + special_tokens

    # Expression tokenization
    num_expression_bins: int = 51
    use_residual_encoding: bool = True

    # Model dimensions
    hidden_dim: int = 512
    num_layers: int = 12
    intermediate_dim: int = 1024  # FFN intermediate dimension

    # Mamba-specific
    state_dim: int = 16  # SSM state dimension (N in Mamba paper)
    conv_kernel_size: int = 4  # Local convolution kernel
    expand_factor: int = 2  # Expansion factor for inner dimension

    # Regularization
    dropout: float = 0.1
    layer_norm_eps: float = 1e-5

    # Pooling
    pooling: str = "cls"  # "cls", "mean", or "attention"

    # Chromosomal position encoding
    max_chr_positions: int = 25000  # Max coarse chromosomal positions
    use_chr_position: bool = True


class GeneEmbedding(nn.Module):
    """
    Embedding layer that combines gene identity, expression value, and position.

    h_i = W_g * gene_id + W_b * bin_embed + W_r * residual + pos_encoding
    """

    def __init__(self, config: MambaEncoderConfig):
        super().__init__()
        self.config = config

        # Gene identity embedding
        self.gene_embedding = nn.Embedding(
            config.vocab_size, config.hidden_dim, padding_idx=0
        )

        # Expression bin embedding
        self.bin_embedding = nn.Embedding(
            config.num_expression_bins + 1,  # +1 for mask token bin
            config.hidden_dim,
        )

        # Continuous residual projection
        if config.use_residual_encoding:
            self.residual_proj = nn.Linear(1, config.hidden_dim, bias=False)

        # Chromosomal position encoding
        if config.use_chr_position:
            self.chr_position_embedding = nn.Embedding(
                config.max_chr_positions, config.hidden_dim
            )

        self.layer_norm = nn.LayerNorm(config.hidden_dim, eps=config.layer_norm_eps)
        self.dropout = nn.Dropout(config.dropout)

    def forward(
        self,
        gene_ids: torch.Tensor,  # (batch, seq_len)
        bin_ids: torch.Tensor,  # (batch, seq_len)
        residuals: torch.Tensor | None = None,  # (batch, seq_len)
        chr_positions: torch.Tensor | None = None,  # (batch, seq_len)
    ) -> torch.Tensor:
        """
        Compute combined gene embeddings.

        Returns:
            (batch, seq_len, hidden_dim) tensor of gene embeddings
        """
        h = self.gene_embedding(gene_ids) + self.bin_embedding(bin_ids)

        if self.config.use_residual_encoding and residuals is not None:
            h = h + self.residual_proj(residuals.unsqueeze(-1))

        if self.config.use_chr_position and chr_positions is not None:
            # Clamp to valid range
            chr_pos = chr_positions.clamp(0, self.config.max_chr_positions - 1)
            h = h + self.chr_position_embedding(chr_pos)

        return self.dropout(self.layer_norm(h))


class MambaBlock(nn.Module):
    """
    A single Mamba block implementing selective state-space modeling.

    This is a simplified pure-PyTorch implementation for clarity.
    For production, use the optimized mamba_ssm.Mamba CUDA kernel.

    Architecture:
        x -> Linear(expand) -> Conv1d -> SSM -> Linear(project) -> + residual
        x -> Linear(expand) -> SiLU -> * (gating)
    """

    def __init__(self, config: MambaEncoderConfig):
        super().__init__()
        self.config = config
        inner_dim = config.hidden_dim * config.expand_factor

        # Input projection (two branches: main + gate)
        self.in_proj = nn.Linear(config.hidden_dim, inner_dim * 2, bias=False)

        # 1D convolution for local context
        self.conv1d = nn.Conv1d(
            inner_dim,
            inner_dim,
            kernel_size=config.conv_kernel_size,
            padding=config.conv_kernel_size - 1,
            groups=inner_dim,
        )

        # SSM parameters - input dependent
        self.x_proj = nn.Linear(inner_dim, config.state_dim * 2 + 1, bias=False)  # B, C, dt

        # Learnable SSM parameters
        self.A_log = nn.Parameter(
            torch.log(torch.arange(1, config.state_dim + 1, dtype=torch.float32))
            .unsqueeze(0)
            .expand(inner_dim, -1)
        )
        self.D = nn.Parameter(torch.ones(inner_dim))

        # dt projection
        self.dt_proj = nn.Linear(1, inner_dim, bias=True)

        # Output projection
        self.out_proj = nn.Linear(inner_dim, config.hidden_dim, bias=False)

        # Layer norm
        self.norm = nn.LayerNorm(config.hidden_dim, eps=config.layer_norm_eps)

    def forward(
        self,
        x: torch.Tensor,  # (batch, seq_len, hidden_dim)
        attention_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Forward pass through the Mamba block.

        Args:
            x: Input tensor (batch, seq_len, hidden_dim)
            attention_mask: Optional mask for padded positions

        Returns:
            Output tensor (batch, seq_len, hidden_dim)
        """
        residual = x
        x = self.norm(x)

        # Project to inner dimension (two branches)
        xz = self.in_proj(x)  # (B, L, 2*inner_dim)
        x_main, z = xz.chunk(2, dim=-1)  # Each (B, L, inner_dim)

        # 1D convolution
        x_main = rearrange(x_main, "b l d -> b d l")
        x_main = self.conv1d(x_main)[:, :, :x.shape[1]]  # Causal: trim padding
        x_main = rearrange(x_main, "b d l -> b l d")
        x_main = F.silu(x_main)

        # SSM computation (simplified scan)
        y = self._ssm_forward(x_main)

        # Gating
        y = y * F.silu(z)

        # Output projection + residual
        output = self.out_proj(y) + residual

        # Apply mask if provided
        if attention_mask is not None:
            output = output * attention_mask.unsqueeze(-1)

        return output

    def _ssm_forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Selective state-space model forward pass.

        Implements the discrete-time SSM:
            s_t = A_bar * s_{t-1} + B_bar * x_t
            y_t = C * s_t + D * x_t

        where A_bar, B_bar are discretized with input-dependent dt.
        """
        batch, seq_len, inner_dim = x.shape

        # Compute input-dependent SSM parameters
        x_dbl = self.x_proj(x)  # (B, L, state_dim*2 + 1)

        # Split into B, C, dt
        B = x_dbl[..., :self.config.state_dim]  # (B, L, N)
        C = x_dbl[..., self.config.state_dim:2*self.config.state_dim]  # (B, L, N)
        dt_raw = x_dbl[..., -1:]  # (B, L, 1)

        # dt projection and softplus
        dt = F.softplus(self.dt_proj(dt_raw))  # (B, L, inner_dim)

        # Discretize A
        A = -torch.exp(self.A_log)  # (inner_dim, N)
        A_bar = torch.exp(dt.unsqueeze(-1) * A.unsqueeze(0).unsqueeze(0))  # (B, L, D, N)

        # Discretize B
        B_bar = dt.unsqueeze(-1) * B.unsqueeze(2)  # (B, L, D, N)

        # Sequential scan (for clarity; use parallel scan in production)
        states = torch.zeros(batch, inner_dim, self.config.state_dim, device=x.device)
        outputs = []

        for t in range(seq_len):
            states = A_bar[:, t] * states + B_bar[:, t] * x[:, t].unsqueeze(-1)
            y_t = (states * C[:, t].unsqueeze(1)).sum(-1)  # (B, D)
            outputs.append(y_t)

        y = torch.stack(outputs, dim=1)  # (B, L, D)
        y = y + x * self.D.unsqueeze(0).unsqueeze(0)  # Skip connection

        return y


class AttentionPooling(nn.Module):
    """Attention-based pooling to aggregate gene-level features into cell embedding."""

    def __init__(self, hidden_dim: int):
        super().__init__()
        self.query = nn.Parameter(torch.randn(1, 1, hidden_dim))
        self.scale = hidden_dim ** -0.5

    def forward(
        self, x: torch.Tensor, mask: torch.Tensor | None = None
    ) -> torch.Tensor:
        """
        Args:
            x: (batch, seq_len, hidden_dim)
            mask: (batch, seq_len) attention mask

        Returns:
            (batch, hidden_dim) pooled representation
        """
        scores = (self.query * x).sum(-1) * self.scale  # (B, L)
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float("-inf"))
        weights = F.softmax(scores, dim=-1)  # (B, L)
        return (weights.unsqueeze(-1) * x).sum(1)  # (B, D)


class MambaGeneEncoder(nn.Module):
    """
    Full Mamba-based gene expression encoder.

    Processes the complete gene expression profile of a cell through:
    1. Gene embedding layer (identity + expression + position)
    2. Stack of Mamba blocks for sequential gene modeling
    3. Pooling layer for cell-level representation

    Output:
        - gene_embeddings: (batch, seq_len, hidden_dim) per-gene representations
        - cell_embedding: (batch, hidden_dim) pooled cell representation
    """

    def __init__(self, config: MambaEncoderConfig):
        super().__init__()
        self.config = config

        # Embedding layer
        self.embedding = GeneEmbedding(config)

        # Stack of Mamba blocks
        self.layers = nn.ModuleList([MambaBlock(config) for _ in range(config.num_layers)])

        # Final layer norm
        self.final_norm = nn.LayerNorm(config.hidden_dim, eps=config.layer_norm_eps)

        # Pooling
        if config.pooling == "attention":
            self.pooler = AttentionPooling(config.hidden_dim)
        else:
            self.pooler = None

        # Prediction heads for pre-training
        self.bin_head = nn.Linear(config.hidden_dim, config.num_expression_bins)
        self.residual_head = nn.Linear(config.hidden_dim, 1)

        self._init_weights()

    def _init_weights(self):
        """Initialize weights using Xavier uniform for linear layers."""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.Embedding):
                nn.init.normal_(module.weight, mean=0.0, std=0.02)
                if module.padding_idx is not None:
                    nn.init.zeros_(module.weight[module.padding_idx])

    def forward(
        self,
        gene_ids: torch.Tensor,
        bin_ids: torch.Tensor,
        residuals: torch.Tensor | None = None,
        attention_mask: torch.Tensor | None = None,
        chr_positions: torch.Tensor | None = None,
        return_gene_embeddings: bool = False,
    ) -> dict[str, torch.Tensor]:
        """
        Forward pass through the Mamba encoder.

        Args:
            gene_ids: (batch, seq_len) gene identity tokens
            bin_ids: (batch, seq_len) expression bin tokens
            residuals: (batch, seq_len) continuous residuals
            attention_mask: (batch, seq_len) padding mask
            chr_positions: (batch, seq_len) chromosomal positions
            return_gene_embeddings: Whether to return per-gene embeddings

        Returns:
            Dictionary with:
                - cell_embedding: (batch, hidden_dim)
                - bin_logits: (batch, seq_len, num_bins) for MGEP
                - residual_pred: (batch, seq_len) for MGEP
                - gene_embeddings: (batch, seq_len, hidden_dim) if requested
        """
        # Embed genes
        h = self.embedding(gene_ids, bin_ids, residuals, chr_positions)

        # Process through Mamba blocks
        for layer in self.layers:
            h = layer(h, attention_mask)

        h = self.final_norm(h)

        # Cell-level pooling
        if self.config.pooling == "cls":
            cell_embedding = h[:, 0, :]  # Use first position as CLS
        elif self.config.pooling == "mean":
            if attention_mask is not None:
                mask = attention_mask.unsqueeze(-1).float()
                cell_embedding = (h * mask).sum(1) / mask.sum(1).clamp(min=1)
            else:
                cell_embedding = h.mean(1)
        elif self.config.pooling == "attention":
            cell_embedding = self.pooler(h, attention_mask)
        else:
            raise ValueError(f"Unknown pooling: {self.config.pooling}")

        # Prediction heads
        bin_logits = self.bin_head(h)
        residual_pred = self.residual_head(h).squeeze(-1)

        result = {
            "cell_embedding": cell_embedding,
            "bin_logits": bin_logits,
            "residual_pred": residual_pred,
        }

        if return_gene_embeddings:
            result["gene_embeddings"] = h

        return result

    @property
    def num_parameters(self) -> int:
        """Total number of trainable parameters."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
