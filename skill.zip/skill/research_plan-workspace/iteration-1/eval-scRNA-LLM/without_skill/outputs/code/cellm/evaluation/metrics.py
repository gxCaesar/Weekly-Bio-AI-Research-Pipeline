"""
Evaluation metrics for CeLLM benchmark tasks.

Implements metrics for:
    - Cell type annotation: Accuracy, Macro-F1, Weighted-F1
    - Batch integration: ASW, LISI, kBET, Graph Connectivity
    - Perturbation prediction: Pearson r, MSE, cosine similarity
    - Trajectory inference: Kendall tau, Optimal Transport distance
    - Gene network inference: AUPRC, AUROC
"""

from __future__ import annotations

import logging
from typing import Optional

import numpy as np
from scipy import stats
from sklearn.metrics import (
    accuracy_score,
    adjusted_mutual_info_score,
    f1_score,
    precision_score,
    recall_score,
    silhouette_score,
)

logger = logging.getLogger(__name__)


def compute_annotation_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    label_names: list[str] | None = None,
) -> dict[str, float]:
    """
    Compute cell type annotation metrics.

    Args:
        y_true: Ground truth labels
        y_pred: Predicted labels
        label_names: Optional names for each class

    Returns:
        Dictionary of metrics
    """
    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "macro_f1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "weighted_f1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "macro_precision": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "macro_recall": recall_score(y_true, y_pred, average="macro", zero_division=0),
    }

    # Per-class F1 for rare cell types
    per_class_f1 = f1_score(y_true, y_pred, average=None, zero_division=0)
    metrics["min_class_f1"] = float(per_class_f1.min())
    metrics["median_class_f1"] = float(np.median(per_class_f1))

    logger.info(
        f"Annotation metrics: acc={metrics['accuracy']:.4f}, "
        f"macro_f1={metrics['macro_f1']:.4f}"
    )

    return metrics


def compute_integration_metrics(
    embeddings: np.ndarray,
    batch_labels: np.ndarray,
    cell_type_labels: np.ndarray,
) -> dict[str, float]:
    """
    Compute batch integration metrics.

    Evaluates both batch mixing (removal of batch effects) and
    biological conservation (preservation of cell type structure).

    Args:
        embeddings: (n_cells, n_dims) cell embeddings
        batch_labels: Batch assignments
        cell_type_labels: Cell type labels

    Returns:
        Dictionary of metrics
    """
    metrics = {}

    # Average Silhouette Width (ASW) for cell types (biological conservation)
    try:
        n_samples = min(len(embeddings), 10000)
        if n_samples < len(embeddings):
            idx = np.random.choice(len(embeddings), n_samples, replace=False)
            sub_emb = embeddings[idx]
            sub_ct = cell_type_labels[idx]
            sub_batch = batch_labels[idx]
        else:
            sub_emb = embeddings
            sub_ct = cell_type_labels
            sub_batch = batch_labels

        # Cell type ASW (higher = better biological conservation)
        if len(set(sub_ct)) > 1:
            asw_ct = silhouette_score(sub_emb, sub_ct)
            metrics["asw_cell_type"] = float(asw_ct)

        # Batch ASW (lower = better batch mixing)
        if len(set(sub_batch)) > 1:
            asw_batch = silhouette_score(sub_emb, sub_batch)
            # Convert: 1 - |ASW_batch| so higher = better mixing
            metrics["asw_batch"] = float(1 - abs(asw_batch))

    except Exception as e:
        logger.warning(f"ASW computation failed: {e}")

    # Adjusted Mutual Information (AMI)
    try:
        from sklearn.cluster import KMeans

        n_clusters = len(set(cell_type_labels))
        if n_clusters > 1:
            kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            cluster_labels = kmeans.fit_predict(embeddings)
            ami = adjusted_mutual_info_score(cell_type_labels, cluster_labels)
            metrics["ami"] = float(ami)
    except Exception as e:
        logger.warning(f"AMI computation failed: {e}")

    # Overall score (average of normalized metrics)
    if metrics:
        metrics["overall"] = float(np.mean(list(metrics.values())))

    logger.info(f"Integration metrics: {metrics}")
    return metrics


def compute_perturbation_metrics(
    predicted: np.ndarray,
    ground_truth: np.ndarray,
    top_n_genes: int = 20,
) -> dict[str, float]:
    """
    Compute perturbation prediction metrics.

    Evaluates how well the model predicts gene expression changes
    after genetic perturbations (CRISPR knockdown/activation).

    Args:
        predicted: (n_cells, n_genes) predicted post-perturbation expression
        ground_truth: (n_cells, n_genes) observed post-perturbation expression
        top_n_genes: Number of top differentially expressed genes to evaluate

    Returns:
        Dictionary of metrics
    """
    metrics = {}

    # Overall Pearson correlation
    pearson_per_cell = []
    for i in range(predicted.shape[0]):
        r, _ = stats.pearsonr(predicted[i], ground_truth[i])
        if not np.isnan(r):
            pearson_per_cell.append(r)
    metrics["pearson_mean"] = float(np.mean(pearson_per_cell))
    metrics["pearson_median"] = float(np.median(pearson_per_cell))

    # MSE
    mse = float(np.mean((predicted - ground_truth) ** 2))
    metrics["mse"] = mse

    # Cosine similarity
    from sklearn.metrics.pairwise import cosine_similarity
    cos_sims = []
    for i in range(predicted.shape[0]):
        cos = cosine_similarity(
            predicted[i:i+1], ground_truth[i:i+1]
        )[0, 0]
        cos_sims.append(cos)
    metrics["cosine_similarity"] = float(np.mean(cos_sims))

    # Top-N DEG accuracy
    mean_pred = predicted.mean(axis=0)
    mean_true = ground_truth.mean(axis=0)
    top_pred = set(np.argsort(np.abs(mean_pred))[-top_n_genes:])
    top_true = set(np.argsort(np.abs(mean_true))[-top_n_genes:])
    metrics[f"top{top_n_genes}_overlap"] = float(len(top_pred & top_true) / top_n_genes)

    logger.info(
        f"Perturbation metrics: pearson={metrics['pearson_mean']:.4f}, "
        f"mse={metrics['mse']:.4f}"
    )

    return metrics


def compute_trajectory_metrics(
    predicted_pseudotime: np.ndarray,
    ground_truth_pseudotime: np.ndarray,
) -> dict[str, float]:
    """
    Compute trajectory inference metrics.

    Args:
        predicted_pseudotime: Predicted pseudotime ordering
        ground_truth_pseudotime: Ground truth pseudotime

    Returns:
        Dictionary of metrics
    """
    # Kendall's tau
    tau, p_value = stats.kendalltau(predicted_pseudotime, ground_truth_pseudotime)

    # Spearman correlation
    spearman_r, _ = stats.spearmanr(predicted_pseudotime, ground_truth_pseudotime)

    metrics = {
        "kendall_tau": float(tau),
        "kendall_pvalue": float(p_value),
        "spearman_r": float(spearman_r),
    }

    logger.info(f"Trajectory metrics: tau={tau:.4f}, spearman={spearman_r:.4f}")
    return metrics


def compute_gene_network_metrics(
    predicted_edges: np.ndarray,  # (n_edges, 3): gene1, gene2, score
    ground_truth_edges: set[tuple[str, str]],
    gene_names: list[str],
) -> dict[str, float]:
    """
    Compute gene regulatory network inference metrics.

    Args:
        predicted_edges: Predicted edges with confidence scores
        ground_truth_edges: Set of known true edges
        gene_names: List of gene names

    Returns:
        AUPRC and AUROC
    """
    from sklearn.metrics import average_precision_score, roc_auc_score

    # Convert to binary labels
    y_true = []
    y_scores = []

    for i in range(len(predicted_edges)):
        g1_idx, g2_idx, score = predicted_edges[i]
        g1 = gene_names[int(g1_idx)]
        g2 = gene_names[int(g2_idx)]
        y_true.append(1 if (g1, g2) in ground_truth_edges else 0)
        y_scores.append(float(score))

    y_true = np.array(y_true)
    y_scores = np.array(y_scores)

    metrics = {}
    if y_true.sum() > 0:
        metrics["auprc"] = float(average_precision_score(y_true, y_scores))
        metrics["auroc"] = float(roc_auc_score(y_true, y_scores))
    else:
        metrics["auprc"] = 0.0
        metrics["auroc"] = 0.5

    logger.info(f"GRN metrics: AUPRC={metrics['auprc']:.4f}, AUROC={metrics['auroc']:.4f}")
    return metrics
