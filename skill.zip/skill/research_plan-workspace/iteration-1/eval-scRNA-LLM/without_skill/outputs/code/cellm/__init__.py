"""
CeLLM: Cell Language-Linked Model

An efficient foundation model bridging single-cell genomics and natural language.

Architecture:
    1. Mamba-SSM Gene Expression Encoder - linear-time full-genome modeling
    2. Knowledge Integration Module (KIM) - GO/KEGG/PPI graph integration
    3. Language Alignment Module (LAM) - CLIP-style cell-text alignment

Key features:
    - Processes all ~20,000 human genes without subsampling (O(n) complexity)
    - Knowledge-grounded pre-training with gene ontology
    - Zero-shot cell type annotation via natural language
    - Hybrid continuous-discrete expression tokenization
"""

__version__ = "0.1.0"
__author__ = "CeLLM Team"
