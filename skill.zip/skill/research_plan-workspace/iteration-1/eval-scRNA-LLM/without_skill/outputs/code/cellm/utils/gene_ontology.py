"""
Gene Ontology and Pathway Graph utilities.

Constructs the heterogeneous gene-pathway graph used by the KIM module,
combining data from:
    - Gene Ontology (GO): Biological process, molecular function, cellular component
    - KEGG pathways
    - Protein-protein interactions (PPI) from STRING database
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import numpy as np
import torch

logger = logging.getLogger(__name__)


class GeneOntologyGraph:
    """
    Build and manage the gene-pathway graph for KIM.

    Nodes: genes (0..num_genes-1) + pathways (num_genes..num_genes+num_pathways-1)
    Edges:
        - gene-pathway membership (bidirectional)
        - gene-gene PPI interactions
        - pathway-pathway hierarchy (parent-child in GO DAG)
    """

    def __init__(
        self,
        gene_names: list[str],
        num_pathways: int = 5000,
    ):
        self.gene_names = gene_names
        self.gene_to_idx = {g: i for i, g in enumerate(gene_names)}
        self.num_genes = len(gene_names)
        self.num_pathways = num_pathways

        self.pathway_names: list[str] = []
        self.pathway_to_idx: dict[str, int] = {}

        # Edge lists
        self.gene_pathway_edges: list[tuple[int, int]] = []
        self.gene_gene_edges: list[tuple[int, int]] = []
        self.pathway_pathway_edges: list[tuple[int, int]] = []

    def load_go_annotations(self, go_file: str | Path) -> None:
        """
        Load Gene Ontology annotations from GAF file.

        Expected format: tab-separated with gene symbol in column 2,
        GO term in column 4.
        """
        path = Path(go_file)
        if not path.exists():
            logger.warning(f"GO file not found: {path}")
            return

        with open(path) as f:
            for line in f:
                if line.startswith("!"):
                    continue
                fields = line.strip().split("\t")
                if len(fields) < 5:
                    continue

                gene_symbol = fields[2]
                go_term = fields[4]

                if gene_symbol in self.gene_to_idx:
                    gene_idx = self.gene_to_idx[gene_symbol]

                    if go_term not in self.pathway_to_idx:
                        if len(self.pathway_names) >= self.num_pathways:
                            continue
                        idx = self.num_genes + len(self.pathway_names)
                        self.pathway_to_idx[go_term] = idx
                        self.pathway_names.append(go_term)

                    pathway_idx = self.pathway_to_idx[go_term]
                    self.gene_pathway_edges.append((gene_idx, pathway_idx))
                    self.gene_pathway_edges.append((pathway_idx, gene_idx))  # Bidirectional

        logger.info(
            f"Loaded GO annotations: {len(self.pathway_names)} terms, "
            f"{len(self.gene_pathway_edges)} edges"
        )

    def load_ppi_network(self, ppi_file: str | Path, score_threshold: float = 700) -> None:
        """
        Load PPI network from STRING database export.

        Expected format: tab-separated with gene1, gene2, combined_score.
        """
        path = Path(ppi_file)
        if not path.exists():
            logger.warning(f"PPI file not found: {path}")
            return

        with open(path) as f:
            header = next(f)  # Skip header
            for line in f:
                fields = line.strip().split("\t")
                if len(fields) < 3:
                    continue

                gene1, gene2 = fields[0], fields[1]
                score = float(fields[2])

                if score < score_threshold:
                    continue

                if gene1 in self.gene_to_idx and gene2 in self.gene_to_idx:
                    idx1 = self.gene_to_idx[gene1]
                    idx2 = self.gene_to_idx[gene2]
                    self.gene_gene_edges.append((idx1, idx2))
                    self.gene_gene_edges.append((idx2, idx1))

        logger.info(f"Loaded PPI network: {len(self.gene_gene_edges)} edges")

    def build_edge_index(self) -> torch.Tensor:
        """
        Build the combined edge index tensor for the full heterogeneous graph.

        Returns:
            (2, num_edges) tensor of edge indices
        """
        all_edges = (
            self.gene_pathway_edges
            + self.gene_gene_edges
            + self.pathway_pathway_edges
        )

        if not all_edges:
            logger.warning("No edges in graph. Creating minimal self-loop graph.")
            # Create self-loops as fallback
            all_edges = [(i, i) for i in range(min(100, self.num_genes))]

        # Remove duplicates
        unique_edges = list(set(all_edges))

        src = [e[0] for e in unique_edges]
        dst = [e[1] for e in unique_edges]

        edge_index = torch.tensor([src, dst], dtype=torch.long)
        logger.info(f"Built edge index: {edge_index.shape[1]} edges")
        return edge_index

    def build_synthetic_graph(self, num_pathways: int = 500, genes_per_pathway: int = 50) -> torch.Tensor:
        """
        Build a synthetic gene-pathway graph for testing/development.

        Creates random pathway memberships to enable development
        without requiring real annotation files.

        Args:
            num_pathways: Number of synthetic pathways
            genes_per_pathway: Average genes per pathway

        Returns:
            Edge index tensor
        """
        rng = np.random.default_rng(42)

        # Create pathway memberships
        for p in range(num_pathways):
            pathway_idx = self.num_genes + p
            self.pathway_names.append(f"SYNTH_PATHWAY_{p}")
            self.pathway_to_idx[f"SYNTH_PATHWAY_{p}"] = pathway_idx

            # Random gene members
            num_members = rng.poisson(genes_per_pathway)
            members = rng.choice(self.num_genes, size=min(num_members, self.num_genes), replace=False)

            for gene_idx in members:
                self.gene_pathway_edges.append((gene_idx, pathway_idx))
                self.gene_pathway_edges.append((pathway_idx, gene_idx))

        # Create some gene-gene edges (synthetic PPI)
        num_ppi = self.num_genes * 5
        for _ in range(num_ppi):
            g1, g2 = rng.choice(self.num_genes, size=2, replace=False)
            self.gene_gene_edges.append((int(g1), int(g2)))
            self.gene_gene_edges.append((int(g2), int(g1)))

        logger.info(
            f"Built synthetic graph: {num_pathways} pathways, "
            f"{len(self.gene_pathway_edges)} pathway edges, "
            f"{len(self.gene_gene_edges)} PPI edges"
        )

        return self.build_edge_index()
