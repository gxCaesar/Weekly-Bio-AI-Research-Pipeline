"""
Dataset classes for CeLLM pre-training and fine-tuning.

Provides:
    - CellDataset: Basic single-cell dataset for pre-training (MGEP objective)
    - CellTextDataset: Cell-text paired dataset for language alignment (LAM objective)
    - PerturbationDataset: Dataset for perturbation prediction fine-tuning
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

import anndata as ad
import numpy as np
import torch
from scipy.sparse import issparse
from torch.utils.data import Dataset

from cellm.data.tokenizer import GeneExpressionTokenizer

logger = logging.getLogger(__name__)


class CellDataset(Dataset):
    """
    Dataset for single-cell gene expression data.

    Loads an AnnData object and tokenizes cells on-the-fly using GeneExpressionTokenizer.
    Supports masked gene expression prediction (MGEP) by randomly masking gene tokens.
    """

    def __init__(
        self,
        adata: ad.AnnData,
        tokenizer: GeneExpressionTokenizer,
        mask_ratio: float = 0.15,
        max_cells: int | None = None,
        cell_type_key: str = "cell_type",
        batch_key: str | None = "batch",
    ):
        """
        Args:
            adata: AnnData object with expression data in .X
            tokenizer: Fitted GeneExpressionTokenizer
            mask_ratio: Fraction of genes to mask for MGEP
            max_cells: Optional limit on number of cells
            cell_type_key: Key in adata.obs for cell type labels
            batch_key: Key in adata.obs for batch labels
        """
        self.tokenizer = tokenizer
        self.mask_ratio = mask_ratio
        self.gene_names = list(adata.var_names)

        # Extract expression matrix
        if issparse(adata.X):
            self.expression_matrix = adata.X.toarray()
        else:
            self.expression_matrix = np.array(adata.X)

        if max_cells and max_cells < self.expression_matrix.shape[0]:
            indices = np.random.choice(
                self.expression_matrix.shape[0], max_cells, replace=False
            )
            self.expression_matrix = self.expression_matrix[indices]
            adata = adata[indices]

        # Extract metadata
        self.cell_types = None
        if cell_type_key in adata.obs.columns:
            self.cell_types = adata.obs[cell_type_key].values
            self.cell_type_vocab = {
                ct: i for i, ct in enumerate(sorted(set(self.cell_types)))
            }

        self.batch_ids = None
        if batch_key and batch_key in adata.obs.columns:
            self.batch_ids = adata.obs[batch_key].values

        logger.info(
            f"CellDataset initialized: {len(self)} cells, {len(self.gene_names)} genes"
        )

    def __len__(self) -> int:
        return self.expression_matrix.shape[0]

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        # Tokenize the cell
        tokens = self.tokenizer.tokenize(
            self.expression_matrix[idx],
            self.gene_names,
            return_tensors="pt",
        )

        # Create masked version for MGEP
        mask_indices = self._create_mask(tokens["attention_mask"])
        tokens["mask_indices"] = mask_indices

        # Store original values for loss computation
        tokens["original_bin_ids"] = tokens["bin_ids"].clone()
        tokens["original_residuals"] = tokens["residuals"].clone()

        # Apply mask
        tokens["bin_ids"] = tokens["bin_ids"].clone()
        tokens["bin_ids"][mask_indices.bool()] = self.tokenizer.config.mask_token_id

        # Add cell type label if available
        if self.cell_types is not None:
            ct = self.cell_types[idx]
            tokens["cell_type_id"] = torch.tensor(
                self.cell_type_vocab.get(ct, -1), dtype=torch.long
            )

        return tokens

    def _create_mask(self, attention_mask: torch.Tensor) -> torch.Tensor:
        """Create random mask for MGEP objective."""
        seq_len = attention_mask.sum().item()
        num_mask = max(1, int(seq_len * self.mask_ratio))

        mask = torch.zeros_like(attention_mask)
        mask_positions = torch.randperm(seq_len)[:num_mask]
        mask[mask_positions] = 1

        return mask


class CellTextDataset(Dataset):
    """
    Dataset for cell-text alignment training (LAM module).

    Each sample is a (cell_expression, text_description) pair where the text
    describes the cell type, state, or relevant biological context.
    """

    def __init__(
        self,
        adata: ad.AnnData,
        tokenizer: GeneExpressionTokenizer,
        text_descriptions: dict[str, str],
        text_tokenizer: Any = None,
        cell_type_key: str = "cell_type",
        max_text_length: int = 128,
    ):
        """
        Args:
            adata: AnnData object
            tokenizer: Fitted GeneExpressionTokenizer
            text_descriptions: Mapping of cell_type -> natural language description
            text_tokenizer: HuggingFace tokenizer for text (e.g., PubMedBERT tokenizer)
            cell_type_key: Key in adata.obs for cell type
            max_text_length: Maximum text token length
        """
        self.tokenizer = tokenizer
        self.text_tokenizer = text_tokenizer
        self.text_descriptions = text_descriptions
        self.max_text_length = max_text_length
        self.gene_names = list(adata.var_names)

        if issparse(adata.X):
            self.expression_matrix = adata.X.toarray()
        else:
            self.expression_matrix = np.array(adata.X)

        self.cell_types = adata.obs[cell_type_key].values

        # Filter to cells with text descriptions
        valid_mask = np.array([ct in text_descriptions for ct in self.cell_types])
        self.expression_matrix = self.expression_matrix[valid_mask]
        self.cell_types = self.cell_types[valid_mask]

        logger.info(
            f"CellTextDataset: {len(self)} cells with text descriptions "
            f"({len(text_descriptions)} unique descriptions)"
        )

    def __len__(self) -> int:
        return self.expression_matrix.shape[0]

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        # Tokenize cell expression
        cell_tokens = self.tokenizer.tokenize(
            self.expression_matrix[idx],
            self.gene_names,
            return_tensors="pt",
        )

        # Get text description and tokenize
        cell_type = self.cell_types[idx]
        description = self.text_descriptions[cell_type]

        if self.text_tokenizer is not None:
            text_tokens = self.text_tokenizer(
                description,
                max_length=self.max_text_length,
                padding="max_length",
                truncation=True,
                return_tensors="pt",
            )
            cell_tokens["text_input_ids"] = text_tokens["input_ids"].squeeze(0)
            cell_tokens["text_attention_mask"] = text_tokens["attention_mask"].squeeze(0)
        else:
            # Placeholder for when text tokenizer is not provided
            cell_tokens["text_raw"] = description

        return cell_tokens


class PerturbationDataset(Dataset):
    """
    Dataset for perturbation prediction fine-tuning.

    Each sample contains a control cell expression, a perturbation specification
    (gene knockdown/overexpression), and the observed post-perturbation expression.
    """

    def __init__(
        self,
        control_adata: ad.AnnData,
        perturbed_adata: ad.AnnData,
        tokenizer: GeneExpressionTokenizer,
        perturbation_key: str = "perturbation",
    ):
        self.tokenizer = tokenizer
        self.gene_names = list(control_adata.var_names)

        if issparse(control_adata.X):
            self.control_expr = control_adata.X.toarray()
        else:
            self.control_expr = np.array(control_adata.X)

        if issparse(perturbed_adata.X):
            self.perturbed_expr = perturbed_adata.X.toarray()
        else:
            self.perturbed_expr = np.array(perturbed_adata.X)

        self.perturbation_labels = perturbed_adata.obs[perturbation_key].values

        # Build perturbation vocabulary
        unique_perts = sorted(set(self.perturbation_labels))
        self.pert_vocab = {p: i for i, p in enumerate(unique_perts)}

    def __len__(self) -> int:
        return self.perturbed_expr.shape[0]

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        # Tokenize control cell (random from control pool)
        ctrl_idx = np.random.randint(self.control_expr.shape[0])
        control_tokens = self.tokenizer.tokenize(
            self.control_expr[ctrl_idx], self.gene_names, return_tensors="pt"
        )

        # Tokenize perturbed cell
        perturbed_tokens = self.tokenizer.tokenize(
            self.perturbed_expr[idx], self.gene_names, return_tensors="pt"
        )

        return {
            "control_gene_ids": control_tokens["gene_ids"],
            "control_bin_ids": control_tokens["bin_ids"],
            "control_residuals": control_tokens["residuals"],
            "control_attention_mask": control_tokens["attention_mask"],
            "perturbed_bin_ids": perturbed_tokens["bin_ids"],
            "perturbed_residuals": perturbed_tokens["residuals"],
            "perturbation_id": torch.tensor(
                self.pert_vocab[self.perturbation_labels[idx]], dtype=torch.long
            ),
        }
