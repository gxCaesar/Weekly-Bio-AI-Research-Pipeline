"""
Fine-tuning trainer for CeLLM.

Supports fine-tuning for downstream tasks:
    - Cell type annotation
    - Batch integration
    - Perturbation prediction
    - Trajectory inference

Implements:
    - Frozen backbone + trainable head
    - Full fine-tuning with lower learning rate
    - LoRA-style parameter-efficient fine-tuning
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data import DataLoader

from cellm.models.cellm_model import CeLLM, CeLLMConfig

logger = logging.getLogger(__name__)


@dataclass
class FineTuneConfig:
    """Configuration for fine-tuning."""

    task: str = "annotation"  # "annotation", "integration", "perturbation"
    num_classes: int = 0  # For annotation task
    freeze_backbone: bool = False
    learning_rate: float = 2e-5
    weight_decay: float = 0.01
    num_epochs: int = 10
    batch_size: int = 32
    warmup_ratio: float = 0.1
    output_dir: str = "./finetune_checkpoints"
    patience: int = 5  # Early stopping patience
    seed: int = 42


class FineTuner:
    """
    Fine-tuning pipeline for CeLLM.

    Loads a pre-trained CeLLM model and fine-tunes it on downstream tasks.

    Usage:
        model = CeLLM.from_pretrained("path/to/checkpoint")
        finetuner = FineTuner(model, config)
        finetuner.train(train_loader, val_loader)
        results = finetuner.evaluate(test_loader)
    """

    def __init__(self, model: CeLLM, config: FineTuneConfig):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Add task-specific head
        if config.task == "annotation" and config.num_classes > 0:
            model.config.num_cell_types = config.num_classes
            model.classifier = nn.Sequential(
                nn.Linear(model.config.encoder.hidden_dim, model.config.encoder.hidden_dim),
                nn.LayerNorm(model.config.encoder.hidden_dim),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(model.config.encoder.hidden_dim, config.num_classes),
            )

        # Freeze backbone if configured
        if config.freeze_backbone:
            for name, param in model.named_parameters():
                if "classifier" not in name:
                    param.requires_grad = False
            logger.info("Backbone frozen, only training classifier head")

        self.model = model.to(self.device)

        # Optimizer
        trainable_params = [p for p in self.model.parameters() if p.requires_grad]
        self.optimizer = AdamW(
            trainable_params,
            lr=config.learning_rate,
            weight_decay=config.weight_decay,
        )

    def train(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader | None = None,
    ) -> dict[str, float]:
        """Run fine-tuning loop."""
        num_steps = len(train_loader) * self.config.num_epochs
        warmup_steps = int(num_steps * self.config.warmup_ratio)

        scheduler = CosineAnnealingLR(
            self.optimizer,
            T_max=num_steps - warmup_steps,
        )

        best_val_metric = 0.0
        patience_counter = 0

        for epoch in range(self.config.num_epochs):
            self.model.train()
            epoch_loss = 0.0
            correct = 0
            total = 0

            for batch in train_loader:
                batch = {
                    k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                    for k, v in batch.items()
                }

                outputs = self.model(**batch)
                loss = outputs.get("classification_loss", outputs["total_loss"])

                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()
                scheduler.step()
                self.optimizer.zero_grad()

                epoch_loss += loss.item()

                # Track accuracy for annotation task
                if "classification_logits" in outputs and "cell_type_id" in batch:
                    preds = outputs["classification_logits"].argmax(dim=-1)
                    mask = batch["cell_type_id"] >= 0
                    correct += (preds[mask] == batch["cell_type_id"][mask]).sum().item()
                    total += mask.sum().item()

            avg_loss = epoch_loss / len(train_loader)
            acc = correct / max(total, 1)
            logger.info(f"Epoch {epoch + 1}: loss={avg_loss:.4f}, accuracy={acc:.4f}")

            # Validation
            if val_loader:
                val_metrics = self.evaluate(val_loader)
                val_metric = val_metrics.get("accuracy", -val_metrics.get("loss", 0))

                if val_metric > best_val_metric:
                    best_val_metric = val_metric
                    patience_counter = 0
                    self._save_checkpoint("best")
                else:
                    patience_counter += 1
                    if patience_counter >= self.config.patience:
                        logger.info(f"Early stopping at epoch {epoch + 1}")
                        break

        return {"final_loss": avg_loss, "final_accuracy": acc}

    @torch.no_grad()
    def evaluate(self, dataloader: DataLoader) -> dict[str, float]:
        """Evaluate model on a dataset."""
        self.model.eval()
        total_loss = 0.0
        all_preds = []
        all_labels = []

        for batch in dataloader:
            batch = {
                k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                for k, v in batch.items()
            }

            outputs = self.model(**batch)
            total_loss += outputs.get("classification_loss", outputs["total_loss"]).item()

            if "classification_logits" in outputs and "cell_type_id" in batch:
                preds = outputs["classification_logits"].argmax(dim=-1)
                mask = batch["cell_type_id"] >= 0
                all_preds.extend(preds[mask].cpu().tolist())
                all_labels.extend(batch["cell_type_id"][mask].cpu().tolist())

        metrics = {"loss": total_loss / len(dataloader)}

        if all_preds:
            from sklearn.metrics import accuracy_score, f1_score
            metrics["accuracy"] = accuracy_score(all_labels, all_preds)
            metrics["macro_f1"] = f1_score(all_labels, all_preds, average="macro")
            logger.info(
                f"Eval: loss={metrics['loss']:.4f}, "
                f"accuracy={metrics['accuracy']:.4f}, "
                f"macro_f1={metrics['macro_f1']:.4f}"
            )

        return metrics

    def _save_checkpoint(self, name: str) -> None:
        path = Path(self.config.output_dir) / name
        path.mkdir(parents=True, exist_ok=True)
        self.model.save_pretrained(path)
        logger.info(f"Fine-tuned model saved: {path}")


def main():
    """Entry point for fine-tuning."""
    import argparse

    parser = argparse.ArgumentParser(description="CeLLM Fine-tuning")
    parser.add_argument("--pretrained", type=str, required=True)
    parser.add_argument("--task", type=str, default="annotation")
    parser.add_argument("--num_classes", type=int, default=10)
    parser.add_argument("--output_dir", type=str, default="./finetune_checkpoints")
    args = parser.parse_args()

    model = CeLLM.from_pretrained(args.pretrained)
    config = FineTuneConfig(
        task=args.task,
        num_classes=args.num_classes,
        output_dir=args.output_dir,
    )
    finetuner = FineTuner(model, config)
    logger.info("Fine-tuner ready. Provide train/val dataloaders to start training.")


if __name__ == "__main__":
    main()
