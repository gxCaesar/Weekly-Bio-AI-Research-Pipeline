"""
Unit tests for CeLLM model components.

Tests cover:
    - Tokenizer encoding/decoding
    - Mamba encoder forward pass
    - KIM graph processing
    - LAM contrastive alignment
    - Full CeLLM forward pass
    - Model save/load
"""

import numpy as np
import pytest
import torch

from cellm.data.tokenizer import GeneExpressionTokenizer, TokenizerConfig
from cellm.models.cellm_model import CeLLM, CeLLMConfig
from cellm.models.mamba_encoder import MambaGeneEncoder, MambaEncoderConfig
from cellm.models.knowledge_module import KnowledgeIntegrationModule, KIMConfig
from cellm.models.language_alignment import LanguageAlignmentModule, LAMConfig


# ============================================================
# Fixtures
# ============================================================


@pytest.fixture
def small_config():
    """Small model config for fast testing."""
    return CeLLMConfig(
        encoder=MambaEncoderConfig(
            num_genes=100,
            vocab_size=103,
            hidden_dim=64,
            num_layers=2,
            state_dim=4,
            num_expression_bins=11,
            pooling="mean",
        ),
        kim=KIMConfig(
            num_genes=100,
            num_pathways=20,
            gat_hidden_dim=32,
            gat_num_heads=2,
            gat_num_layers=1,
            hidden_dim=64,
            num_cross_attn_heads=2,
        ),
        lam=LAMConfig(
            cell_embed_dim=64,
            text_embed_dim=64,
            projection_dim=32,
            projector_hidden_dim=32,
            projector_num_layers=1,
        ),
        use_kim=False,  # Disable KIM by default (requires graph setup)
        use_lam=False,  # Disable LAM by default (requires text encoder)
    )


@pytest.fixture
def sample_batch():
    """Create a sample batch of tokenized cells."""
    batch_size = 4
    seq_len = 100

    return {
        "gene_ids": torch.randint(3, 103, (batch_size, seq_len)),
        "bin_ids": torch.randint(0, 11, (batch_size, seq_len)),
        "residuals": torch.randn(batch_size, seq_len),
        "attention_mask": torch.ones(batch_size, seq_len, dtype=torch.long),
        "chr_positions": torch.randint(0, 25000, (batch_size, seq_len)),
        "mask_indices": torch.zeros(batch_size, seq_len, dtype=torch.long),
        "original_bin_ids": torch.randint(0, 11, (batch_size, seq_len)),
        "original_residuals": torch.randn(batch_size, seq_len),
    }


@pytest.fixture
def gene_names():
    """Generate test gene names."""
    return [f"GENE_{i}" for i in range(100)]


# ============================================================
# Tokenizer Tests
# ============================================================


class TestTokenizer:
    def test_init(self):
        config = TokenizerConfig(num_bins=11, max_genes=100)
        tokenizer = GeneExpressionTokenizer(config)
        assert not tokenizer.is_fitted

    def test_fit(self, gene_names):
        config = TokenizerConfig(num_bins=11, max_genes=100)
        tokenizer = GeneExpressionTokenizer(config)

        # Generate fake expression data
        expr = np.random.exponential(2, size=(50, 100)).astype(np.float32)

        tokenizer.fit(expr, gene_names)
        assert tokenizer.is_fitted
        assert len(tokenizer.gene_vocab) == 100
        assert tokenizer.bin_edges is not None

    def test_tokenize(self, gene_names):
        config = TokenizerConfig(num_bins=11, max_genes=100)
        tokenizer = GeneExpressionTokenizer(config)

        expr = np.random.exponential(2, size=(50, 100)).astype(np.float32)
        tokenizer.fit(expr, gene_names)

        # Tokenize a single cell
        cell_expr = np.random.exponential(2, size=(100,)).astype(np.float32)
        tokens = tokenizer.tokenize(cell_expr, gene_names)

        assert "gene_ids" in tokens
        assert "bin_ids" in tokens
        assert "residuals" in tokens
        assert "attention_mask" in tokens
        assert tokens["gene_ids"].shape == (100,)
        assert tokens["bin_ids"].shape == (100,)

    def test_batch_tokenize(self, gene_names):
        config = TokenizerConfig(num_bins=11, max_genes=100)
        tokenizer = GeneExpressionTokenizer(config)

        expr = np.random.exponential(2, size=(50, 100)).astype(np.float32)
        tokenizer.fit(expr, gene_names)

        batch = tokenizer.batch_tokenize(expr[:4], gene_names)
        assert batch["gene_ids"].shape == (4, 100)

    def test_save_load(self, gene_names, tmp_path):
        config = TokenizerConfig(num_bins=11, max_genes=100)
        tokenizer = GeneExpressionTokenizer(config)

        expr = np.random.exponential(2, size=(50, 100)).astype(np.float32)
        tokenizer.fit(expr, gene_names)

        # Save
        tokenizer.save(tmp_path / "tokenizer")

        # Load
        loaded = GeneExpressionTokenizer.load(tmp_path / "tokenizer")
        assert loaded.is_fitted
        assert len(loaded.gene_vocab) == 100


# ============================================================
# Mamba Encoder Tests
# ============================================================


class TestMambaEncoder:
    def test_forward(self, sample_batch):
        config = MambaEncoderConfig(
            num_genes=100, vocab_size=103, hidden_dim=64,
            num_layers=2, state_dim=4, num_expression_bins=11,
            pooling="mean",
        )
        encoder = MambaGeneEncoder(config)

        output = encoder(
            gene_ids=sample_batch["gene_ids"],
            bin_ids=sample_batch["bin_ids"],
            residuals=sample_batch["residuals"],
            attention_mask=sample_batch["attention_mask"],
        )

        assert "cell_embedding" in output
        assert "bin_logits" in output
        assert output["cell_embedding"].shape == (4, 64)
        assert output["bin_logits"].shape == (4, 100, 11)

    def test_with_gene_embeddings(self, sample_batch):
        config = MambaEncoderConfig(
            num_genes=100, vocab_size=103, hidden_dim=64,
            num_layers=2, state_dim=4, num_expression_bins=11,
        )
        encoder = MambaGeneEncoder(config)

        output = encoder(
            gene_ids=sample_batch["gene_ids"],
            bin_ids=sample_batch["bin_ids"],
            return_gene_embeddings=True,
        )

        assert "gene_embeddings" in output
        assert output["gene_embeddings"].shape == (4, 100, 64)

    def test_parameter_count(self):
        config = MambaEncoderConfig(
            num_genes=100, vocab_size=103, hidden_dim=64,
            num_layers=2, state_dim=4,
        )
        encoder = MambaGeneEncoder(config)
        assert encoder.num_parameters > 0


# ============================================================
# KIM Tests
# ============================================================


class TestKIM:
    def test_forward(self):
        config = KIMConfig(
            num_genes=100, num_pathways=20,
            gat_hidden_dim=32, gat_num_heads=2, gat_num_layers=1,
            hidden_dim=64, num_cross_attn_heads=2,
        )
        kim = KnowledgeIntegrationModule(config)

        # Build synthetic graph
        from cellm.utils.gene_ontology import GeneOntologyGraph
        gene_names = [f"GENE_{i}" for i in range(100)]
        go_graph = GeneOntologyGraph(gene_names, num_pathways=20)
        edge_index = go_graph.build_synthetic_graph(num_pathways=20, genes_per_pathway=10)
        kim.set_graph(edge_index)

        # Test forward
        mamba_output = torch.randn(4, 100, 64)
        gene_ids = torch.randint(0, 100, (4, 100))

        fused = kim(mamba_output, gene_ids)
        assert fused.shape == (4, 100, 64)


# ============================================================
# LAM Tests
# ============================================================


class TestLAM:
    def test_projectors(self):
        config = LAMConfig(
            cell_embed_dim=64, text_embed_dim=64,
            projection_dim=32, projector_hidden_dim=32,
            projector_num_layers=1,
        )
        lam = LanguageAlignmentModule(config)

        cell_emb = torch.randn(4, 64)
        text_emb = torch.randn(4, 64)

        cell_proj = lam.encode_cells(cell_emb)
        text_proj = lam.encode_text(text_embeddings=text_emb)

        assert cell_proj.shape == (4, 32)
        assert text_proj.shape == (4, 32)
        # Check normalization
        assert torch.allclose(cell_proj.norm(dim=-1), torch.ones(4), atol=1e-5)

    def test_contrastive_loss(self):
        config = LAMConfig(
            cell_embed_dim=64, text_embed_dim=64,
            projection_dim=32, projector_hidden_dim=32,
        )
        lam = LanguageAlignmentModule(config)

        cell_emb = torch.randn(8, 64)
        text_emb = torch.randn(8, 64)

        output = lam(cell_emb, text_embeddings=text_emb)

        assert "loss" in output
        assert output["loss"].requires_grad
        assert output["loss"].item() > 0


# ============================================================
# Full CeLLM Tests
# ============================================================


class TestCeLLM:
    def test_forward_minimal(self, small_config, sample_batch):
        model = CeLLM(small_config)

        # Set mask
        sample_batch["mask_indices"][:, :15] = 1

        output = model(**sample_batch)

        assert "cell_embedding" in output
        assert "total_loss" in output
        assert output["cell_embedding"].shape == (4, 64)
        assert output["total_loss"].requires_grad

    def test_gradient_flow(self, small_config, sample_batch):
        model = CeLLM(small_config)
        sample_batch["mask_indices"][:, :15] = 1

        output = model(**sample_batch)
        output["total_loss"].backward()

        # Check gradients exist
        has_grad = False
        for p in model.parameters():
            if p.grad is not None and p.grad.abs().sum() > 0:
                has_grad = True
                break
        assert has_grad

    def test_parameter_count(self, small_config):
        model = CeLLM(small_config)
        assert model.num_parameters > 0

    def test_cell_embeddings(self, small_config, sample_batch):
        model = CeLLM(small_config)
        emb = model.get_cell_embeddings(
            sample_batch["gene_ids"],
            sample_batch["bin_ids"],
            sample_batch["residuals"],
            sample_batch["attention_mask"],
        )
        assert emb.shape == (4, 64)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
