#!/bin/bash
# CeLLM Benchmark Evaluation Script
# ==================================

set -euo pipefail

MODEL_PATH="${1:-./checkpoints/cellm_pretrain_v1/best}"
DATA_DIR="${2:-./benchmark_data}"
OUTPUT="${3:-./results/benchmark_results.json}"

echo "============================================"
echo "CeLLM Benchmark Evaluation"
echo "============================================"
echo "Model: ${MODEL_PATH}"
echo "Data: ${DATA_DIR}"
echo "Output: ${OUTPUT}"
echo "============================================"

python -m cellm.evaluation.benchmark \
    --model_path "${MODEL_PATH}" \
    --data_dir "${DATA_DIR}" \
    --tasks annotation integration perturbation trajectory zero_shot \
    --output "${OUTPUT}"

echo "Benchmark complete! Results saved to ${OUTPUT}"
