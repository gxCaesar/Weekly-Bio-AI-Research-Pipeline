"""
Gene Expression Tokenizer

Implements the hybrid continuous-discrete encoding scheme for CeLLM.

The tokenizer converts raw gene expression counts into a structured representation:
  - Discrete bin token: expression level binned into B categories
  - Continuous residual: the difference between log-expression and bin center
  - Gene identity token: unique ID for each gene
  - Chromosomal position encoding: based on genomic coordinates

This hybrid approach preserves quantitative information lost by pure binning
while maintaining the discrete token structure needed for masked prediction.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
import torch
from scipy.sparse import issparse


@dataclass
class TokenizerConfig:
    """Configuration for gene expression tokenization."""

    num_bins: int = 51  # Number of expression bins (0 = zero expression, 1-50 = quantile bins)
    max_genes: int = 20000  # Maximum number of genes to model
    pad_token_id: int = 0
    mask_token_id: int = 1
    cls_token_id: int = 2
    special_tokens: int = 3  # PAD, MASK, CLS
    include_zero_bin: bool = True
    log_transform: bool = True  # Apply log1p before binning
    gene_order: str = "chromosomal"  # "chromosomal", "alphabetical", or "expression_rank"
    vocab_path: Optional[str] = None  # Path to gene vocabulary file


class GeneExpressionTokenizer:
    """
    Tokenizes gene expression profiles into hybrid continuous-discrete representations.

    For each gene i in a cell:
        - bin_id[i]: discrete bin index (0 = not expressed, 1..B = expression quantiles)
        - residual[i]: continuous offset from bin center
        - gene_id[i]: integer gene identity token

    The tokenizer is fitted on a reference dataset to determine bin boundaries.
    """

    def __init__(self, config: TokenizerConfig | None = None):
        self.config = config or TokenizerConfig()
        self.gene_vocab: dict[str, int] = {}
        self.gene_to_chr: dict[str, tuple[int, int]] = {}  # gene -> (chromosome, position)
        self.bin_edges: np.ndarray | None = None
        self.bin_centers: np.ndarray | None = None
        self.is_fitted = False

    def fit(
        self,
        reference_expressions: np.ndarray,
        gene_names: list[str],
        gene_chr_positions: dict[str, tuple[int, int]] | None = None,
    ) -> "GeneExpressionTokenizer":
        """
        Fit the tokenizer on reference expression data.

        Args:
            reference_expressions: (n_cells, n_genes) expression matrix (raw counts or normalized)
            gene_names: List of gene names corresponding to columns
            gene_chr_positions: Optional mapping of gene name -> (chromosome_int, position)

        Returns:
            self
        """
        if issparse(reference_expressions):
            reference_expressions = reference_expressions.toarray()

        # Build gene vocabulary
        self.gene_vocab = {
            gene: idx + self.config.special_tokens for idx, gene in enumerate(gene_names)
        }

        # Store chromosomal positions if provided
        if gene_chr_positions:
            self.gene_to_chr = gene_chr_positions

        # Log-transform if configured
        if self.config.log_transform:
            expr_values = np.log1p(reference_expressions)
        else:
            expr_values = reference_expressions.copy()

        # Compute bin edges from non-zero values
        nonzero_values = expr_values[expr_values > 0]
        if len(nonzero_values) == 0:
            raise ValueError("No non-zero expression values found in reference data")

        # Create quantile-based bins for non-zero values
        n_nonzero_bins = self.config.num_bins - 1  # Reserve bin 0 for zero expression
        quantiles = np.linspace(0, 100, n_nonzero_bins + 1)
        self.bin_edges = np.percentile(nonzero_values, quantiles)
        self.bin_edges[0] = 0.0  # Ensure lower bound is 0

        # Compute bin centers
        self.bin_centers = np.zeros(self.config.num_bins)
        self.bin_centers[0] = 0.0  # Zero-expression bin center
        for i in range(1, self.config.num_bins):
            if i < len(self.bin_edges):
                self.bin_centers[i] = (self.bin_edges[i - 1] + self.bin_edges[min(i, len(self.bin_edges) - 1)]) / 2

        self.is_fitted = True
        return self

    def tokenize(
        self,
        expression_vector: np.ndarray,
        gene_names: list[str],
        return_tensors: str = "pt",
    ) -> dict[str, torch.Tensor | np.ndarray]:
        """
        Tokenize a single cell's expression profile.

        Args:
            expression_vector: (n_genes,) expression values for one cell
            gene_names: Gene names corresponding to expression values
            return_tensors: "pt" for PyTorch tensors, "np" for numpy arrays

        Returns:
            Dictionary with keys:
                - gene_ids: (seq_len,) gene identity tokens
                - bin_ids: (seq_len,) discrete expression bin tokens
                - residuals: (seq_len,) continuous residual values
                - attention_mask: (seq_len,) 1 for real genes, 0 for padding
                - chr_positions: (seq_len,) chromosomal position indices
        """
        if not self.is_fitted:
            raise RuntimeError("Tokenizer must be fitted before tokenizing. Call fit() first.")

        if issparse(expression_vector):
            expression_vector = expression_vector.toarray().flatten()

        # Filter to known genes and get their order
        gene_ids = []
        bin_ids = []
        residuals = []
        chr_positions = []

        for i, gene in enumerate(gene_names):
            if gene not in self.gene_vocab:
                continue

            gene_id = self.gene_vocab[gene]
            expr_val = expression_vector[i]

            # Log transform
            if self.config.log_transform:
                log_expr = np.log1p(expr_val)
            else:
                log_expr = expr_val

            # Determine bin
            if log_expr == 0:
                bin_id = 0
                residual = 0.0
            else:
                bin_id = int(np.searchsorted(self.bin_edges, log_expr, side="right"))
                bin_id = min(bin_id, self.config.num_bins - 1)
                residual = float(log_expr - self.bin_centers[bin_id])

            gene_ids.append(gene_id)
            bin_ids.append(bin_id)
            residuals.append(residual)

            # Chromosomal position
            if gene in self.gene_to_chr:
                chr_num, pos = self.gene_to_chr[gene]
                chr_positions.append(chr_num * 1_000_000 + pos // 1000)  # Coarse position
            else:
                chr_positions.append(0)

        # Sort by chromosomal position if configured
        if self.config.gene_order == "chromosomal" and any(p > 0 for p in chr_positions):
            order = np.argsort(chr_positions)
            gene_ids = [gene_ids[i] for i in order]
            bin_ids = [bin_ids[i] for i in order]
            residuals = [residuals[i] for i in order]
            chr_positions = [chr_positions[i] for i in order]

        # Pad or truncate to max_genes
        seq_len = min(len(gene_ids), self.config.max_genes)
        attention_mask = [1] * seq_len + [0] * (self.config.max_genes - seq_len)

        gene_ids = gene_ids[:seq_len] + [self.config.pad_token_id] * (self.config.max_genes - seq_len)
        bin_ids = bin_ids[:seq_len] + [0] * (self.config.max_genes - seq_len)
        residuals = residuals[:seq_len] + [0.0] * (self.config.max_genes - seq_len)
        chr_positions = chr_positions[:seq_len] + [0] * (self.config.max_genes - seq_len)

        result = {
            "gene_ids": gene_ids,
            "bin_ids": bin_ids,
            "residuals": residuals,
            "attention_mask": attention_mask,
            "chr_positions": chr_positions,
        }

        if return_tensors == "pt":
            result = {
                "gene_ids": torch.tensor(result["gene_ids"], dtype=torch.long),
                "bin_ids": torch.tensor(result["bin_ids"], dtype=torch.long),
                "residuals": torch.tensor(result["residuals"], dtype=torch.float32),
                "attention_mask": torch.tensor(result["attention_mask"], dtype=torch.long),
                "chr_positions": torch.tensor(result["chr_positions"], dtype=torch.long),
            }

        return result

    def batch_tokenize(
        self,
        expression_matrix: np.ndarray,
        gene_names: list[str],
    ) -> dict[str, torch.Tensor]:
        """Tokenize a batch of cells."""
        batch = [
            self.tokenize(expression_matrix[i], gene_names, return_tensors="pt")
            for i in range(expression_matrix.shape[0])
        ]
        return {key: torch.stack([b[key] for b in batch]) for key in batch[0].keys()}

    def save(self, path: str | Path) -> None:
        """Save tokenizer state to disk."""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        state = {
            "config": {
                "num_bins": self.config.num_bins,
                "max_genes": self.config.max_genes,
                "log_transform": self.config.log_transform,
                "gene_order": self.config.gene_order,
            },
            "gene_vocab": self.gene_vocab,
            "bin_edges": self.bin_edges.tolist() if self.bin_edges is not None else None,
            "bin_centers": self.bin_centers.tolist() if self.bin_centers is not None else None,
        }

        with open(path / "tokenizer.json", "w") as f:
            json.dump(state, f, indent=2)

    @classmethod
    def load(cls, path: str | Path) -> "GeneExpressionTokenizer":
        """Load tokenizer from disk."""
        path = Path(path)
        with open(path / "tokenizer.json") as f:
            state = json.load(f)

        config = TokenizerConfig(**state["config"])
        tokenizer = cls(config)
        tokenizer.gene_vocab = state["gene_vocab"]
        tokenizer.bin_edges = np.array(state["bin_edges"]) if state["bin_edges"] else None
        tokenizer.bin_centers = np.array(state["bin_centers"]) if state["bin_centers"] else None
        tokenizer.is_fitted = tokenizer.bin_edges is not None
        return tokenizer
