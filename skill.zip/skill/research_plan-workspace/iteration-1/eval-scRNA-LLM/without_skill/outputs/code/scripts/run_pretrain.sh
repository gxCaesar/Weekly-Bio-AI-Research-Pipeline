#!/bin/bash
# CeLLM Pre-training Script
# ========================
# Run on 8x A100 GPUs with DDP

set -euo pipefail

# Configuration
export MASTER_ADDR="localhost"
export MASTER_PORT="29500"
export WORLD_SIZE=8

OUTPUT_DIR="./checkpoints/cellm_pretrain_v1"
DATA_DIR="./data/pretrain"
CONFIG="cellm/configs/default_config.yaml"

# Create output directory
mkdir -p "${OUTPUT_DIR}"

echo "============================================"
echo "CeLLM Pre-training"
echo "============================================"
echo "Output: ${OUTPUT_DIR}"
echo "GPUs: ${WORLD_SIZE}"
echo "============================================"

# Run with torchrun for DDP
torchrun \
    --nproc_per_node=${WORLD_SIZE} \
    --master_addr=${MASTER_ADDR} \
    --master_port=${MASTER_PORT} \
    -m cellm.trainers.pretrain \
    --output_dir "${OUTPUT_DIR}" \
    --max_steps 200000 \
    --batch_size 64 \
    --learning_rate 1e-4

echo "Pre-training complete!"
