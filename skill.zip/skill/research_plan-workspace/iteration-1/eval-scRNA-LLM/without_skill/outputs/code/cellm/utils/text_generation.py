"""
Cell-Text pair generation utilities.

Generates natural language descriptions for cell types to create
training data for the Language Alignment Module (LAM).

Sources:
    1. Cell Ontology (CL) definitions
    2. Marker gene-based descriptions
    3. Pathway enrichment summaries
    4. LLM-generated descriptions (GPT-4 / Claude)
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Curated cell type descriptions based on Cell Ontology and standard biology references
CELL_TYPE_DESCRIPTIONS = {
    "T cell": (
        "T lymphocyte, a type of white blood cell that plays a central role in "
        "adaptive immunity. Characterized by expression of CD3, TCR genes. "
        "Subtypes include CD4+ helper T cells and CD8+ cytotoxic T cells."
    ),
    "B cell": (
        "B lymphocyte, responsible for humoral immunity through antibody production. "
        "Expresses surface immunoglobulins (BCR), CD19, CD20, and PAX5. "
        "Differentiates into antibody-secreting plasma cells upon activation."
    ),
    "monocyte": (
        "Large mononuclear phagocytic cell of the innate immune system. "
        "Expresses CD14, CD16, and CSF1R. Circulates in blood and differentiates "
        "into macrophages or dendritic cells upon tissue migration."
    ),
    "macrophage": (
        "Tissue-resident phagocytic cell derived from monocytes. Functions in "
        "innate immunity, antigen presentation, and tissue homeostasis. "
        "Expresses CD68, CD163, MARCO. Polarizes into M1 (pro-inflammatory) "
        "or M2 (anti-inflammatory) states."
    ),
    "dendritic cell": (
        "Professional antigen-presenting cell that bridges innate and adaptive immunity. "
        "Expresses MHC-II, CD11c, CD80/CD86. Captures antigens in peripheral tissues "
        "and migrates to lymph nodes to activate T cells."
    ),
    "NK cell": (
        "Natural killer cell, a cytotoxic lymphocyte of the innate immune system. "
        "Expresses NKG2D, CD56, CD16 (FCGR3A). Kills virus-infected and tumor cells "
        "without prior sensitization through perforin/granzyme pathway."
    ),
    "neutrophil": (
        "Most abundant granulocyte in blood, first responder to infection. "
        "Expresses CD66b, CD15, S100A8/A9. Functions through phagocytosis, "
        "degranulation, and neutrophil extracellular trap (NET) formation."
    ),
    "fibroblast": (
        "Mesenchymal cell responsible for extracellular matrix production and "
        "tissue structural support. Expresses COL1A1, COL3A1, VIM, FAP. "
        "Key role in wound healing and tissue fibrosis."
    ),
    "endothelial cell": (
        "Cell lining blood and lymphatic vessels, forming the endothelium. "
        "Expresses PECAM1 (CD31), VWF, CDH5, KDR. Regulates vascular permeability, "
        "angiogenesis, and immune cell trafficking."
    ),
    "epithelial cell": (
        "Cell forming epithelial tissue that lines body surfaces and cavities. "
        "Expresses EPCAM, KRT8, KRT18, CDH1. Functions in barrier protection, "
        "secretion, and absorption. Subtypes vary by tissue."
    ),
    "hepatocyte": (
        "Primary parenchymal cell of the liver, performing metabolic functions. "
        "Expresses ALB, HNF4A, CYP enzymes, APOB. Responsible for protein "
        "synthesis, bile production, detoxification, and metabolism."
    ),
    "neuron": (
        "Electrically excitable cell of the nervous system that processes and "
        "transmits information via synaptic signaling. Expresses RBFOX3 (NeuN), "
        "SYP, MAP2. Subtypes include excitatory (glutamatergic) and inhibitory (GABAergic)."
    ),
    "astrocyte": (
        "Star-shaped glial cell in the central nervous system. Expresses GFAP, "
        "AQP4, S100B, SLC1A3. Functions in blood-brain barrier maintenance, "
        "neurotransmitter recycling, and metabolic support of neurons."
    ),
    "oligodendrocyte": (
        "Glial cell responsible for myelination of axons in the central nervous system. "
        "Expresses MBP, PLP1, MOG, OLIG2. Each oligodendrocyte can myelinate "
        "multiple axon segments to enable rapid signal conduction."
    ),
    "cardiomyocyte": (
        "Cardiac muscle cell responsible for heart contraction. Expresses TNNT2, "
        "MYH7, ACTC1, NKX2-5. Features sarcomeric organization, gap junctions "
        "for electrical coupling, and high mitochondrial content."
    ),
}


class CellTextGenerator:
    """
    Generate natural language descriptions for cell types.

    Combines curated descriptions with automated generation from
    marker genes and pathway enrichment results.
    """

    def __init__(self, custom_descriptions: dict[str, str] | None = None):
        """
        Args:
            custom_descriptions: Additional cell type descriptions to use
        """
        self.descriptions = dict(CELL_TYPE_DESCRIPTIONS)
        if custom_descriptions:
            self.descriptions.update(custom_descriptions)

    def get_description(self, cell_type: str) -> str | None:
        """Get description for a cell type (case-insensitive fuzzy match)."""
        # Exact match
        if cell_type in self.descriptions:
            return self.descriptions[cell_type]

        # Case-insensitive match
        lower_map = {k.lower(): v for k, v in self.descriptions.items()}
        if cell_type.lower() in lower_map:
            return lower_map[cell_type.lower()]

        # Partial match
        for key, desc in self.descriptions.items():
            if cell_type.lower() in key.lower() or key.lower() in cell_type.lower():
                return desc

        return None

    def generate_from_markers(
        self,
        cell_type: str,
        marker_genes: list[str],
        top_n: int = 10,
    ) -> str:
        """
        Generate a description from marker genes.

        Args:
            cell_type: Cell type name
            marker_genes: List of marker gene names (sorted by importance)
            top_n: Number of top markers to include

        Returns:
            Natural language description
        """
        top_markers = marker_genes[:top_n]
        marker_str = ", ".join(top_markers)
        return (
            f"{cell_type} is characterized by high expression of {marker_str}. "
            f"These marker genes suggest involvement in specific biological "
            f"processes and cellular functions associated with {cell_type} identity."
        )

    def generate_from_enrichment(
        self,
        cell_type: str,
        enriched_pathways: list[tuple[str, float]],  # (pathway_name, p_value)
        top_n: int = 5,
    ) -> str:
        """
        Generate description from pathway enrichment results.

        Args:
            cell_type: Cell type name
            enriched_pathways: List of (pathway_name, p_value) tuples
            top_n: Number of top pathways to include

        Returns:
            Natural language description
        """
        top_pathways = sorted(enriched_pathways, key=lambda x: x[1])[:top_n]
        pathway_names = [p[0] for p in top_pathways]
        pathway_str = "; ".join(pathway_names)
        return (
            f"{cell_type} shows enrichment for the following biological pathways: "
            f"{pathway_str}. These pathway signatures define the functional "
            f"characteristics and cellular state of {cell_type}."
        )

    def get_all_descriptions(self) -> dict[str, str]:
        """Return all available cell type descriptions."""
        return dict(self.descriptions)

    def save(self, path: str | Path) -> None:
        """Save descriptions to JSON."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.descriptions, f, indent=2)

    @classmethod
    def load(cls, path: str | Path) -> "CellTextGenerator":
        """Load descriptions from JSON."""
        with open(path) as f:
            descriptions = json.load(f)
        return cls(custom_descriptions=descriptions)
