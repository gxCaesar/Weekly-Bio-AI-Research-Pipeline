# Code Project Structure & Conventions

## Project Layout

```
code/
├── configs/                      # All hyperparameters live here
│   ├── default.yaml              # Default config (inherited by others)
│   ├── baseline_method1.yaml     # Override for baseline 1
│   ├── baseline_method2.yaml     # Override for baseline 2
│   ├── ablation_no_component1.yaml
│   └── ablation_no_component2.yaml
├── data/
│   ├── __init__.py
│   ├── download.py               # Automated dataset download
│   ├── preprocess.py             # Raw → processed data pipeline
│   ├── dataset.py                # torch.utils.data.Dataset classes
│   └── collator.py               # Custom collate functions
├── models/
│   ├── __init__.py
│   ├── model.py                  # Main model class
│   ├── modules.py                # Reusable sub-modules
│   └── losses.py                 # Loss functions
├── baselines/
│   ├── __init__.py
│   └── {name}.py                 # One file per baseline
├── training/
│   ├── __init__.py
│   ├── trainer.py                # Training loop
│   ├── optimizer.py              # Optimizer & scheduler factory
│   └── callbacks.py              # Checkpointing, logging, early stop
├── evaluation/
│   ├── __init__.py
│   ├── metrics.py                # Metric computation functions
│   ├── evaluate.py               # Full evaluation pipeline
│   └── visualize.py              # Plot generation
├── scripts/
│   ├── run_all.sh                # End-to-end pipeline
│   ├── train.sh                  # Train with args
│   ├── eval.sh                   # Evaluate checkpoint
│   ├── run_baselines.sh          # All baselines
│   └── run_ablation.sh           # All ablations
├── ablation/
│   └── run_ablation.py           # Orchestrates ablation experiments
├── main.py                       # CLI entry point
├── requirements.txt              # Pinned versions
└── README.md                     # English: setup, usage, structure
```

## Code Patterns

### Configuration (configs/default.yaml)

```yaml
# Model
model:
  name: "OurModel"
  hidden_dim: 768
  num_layers: 12
  num_heads: 12
  dropout: 0.1

# Data
data:
  dataset: "dataset_name"
  data_dir: "./data/processed"
  max_length: 512
  num_workers: 4

# Training
training:
  epochs: 100
  batch_size: 32
  gradient_accumulation_steps: 4
  learning_rate: 1e-4
  weight_decay: 0.01
  warmup_ratio: 0.1
  fp16: true
  gradient_checkpointing: false
  seed: 42

# Evaluation
evaluation:
  eval_every: 5
  metrics: ["accuracy", "f1", "auroc"]

# Logging
logging:
  wandb_project: "project-name"
  log_every: 100
  save_every: 10
  save_best: true

# Hardware
hardware:
  num_gpus: 1
  gpu_ids: [0]
```

### Main Entry Point (main.py)

```python
import argparse
import yaml
import torch
import random
import numpy as np
from pathlib import Path

def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True

def load_config(path: str) -> dict:
    with open(path) as f:
        config = yaml.safe_load(f)
    return config

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--mode", choices=["train", "eval", "train_eval"], default="train_eval")
    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--output_dir", type=str, default="./outputs")
    args = parser.parse_args()

    config = load_config(args.config)
    set_seed(config["training"]["seed"])
    # ... rest of pipeline
```

### Trainer Pattern (training/trainer.py)

Key requirements:
- Mixed precision with `torch.cuda.amp.GradScaler`
- Gradient accumulation loop
- Periodic evaluation
- Best model checkpointing
- Wandb/tensorboard logging
- Resume from checkpoint support
- Multi-GPU with `torch.nn.parallel.DistributedDataParallel`

```python
class Trainer:
    def __init__(self, model, train_loader, val_loader, config, device):
        self.model = model
        self.config = config
        self.device = device
        self.scaler = torch.cuda.amp.GradScaler(enabled=config["training"]["fp16"])
        self.best_metric = 0.0
        # ... setup optimizer, scheduler, logger

    def train_epoch(self, epoch: int):
        self.model.train()
        for step, batch in enumerate(self.train_loader):
            with torch.cuda.amp.autocast(enabled=self.config["training"]["fp16"]):
                loss = self.model(**batch).loss
                loss = loss / self.config["training"]["gradient_accumulation_steps"]

            self.scaler.scale(loss).backward()

            if (step + 1) % self.config["training"]["gradient_accumulation_steps"] == 0:
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.scheduler.step()
                self.optimizer.zero_grad()
```

### Shell Scripts Pattern (scripts/train.sh)

```bash
#!/bin/bash
set -e

CONFIG=${1:-configs/default.yaml}
OUTPUT_DIR=${2:-outputs/default}
NUM_GPUS=${3:-1}

echo "Training with config: $CONFIG"
echo "Output: $OUTPUT_DIR"

if [ "$NUM_GPUS" -gt 1 ]; then
    torchrun --nproc_per_node=$NUM_GPUS main.py \
        --config $CONFIG \
        --mode train_eval \
        --output_dir $OUTPUT_DIR
else
    python main.py \
        --config $CONFIG \
        --mode train_eval \
        --output_dir $OUTPUT_DIR
fi
```

### Requirements.txt Pattern

```
torch>=2.1.0
transformers>=4.36.0
datasets>=2.16.0
accelerate>=0.25.0
peft>=0.7.0
wandb>=0.16.0
scikit-learn>=1.3.0
scipy>=1.11.0
numpy>=1.24.0
pandas>=2.0.0
pyyaml>=6.0
tqdm>=4.65.0
matplotlib>=3.7.0
seaborn>=0.12.0
scanpy>=1.9.0
anndata>=0.10.0
```

(Adjust packages based on the specific research direction)

## Technical Manual Template (Chinese)

```markdown
# {项目名称} 技术手册

## 1. 环境配置

### 1.1 系统要求
- OS: Linux (Ubuntu 20.04/22.04 推荐)
- GPU: NVIDIA A100 80GB × 1-2
- CUDA: 11.8+
- Python: 3.10+

### 1.2 安装步骤

conda create -n {project} python=3.10 -y
conda activate {project}
pip install -r requirements.txt

### 1.3 验证安装
python -c "import torch; print(torch.cuda.is_available())"

## 2. 数据准备

### 2.1 下载数据
python data/download.py --dataset {name} --output_dir data/raw/

### 2.2 预处理
python data/preprocess.py --input_dir data/raw/ --output_dir data/processed/

### 2.3 验证数据
[期望的文件列表和大小]

## 3. 运行基线实验

### 3.1 基线1: {name}
bash scripts/run_baselines.sh baseline_method1

### 3.2 基线2: {name}
[...]

期望结果范围: [指标A: XX-XX, 指标B: XX-XX]

## 4. 训练我们的模型

### 4.1 默认配置训练
bash scripts/train.sh configs/default.yaml outputs/main

### 4.2 训练监控
- wandb: 浏览器打开 wandb.ai 查看训练曲线
- 日志: outputs/main/train.log
- 预期训练时间: ~XX 小时 (1x A100)

### 4.3 断点续训
python main.py --config configs/default.yaml --checkpoint outputs/main/last.pt

## 5. 评估

bash scripts/eval.sh outputs/main/best_model.pt

结果保存在: outputs/main/eval_results.json

## 6. 消融实验

bash scripts/run_ablation.sh

各消融实验说明:
- ablation_no_X: [移除了什么，验证什么]

## 7. 常见问题

### OOM (显存不足)
- 减小batch_size
- 开启gradient_checkpointing: true
- 减小max_length

### 训练loss不下降
- 检查学习率（尝试1e-5 到 1e-3范围）
- 检查数据预处理是否正确

### CUDA版本不匹配
conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia
```
