# Paper Writing Guide for Top Venues

## NeurIPS / ICML / ICLR Standards

### General Requirements
- **Page limit**: 9 pages main text + unlimited references and appendix
- **Format**: Two-column, 10pt font
- **Anonymous**: No author names, no identifying information in submission
- **Reproducibility**: Must include implementation details sufficient for reproduction

### Section-by-Section Guide

#### Abstract (~250 words)
Structure: Context → Problem → Approach → Key Results → Impact

Template:
```
[One sentence: broad context and why it matters]
[One sentence: specific problem or limitation of existing approaches]
[One sentence: what we propose — name the method]
[Two sentences: how the method works at a high level]
[Two sentences: key experimental results — datasets, metrics, improvement over SOTA]
[One sentence: broader significance or what this enables]
```

#### 1. Introduction (1.5 pages)

Paragraph structure:
1. **Hook** (1 para): Why this domain/problem matters. Start broad, narrow quickly.
2. **Problem** (1 para): What specific challenge exists. What have people tried. Why it's hard.
3. **Limitation** (1 para): What current best methods cannot do. Be specific and cite.
4. **Our approach** (1 para): High-level description of our method. What insight drives it.
5. **Contributions** (numbered list):
   - "We propose [METHOD], a [description] that [key innovation]."
   - "We introduce [technique/module] that [what it achieves]."
   - "Extensive experiments on [datasets] demonstrate that [METHOD] achieves [results]."
6. **Paper organization** (1 sentence): "The remainder of this paper is organized as follows..."

#### 2. Related Work (1-1.5 pages)

Organize by approach category, not chronologically. For each category:
- Brief description of the approach family
- Key representative papers (2-3 per category)
- How our work differs

End with a clear positioning statement: "Unlike [closest work], our method..."

Categories typically include:
- Traditional methods for the domain
- Deep learning approaches
- LLM/Foundation model based approaches
- [Domain-specific category]

#### 3. Method (2-3 pages)

Structure:
1. **Problem Formulation** (0.5 page): Formal notation, input/output definitions
   - Define all symbols in a notation table
   - State the learning objective mathematically

2. **Overall Framework** (0.5 page): High-level pipeline description
   - Reference Figure 2 (architecture diagram)
   - List all major components

3. **Component Details** (1-2 pages): One subsection per key component
   - For each: intuition → formulation → equations
   - Number all important equations
   - Explain design choices (why this architecture/loss/etc.)

4. **Training Objective** (0.25 page):
   - Final loss function (combination of component losses)
   - Training procedure (any special tricks)

5. **Complexity Analysis** (optional, 0.25 page):
   - Time and space complexity
   - Comparison with baselines

#### 4. Experiments (1.5-2 pages)

**4.1 Experimental Setup**
- Datasets: name, size, splits, preprocessing
- Baselines: list with citations, brief description
- Metrics: define each metric
- Implementation details: hardware, optimizer, learning rate, epochs, etc.

**4.2 Main Results**
- Table format: rows = methods, columns = metrics
- Bold best results, underline second-best
- Include ± std from multiple runs
- Placeholder: use `XX.X ± X.X`

**4.3 Ablation Study**
- Table showing contribution of each component
- Full model vs. removing each component

**4.4 Analysis / Case Study**
- Qualitative examples
- Visualization of learned representations
- Parameter sensitivity analysis

#### 5. Discussion (0.5 page)
- Interpretation of results
- Limitations (be honest — reviewers appreciate it)
- Broader impact statement

#### 6. Conclusion (0.5 page)
- Summarize contributions (don't just repeat abstract)
- Future work directions

### Writing Tips for Top Venues

1. **Every claim needs evidence**: either a citation or your own experiment
2. **Figures are the first thing reviewers look at**: make them self-contained with good captions
3. **Tables should tell a story**: arrange rows/columns so the pattern is obvious
4. **Related work is not a literature review**: it's a positioning exercise
5. **Method section**: balance between clarity (for general audience) and rigor (for experts)
6. **Results**: always include error bars / confidence intervals
7. **Writing quality matters**: proofread, consistent notation, no grammar errors

### Nature Sub-journal Differences

If targeting Nature Methods / Nature Machine Intelligence:
- Single column, longer format
- More emphasis on biological/domain significance
- Methods section often in supplementary
- Figures are larger and more elaborate (6+ composite figures)
- Need strong motivation from domain perspective
- Results narrative-driven rather than table-heavy

## Figure Count and Types

Plan for 6+ figures minimum:

| Figure | Content | Type |
|--------|---------|------|
| Fig 1 | Traditional vs. our approach | Comparison/overview diagram |
| Fig 2 | Model architecture | Architecture diagram |
| Fig 3 | Method detail / data pipeline | Technical diagram |
| Fig 4 | Main results visualization | Bar chart / line plot |
| Fig 5 | Ablation / analysis | Heatmap / bar chart |
| Fig 6 | Case study / qualitative | Domain-specific visualization |

Each figure should be composable into sub-panels (a, b, c, d) for Nature-style papers.

## Bibliography Standards

- 30-50 references for conference papers
- 50-80 for journal papers
- Always cite: seminal works, direct competitors, dataset papers, evaluation metric papers
- Use consistent citation format (author-year for Nature, numbered for NeurIPS)
