# Literature Survey Guide

## Survey Template (Chinese)

```markdown
# {研究方向} 文献调研报告

## 1. 研究背景

### 1.1 领域概述
[简要介绍该研究方向的背景，2-3段]

### 1.2 研究意义
[为什么这个方向重要，实际应用价值]

### 1.3 技术发展脉络
[从传统方法到深度学习到大模型的演进]

## 2. 核心论文汇总

| # | 论文标题 | 作者 | 发表venue | 年份 | 核心方法 | 数据集 | 开源代码 |
|---|---------|------|-----------|------|---------|--------|---------|
| 1 | ... | ... | NeurIPS | 2024 | ... | ... | GitHub链接 |
| 2 | ... | ... | Nature Methods | 2025 | ... | ... | GitHub链接 |
[收录15-30篇代表性论文]

## 3. 方法分类体系

### 3.1 基于[类别A]的方法
[描述该类方法的核心思路，代表论文，优缺点]

### 3.2 基于[类别B]的方法
[...]

### 3.3 基于[类别C]的方法
[...]

### 3.4 方法对比总结

| 方法类别 | 优势 | 局限性 | 代表论文 | 适用场景 |
|---------|------|--------|---------|---------|

## 4. 公开数据集与基准

| 数据集名称 | 来源 | 规模 | 任务类型 | 下载链接 | 常用指标 |
|-----------|------|------|---------|---------|---------|
[列出该方向所有常用公开数据集]

## 5. 研究空白分析

### 5.1 现有方法的共同局限
[识别当前方法的系统性不足]

### 5.2 未被充分探索的方向
[哪些角度还没有被充分研究]

### 5.3 技术机遇
[最新的AI技术（LLM, Agent, etc.）如何填补这些空白]

## 6. 推荐研究方向

### 6.1 方向描述
[基于上述分析，推荐最有前景的研究方向]

### 6.2 可行性分析
[为什么这个方向可行，有哪些现有工作可以借鉴]

### 6.3 预期创新点
[初步设想的创新点]

### 6.4 目标venue适配性
[这个方向适合投哪里，为什么]
```

## Search Strategy

### Primary Search Queries
Run at least 6 different queries combining:
- The research direction keywords
- Method keywords: LLM, foundation model, transformer, attention, agent, pre-training, fine-tuning
- Venue keywords: NeurIPS, ICML, ICLR, Nature Methods
- Recency: 2024, 2025, 2026

### Quality Filters
Prioritize papers that:
1. Appear at top venues (NeurIPS/ICML/ICLR/Nature family)
2. Have open-source code on GitHub
3. Use publicly available datasets
4. Report comprehensive benchmarks
5. Have been cited frequently (if older)

### Recording Standards
For each paper, extract:
- Full citation (authors, title, venue, year)
- One-sentence summary of the core contribution
- Key innovation (what's new)
- Datasets used (note which are public)
- GitHub URL (if available)
- Reported SOTA numbers on standard benchmarks
- Limitations mentioned by the authors
