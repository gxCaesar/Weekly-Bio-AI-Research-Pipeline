# LaTeX/TikZ Figure Guide

## Figure 1: Method Comparison Diagram

This figure shows why existing approaches fall short and how ours is different.
Use a side-by-side layout: left = traditional pipeline, right = our pipeline.

```latex
\begin{figure*}[t]
\centering
\begin{tikzpicture}[
    node distance=0.8cm and 1.2cm,
    block/.style={rectangle, draw, rounded corners, minimum height=1cm, minimum width=2.2cm, align=center, font=\small},
    arrow/.style={->, >=stealth, thick},
    label/.style={font=\small\bfseries, above},
    dashedblock/.style={rectangle, draw, dashed, rounded corners, minimum height=1cm, minimum width=2.2cm, align=center, font=\small, draw=gray},
]

% Left side: Traditional approach
\node[label] (trad_label) {(a) Traditional Approach};
\node[block, below=0.3cm of trad_label, fill=blue!10] (trad_input) {Raw Data};
\node[block, below=of trad_input, fill=blue!10] (trad_proc) {Feature\\Engineering};
\node[block, below=of trad_proc, fill=blue!10] (trad_model) {Task-Specific\\Model};
\node[block, below=of trad_model, fill=red!10] (trad_out) {Limited\\Results};

\draw[arrow] (trad_input) -- (trad_proc);
\draw[arrow] (trad_proc) -- (trad_model);
\draw[arrow] (trad_model) -- (trad_out);

% Cross mark for limitations
\node[right=0.1cm of trad_proc, text=red, font=\small] {$\times$ Manual};
\node[right=0.1cm of trad_model, text=red, font=\small] {$\times$ Not scalable};

% Right side: Our approach
\node[label, right=4cm of trad_label] (our_label) {(b) Our Approach};
\node[block, below=0.3cm of our_label, fill=green!10] (our_input) {Raw Data};
\node[block, below=of our_input, fill=green!10] (our_enc) {Foundation\\Model};
\node[block, below=of our_enc, fill=green!10] (our_novel) {\textbf{Our Novel}\\Module};
\node[block, below=of our_novel, fill=green!20] (our_out) {Superior\\Results};

\draw[arrow] (our_input) -- (our_enc);
\draw[arrow] (our_enc) -- (our_novel);
\draw[arrow] (our_novel) -- (our_out);

% Check marks for advantages
\node[right=0.1cm of our_enc, text=green!60!black, font=\small] {\checkmark~Automated};
\node[right=0.1cm of our_novel, text=green!60!black, font=\small] {\checkmark~Scalable};

\end{tikzpicture}
\caption{\textbf{Comparison of traditional approaches and our method.} (a)~Traditional methods require manual feature engineering and task-specific models that do not scale. (b)~Our approach leverages a foundation model backbone with our novel [Module Name] to achieve automated, scalable analysis.}
\label{fig:comparison}
\end{figure*}
```

## Figure 2: Model Architecture Diagram

The main architecture figure. Use blocks, arrows, and clear labeling.

```latex
\begin{figure*}[t]
\centering
\begin{tikzpicture}[
    node distance=0.6cm and 1.5cm,
    module/.style={rectangle, draw, rounded corners=3pt, minimum height=1.2cm, minimum width=2.5cm, align=center, font=\small},
    smallmod/.style={rectangle, draw, rounded corners=2pt, minimum height=0.8cm, minimum width=1.8cm, align=center, font=\scriptsize},
    arrow/.style={->, >=stealth, thick},
    darrow/.style={->, >=stealth, thick, dashed},
    bigarrow/.style={->, >=stealth, line width=1.5pt},
    label/.style={font=\scriptsize, midway},
    grouplabel/.style={font=\small\bfseries},
]

% Input
\node[module, fill=blue!15] (input) {Input\\Representation};

% Encoder block
\node[module, right=1.5cm of input, fill=orange!15] (encoder) {Encoder\\(Transformer)};

% Novel module (highlighted)
\node[module, right=1.5cm of encoder, fill=red!15, line width=1.5pt, draw=red!60] (novel) {\textbf{Our Novel}\\Module};

% Decoder/output
\node[module, right=1.5cm of novel, fill=green!15] (decoder) {Task Head};

% Output
\node[module, right=1.5cm of decoder, fill=gray!15] (output) {Prediction};

% Arrows
\draw[bigarrow] (input) -- (encoder);
\draw[bigarrow] (encoder) -- (novel);
\draw[bigarrow] (novel) -- (decoder);
\draw[bigarrow] (decoder) -- (output);

% Sub-components inside novel module (expanded below)
\node[grouplabel, below=1.5cm of novel] (detail_label) {Novel Module Detail};
\node[smallmod, below=0.3cm of detail_label, fill=red!8] (sub1) {Component A};
\node[smallmod, right=0.5cm of sub1, fill=red!8] (sub2) {Component B};
\node[smallmod, right=0.5cm of sub2, fill=red!8] (sub3) {Component C};

% Connection from main to detail
\draw[darrow, red!60] (novel.south) -- ++(0,-0.5) -| (sub1.north);
\draw[darrow, red!60] (novel.south) -- ++(0,-0.5) -| (sub2.north);
\draw[darrow, red!60] (novel.south) -- ++(0,-0.5) -| (sub3.north);

% Detail arrows
\draw[arrow] (sub1) -- (sub2);
\draw[arrow] (sub2) -- (sub3);

% Dimension annotations
\node[font=\scriptsize, above=0.15cm of input] {$\mathbb{R}^{N \times d}$};
\node[font=\scriptsize, above=0.15cm of encoder] {$\mathbb{R}^{N \times h}$};
\node[font=\scriptsize, above=0.15cm of output] {$\mathbb{R}^{N \times C}$};

% Loss
\node[module, below=1cm of output, fill=yellow!15] (loss) {Loss $\mathcal{L}$};
\draw[darrow] (output) -- (loss);

\end{tikzpicture}
\caption{\textbf{Overview of our proposed framework.} The model consists of [describe components]. The highlighted \textbf{Our Novel Module} is our key contribution, which [describe what it does]. Dashed arrows indicate the detailed structure shown in the expanded view below.}
\label{fig:architecture}
\end{figure*}
```

## Figure 3+: Additional Figure Templates

### Data Pipeline Figure

```latex
\begin{figure}[t]
\centering
\begin{tikzpicture}[
    node distance=0.5cm,
    step/.style={rectangle, draw, rounded corners, minimum height=0.8cm, minimum width=3cm, align=center, font=\small, fill=blue!8},
    arrow/.style={->, >=stealth, thick},
    data/.style={font=\scriptsize\itshape, text=gray},
]
\node[step] (s1) {Step 1: Raw Data};
\node[step, below=of s1] (s2) {Step 2: Filtering};
\node[step, below=of s2] (s3) {Step 3: Normalization};
\node[step, below=of s3] (s4) {Step 4: Tokenization};
\node[step, below=of s4] (s5) {Step 5: Ready for Training};

\draw[arrow] (s1) -- (s2) node[data, right, midway] {N samples};
\draw[arrow] (s2) -- (s3) node[data, right, midway] {N' samples};
\draw[arrow] (s3) -- (s4);
\draw[arrow] (s4) -- (s5);
\end{tikzpicture}
\caption{\textbf{Data preprocessing pipeline.} [Description]}
\label{fig:data_pipeline}
\end{figure}
```

### Results Bar Chart (placeholder)

```latex
\begin{figure}[t]
\centering
\begin{tikzpicture}
\begin{axis}[
    ybar,
    bar width=12pt,
    width=\columnwidth,
    height=5cm,
    ylabel={Performance (\%)},
    symbolic x coords={Method A, Method B, Method C, Ours},
    xtick=data,
    x tick label style={rotate=30, anchor=east, font=\small},
    ymin=70, ymax=100,
    legend style={at={(0.5,1.05)}, anchor=south, legend columns=2, font=\small},
    nodes near coords,
    nodes near coords style={font=\tiny},
    every node near coord/.append style={above},
]
% Placeholder values - replace with actual results
\addplot coordinates {(Method A, 82.3) (Method B, 84.1) (Method C, 86.5) (Ours, 91.2)};
\addplot coordinates {(Method A, 79.5) (Method B, 81.8) (Method C, 84.2) (Ours, 89.7)};
\legend{Metric 1, Metric 2}
\end{axis}
\end{tikzpicture}
\caption{\textbf{Main results comparison.} Our method significantly outperforms all baselines on both metrics. [Update with real numbers]}
\label{fig:main_results}
\end{figure}
```

### Ablation Heatmap (placeholder)

```latex
\begin{figure}[t]
\centering
\begin{tikzpicture}
\begin{axis}[
    colormap/YlOrRd,
    colorbar,
    point meta min=70, point meta max=95,
    width=\columnwidth,
    height=5cm,
    xlabel={Component},
    ylabel={Metric},
    xtick={0,1,2,3},
    xticklabels={Full, w/o A, w/o B, w/o C},
    ytick={0,1,2},
    yticklabels={Acc, F1, AUC},
    x tick label style={rotate=30, anchor=east, font=\small},
    y tick label style={font=\small},
]
% Placeholder values
\addplot[matrix plot*, mesh/cols=4, point meta=explicit] coordinates {
    (0,0) [91.2] (1,0) [87.3] (2,0) [85.1] (3,0) [83.8]
    (0,1) [89.7] (1,1) [85.2] (2,1) [83.5] (3,1) [81.9]
    (0,2) [93.1] (1,2) [89.8] (2,2) [87.2] (3,2) [86.5]
};
\end{axis}
\end{tikzpicture}
\caption{\textbf{Ablation study.} Removing any component degrades performance, confirming each module's contribution.}
\label{fig:ablation}
\end{figure}
```

## General TikZ Tips

1. **Colors**: Use pastel fills (`blue!10`, `green!15`) for readability
2. **Fonts**: Use `\small` or `\scriptsize` inside nodes for compact diagrams
3. **Arrows**: Use `>=stealth` for professional-looking arrowheads
4. **Highlighting**: Use thicker borders and brighter colors for novel components
5. **Spacing**: `node distance` controls default spacing; adjust per figure
6. **Width**: Use `\columnwidth` for single-column, `\textwidth` for full-width figures
7. **Required packages**: `\usepackage{tikz, pgfplots}` and `\usetikzlibrary{positioning, arrows.meta, calc, fit, backgrounds}`

## Figure Naming Convention

Save individual TikZ figures as separate `.tex` files in `paper/figures/`:
```
figures/
├── fig_comparison.tex
├── fig_architecture.tex
├── fig_data_pipeline.tex
├── fig_main_results.tex
├── fig_ablation.tex
└── fig_case_study.tex
```

Include in main.tex with `\input{figures/fig_comparison.tex}`.
