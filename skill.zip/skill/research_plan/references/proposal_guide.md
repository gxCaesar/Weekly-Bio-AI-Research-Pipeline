# Research Proposal Guide

## Proposal Template (Chinese)

```markdown
# {项目名称} 研究方案

## 1. 研究问题与动机

### 1.1 问题定义
[清晰定义要解决的科学问题/技术问题]

### 1.2 研究动机
[为什么现在需要解决这个问题]
[当前方法的关键局限是什么]

### 1.3 目标
[本研究的具体目标，可量化]

## 2. 创新点

### 创新点1: [名称]
- **描述**: [具体描述这个创新]
- **解决的问题**: [这个创新解决了什么问题]
- **与现有工作的区别**: [和最接近的相关工作相比，有什么不同]
- **技术依据**: [基于哪些论文/技术发展]

### 创新点2: [名称]
[同上结构]

### 创新点3: [名称]
[同上结构]

## 3. 方法概述

### 3.1 整体框架
[描述方法的整体pipeline/framework]

### 3.2 模型架构

#### ASCII架构图
```
[Input] --> [Module A] --> [Module B] --> [Module C] --> [Output]
                |              |
                v              v
           [Sub-module]   [Sub-module]
```

#### 架构详细说明
[逐个模块描述，包括输入输出维度，计算过程]

### 3.3 训练策略
[预训练/微调策略，损失函数设计，优化方法]

### 3.4 关键技术细节
[算法伪代码或关键公式]

## 4. 数据集

| 数据集 | 来源 | 规模 | 用途 | 下载方式 | 预处理方法 |
|-------|------|------|------|---------|-----------|
[列出所有使用的数据集]

### 4.1 数据预处理流程
[详细的预处理步骤]

### 4.2 数据划分
[训练/验证/测试集划分策略]

## 5. 基线方法

| 基线方法 | 论文 | 年份 | 开源代码链接 | 关键指标 |
|---------|------|------|-------------|---------|
[列出5-8个基线方法]

### 各基线简述
[简要描述每个基线的核心方法]

## 6. 评估指标

| 指标名称 | 数学定义 | 评估维度 | 备注 |
|---------|---------|---------|------|
[列出所有评估指标]

## 7. 消融实验设计

| 实验编号 | 消融对象 | 具体做法 | 验证目的 |
|---------|---------|---------|---------|
| A1 | [组件1] | [移除/替换...] | [验证组件1的贡献] |
| A2 | [组件2] | [...] | [...] |
[至少设计5个消融实验]

## 8. 计算资源评估

### 8.1 GPU显存估算
- 模型参数量: ~XX M/B parameters
- 单样本显存: ~XX GB
- 批次大小 × 梯度累积: XX × XX
- 峰值显存: ~XX GB (需 ≤ 80 GB)

### 8.2 训练时间估算
- 单epoch时间: ~XX hours (on 1x A100)
- 总epoch数: XX
- 总训练时间: ~XX hours / XX days
- 多GPU策略: [DDP/FSDP, 使用几张卡]

### 8.3 推理时间估算
[评估阶段的时间成本]

## 9. 基于的论文和开源代码

| 参考论文 | 使用方式 | GitHub链接 | 许可证 |
|---------|---------|-----------|--------|
[列出我们模型的代码基础来源]

### 9.1 代码复用计划
[具体说明从哪个repo复用哪些组件，自己需要写哪些]

## 10. 风险评估与备选方案

| 风险 | 可能性 | 影响 | 备选方案 |
|------|--------|------|---------|
[识别主要风险和应对策略]

## 11. 时间规划

| 阶段 | 任务 | 时间 | 产出 |
|------|------|------|------|
| 第1-2周 | 数据准备+环境搭建 | 2周 | 数据就绪 |
| 第3-4周 | 模型实现+基线复现 | 2周 | 代码完成 |
| 第5-6周 | 训练+调参 | 2周 | 初步结果 |
| 第7-8周 | 消融实验+论文撰写 | 2周 | 完整论文 |
```

## Innovation Point Standards

For top-venue acceptance, innovation points must be:

1. **Novel**: Not a trivial combination of existing techniques
2. **Significant**: Solves a real limitation, not incremental improvement
3. **Generalizable**: Not ad-hoc to one dataset
4. **Technically sound**: Grounded in established theory or clear empirical evidence
5. **Clearly articulated**: A reviewer can understand the novelty in one sentence

Common innovation patterns at top venues:
- New architecture component that addresses a specific limitation
- Novel training objective that captures previously ignored signals
- New problem formulation that enables better modeling
- Cross-domain transfer of techniques with non-trivial adaptation
- Unified framework that connects previously separate approaches

## Compute Budget Guidelines (A100 80GB)

| Model Scale | Parameters | Training Memory | Training Time (est.) |
|------------|-----------|-----------------|---------------------|
| Small | 100M-500M | 20-40 GB | 1-3 days |
| Medium | 500M-2B | 40-60 GB | 3-7 days |
| Large (fine-tune) | 7B (LoRA/QLoRA) | 30-50 GB | 2-5 days |
| Large (full) | 7B | 70-80 GB | 7-14 days |

With 2x A100: can use DDP to roughly halve training time.
