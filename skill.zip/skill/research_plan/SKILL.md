---
name: research_plan
description: >
  Comprehensive research planning skill that produces publication-ready deliverables for
  top CS conferences (NeurIPS, ICML, ICLR) or Nature sub-journals. Given a research direction,
  it executes a full pipeline: literature survey, research proposal, complete PyTorch+HuggingFace
  code project, LaTeX paper draft, technical manual, and HTML presentation. Use this skill whenever
  the user wants to plan a research project, prepare for conference submission, create a full
  research pipeline, set up experiments for students, or produce publication-quality deliverables
  from a research idea. Also triggers for: research proposal writing, experiment design,
  paper preparation, literature review for ML/AI/bioinformatics research.
---

# Research Plan Skill

This skill takes a research direction from the user and produces a complete, publication-ready
research package. Every deliverable is designed to be handed directly to students for execution —
no ambiguity, no placeholder logic, no missing pieces.

**Hardware assumption**: 1-2x NVIDIA A100 80GB GPUs
**Timeline**: 1-2 months for experiment completion
**Framework**: PyTorch + HuggingFace Transformers
**Language convention**: Survey, proposal, and technical manual in Chinese (中文); paper and code in English

## Output Structure

All outputs go into a project directory named after the research topic:

```
{project_name}/
├── survey.md                    # 文献调研报告 (Chinese)
├── proposal.md                  # 研究方案 (Chinese)
├── code/                        # Complete code project
│   ├── configs/
│   ├── data/
│   ├── models/
│   ├── baselines/
│   ├── training/
│   ├── evaluation/
│   ├── scripts/
│   ├── ablation/
│   ├── requirements.txt
│   └── README.md
├── paper/                       # LaTeX paper project
│   ├── main.tex
│   ├── references.bib
│   ├── figures/
│   └── neurips_2026.sty
├── technical_manual.md          # 技术手册 (Chinese)
└── presentation.html            # 项目介绍幻灯片
```

---

## Phase 1: Literature Survey

The survey is the foundation — it determines what innovation is possible and credible.

### Research Strategy

Use WebSearch to find papers from the past 5 years (2021-2026) across these venues:

**CS Conferences**: NeurIPS, ICML, ICLR, AAAI, KDD, WWW, RECOMB
**Journals**: Nature Methods, Nature Biotechnology, Nature Machine Intelligence, Cell Systems, Genome Biology, Bioinformatics, Briefings in Bioinformatics, Nucleic Acids Research

Search queries to run (replace `{DIR}` with the user's research direction):
1. `{DIR} large language model 2024 2025 2026`
2. `{DIR} foundation model deep learning NeurIPS ICML ICLR`
3. `{DIR} transformer attention mechanism benchmark`
4. `{DIR} agent AI Nature Methods`
5. `{DIR} open source code GitHub dataset`
6. `{DIR} state of the art SOTA benchmark`

For each promising paper found, record:
- Title, authors, venue, year
- Core method and innovation
- Datasets used (note if publicly available)
- GitHub repo URL (if open source)
- Key results and metrics

### Survey Output

Read `references/survey_guide.md` for the detailed template. The survey must include:
- Background overview of the field
- Summary table of 15-30 key papers
- Methods taxonomy (categorize approaches)
- Public datasets and benchmarks table
- Research gaps analysis
- Recommended research direction with justification

Write to `{project_name}/survey.md` in Chinese, keeping paper titles and technical terms in English.

---

## Phase 2: Research Proposal

Based on the survey's gap analysis, design a novel method that combines latest AI/LLM techniques with the target domain.

### Innovation Requirements

The proposal must contain **at least 3 clear innovation points**, each one:
- Grounded in an identified research gap from the survey
- Technically feasible with 1-2x A100 80GB in 1-2 months
- Differentiated from existing work in a concrete, measurable way
- Based on or extending open-source implementations (cite the repos)

### Proposal Structure

Read `references/proposal_guide.md` for the detailed template. Key sections:
1. Research question and motivation
2. Innovation points (3+), each with: description, why it matters, how it differs from prior work
3. Method overview with architecture description (include plaintext/ASCII architecture diagram)
4. Datasets: which public datasets, how to obtain, preprocessing needed
5. Baselines: which existing methods to compare against, their open-source repos
6. Evaluation metrics and protocol
7. Ablation study design (which components to ablate)
8. Compute budget: estimated GPU hours, memory requirements, training time
9. Risk assessment and fallback plans
10. Based-on papers: list the papers whose code you will build upon

Write to `{project_name}/proposal.md` in Chinese.

---

## Phase 3: Code Implementation

Build a complete, runnable code project. Every file must be real code — no stubs, no TODOs, no "implement this" comments.

### Project Structure

Read `references/code_structure.md` for conventions and patterns. Create:

```
code/
├── configs/
│   ├── default.yaml              # Default hyperparameters
│   ├── baseline_*.yaml           # One config per baseline
│   └── ablation_*.yaml           # Ablation configs
├── data/
│   ├── __init__.py
│   ├── download.py               # Download & extract datasets
│   ├── preprocess.py             # Data preprocessing pipeline
│   ├── dataset.py                # PyTorch Dataset classes
│   └── collator.py               # Data collation for batching
├── models/
│   ├── __init__.py
│   ├── model.py                  # Main model architecture
│   ├── modules.py                # Sub-modules (attention, encoders, etc.)
│   └── losses.py                 # Custom loss functions
├── baselines/
│   ├── __init__.py
│   └── {baseline_name}.py        # One file per baseline method
├── training/
│   ├── __init__.py
│   ├── trainer.py                # Training loop with AMP, gradient accumulation
│   ├── optimizer.py              # Optimizer and scheduler setup
│   └── callbacks.py              # Logging, checkpointing, early stopping
├── evaluation/
│   ├── __init__.py
│   ├── metrics.py                # All evaluation metrics
│   ├── evaluate.py               # Evaluation pipeline
│   └── visualize.py              # Result visualization scripts
├── scripts/
│   ├── run_all.sh                # Master script: downloads data, trains, evaluates
│   ├── train.sh                  # Training with default config
│   ├── eval.sh                   # Evaluation only
│   ├── run_baselines.sh          # Run all baselines
│   └── run_ablation.sh           # Run ablation studies
├── ablation/
│   └── run_ablation.py           # Ablation study orchestrator
├── main.py                       # Entry point
├── requirements.txt              # Pinned dependencies
└── README.md                     # English README
```

### Code Quality Standards

- Use `torch.cuda.amp` for mixed-precision training
- Implement gradient accumulation for large batch simulation
- Add wandb/tensorboard logging for all metrics
- Use `torch.distributed` or `accelerate` for multi-GPU support
- Include checkpointing (save every N epochs + best model)
- Use type hints for function signatures
- Include docstrings for all public classes and functions
- Config-driven: all hyperparameters in YAML, no magic numbers in code
- Reproducibility: set all random seeds, log full config with each run
- Memory-efficient: use gradient checkpointing if needed for A100 80GB

---

## Phase 4: Code Review

After writing all code, do a thorough review:

1. **Syntax check**: Run `python -c "import ast; ast.parse(open(f).read())"` on every .py file
2. **Import check**: Verify all imports reference real packages or project modules
3. **Completeness**: No TODO, FIXME, or placeholder comments
4. **Memory**: Estimate peak GPU memory — must fit in 80GB for the largest config
5. **Data pipeline**: Verify dataset download URLs are real, preprocessing is deterministic
6. **Training loop**: Verify loss computation, backward pass, optimizer step, scheduler step
7. **Evaluation**: Verify metrics match what the proposal promised
8. Fix any issues found immediately.

---

## Phase 5: Technical Manual

Write a step-by-step guide that enables a student to reproduce all experiments without asking questions.

Read `references/code_structure.md` for the manual template section. Include:

1. **环境配置** (Environment Setup): conda/pip commands, CUDA version, exact package versions
2. **数据准备** (Data Preparation): How to download, where it goes, expected sizes
3. **运行基线** (Running Baselines): Exact commands for each baseline
4. **训练模型** (Training Our Model): Commands, expected training time, how to monitor
5. **评估** (Evaluation): How to run eval, where results appear, expected format
6. **消融实验** (Ablation Studies): Commands and what each ablation tests
7. **常见问题** (Troubleshooting): OOM solutions, common errors, how to resume training
8. **预期结果格式** (Expected Results Format): What tables/plots the student should produce

Write to `{project_name}/technical_manual.md` in Chinese.

---

## Phase 6: Paper Draft

Write a complete paper draft in LaTeX, targeting NeurIPS 2026 format (or adapt for Nature sub-journal).

### LaTeX Setup

Create a `paper/` directory with the NeurIPS 2026 style file. If you cannot download it, create a reasonable approximation based on the standard NeurIPS template structure (two-column, 9-page limit for main text).

### Paper Sections

Read `references/paper_guide.md` for detailed writing standards. Write:

1. **Title**: Concise, includes method name and domain
2. **Abstract**: ~250 words, structured: problem → approach → results summary → impact
3. **Introduction**: 1.5 pages, problem motivation → limitations of existing work → our contributions (numbered list) → paper organization
4. **Related Work**: 1-1.5 pages, organized by approach category, position our work clearly
5. **Method**: 2-3 pages, formal notation → overall framework → each component described → training objective → complexity analysis
6. **Experiments**: 1.5-2 pages, setup complete (datasets, baselines, metrics, implementation details), result tables with placeholder numbers (use `XX.X`), include table structure for main results, ablation, and case study
7. **Discussion / Analysis**: 0.5-1 page, interpret results, limitations, broader impact
8. **Conclusion**: 0.5 page, summarize contributions and future work

### Figures (LaTeX/TikZ)

Read `references/figure_guide.md` for TikZ templates. Create at minimum:

- **Figure 1**: Comparison diagram showing limitations of traditional approaches vs. our approach (side-by-side or pipeline comparison)
- **Figure 2**: Full model architecture diagram drawn in TikZ (blocks, arrows, layer labels)
- **Figure 3**: Data processing pipeline or method detail
- Plan placeholders for 3+ additional figures (results will be added after experiments)

All figures should be publication quality — clear labels, consistent style, proper font sizes.

### Bibliography

Include 30-50 references in `references.bib`. Use real paper entries from the survey phase.

Write all paper files to `{project_name}/paper/`.

---

## Phase 7: Presentation

Create an HTML presentation explaining the research project. Read the template from
`assets/presentation_template.html` and customize it.

### Slides to include:

1. **Title slide**: Project name, research direction, target venue
2. **Problem & Motivation**: Why this research matters (2-3 slides)
3. **Related Work Overview**: Key prior methods and their limitations
4. **Our Method**: Architecture overview, innovation points
5. **Technical Details**: Key components explained
6. **Experiment Design**: Datasets, baselines, metrics
7. **Expected Results**: What we expect to show
8. **Timeline & Task Assignment**: 1-2 month plan breakdown
9. **References**: Key papers

Write to `{project_name}/presentation.html`.

---

## Phase 8: Final Assembly & Verification

After all phases complete:

1. Verify every expected file exists in the project directory
2. List all files with their sizes
3. Print a summary table:

| Deliverable | File | Status |
|---|---|---|
| Literature Survey | survey.md | ... |
| Research Proposal | proposal.md | ... |
| Code Project | code/ | ... |
| Technical Manual | technical_manual.md | ... |
| Paper Draft | paper/ | ... |
| Presentation | presentation.html | ... |

4. Provide a brief "Next Steps" section for the user:
   - What the student should do first
   - Expected timeline for each phase
   - When to check back for results
   - How to handle common issues

---

## Important Notes

- This skill runs all 8 phases automatically without stopping. Each phase builds on the previous.
- If WebSearch returns limited results for a niche topic, supplement with your knowledge of the field and note which references need manual verification.
- All code must be genuinely runnable — treat this as if you're writing production code that will be tested immediately.
- The paper should read as a complete draft minus numerical results. A reader should understand the full contribution from the text alone.
- For the research direction, always consider what makes a strong submission: novelty of approach, significance of the problem, thoroughness of experiments, and quality of writing.
