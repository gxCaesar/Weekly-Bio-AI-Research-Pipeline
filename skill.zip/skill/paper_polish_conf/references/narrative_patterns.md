# Narrative Patterns (Phase 1)

Guide for constructing the paper's story line based on actual experimental results. Read after
Phase 0 passes, before touching any text.

## Core Principle

**The story must match the data.** A pre-experiment draft is a hypothesis about what the story
will be. After experiments, the story may need to change. Forcing an outdated story onto
mismatched data is how papers get rejected.

## The 5 Result Types

Classify actual results into exactly one of these 5 types. If ambiguous, pick the less
optimistic type.

### Type 1: Strong Results

**Criteria**:
- Main experiment improves over best baseline by >10% on the primary metric
- Statistically significant (p < 0.01, not just < 0.05)
- Consistent across datasets (no dataset where method loses badly)
- Ablations all contribute positively (no component is useless)
- Effect size large (Cohen's d > 0.8)

**Narrative Strategy**: **Bold claim**

**Example contribution bullet**:
> "We propose CellAgent, which improves rare cell-type annotation F1 by 12.3% over the strongest
> baseline (p < 0.001, Cohen's d = 1.2) consistently across three benchmark datasets."

**Example abstract sentence**:
> "Our experiments demonstrate that CellAgent outperforms state-of-the-art methods by a large
> margin across all evaluation settings."

**Example RQ1 topic sentence**:
> "Our method substantially outperforms all baselines on rare cell-type annotation (Table 1),
> with particularly strong gains on datasets with <5% rare cell populations."

**Framing**: Confident, but still honest about limitations. Even "strong" papers have failure
modes. Discuss them in Discussion.

---

### Type 2: Marginal Results

**Criteria**:
- 3-10% improvement on primary metric
- Significant (p < 0.05) but not dramatic
- Effect size moderate (Cohen's d 0.3-0.8)
- Works on most but not all settings
- Improvements are consistent even if small

**Narrative Strategy**: **Conditional claim with characterization**

**Example contribution bullet**:
> "We identify conditions under which knowledge-guided attention consistently improves
> single-cell annotation. On datasets with rich prior knowledge (GRN-annotated), our method
> achieves 5.8% higher F1 (p < 0.01); on knowledge-sparse datasets, it matches baseline
> performance while providing improved interpretability."

**Example abstract sentence**:
> "Our experiments reveal that the proposed method provides consistent improvements on datasets
> with sufficient prior knowledge, achieving 5.8% higher F1 scores while also enabling
> mechanism-level interpretation."

**Framing**: Own the modest improvement. Make interpretability, efficiency, or theoretical
understanding the co-equal contribution. Readers will respect honesty.

**Recovery strategies if marginal**:
- Identify a subset where results are stronger and frame as "works especially well for X"
- Strengthen the theoretical contribution to compensate
- Add a detailed ablation / analysis that explains WHY
- Lead with a characterization finding rather than a performance finding

---

### Type 3: Mixed Results

**Criteria**:
- Strong on some datasets/metrics, weak on others
- No clear pattern of "always better"
- Possibly SOTA on 1-2 datasets but loses on others
- Ablation shows some components help, others hurt

**Narrative Strategy**: **Characterization — map the landscape**

**Example contribution bullet**:
> "We characterize the regimes in which LLM-based cell typing succeeds and fails: our method
> achieves best-in-class performance on rare cell types (F1 +15%) but underperforms specialized
> methods on abundant cell types. We provide an analysis of when each approach is preferred."

**Example abstract sentence**:
> "Our analysis reveals a clear trade-off between rare cell type identification (where our LLM
> approach excels by 15%) and abundant cell type annotation (where specialized encoders remain
> superior), suggesting practitioners select methods based on their target cell type frequency."

**Framing**: Turn the mixed result into the contribution. The paper's value becomes "we
understand the trade-offs", not "we are the best at everything". This is often more valuable
and more honest than strong-looking papers.

**Recovery strategies if mixed**:
- Lead the paper with the characterization, not the performance
- Build a "when to use which method" decision tree
- Mechanism analysis: why does X work here and not there?
- Frame as a *scientific* contribution rather than an *engineering* win

---

### Type 4: Counter-Intuitive Results

**Criteria**:
- A simpler baseline outperforms a complex method (yours or a competitor's)
- A theoretically optimal approach loses in practice
- A commonly accepted technique hurts rather than helps
- A component you expected to dominate turns out to be minor

**Narrative Strategy**: **Discovery framing — "we reveal a surprising phenomenon"**

**Example contribution bullet**:
> "We reveal that, contrary to common belief, increasing model capacity beyond 300M parameters
> does not improve single-cell annotation on datasets with fewer than 50K cells. We analyze the
> mechanism behind this saturation and propose a parameter-efficient alternative that matches
> the best large model while using 10x less compute."

**Example abstract sentence**:
> "Our systematic evaluation uncovers an unexpected finding: larger foundation models saturate
> quickly on single-cell annotation, with no benefit beyond 300M parameters on standard
> benchmarks."

**Framing**: The counter-intuitive finding IS the contribution. Papers that overturn
conventional wisdom are highly valued, IF the finding is rigorously verified.

**Critical requirements**:
- Verify the counter-intuitive finding on multiple datasets (at least 3)
- Run many seeds (5+) to rule out noise
- Provide a mechanistic explanation (why does this happen?)
- Predict when the finding generalizes and when it doesn't
- Acknowledge what would falsify the claim

**Recovery strategies if counter-intuitive**:
- Make the discovery the headline, not an afterthought
- Dedicate a full section to understanding the phenomenon
- Connect to broader theoretical literature (information theory, learning theory)
- Provide practical guidance for practitioners

---

### Type 5: Negative Results

**Criteria**:
- The proposed method does not beat baselines on the primary metric
- No amount of tuning rescues the main claim
- Ablation shows the method's core innovation doesn't help

**Narrative Strategy**: **Minimum Publishable Unit (MPU) — downgrade to secondary contributions**

**What to do**:
1. **Check the proposal's MPU fallback** — `conference_plan` should have pre-planned one
2. **Identify the secondary contributions**:
   - Theoretical analysis that stands on its own
   - A useful failure-mode characterization
   - A novel benchmark or evaluation protocol
   - An interpretability method
   - A new dataset
3. **Reframe the paper** around those contributions

**Example contribution bullet (salvaged from negative result)**:
> "We document the failure modes of applying large-scale LLMs to single-cell annotation,
> identifying three systematic limitations and providing a benchmark with 5 controlled test
> cases that expose them. Our analysis suggests specific architectural requirements for future
> work in this direction."

**Example abstract sentence**:
> "Despite strong performance on NLP benchmarks, general-purpose large language models
> significantly underperform specialized methods on single-cell cell-type annotation, even with
> domain adaptation. We systematically characterize three failure modes and propose evaluation
> protocols that future work should address."

**Framing**: Negative results are valuable IF they are rigorously established. The paper becomes
"here's what doesn't work and why", which saves the community from repeating the same mistakes.

**Critical requirements**:
- Must have strong baselines (otherwise "we beat a bad baseline" is not a negative result, it's
  poor experimental design)
- Must be thorough (tried reasonable variations, different datasets, different tuning)
- Must provide insight (not just "we tried X and it didn't work")
- Must connect to broader understanding

**Alternative**: If negative results cannot be salvaged into a publishable paper, **recommend
not submitting**. It's better than a rejection that burns your reviewer goodwill for the next
submission.

---

## Classification Decision Tree

```
Main experiment significant (p < 0.05)?
├─ NO → Type 5 (Negative)
└─ YES → Improvement magnitude?
         ├─ > 10% and consistent → Type 1 (Strong)
         ├─ 3-10% → Type 2 (Marginal)
         └─ Mixed (some win, some lose) → Type 3 (Mixed)

Regardless of magnitude:
  Any counter-intuitive finding?
  └─ YES → Type 4 (Counter-Intuitive) — possibly overriding the above
```

If multiple types apply (e.g., Marginal + Counter-Intuitive), pick the one that gives the most
honest and compelling story. Usually Counter-Intuitive is stronger than Marginal if the finding
is verified.

## Contribution Bullets Pattern

Across all 5 types, contribution bullets should follow this pattern:

1. **Start with the action**: "We propose / identify / characterize / reveal / document..."
2. **Specific claim**: What exactly was done
3. **Exact number**: At least one concrete number (improvement %, accuracy, p-value)
4. **Qualifier**: Condition, limit, or caveat

Avoid:
- "Significantly improves..." (without specifying)
- "Achieves SOTA..." (without specifying dataset or metric)
- "State-of-the-art performance..." (vague)
- "Novel approach..." (what exactly is novel?)

## Per-RQ Topic Sentences

Each Research Question's section should begin with a **one-sentence answer** to the RQ, not a
restatement of the hypothesis.

**Bad (hypothesis restatement)**:
> "In this section, we investigate whether knowledge-guided attention improves annotation
> accuracy."

**Good (finding-led)**:
> "Knowledge-guided attention improves annotation accuracy by 8.3% on rare cell types while
> matching baseline performance on abundant types, as shown in Table 2."

## Avoiding Common Narrative Pitfalls

1. **Don't oversell a Marginal result as Strong** — reviewers will check the numbers
2. **Don't hide Mixed results** — bury them and reviewers find them, frame them and reviewers
   accept them
3. **Don't ignore Counter-Intuitive results** — they are the most valuable finding you can make
4. **Don't give up on Negative results too quickly** — there's usually a salvageable contribution

## Narrative Design Document Template

```markdown
# Phase 1: 叙事设计决策

## 结果类型分类
**判决**: Strong / Marginal / Mixed / Counter-Intuitive / Negative
**依据**:
- 主实验改进: {value}% (p = {p-value})
- 数据集数量: {N}，其中 {M} 个显著
- Effect size: Cohen's d = {value}
- Ablation 贡献: {summary}

## 叙事策略
{one-paragraph summary of the chosen strategy}

## 新的 Contribution Bullets
1. {specific, numbered, with concrete number}
2. {specific, numbered, with concrete number}
3. {specific, numbered, with concrete number}

## 每个 RQ 的 Topic Sentence 更新

### RQ1: {question}
- 旧: {before}
- 新: {after - finding-led}

### RQ2: {question}
- 旧: {before}
- 新: {after}

[... continue for all RQs ...]

## 需要重写的章节
- [ ] Abstract
- [ ] Introduction contributions paragraph
- [ ] Experiments RQ1 topic paragraph
- [ ] [... list ...]

## 特殊考虑
{any conference-specific considerations, e.g., ICML theoretical framing, NeurIPS broader impact}
```
