# Polishing Checklist (Phases 3-6)

Detailed checklists for figure polishing, writing style audit, and final quality gate.
Used in Phases 3, 5, and 6 of `paper_polish_conf/SKILL.md`.

## Phase 3: Figure Polishing Checklist

### Per-Figure Audit

For every figure in `paper/figures/`:

**File format**:
- [ ] Source file exists (`.tex` for TikZ, `.py` for matplotlib, `.drawio` for diagrams)
- [ ] Output PDF exists and is current (regenerated from latest data)
- [ ] No lingering `.png` placeholder where a vector version should be

**Resolution & fonts**:
- [ ] Vector format (PDF from TikZ or matplotlib) preferred
- [ ] If raster, minimum 300 DPI
- [ ] Font family: Arial or Helvetica (sans-serif)
- [ ] Font size 8-10pt (readable when scaled to paper column width)
- [ ] No Times New Roman inside figures (breaks consistency with sans-serif convention)

**Color**:
- [ ] Colorblind-friendly palette (Okabe-Ito 8-color, ColorBrewer qualitative, or equivalent)
- [ ] Prints well in grayscale (test: convert to grayscale, is it still readable?)
- [ ] No red-green combinations (most common color vision deficiency)
- [ ] Consistent color mapping across figures (method X is always blue, baseline Y is always orange)

**Layout**:
- [ ] Panel labels (a, b, c) in top-left, bold, 10pt
- [ ] Axis labels readable, units included where applicable
- [ ] Legend placement doesn't obscure data
- [ ] Error bars / confidence intervals shown for all experimental results
- [ ] Statistical significance markers (*, **, ***) placed consistently

**Captions**:
- [ ] Caption is self-contained (reader understands figure without reading main text)
- [ ] Caption first sentence is a **title statement** describing what the figure shows
- [ ] Panel letters referenced in caption (e.g., "(a) Architecture overview. (b) Results on...")
- [ ] Statistical details in caption (N, test type, significance threshold)

**Content-specific**:

*Architecture diagrams*:
- [ ] Flow direction clear (left → right or bottom → top)
- [ ] Inputs and outputs labeled at boundaries
- [ ] Novel components visually distinguished (bold border, shading)
- [ ] Dimensions annotated if relevant (e.g., "BxN" for batch x sequence)

*Results plots*:
- [ ] Y-axis starts at appropriate value (don't zoom to exaggerate tiny differences)
- [ ] X-axis has meaningful scale (linear vs log)
- [ ] Error bars labeled (std, 95% CI, SE)
- [ ] Direction of "better" clear (↑ for higher-is-better metrics)

*Ablation plots*:
- [ ] Baseline clearly marked (e.g., horizontal line)
- [ ] Components added cumulatively or individually — state which
- [ ] Components in meaningful order (by contribution, by complexity)

*Case study figures*:
- [ ] Both success and failure cases shown
- [ ] Explanation annotations (arrows, text labels) without overwhelming
- [ ] Real data, not cartoon illustration (unless clearly labeled as schematic)

### Conference-Specific Figure Adjustments

**AAAI / IJCAI (7-page limit)**:
- [ ] Maximum 5 figures in main paper
- [ ] Use compact variants (stacked panels, smaller fonts)
- [ ] Consider combining Figure 2 (architecture) and Figure 3 (method detail) into one multi-panel figure

**ICML (8 pages)**:
- [ ] Figures should emphasize methods and theory
- [ ] Mathematical notation in figures consistent with main text

**NeurIPS / ICLR (9 pages)**:
- [ ] More room for analysis figures; use it for mechanism analysis plots
- [ ] Consider a dedicated figure for representation analysis / ablation visualization

## Phase 5: Writing Style Audit Checklist

Run this audit using `grep` / regex search through `paper/main.tex`.

### Banned Words and Phrases

Search for these patterns and replace or remove:

**AI-ish verbs** (replace with plain verbs):
- [ ] `leverage` / `leverages` / `leveraging` → `use` / `uses` / `using`
- [ ] `utilize` / `utilizes` / `utilizing` → `use` / `uses` / `using`
- [ ] `delve into` → `study` / `examine`
- [ ] `dive deep` → `analyze in detail`
- [ ] `drive` (metaphorical) → `cause` / `enable`

**Filler phrases** (delete):
- [ ] "It is important to note that..."
- [ ] "It should be mentioned that..."
- [ ] "In this paper, we..."
- [ ] "This paper presents..."
- [ ] "We are excited to..."
- [ ] "In conclusion," / "In summary,"

**Vague superlatives** (make specific or delete):
- [ ] "significantly better" → "X% higher, p<Y"
- [ ] "substantially" → specific number
- [ ] "dramatically" → specific number
- [ ] "much higher" → specific comparison
- [ ] "vast" / "myriad" / "plethora" → specific count
- [ ] "comprehensive" → specific scope
- [ ] "seamlessly" → delete (usually filler)
- [ ] "robustly" → specific robustness measurement

**Overpromising claims** (qualify or remove):
- [ ] "We solve X" → "We address X" / "We study X"
- [ ] "Novel" → specific differentiation
- [ ] "First" (unless rigorously defensible)
- [ ] "Optimal" → "near-optimal" with bound
- [ ] "Perfect" → specific accuracy number
- [ ] "State-of-the-art" without dataset/metric context

### Sentence-Level Patterns

**Em-dash chains**:
- [ ] No more than 2 em-dashes per paragraph
- [ ] Prefer parenthesis or restructuring over em-dash abuse

**Semicolon tricolons**:
- [ ] Avoid "X; Y; Z" constructions (scans as AI-ish)
- [ ] Replace with bullet lists or separate sentences

**Passive voice overuse**:
- [ ] Check for excessive "is/are [verb]ed" constructions
- [ ] Active voice preferred when the agent is clear

**Sentence length distribution**:
- [ ] Not all sentences the same length (variety signals human writing)
- [ ] Aim for 8-25 words per sentence, with mix
- [ ] Very long (>30 words) or very short (<5 words) sentences sparingly, for effect

### Paragraph-Level Patterns

- [ ] Each paragraph has a topic sentence
- [ ] Topic sentence makes a claim, not just introduces a topic
- [ ] Paragraph length 4-8 sentences typically
- [ ] Logical flow: each sentence follows from the previous

### Read-Aloud Test

For Abstract and Introduction:
- [ ] Read each sentence aloud (or imagine doing so)
- [ ] Does it sound natural?
- [ ] Would a human speaker produce this sentence?
- [ ] Flag any sentence that fails the test

### Conference-Specific Style

**AAAI**: Direct, technical, concise (7-page limit forces economy)

**IJCAI**: Formal, theorem-oriented when introducing results

**ICML**: Mathematical precision, define notation before use, clear distinction between informal
intuition and formal statements

**NeurIPS**: Balance between technical depth and accessibility, "insight-first" framing

**ICLR**: Informal where helpful, but still rigorous, open-review friendly (anticipate
skeptical readers)

## Phase 6: Final Quality Gate Checklist

### Completeness

**Content presence**:
- [ ] Title, abstract, all sections, references, appendices
- [ ] Figures in correct locations (referenced from text)
- [ ] Tables in correct locations
- [ ] No `XX.X` placeholders remaining
- [ ] No `% [Analysis:...]` annotations remaining (except in backup file)
- [ ] No `TODO` / `FIXME` / `???` / `xxx` in the paper
- [ ] No Lorem Ipsum or other filler

**References**:
- [ ] All citations in text have entries in `references.bib`
- [ ] All `references.bib` entries are cited (unused entries removed)
- [ ] At least 30 references (conference expectation)
- [ ] Mix of classic and recent papers (2024-2026 for state-of-the-art context)
- [ ] Correct citation keys match text commands

### Format Compliance

**Page count** (content + references):
- [ ] AAAI: ≤ 7 pages main + 2 pages references
- [ ] IJCAI: ≤ 7 pages main + 2 pages references
- [ ] ICML: ≤ 8 pages main + unlimited references
- [ ] NeurIPS: ≤ 9 pages main + unlimited references
- [ ] ICLR: ≤ 9 pages main + unlimited references

If over: content to cut (in order):
1. Related work (compress)
2. Repetitive explanations
3. Overly verbose method description
4. Extra figures
5. Proofs (move to appendix)

**Style file**:
- [ ] Correct `.sty` for target conference (e.g., `neurips_2026.sty`)
- [ ] Compiles without errors
- [ ] Compiles without warnings (or warnings explained)

**Citation format**:
- [ ] AAAI / IJCAI: author-year or numbered (check current year)
- [ ] ICML: author-year
- [ ] NeurIPS: numbered
- [ ] ICLR: author-year

**Fonts**:
- [ ] Main text font matches template (usually Times or Computer Modern)
- [ ] Code font is monospace (e.g., `\texttt{}` or `lstlisting`)
- [ ] No font fallbacks (all Unicode characters render correctly)

### Statistical Integrity

- [ ] All improvements claimed in abstract have corresponding p-values in tables
- [ ] Effect sizes reported somewhere (main or appendix)
- [ ] Std values consistent between inline text and tables
- [ ] Significance markers consistent (* = p<0.05, etc. defined in caption or legend)
- [ ] No rounding that misleads (e.g., 4.99 rounded up to 5.0 as "5% improvement")

### Narrative-Result Alignment

- [ ] Abstract claims match actual Table X numbers
- [ ] Introduction contribution bullets match what Experiments section shows
- [ ] Conclusion summary matches experimental findings (not wishes)
- [ ] Limitations section acknowledges the weaknesses the results reveal

### Conference-Specific Checks

**AAAI**:
- [ ] Ethical Considerations paragraph
- [ ] Formal problem definition
- [ ] Page count ≤ 7

**IJCAI**:
- [ ] Formal properties stated
- [ ] Theorems in main, proofs in supplementary
- [ ] Page count ≤ 7

**ICML**:
- [ ] Dedicated Theoretical Analysis subsection
- [ ] At least one proposition or theorem
- [ ] Clean mathematical notation
- [ ] Derivations traceable

**NeurIPS**:
- [ ] Broader Impact section
- [ ] Reproducibility Checklist completed (Appendix)
- [ ] Limitations explicitly discussed

**ICLR**:
- [ ] Representation analysis section
- [ ] Code availability statement
- [ ] OpenReview-friendly (anticipate public objections)

### Reviewer Anticipation

Read `references/acceptance_checklist.md` (symlinked from conference_plan) and run the
"Top 10 rejection patterns" section. For each pattern, note whether the paper addresses it:

1. [ ] Overclaiming — specific numbers used, not vague superlatives
2. [ ] Insufficient baselines — ≥ 5 strong baselines
3. [ ] Unfair comparison — protocol stated
4. [ ] Cherry-picking datasets — ≥ 3 datasets
5. [ ] No statistical significance — p-values everywhere
6. [ ] No ablation — ablation section present
7. [ ] No failure analysis — limitations discussed
8. [ ] No theoretical grounding — theoretical contribution listed
9. [ ] Poor writing — style audit passed
10. [ ] Missing reproducibility — code, configs, seeds documented

### Final Report Format

```markdown
# Phase 6: 最终质量检查报告

**项目**: {project_name}
**目标会议**: {CONFERENCE}
**检查时间**: {timestamp}
**提交就绪度**: Ready / Needs minor fix / Needs significant work

## 完整性 (Completeness)
- ✅/❌ 所有占位符已替换
- ✅/❌ 所有 [Analysis:] 注释已移除
- ✅/❌ 参考文献完整
- ...

## 格式合规 (Format Compliance)
- ✅/❌ 页数符合 {CONFERENCE} 要求 (estimated {N} pages)
- ✅/❌ 样式文件正确
- ✅/❌ 引用格式正确
- ...

## 统计完整性 (Statistical Integrity)
- ✅/❌ 所有 claim 有 p 值
- ✅/❌ 表格数字与正文一致
- ...

## 叙事-结果对齐 (Narrative Alignment)
- ✅/❌ Abstract 数字与表格一致
- ✅/❌ Contribution 对应实际结果
- ...

## 会议特定检查
[... specific to {CONFERENCE} ...]

## 审稿人视角自查 (Top 10 Rejection Patterns)
1. ✅/❌ Overclaiming
2. ✅/❌ Insufficient baselines
[...]

## 剩余问题 (按严重性排序)
1. [Critical] ...
2. [Important] ...
3. [Minor] ...

## 建议的修复
{list of fixes with estimated effort}

## 总体判决
{Ready / Needs minor fix / Needs significant work}
```
