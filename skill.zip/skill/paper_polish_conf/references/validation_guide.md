# Result Validation Guide (Phase 0)

This guide defines the mandatory checks that must pass before any paper polishing can begin.
It is consumed by `paper_polish_conf/SKILL.md` Phase 0 and `paper_polish_journal/SKILL.md` Phase 0.
Both skills reference this same document (via symlink from journal version).

## Philosophy

**Writing a paper on top of broken results is worse than not writing it.** A polished paper
that stands on a statistical flaw, leaked data, or an unfair comparison is a wasted effort at
best and a retraction risk at worst. Phase 0 enforces result integrity before a single word is
polished.

## The 5 Mandatory Checks

### Check 1: Statistical Rigor

**What to verify**:

1. **Per-comparison significance test**:
   - Paired t-test or Wilcoxon signed-rank test for paired comparisons
   - Independent t-test or Mann-Whitney U for unpaired comparisons
   - Report exact p-value, not just "p < 0.05"

2. **Multiple comparison correction**:
   - Bonferroni when number of comparisons ≤ 10 (conservative)
   - Benjamini-Hochberg FDR when comparisons > 10 (less conservative, more power)
   - Required whenever a table reports many comparisons (e.g., ours vs 5 baselines across 3 datasets = 15 tests)

3. **Effect size**:
   - Cohen's d for two-group continuous outcomes (small: 0.2, medium: 0.5, large: 0.8)
   - Cliff's delta for non-parametric comparisons
   - η² (eta-squared) for ANOVA-style analyses
   - Effect sizes too small (< 0.2) may be statistically significant but practically trivial

4. **Confidence intervals**:
   - 95% CI required for every main claim
   - Bootstrap CI for non-standard metrics (e.g., F1, ROC-AUC)
   - CI should not cross the "no improvement" threshold

5. **Seed diversity**:
   - Minimum 3 seeds per experiment (hard floor)
   - 5+ seeds strongly recommended for main results
   - 10+ seeds for anything marginal (effect size < 0.5)

**How to check**:
- Parse `analysis_outputs/statistical_tests.json` (if `statistical_tests.py` was run)
- Compute from raw `eval_results.json` files if analysis wasn't run
- Cross-check against numbers in `paper/tables/*.tex`

**Common failures**:
- No p-values reported (only means ± std)
- Only 1-2 seeds (not enough for statistical claim)
- Effect size not computed
- No multiple comparison correction despite many tests
- CI overlaps zero but improvement claimed anyway

**What triggers NO-GO**:
- Main claim has p > 0.05 (not significant)
- Only 1 seed for the main experiment
- Effect size computed but < 0.1 (practically no effect)

**What triggers WARN**:
- Effect size small (0.1-0.3) but significant
- Seeds = 3 (minimum, but would be better with more)
- No multiple comparison correction but claims conservative

---

### Check 2: Fair Comparison Protocol

**What to verify**:

1. **Seed consistency**:
   - All methods run with the same set of random seeds
   - Seeds recorded in config files
   - Different seeds → different runs → per-run statistics

2. **Data split consistency**:
   - All methods use exactly the same train/val/test split
   - Split file (e.g., `splits.json`) shared across all training scripts
   - For cross-validation: same fold assignments

3. **Compute budget equivalence**:
   - Option A: Same number of training epochs
   - Option B: Same wall-clock time (fair if compute is the bottleneck)
   - Option C: Same number of gradient steps (common for pre-training)
   - Document which option is chosen and justify

4. **Hyperparameter fairness**:
   - Either: grid-searched for all methods with the same search space
   - Or: each method uses the authors' recommended defaults from original paper
   - Do NOT: carefully tune your method and use defaults for baselines

5. **Baseline reproduction quality**:
   - Reproduce each baseline within 2% of its original paper's numbers on the same dataset
   - If reproduction fails, document in limitations and use the reported (not reproduced) numbers with a footnote
   - Do NOT: report your (weaker) reproduction as if it were the baseline

**How to check**:
- Compare `code/configs/*.yaml` for all baselines and your method
- Check `scripts/train.sh` and `scripts/run_baselines.sh` for same hyperparameters
- Verify splits are produced by a single script (e.g., `code/data/prepare_splits.py`)

**Common failures**:
- Your method uses 500 epochs, baselines use 100 (unfair compute)
- Your method uses different data augmentation than baselines
- Baseline hyperparameters are defaults while yours are grid-searched
- Different seeds across methods (introduces noise in comparison)

**What triggers NO-GO**:
- Baselines trained on a subset of the data your method uses
- Your method trained for 5x more compute than baselines
- Baselines use different evaluation protocol (e.g., different metric)

**What triggers WARN**:
- Reproduction gap 2-5% (document in limitations)
- Hyperparameters not grid-searched uniformly (document rationale)

---

### Check 3: Data Leakage Detection

**What to verify**:

1. **Train/val/test disjointness**:
   - Compute hashes of samples in each split; verify no intersection
   - For bio data: check by patient ID, donor ID, sample ID — not just row ID
   - For time-series: check that test dates are strictly after training dates

2. **Feature leakage**:
   - No target-derived features in input (e.g., using cell-type label to compute a marker)
   - No post-hoc normalization that uses test statistics
   - No features computed over the full dataset before splitting

3. **Pretraining data leakage**:
   - If using a pretrained model, verify its pretraining data doesn't overlap with your test set
   - Common pitfall: benchmarks included in the pretraining corpus

4. **Hyperparameter tuning leakage**:
   - Hyperparameters tuned on validation set, not test set
   - Test set touched at most once (for final reporting)

**How to check**:
- Run `code/data/verify_splits.py` (if it exists) or write a quick hash-based verifier
- Read data loading code to confirm no cross-split information

**Common failures**:
- Splits done by random sampling on a dataset where samples are non-IID (e.g., multiple cells from the same donor)
- Z-score normalization computed on the full dataset before splitting
- Test set used multiple times during model development

**What triggers NO-GO**:
- Confirmed test set contamination (even partial)
- Donor/patient leakage in bio data
- Features computed from full-dataset statistics

**What triggers WARN**:
- Potential (but not confirmed) leakage — user should verify before proceeding

---

### Check 4: Overfitting Detection

**What to verify**:

1. **Training curve health**:
   - Train loss and val loss both decrease
   - Val loss flattens before train loss (expected) but doesn't diverge
   - No explosive val loss late in training

2. **Val/test consistency**:
   - Test performance within 5-10% of val performance (depends on dataset size)
   - Larger gap suggests distribution shift or overfitting to val

3. **Generalization patterns**:
   - Performance on harder test subsets (e.g., rare classes) not dramatically worse
   - Model confidence calibration reasonable

**How to check**:
- Parse training logs (`tensorboard` events or `wandb` dumps)
- Compare val and test metrics in `eval_results.json`

**Common failures**:
- Test accuracy is 20% lower than val accuracy — heavy overfitting to val
- Train loss → 0 but val loss stuck high — memorization
- Model picks best checkpoint by val, and test happens to be very similar to val

**What triggers NO-GO**:
- Test/val gap > 15% (model doesn't generalize)
- Train/val gap > 20% with val stuck (overfitting)

**What triggers WARN**:
- Test/val gap 5-15% (document, consider as limitation)
- Marginal overfitting signals

---

### Check 5: Counter-Intuitive Result Identification

**What to verify**:

Sometimes results don't match intuition. Before writing them up, we must decide: is this a
**bug**, or a **real finding**?

1. **Flag any result** where:
   - A simpler baseline outperforms a more complex method
   - A theoretically optimal method loses to a heuristic
   - Ablation shows a component hurts rather than helps
   - Performance on easy examples is worse than hard ones

2. **For each flagged result**, ask:
   - Could this be a bug? (e.g., wrong data loading, loss function, evaluation metric)
   - Could this be overfitting to a specific dataset?
   - Could this be a real finding that contradicts common belief?

3. **Before writing up a counter-intuitive result**:
   - Verify on multiple datasets
   - Run with multiple seeds
   - Add at least one sanity-check experiment
   - Document the investigation in the paper (transparency builds trust)

**How to check**:
- Compare Table X results against what was expected in `proposal.md`
- Flag anything > 2σ from expected
- Ask user: "This result [X] is unexpected. Is this verified?"

**What triggers NO-GO**:
- Counter-intuitive result not investigated, and user can't explain it
- Evidence points to a bug (e.g., evaluation metric swapped)

**What triggers WARN**:
- Counter-intuitive result verified on 1 dataset, not replicated
- Should be investigated further before final claim

---

## Verdict Decision Tree

```
All 5 checks passed?
  └─ YES → GO (proceed to Phase 1)
  └─ NO → Any severe issue?
           └─ YES (data leakage, unfair comparison, no significance, bug suspected)
               → NO-GO (stop, fix, re-run)
           └─ NO (only minor warnings)
               → WARN (continue, document as limitations)
```

## Validation Report Template

```markdown
# Phase 0: 结果验证报告

**项目**: {project_name}
**目标会议**: {CONFERENCE}
**验证时间**: {timestamp}
**总体判决**: GO / NO-GO / WARN

## Check 1: 统计严谨性
- 状态: ✅ PASS / ❌ FAIL / ⚠️ WARN
- 检查点:
  - [ ] 所有主要声明有 p 值
  - [ ] 多重比较校正 ({method})
  - [ ] 效果量 (Cohen's d = {value})
  - [ ] 置信区间 95%
  - [ ] 种子数 {N}
- 发现的问题: ...
- 建议: ...

## Check 2: 公平比较
- 状态: ✅ PASS / ❌ FAIL / ⚠️ WARN
- 检查点:
  - [ ] 种子一致
  - [ ] 数据划分一致
  - [ ] 计算预算等价 (option: {A/B/C})
  - [ ] 超参数公平
  - [ ] 基线复现 {gap}%
- 发现的问题: ...

## Check 3: 数据泄漏
- 状态: ✅ PASS / ❌ FAIL / ⚠️ WARN
- 检查点:
  - [ ] Train/val/test 不相交
  - [ ] 无特征泄漏
  - [ ] 预训练数据检查
  - [ ] 超参调优在 val 上
- 发现的问题: ...

## Check 4: 过拟合检测
- 状态: ✅ PASS / ❌ FAIL / ⚠️ WARN
- 指标:
  - Train/val gap: {value}
  - Val/test gap: {value}
- 发现的问题: ...

## Check 5: 反直觉结果
- 状态: ✅ PASS / ❌ FAIL / ⚠️ WARN
- 反直觉结果数量: {N}
- 已调查数量: {M}
- 发现的问题: ...

## 最终判决

{GO/NO-GO/WARN}

{如果 NO-GO: 必须修复的问题列表 + 建议的修复步骤}
{如果 WARN: 将在论文 limitations 中记录的问题}
{如果 GO: 签字确认，进入 Phase 1}
```

## Interaction with Express Mode

In express mode:
- NO-GO always stops execution (cannot be bypassed)
- WARN prompts: "Found [N] warnings. Continue and document as limitations? (y/n)"
- GO auto-continues

In full interactive mode:
- NO-GO reports and stops
- WARN reports and pauses for confirmation
- GO reports and pauses for sign-off before continuing

## Recovery from NO-GO

If the verdict is NO-GO, the user must:
1. Read the validation report
2. Fix the identified issues (usually re-run experiments with corrections)
3. Re-invoke the skill — Phase 0 will re-run

The skill does NOT remember previous NO-GO states; each invocation is fresh.
