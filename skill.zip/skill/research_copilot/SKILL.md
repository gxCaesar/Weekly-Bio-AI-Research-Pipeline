---
name: research_copilot
description: >
  Unified interactive research planning skill for AI/LLM/Agent bioinformatics papers targeting
  both top CS conferences (AAAI, IJCAI, ICML, NeurIPS, ICLR) AND high-impact journals
  (Nature/Science/Cell family). Features 10 interactive phases with user choice at every step,
  three-dimensional innovation scoring (theoretical depth, biological significance, engineering
  impact), dual-track paper generation (conference + journal), and student handoff package.
  Use this skill when the user wants to: plan research targeting top venues, explore innovative
  research directions in AI for bioinformatics, produce publication-quality deliverables for
  conference or journal submission, design experiments for single-cell/drug-design/virtual-cell
  research, or get step-by-step guidance through the full research pipeline. Also triggers for:
  research planning, paper preparation, experiment design, innovation discovery, dual-track
  submission strategy.
---

# Research Copilot

An interactive research planning skill that guides you step-by-step from idea discovery to
student-ready deliverables. Every phase pauses for your input. You make the strategic decisions;
the skill handles execution.

**Venue scope**: Top CS conferences (AAAI/IJCAI/ICML/NeurIPS/ICLR) + Nature/Science/Cell family journals (18+ venues)
**Domain**: AI/LLM/Agent for bioinformatics (single-cell, drug design, virtual cells, biomolecular generation)
**Research type**: Purely computational (all validation in silico using public datasets)
**Hardware**: 1x NVIDIA A100 80GB (strict, no multi-GPU)
**Timeline**: 1-2 months (8 weeks) with parallel execution schedule
**Framework**: PyTorch + HuggingFace Transformers
**Language**: Survey, proposal, manual, post-experiment guide in Chinese; paper, cover letter, code in English
**Writing style**: Direct, precise, technical. No AI-sounding text. Conference: math-rigorous. Journal: narrative, biology-first.

## Output Structure

```
{project_name}/
├── research_discovery_notes.md     # Phase 0: exploration record (Chinese)
├── venue_strategy.md               # Phase 1: venue decision + interaction mode
├── survey.md                       # Phase 2: literature survey (Chinese)
├── innovation_design_notes.md      # Phase 3: innovation portfolio (Chinese)
├── proposal.md                     # Phase 4: research proposal (Chinese)
├── architecture_blueprint.md       # Phase 5: code architecture design
├── code/                           # Phase 6: complete code project
│   ├── configs/ data/ models/ baselines/ training/ evaluation/
│   ├── analysis/                   # Bio validation + compound figures + statistical tests
│   ├── scripts/ ablation/
│   ├── main.py, requirements.txt, README.md
├── paper/                          # Phase 7: conference paper (if applicable)
│   ├── main.tex, references.bib, {venue}.sty, figures/, tables/
├── paper_journal/                  # Phase 7: journal paper (if applicable)
│   ├── main.tex, methods.tex, supplementary.tex, cover_letter.tex
│   ├── figures/fig1/ fig2/ ..., reviewer_suggestions.md
├── technical_manual.md             # Phase 6: step-by-step guide (Chinese)
├── presentation.html               # Phase 7: project slides
├── quality_gate_report.md          # Phase 8: scorecard
├── post_experiment_guide.md        # Phase 9: post-experiment workflow (Chinese)
└── HANDOFF_README.md               # Phase 9: student entry point (bilingual)
```

When venue type is `conference`, only `paper/` is created. When `journal`, only `paper_journal/`. When `dual`, both.

---

## Phase 0: Research Discovery (INTERACTIVE)

### Step 1: Landscape Scanning

Use WebSearch to scan the latest research landscape across these trending bio-AI areas:
1. Single-cell analysis + LLM/Foundation models
2. Drug design/discovery + Agent architectures
3. Virtual cell / digital cell modeling
4. Gene regulatory network inference + AI
5. Protein/molecular generation + LLM
6. Spatial transcriptomics + AI

For each area, identify 2-3 specific research **gaps** (not just topics). Rate each gap on:
- Theoretical potential (1-5)
- Biological significance (1-5)
- Engineering impact (1-5)
- Feasibility with 1x A100 (High/Medium/Low)

Read `references/innovation_rubric.md` for scoring criteria.

### **PAUSE 1** (User Choice)
> Present the 12-18 candidate gaps as a scored matrix. Ask:
> "Which 2-3 gaps interest you most? Or describe your own research direction."

### Step 2: Research Question Refinement

For user-selected gaps, use WebSearch to refine into 3-5 specific research questions. Each with:
- One-paragraph description of what would be built
- Key datasets available
- Estimated novelty level (based on arXiv/OpenReview search)
- Venue fit analysis (which conferences/journals this targets best)

### **PAUSE 2** (User Choice)
> "Here are 3-5 specific research questions. Which do you want to pursue?"

**Output**: `{project_name}/research_discovery_notes.md` (Chinese)

---

## Phase 1: Venue Strategy (INTERACTIVE)

### Step 1: Cross-Venue Analysis

Read `references/venue_profiles.md`. For the selected research question, score venue fit across all conferences AND journals. Produce a recommendation matrix showing:
- Top 3 conference options with fit scores
- Top 3 journal options with fit scores
- Trade-offs between conference and journal for this specific topic

Recommend a strategy:
- **Option A**: Conference-first (submit to [X], deadline [date])
- **Option B**: Journal-first (submit to [Y])
- **Option C**: Dual-track (conference [X] + journal [Y], shared code/experiments)

### **PAUSE 3** (User Choice)
> "Venue analysis complete. I recommend [strategy] because [reasons]. Choose:
> (A) Conference: [X], (B) Journal: [Y], (C) Dual-track: [X] + [Y], (D) Other venue"

### Step 2: Interaction Mode Selection

### **PAUSE 4** (User Choice)
> "Confirmed: [venue strategy]. Choose interaction mode:
> (A) Full interactive — pause at every phase for your review (recommended for first use)
> (B) Express — I'll run Phases 2-9 automatically (like conference_plan/journal_plan)
> (C) Custom — tell me which phases to pause at"

Set `{VENUE_TYPE}` (conference/journal/dual), `{PRIMARY_VENUE}`, `{INTERACTION_MODE}`.

**Output**: `{project_name}/venue_strategy.md`

---

## Phase 2: Literature Survey (INTERACTIVE if full mode)

Use WebSearch to find papers from 2024-2026 across venues relevant to the selected direction.

### Search Queries (10+ adaptive)

**Direction-specific (3)**: `{DIR} large language model 2024 2025 2026`, `{DIR} foundation model benchmark SOTA`, `{DIR} open source code GitHub`
**LLM-specific (3)**: `{DIR} LLM fine-tuning`, `{DIR} pre-trained language model`, `{DIR} RAG retrieval augmented`
**Agent-specific (2)**: `{DIR} AI agent tool use reasoning`, `{DIR} multi-agent collaboration`
**Venue-specific (1)**: `{PRIMARY_VENUE} 2024 2025 {DIR}`
**Novelty check (1+)**: `[proposed idea] arXiv OpenReview`

Read `references/survey_guide.md` for full template. Produce survey with:
- Technology radar (latest LLM/Agent/Bio-AI advances)
- 15-30 paper summary table (with feasibility and 1xA100 columns)
- Methods taxonomy (LLM/Agent-specific categories)
- Research gaps with **three-dimensional scoring** (from `references/innovation_rubric.md`)
- Feasibility pre-screening (infeasible gaps excluded)

### **PAUSE 5** (User Choice, if full mode)
> "Top 5 gaps found. Gap #1 scores highest on theoretical depth; Gap #3 on biological significance; Gap #5 on engineering impact. Which gaps should our innovations target?"

**Output**: `{project_name}/survey.md` (Chinese)

---

## Phase 3: Innovation Design (INTERACTIVE if full mode)

Read `references/innovation_rubric.md` for scoring criteria and portfolio optimization.

### Step 1: Over-Generate Candidates

Design **5 candidate innovation points** (deliberately more than the final 3). For each:
- Description
- Innovation depth level (1-3)
- Theoretical contribution type (from 6 patterns in `references/proposal_guide.md`)
- Biological significance type
- Engineering impact
- Three-dimensional score (T/B/E out of 5 each)
- Venue fit score

### Step 2: Portfolio Recommendation

Recommend optimal portfolio of 3 that maximizes total score while maintaining balance. Show:
- Recommended portfolio with total scores
- Alternative portfolio optimized for conference
- Alternative portfolio optimized for journal

### **PAUSE 6** (User Choice, if full mode)
> "5 candidates designed. Recommended portfolio of 3:
> - Innovation 1 [name]: T=4, B=3, E=3 (theoretical anchor)
> - Innovation 2 [name]: T=2, B=5, E=3 (biological anchor)
> - Innovation 3 [name]: T=3, B=3, E=4 (engineering anchor)
> Total: T=9/15, B=11/15, E=10/15. Accept, swap, or see alternatives?"

**Output**: `{project_name}/innovation_design_notes.md` (Chinese)

---

## Phase 4: Research Proposal (INTERACTIVE if full mode)

Read `references/proposal_guide.md` for template. Write full proposal with:

1. Research question and motivation
2. Innovation points (user-selected portfolio) with implementation paths, theoretical support, novelty evidence
3. **Feasibility validation** (mandatory): compute <75GB, data URLs verified, base repos compatible, timeline <35 GPU-days
4. Method overview with architecture + open-source dependency graph
5. Datasets (min 3) with verified download status
6. Baselines (min 5) covering diverse paradigms + reproduction status
7. **Hypothesis-driven experiment plan** (from `references/experiment_narrative_guide.md`)
8. Ablation study design (5+ diverse types: removal, replacement, degradation, cross-condition)
9. **Biological validation plan** (from `references/bio_validation_guide.md`, min 3 types)
10. Compute budget (strict 1x A100, 8-week parallel schedule)
11. **Fair comparison protocol** (from `references/acceptance_checklist.md`)
12. **Rebuttal emergency experiments** (pre-plan 3-4 quick experiments)
13. Risk assessment with go/no-go milestones
14. **Minimum Publishable Unit** (fallback plan)
15. If journal target: cover letter plan, reviewer suggestions, data deposition plan
16. 8-week parallel execution timeline

### **PAUSE 7** (User Choice, if full mode)
> "Proposal complete. Feasibility: [PASS/FAIL]. Innovation scores: T=[X], B=[Y], E=[Z].
> Key decisions for review:
> - Backbone model: [choice]
> - Primary dataset: [choice]
> - Strongest baseline: [name]
> - GPU budget: [X]/80GB, [Y] days
> Approve, or adjust any aspect?"

**Output**: `{project_name}/proposal.md` (Chinese)

---

## Phase 5: Code Architecture Review (INTERACTIVE if full mode)

Before writing code, design and present the architecture blueprint:
- Module dependency graph
- Key class/function signatures (model, trainer, evaluator, analysis)
- Config schema (default.yaml structure)
- Analysis script-to-paper mapping table
- Memory budget breakdown by component
- Base repo and modification plan

### **PAUSE 8** (User Choice, if full mode)
> "Architecture blueprint ready. Backbone: [X], base repo: [Y], peak memory: [Z]GB/80GB.
> Analysis scripts produce [N] paper elements. Approve or change?"

**Output**: `{project_name}/architecture_blueprint.md`

---

## Phase 6: Code Implementation + Review (INTERACTIVE if full mode)

Read `references/code_structure.md` for conventions. Build complete code project:

### Code Project
- `configs/` — YAML configs (num_gpus: 1, all hyperparameters)
- `data/` — Download, preprocess, dataset, collator
- `models/` — Main model, modules, losses
- `baselines/` — One file per baseline
- `training/` — Trainer (single-GPU, mixed precision, gradient accumulation, stability: gradient clipping, NaN detection, warmup, checkpointing)
- `evaluation/` — Metrics, evaluation pipeline
- `analysis/` — parse_results.py, statistical_tests.py, generate_tables.py, generate_figures.py, comparison_analysis.py, ablation_analysis.py, case_study.py, bio_validation.py, bio_visualization.py, compound_figures.py (journal), run_all_analysis.sh
- `scripts/` — train.sh, eval.sh, run_baselines.sh, run_ablation.sh, run_analysis.sh, run_seeds.sh
- `main.py`, `requirements.txt`, `README.md`

### Code Review
Run full checklist from `references/code_structure.md`:
- Syntax + imports + completeness
- Memory simulation table (must be <75GB)
- Analysis-paper alignment
- End-to-end pipeline trace
- Training stability checks
- Fair comparison protocol
- Figure generation quality (300 DPI for journal)

### Technical Manual
Write `technical_manual.md` (Chinese) with: environment setup, data preparation, running baselines, training, evaluation, ablation, result analysis, troubleshooting.

### **PAUSE 9** (User Choice, if full mode)
> "Code complete. [N] Python files, all syntax-valid. Memory: [X]/80GB. Pipeline: PASS.
> [M] analysis scripts mapped to paper. Any concerns?"

**Output**: `{project_name}/code/`, `{project_name}/technical_manual.md`

---

## Phase 7: Paper Draft (INTERACTIVE if full mode)

Read `references/paper_guide.md` for venue-specific writing standards. Read `references/figure_guide.md` for figure templates. Read `references/experiment_narrative_guide.md` for results structure.

### Writing Style (ALL venues)
Follow `references/paper_guide.md` Writing Style Standards. Direct, precise, no AI-sounding text. No excessive em-dashes, no "leverages/utilizes", no vague superlatives. Every sentence carries specific information.

### If Conference Target
- Conference-specific LaTeX template (from `references/venue_profiles.md`)
- Structure: Abstract > Intro > Related Work > Method (with Theoretical Analysis required for ICML/NeurIPS) > Experiments (RQ-structured) > Discussion > Conclusion
- Figures: TikZ (comparison, architecture, pipeline) + placeholder results figures
- Tables with XX.X placeholders and `% [Analysis:...]` annotations
- Conference-specific additions (ethics/AAAI, proofs/IJCAI, rigor/ICML, reproducibility/NeurIPS, representation/ICLR)

### If Journal Target
- Structure: Abstract > Introduction (no Related Work) > Results (3-5 narrative subsections with finding-based titles) > Discussion > Methods (separate file)
- Figures: 4-6 compound multi-panel (a,b,c,d), structure defined, pre-experiment panels drawn
- Figure legends: Self-contained paragraphs with statistical details
- Cover letter (`references/cover_letter_guide.md`), reviewer suggestions
- Journal-specific items: Highlights (Nature Methods), Graphical Abstract (Cell), CRediT, ORCID, Data Availability

### If Dual-Track
- Generate BOTH paper/ and paper_journal/
- Shared: bibliography, core results data, analysis scripts
- Different: structure, figure format, framing emphasis (algorithmic vs biological)

### All Venues
- All non-results sections: polished, publication-ready
- Results: XX.X placeholders with `% [Analysis:...]` annotations emphasizing biological significance for journals, theoretical findings for conferences
- Pre-experiment figures fully drawn; post-experiment structures defined

### **PAUSE 10** (User Choice, if full mode)
> "Paper draft complete.
> Abstract: [shown in full]
> Structure: [outline with section titles]
> Figures: [N drawn, M placeholders]
> [If dual-track: Conference version emphasizes X; Journal version emphasizes Y]
> Review any section?"

**Output**: `{project_name}/paper/` and/or `{project_name}/paper_journal/`, `{project_name}/presentation.html`

---

## Phase 8: Quality Gate (INTERACTIVE if full mode)

Read `references/acceptance_checklist.md`. Run venue-specific checks:

### Scorecard Items
- [ ] Experimental scope: >= 3 datasets, >= 5 baselines, >= 3 metrics
- [ ] Fair comparison protocol documented
- [ ] Statistical rigor: analysis scripts ready for p-values + effect sizes
- [ ] Paper completeness: all non-results sections polished
- [ ] Venue compliance: format, page limit, template, citations
- [ ] Analysis-paper alignment: every XX.X has annotation, every annotation has script
- [ ] Biological validation: >= 2 types planned with scripts
- [ ] Training stability: gradient clipping, warmup, NaN detection in code
- [ ] [If journal] Cover letter, reviewer suggestions, data deposition plan
- [ ] [If journal] Figure legends self-contained, 300 DPI, correct fonts
- [ ] [If conference] Theoretical analysis in Method section
- [ ] Self-review from reviewer perspective (top 10 rejection patterns addressed)

### **PAUSE 11** (User Choice, if full mode)
> "Quality scorecard:
> [table of items with PASS/FAIL]
> [N] issues found: [list]
> Fix automatically, or discuss specific issues?"

**Output**: `{project_name}/quality_gate_report.md`

---

## Phase 9: Student Handoff (INTERACTIVE if full mode)

### Post-Experiment Guide
Generate `post_experiment_guide.md` (Chinese) with:
- Result collection workflow
- Statistical significance checks (p < 0.05, Cohen's d >= 0.5)
- Table/figure generation commands
- Placeholder replacement workflow
- Result diagnosis flowchart (underperformance, marginal results, inconsistent results)
- Venue-specific submission checklist (30+ items)
- [If journal] Figure assembly, data deposition, cover letter finalization

### HANDOFF_README.md
Single-page bilingual entry point for students:
```
# [Project Name] — Student Handoff

## What is this project?
[One paragraph in Chinese and English]

## What you need
- 1x NVIDIA A100 80GB
- Python 3.10+, CUDA 12.1+
- ~X GB disk space for data
- ~Y weeks estimated experiment time

## Quick Start (3 steps)
1. Setup: conda create ... && pip install -r requirements.txt
2. Verify: python -c "import torch; print(torch.cuda.is_available())"
3. Run: bash scripts/run_all.sh

## Detailed Guide
See technical_manual.md for full step-by-step instructions.

## When Things Go Wrong
See post_experiment_guide.md "结果不如预期时的应对" section.

## File Structure
[Brief description of what each directory/file does]
```

### **PAUSE 12** (User Choice, if full mode)
> "Handoff package ready. HANDOFF_README shows student's first steps. Timeline: [X weeks].
> Deliverables: [summary table]. Review or finalize?"

**Output**: `{project_name}/post_experiment_guide.md` (Chinese), `{project_name}/HANDOFF_README.md` (bilingual)

---

## Interaction Protocol

### Express Mode Behavior
When user selects Express mode at PAUSE 4:
- Phases 2-9 run automatically without pausing
- Same outputs are produced
- Quality gate results shown at the end (single PAUSE at Phase 8)

### Custom Mode Behavior
User specifies which phases to pause at: e.g., "Pause at 3, 7, 8" means only Innovation Design, Paper Draft, and Quality Gate are interactive.

### Handling User Responses at Pause Points
At each PAUSE:
- If user says "approve" / "proceed" / "OK": continue to next phase
- If user provides specific feedback: incorporate and re-present the affected section
- If user asks to go back: re-run the previous phase with adjusted parameters
- If user asks to skip: mark as auto-approved and continue

---

## Important Notes

- **Phase 0 and 1 are ALWAYS interactive** regardless of mode
- **1x A100 is a hard constraint** — verified at Phase 4, 6, and 8
- **Computational only** — all validation is in silico, no wet-lab
- **Writing style** — conference: math-rigorous, formal. Journal: narrative, accessible, biology-first. Both: no AI-sounding text
- **Dual-track** — when targeting both venues, code and experiments are shared. Papers are separate with different framing
- **Innovation scoring** — use `references/innovation_rubric.md` throughout. Every innovation evaluated on three dimensions
- For specific venue profiles, read `references/venue_profiles.md`
- For paper writing, read `references/paper_guide.md` (has both conference and journal sections)
- For figures, read `references/figure_guide.md` (has both TikZ and compound figure sections)
