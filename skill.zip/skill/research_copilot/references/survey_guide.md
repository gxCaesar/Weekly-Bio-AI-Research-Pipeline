# Literature Survey Guide

## Survey Template (Chinese)

```markdown
# {研究方向} 文献调研报告

## 1. 研究背景

### 1.1 领域概述
[简要介绍该研究方向的背景，2-3段]

### 1.2 研究意义
[为什么这个方向重要，实际应用价值]

### 1.3 技术发展脉络
[从传统方法到深度学习到大模型/Agent的演进]

## 2. 前沿技术速递 (2024-2026)

### 2.1 LLM技术进展
[最新大模型架构和能力进展，与本领域的关联]
- 高效微调: LoRA变体、Adapter fusion、QLoRA
- 长上下文: 扩展context window技术
- RAG: 检索增强生成在科学领域的应用
- 多模态: 文本+结构化数据联合建模

### 2.2 Agent技术进展
[最新Agent框架和范式]
- 多Agent协作: AutoGen, CrewAI, LangGraph
- 工具使用: Function calling, tool-use范式
- 推理规划: Chain-of-Thought, Tree-of-Thought, ReAct
- 科学发现Agent: 自动化实验设计和假设生成

### 2.3 AI for Bioinformatics进展
[生物信息学领域专用模型]
- 单细胞: scGPT, scFoundation, CellPLM
- 蛋白质: ESM-3, AlphaFold3
- 基因组: Evo, DNABERT-2, Nucleotide Transformer
- 药物: DrugGPT, MoleculeSTM

### 2.4 关键趋势总结

| 技术趋势 | 代表论文 | 成熟度(1-5) | 与生物信息学结合程度 | 研究机会 |
|---------|---------|:---:|---------|---------|
| [趋势1] | [论文] | X | [高/中/低] | [机会描述] |
| ... | ... | ... | ... | ... |

## 3. 热门方向探索

[仅在用户未指定方向时使用此节]

### 3.1 候选方向

| 候选方向 | 新颖性(1-5) | 可行性(1-5) | 数据可获取性 | 竞争程度 | 目标会议适配度 | 综合推荐 |
|---------|:---:|:---:|---------|---------|---------|---------|
| [方向1] | X | X | [描述] | [高/中/低] | [描述] | ★★★★☆ |
| ... | ... | ... | ... | ... | ... | ... |

### 3.2 推荐Top 3
[每个方向一段话阐述为什么推荐]

## 4. 核心论文汇总

| # | 论文标题 | 作者 | Venue | 年份 | 核心方法 | 数据集 | 开源代码 | 复现难度(1-5) | 1xA100可行 |
|---|---------|------|-------|------|---------|--------|---------|:---:|:---:|
| 1 | ... | ... | NeurIPS | 2025 | ... | ... | GitHub链接 | X | ✓/✗ |
| 2 | ... | ... | ICML | 2025 | ... | ... | GitHub链接 | X | ✓/✗ |
[收录15-30篇代表性论文，至少10篇来自2024-2026]

## 5. 方法分类体系

### 5.1 基于Foundation Model预训练的方法
[预训练生物大模型的核心思路、代表论文、优缺点]

### 5.2 基于LLM Prompt/Fine-tune的方法
[利用通用LLM进行领域适配的方法]

### 5.3 基于Agent架构的方法
[利用Agent框架解决生物信息学问题的方法]

### 5.4 基于传统深度学习的方法
[CNN/GNN/Transformer等非LLM方法]

### 5.5 方法对比总结

| 方法类别 | 优势 | 局限性 | 代表论文 | 适用场景 |
|---------|------|--------|---------|---------|

## 6. 公开数据集与基准

| 数据集名称 | 来源 | 规模 | 任务类型 | 下载链接 | 常用指标 | 存储大小 |
|-----------|------|------|---------|---------|---------|---------|
[列出该方向所有常用公开数据集]

## 7. 研究空白分析

### 7.1 现有方法的共同局限
[识别当前方法的系统性不足]

### 7.2 未被充分探索的方向
[哪些角度还没有被充分研究]

### 7.3 理论层面的空白 (Critical for Top Venues)
[识别缺乏理论理解的关键问题——顶会重视"为什么有效"而非仅"是否有效"]
- 哪些方法缺乏收敛性证明或泛化界?
- 哪些问题尚未被形式化定义?
- 现有方法的表达能力/信息论极限是什么?
- 跨域迁移的理论基础是否建立?
- 是否存在可证明的更优方法，但尚未被实现?

### 7.4 LLM/Agent技术机遇
[最新的LLM/Agent技术如何填补上述应用和理论空白]

### 7.5 可行性预筛选

| 研究空白 | 类型(应用/理论/混合) | 解决方案思路 | 1xA100可行 | 数据可获取 | 有开源基础 | 理论贡献潜力 | 携带到方案? |
|---------|:---:|-----------|:---:|:---:|:---:|:---:|:---:|
| [空白1] | 混合 | [思路] | ✓/✗ | ✓/✗ | ✓/✗ | 高/中/低 | ✓/✗ |
[不可行的空白标记为✗；纯应用空白(无理论潜力)在ICML/NeurIPS投稿中优先级降低]

## 8. 推荐研究方向

### 8.1 方向描述
[基于上述分析，推荐最有前景的研究方向]

### 8.2 创新性验证
[搜索arXiv/OpenReview验证该方向的创新性]
- 搜索查询1: "[具体idea关键词]" → 结果: [是否有类似工作]
- 搜索查询2: "[具体idea关键词]" → 结果: [是否有类似工作]
- 结论: [确认创新/需要差异化/放弃]

### 8.3 可行性分析
- GPU显存估算: ~XX GB (1x A100 80GB)
- 训练时间估算: ~XX 天
- 可依赖的开源代码: [repo URL列表]

### 8.4 目标venue适配性
[参考venue_profiles.md，分析该方向与目标会议/期刊的匹配度]
- 评审偏好匹配: [说明]
- 贡献类型匹配: [说明]
- 历史接收模式: [该会议近年是否接收类似论文]
```

## Search Strategy

### Primary Search Queries

Run at least 10 queries combining different dimensions (replace `{DIR}` with research direction):

**Direction-specific queries (3)**:
1. `{DIR} large language model 2024 2025 2026`
2. `{DIR} foundation model deep learning benchmark SOTA`
3. `{DIR} state of the art open source code GitHub dataset`

**LLM-specific queries (3)**:
4. `{DIR} LLM fine-tuning prompt engineering`
5. `{DIR} pre-trained language model transfer learning`
6. `{DIR} retrieval augmented generation RAG`

**Agent-specific queries (2)**:
7. `{DIR} AI agent tool use reasoning planning`
8. `{DIR} multi-agent collaboration automated discovery`

**Conference-specific queries (1)**:
9. `{CONFERENCE} 2024 2025 {DIR} accepted paper`

**Novelty verification queries (1+)**:
10. `[exact proposed idea description] arXiv OpenReview`

### Source Priority

1. OpenReview (ICLR, NeurIPS, ICML submissions — including rejected for learning what fails)
2. arXiv cs.AI, cs.LG, cs.CL, q-bio (past 12 months)
3. Semantic Scholar (citation-sorted)
4. Conference proceedings: AAAI, IJCAI, ICML, NeurIPS, ICLR (past 2 years)
5. Journals: Nature Methods, Nature Machine Intelligence, Genome Biology, Bioinformatics

### Quality Filters

Prioritize papers that:
1. Appear at top venues (AAAI/IJCAI/ICML/NeurIPS/ICLR/Nature family)
2. Have open-source code on GitHub
3. Use publicly available datasets
4. Report comprehensive benchmarks with ablation
5. Have been cited frequently (if older)
6. Are reproducible on 1x A100

### Recording Standards

For each paper, extract:
- Full citation (authors, title, venue, year)
- One-sentence summary of the core contribution
- Key innovation (what's new)
- Datasets used (note which are public)
- GitHub URL (if available)
- Reported SOTA numbers on standard benchmarks
- Limitations mentioned by the authors
- Hardware requirements (if reported)
- Estimated reproducibility on 1x A100
