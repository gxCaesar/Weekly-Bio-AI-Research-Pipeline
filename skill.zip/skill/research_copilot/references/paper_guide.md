# Paper Writing Guide (Conference + Journal Unified)

## Conference Format Quick Reference

| Conference | Pages (main) | Refs/Appendix | Template Source | Citation Style |
|-----------|:---:|---------|-----------------|---------------|
| AAAI | 7 + 1 ethics | Limited supplementary | aaai.org/authorkit | Numbered |
| IJCAI | 7 + 2 refs | Unlimited supplementary | ijcai.org/authors_kit | Numbered |
| ICML | 8 | Unlimited refs + appendix | icml.cc/Conferences | Author-year (natbib) |
| NeurIPS | 9 | Unlimited refs + appendix | neurips.cc/Conferences | Numbered (natbib) |
| ICLR | 9 | Unlimited refs + appendix | openreview.net (ICLR group) | Author-year (natbib) |

**Note**: Always verify on official website. Formats change yearly.

---

## Template Download Instructions

### AAAI
- Primary: `https://aaai.org/authorkit` → download "AAAI-[YY] Author Kit"
- Overleaf: Search "AAAI 2026" or "AAAI 2025" template
- Files needed: `aaai26.sty`, `aaai-named.bst`
- Fallback: Use `\usepackage{aaai26}` with two-column, Times font

### IJCAI
- Primary: `https://www.ijcai.org/authors_kit`
- Overleaf: Search "IJCAI" template
- Files needed: `ijcai26.sty`
- Fallback: Two-column, Times, 7-page main body

### ICML
- Primary: `https://icml.cc/Conferences/[year]/StyleAuthorInstructions`
- Overleaf: Search "ICML 2026" template
- Files needed: `icml2026.sty`, `fancyhdr.sty`
- Key: Uses `natbib` for author-year citations

### NeurIPS
- Primary: `https://neurips.cc/Conferences/[year]/PaperInformation/StyleFiles`
- Overleaf: Search "NeurIPS 2026" template
- Files needed: `neurips_2026.sty`
- Key: Uses `natbib` for numbered citations (unsrtnat)

### ICLR
- Primary: `https://github.com/ICLR/Master-Template`
- Overleaf: Search "ICLR 2026" template
- Files needed: `iclr2026_conference.sty`
- Key: Uses `natbib` for author-year citations

**Strategy**: Use WebSearch to find `{CONFERENCE} {year} LaTeX template`. If exact year not found, use the most recent available year's template and note this.

---

## Page Budget by Conference

| Section | AAAI (7pg) | IJCAI (7pg) | ICML (8pg) | NeurIPS (9pg) | ICLR (9pg) |
|---------|:---:|:---:|:---:|:---:|:---:|
| Abstract | 0.3 | 0.3 | 0.3 | 0.3 | 0.3 |
| Introduction | 1.0 | 1.0 | 1.2 | 1.5 | 1.5 |
| Related Work | 0.7 | 0.7 | 1.0 | 1.0 | 1.0 |
| Method | 2.0 | 2.0 | 2.5 | 3.0 | 3.0 |
| Experiments | 2.0 | 2.0 | 2.0 | 2.0 | 2.0 |
| Discussion + Conclusion | 0.5 | 0.5 | 0.5 | 0.7 | 0.7 |
| Ethics/Impact | 0.5 (req'd) | 0.5 | — | 0.5 (req'd) | — |

**AAAI/IJCAI (7-page)**: Method and Experiments must be concise. Move proofs, extra results, and implementation details to supplementary.

**ICML/NeurIPS/ICLR (8-9 page)**: More room for detailed method section and thorough analysis.

---

## Section-by-Section Guide

### Abstract (~200-250 words)

Structure: Context → Problem → Approach → Key Results → Impact

Template:
```
[One sentence: broad context and why it matters]
[One sentence: specific problem or limitation of existing approaches]
[One sentence: what we propose — name the method]
[Two sentences: how the method works at a high level]
[Two sentences: key experimental results — datasets, metrics, improvement over SOTA]
[One sentence: broader significance or what this enables]
```

### 1. Introduction (1.0-1.5 pages)

Paragraph structure:
1. **Hook** (1 para): Why this domain/problem matters. Start broad, narrow quickly.
2. **Problem** (1 para): What specific challenge exists. What have people tried. Why it's hard.
3. **Limitation** (1 para): What current best methods cannot do. Be specific and cite.
4. **Our approach** (1 para): High-level description of our method. What insight drives it.
5. **Contributions** (numbered list — must include at least one theoretical contribution):
   - (Theoretical) "We provide the first theoretical analysis of [problem], establishing [formal result, e.g., generalization bound / convergence guarantee / expressiveness result]."
   - (Methodological) "We propose [METHOD], a principled [description] grounded in [theoretical insight], that [key innovation]."
   - (Empirical) "Extensive experiments on [datasets] demonstrate that [METHOD] achieves [results], validating our theoretical predictions."
   
   **Contribution framing by conference**:
   - ICML: Lead with theoretical contribution; method follows from the theory
   - NeurIPS: Lead with key insight; theoretical analysis supports the insight
   - ICLR: Lead with representation learning contribution; formal analysis shows what is learned
   - AAAI/IJCAI: Lead with problem significance; theoretical grounding strengthens credibility
6. **Paper organization** (1 sentence): "The remainder of this paper is organized as follows..."

### 2. Related Work (0.7-1.5 pages)

Organize by approach category, not chronologically. For each category:
- Brief description of the approach family
- Key representative papers (2-3 per category)
- How our work differs

End with a positioning statement: "Unlike [closest work], our method..."

Typical categories for LLM/Agent bioinformatics:
- Traditional computational biology methods
- Deep learning approaches (CNN/GNN/Transformer)
- LLM/Foundation model based approaches
- Agent-based approaches (if applicable)

### 3. Method (2.0-3.0 pages)

Structure:
1. **Problem Formulation** (0.5 page): Formal notation, input/output definitions
   - Define all symbols in a notation table
   - State the learning objective mathematically
   - State formal assumptions (e.g., data distribution, graph structure, smoothness)
   - **This section must be rigorous enough that a theoretician can evaluate the problem independently of the implementation**

2. **Overall Framework** (0.5 page): High-level pipeline
   - Reference Figure 2 (architecture diagram)
   - List all major components

3. **Component Details** (1-2 pages): One subsection per key component
   - For each: **intuition → formal definition → theoretical justification → equations**
   - Number all important equations
   - **Explain design choices with formal reasoning, not just empirical motivation**
   - Include propositions/lemmas for key properties where possible

4. **Theoretical Analysis** (0.5-1 page — REQUIRED for ICML/NeurIPS, recommended for others):
   - **Convergence / Consistency**: Prove or formally argue that the method converges to the correct solution under stated assumptions
   - **Generalization Bound**: Derive or cite bounds on how the method generalizes from training to unseen data
   - **Expressiveness**: Show what the model can represent that prior approaches cannot (formally, not just by example)
   - **Complexity Analysis**: Time and space complexity, comparison with baselines
   - **Connection to Theory**: Link to established theoretical frameworks (information theory, PAC learning, optimal transport, etc.)
   
   Template for a theorem:
   ```latex
   \begin{theorem}[Informal]
   Under Assumptions 1-3, our method achieves [formal guarantee],
   which improves upon [prior bound/result] by [quantification].
   \end{theorem}
   ```
   
   If a full proof is too long for the main text, state the theorem in the main paper and defer the proof to the appendix. But the theorem statement must appear in the main text.

5. **Training Objective** (0.25 page): Final loss function with theoretical motivation
   - Derive the loss from a principled objective (e.g., variational bound, mutual information maximization, contrastive learning theory)
   - Explain why this objective is theoretically sound, not just empirically effective

### 4. Experiments — Pre-Experiment Draft Strategy

This is the key section that is written BEFORE experiments, with placeholders and analysis plan annotations.

**4.1 Experimental Setup** (write fully)

- Datasets: name, size, splits, preprocessing
- Baselines: list with citations, brief description
- Metrics: define each metric
- Implementation details: hardware (1x A100 80GB), optimizer, learning rate, epochs, etc.

**4.2 Main Results — Draft with Placeholders**

Table structure with XX.X placeholders:
```latex
\begin{table}[t]
\centering
\caption{Main results on [Dataset1] and [Dataset2]. Best in \textbf{bold},
second-best \underline{underlined}. * indicates $p < 0.05$.}
\label{tab:main}
\begin{tabular}{l|cc|cc}
\toprule
& \multicolumn{2}{c|}{Dataset1} & \multicolumn{2}{c}{Dataset2} \\
Method & Metric1 & Metric2 & Metric1 & Metric2 \\
\midrule
Baseline A & XX.X{\scriptsize$\pm$X.X} & XX.X{\scriptsize$\pm$X.X} & XX.X{\scriptsize$\pm$X.X} & XX.X{\scriptsize$\pm$X.X} \\
Baseline B & XX.X{\scriptsize$\pm$X.X} & XX.X{\scriptsize$\pm$X.X} & XX.X{\scriptsize$\pm$X.X} & XX.X{\scriptsize$\pm$X.X} \\
\midrule
Ours & \textbf{XX.X}{\scriptsize$\pm$X.X} & \textbf{XX.X}{\scriptsize$\pm$X.X} & \textbf{XX.X}{\scriptsize$\pm$X.X} & \textbf{XX.X}{\scriptsize$\pm$X.X} \\
\bottomrule
\end{tabular}
\end{table}
```

Results narrative with analysis plan annotations:
```latex
Table~\ref{tab:main} presents the main results across all datasets and metrics.
Our method achieves XX.X\% on Metric1, outperforming the strongest baseline by XX.X\%.
% [Analysis: generate_tables.py --table main; compare ours vs baselines on all metrics;
%  expect ~3-5% improvement on Metric1 because our novel component captures patterns
%  that flat approaches miss; if improvement <2%, investigate whether data quality
%  is a bottleneck. Source: analysis/comparison_analysis.py]

Notably, the improvement is more pronounced on Dataset2 (XX.X\% vs XX.X\%),
which contains [characteristic that our method handles better].
% [Analysis: comparison_analysis.py --by_dataset; expect larger gains on datasets
%  with richer structure; validates our architectural design choice]
```

**4.3 Ablation Study — Draft with Placeholders**

```latex
\begin{table}[t]
\centering
\caption{Ablation study on [Dataset1]. Each row removes one component.}
\label{tab:ablation}
\begin{tabular}{l|cc}
\toprule
Variant & Metric1 & Metric2 \\
\midrule
Full model & XX.X & XX.X \\
w/o Component A & XX.X & XX.X \\
w/o Component B & XX.X & XX.X \\
w/o Component C & XX.X & XX.X \\
\bottomrule
\end{tabular}
\end{table}
```

Ablation narrative with annotations:
```latex
Removing Component A causes the largest performance drop (XX.X\% $\to$ XX.X\%),
confirming its critical role in [description].
% [Analysis: ablation_analysis.py; expect ~3-5% drop for Component A because
%  it provides the core [domain] inductive bias; if drop <1%, our key innovation
%  may not be learning meaningful patterns -- revisit design]

Component B contributes XX.X\% improvement, validating that [rationale].
% [Analysis: ablation_analysis.py; Component B should show moderate ~1-3% gain;
%  it provides auxiliary signal that complements the main module]
```

**4.4 Analysis Subsections — Templates with Annotations**

4.4.1 Efficiency Analysis
```latex
% [Analysis: generate_tables.py --table efficiency
%  Show: training time, inference time, GPU memory, #parameters
%  Compare against all baselines
%  Expect: our method comparable or faster than baselines;
%  memory usage should be <50GB with default config]
```

4.4.2 Sensitivity Analysis
```latex
% [Analysis: generate_figures.py --fig sensitivity
%  Vary: key hyperparameters (e.g., number of layers, hidden dim, learning rate)
%  Show: line plot of metric vs hyperparameter value
%  Expect: robust within reasonable range, sharp drop at extremes]
```

4.4.3 Case Study / Qualitative Analysis
```latex
% [Analysis: case_study.py
%  Select: 2-3 representative examples where our method succeeds and baselines fail
%  Visualize: domain-specific visualization (attention weights, predictions, etc.)
%  Narrative: explain WHY our method gets these cases right -- connect to architecture]
```

### 5. Discussion (0.3-0.7 pages)

- Interpret key results — don't repeat numbers, explain patterns
- Limitations (be honest — reviewers appreciate transparency)
- Broader impact / Ethical considerations
  - AAAI/NeurIPS: Required section, take it seriously
  - ICML/ICLR: Include even if not strictly required

### 6. Conclusion (0.3-0.5 pages)

- Summarize contributions (don't repeat abstract)
- Future work directions (1-2 sentences)

---

## Conference-Specific Writing Advice

### AAAI / IJCAI (7-page venues)
- **Concision is critical**: every sentence must earn its space
- Move heavy math and proofs to supplementary/appendix (but state theorems in main paper)
- Related Work can be shorter — focus on direct competitors only
- AAAI: Include ethical considerations paragraph (reviewers check for it)
- IJCAI: Emphasize formal problem definition; reviewers value theoretical grounding and connections to AI principles
- Both: Frame bio contributions as AI methodology demonstrated on biology, not vice versa
- Supplementary: put detailed ablations, extra tables, full proofs here
- **Theory expectation**: At minimum, formally define the problem and justify design choices with theoretical arguments. Full proofs can go to supplementary.

### ICML (8-page venue)
- **Mathematical rigor is non-negotiable**: papers without formal analysis are frequently desk-rejected
- Include a dedicated Theoretical Analysis subsection in Method with at least one proposition/theorem
- Derive the training objective from a principled framework (variational inference, information theory, optimal transport, etc.)
- Include complexity analysis comparing with baselines
- Notation must be precise and consistent; define every symbol
- Agent papers: prove properties of the agent architecture (convergence, optimality, expressiveness), don't just demonstrate it works
- **Common ICML reviewer comment**: "The method is interesting but the paper lacks theoretical analysis. Why does this work? What are the formal guarantees?"

### NeurIPS (9-page venue)
- **Novelty bar is highest**: frame around a **key theoretical insight**, not just benchmark gains
- The best NeurIPS papers reveal a principle: "We show that X is equivalent to Y" or "We prove that Z is necessary and sufficient for W"
- Broader Impact section is mandatory and reviewed — invest effort
- Reproducibility checklist is mandatory
- More room for theoretical analysis — use extra page for deeper formal treatment
- Datasets & Benchmarks track: consider if you create a new benchmark
- **Theory expectation**: Include formal analysis that explains WHY the method works, not just that it works. Ablation + theory together is the gold standard.

### ICLR (9-page venue, open review)
- **Write for public scrutiny**: paper is visible immediately on OpenReview
- Anticipate common reviewer objections and address them with formal arguments
- Representation analysis: formally characterize what the model learns (information-theoretic analysis, probing experiments, formal expressiveness results)
- Discussion period: be prepared to defend theoretical claims with mathematical rigor
- Foundation model/pre-training papers are core ICLR scope — strong fit
- **Theory expectation**: Show what is learned and why. Information-theoretic or representation-theoretic arguments are highly valued. "Our representation preserves X because of Y" with formal justification.

---

## Writing Style Standards (Avoiding AI-Sounding Text)

Top conference papers are written in a precise, direct, technical style. The text must read as if written by a domain expert, not generated by an AI assistant.

### Forbidden Patterns

| Pattern | Example (BAD) | Replacement (GOOD) |
|---------|--------------|-------------------|
| Em-dash overuse | "Our method -- which uses attention -- outperforms baselines" | "Our method uses attention and outperforms baselines." |
| Semicolon chains | "We use transformers; they capture long-range dependencies; this is important for..." | Split into separate sentences. |
| "Leverages/utilizes" | "Our method leverages foundation models" | "Our method builds on foundation models" or "uses" |
| "Cutting-edge/novel/innovative" | "We propose a novel cutting-edge framework" | "We propose [MethodName], a [concrete description]" |
| "It is worth noting that" | "It is worth noting that our method is faster" | "Our method is faster." |
| "In this paper, we..." (repeated) | Starting every paragraph with this | Vary sentence structure. Use "We" sparingly. |
| Vague superlatives | "significantly outperforms" (without numbers) | "outperforms by 3.7% accuracy (p<0.01)" |
| Empty transitions | "Furthermore, moreover, additionally" | Use logical connectives that carry meaning |

### Preferred Writing Style

**Concise and direct**: Remove words that add no information.
- BAD: "In order to address the aforementioned limitations, we propose..."
- GOOD: "To address this, we propose..."

**Concrete over abstract**: Replace abstract claims with specific facts.
- BAD: "Our method achieves superior performance across various benchmarks."
- GOOD: "Our method achieves 91.2% accuracy on Tabula Sapiens, 88.7% on PBMC, and 85.3% on Pancreas."

**Active voice**: Prefer "We train the model" over "The model is trained."

**One idea per sentence**: If a sentence has more than one comma-separated clause, split it.

**Technical precision**: Use domain-specific terms correctly.
- BAD: "We process the single-cell data using AI techniques."
- GOOD: "We normalize the count matrix using scran pooling, select 2000 highly variable genes, and encode each cell as a 768-dimensional vector."

### Paragraph Structure

Each paragraph should have:
1. **Topic sentence** (what this paragraph is about)
2. **Evidence/detail** (2-3 sentences of substance)
3. **Connection** (link to the next paragraph or the paper's argument)

No paragraph should exceed 8 sentences. No paragraph should be a single sentence (except in rare cases like contribution lists).

### Notation Consistency Checklist

- [ ] Every symbol defined at first use
- [ ] Same symbol never means two different things
- [ ] Vectors are bold lowercase, matrices are bold uppercase, scalars are italic
- [ ] All equations are numbered if referenced in text
- [ ] "we" is lowercase even at sentence start in some styles (check conference template)

## Writing Tips for Top Venues

1. **Every claim needs evidence**: either a citation or your own experiment
2. **Figures are the first thing reviewers look at**: make them self-contained with good captions
3. **Tables should tell a story**: arrange rows/columns so the pattern is obvious
4. **Related work is positioning, not literature review**: show how you fit in the landscape
5. **Method section**: balance clarity (general audience) and rigor (expert reviewers)
6. **Results**: always include error bars / confidence intervals (3+ seeds)
7. **Writing quality matters**: proofread, consistent notation, no grammar errors
8. **Read your paper aloud**: if a sentence sounds like a chatbot wrote it, rewrite it

---

## Figure Count and Types

Plan for 6+ figures minimum:

| Figure | Content | Type | When to draw |
|--------|---------|------|-------------|
| Fig 1 | Traditional vs. our approach | Comparison/overview | Pre-experiment |
| Fig 2 | Model architecture | Architecture diagram | Pre-experiment |
| Fig 3 | Method detail / data pipeline | Technical diagram | Pre-experiment |
| Fig 4 | Main results visualization | Bar chart / line plot | Post-experiment (placeholder) |
| Fig 5 | Ablation / analysis | Heatmap / bar chart | Post-experiment (placeholder) |
| Fig 6 | Case study / qualitative | Domain-specific | Post-experiment (placeholder) |

Pre-experiment figures should be fully drawn. Post-experiment figures should have structure defined with placeholder values.

---

## Bibliography Standards

- 30-50 references for conference papers
- Always cite: seminal works, direct competitors, dataset papers, metric papers
- Use consistent citation format per conference:
  - AAAI/IJCAI/NeurIPS: Numbered `[1]`
  - ICML/ICLR: Author-year `(Author, 2025)`
- All references should be from the survey phase — real, verified entries

---

## Analysis Plan Annotation Format

Analysis annotations in the results draft use this format (as LaTeX comments):

```latex
% [Analysis: <script_name> [--args];
%  <what to compute>;
%  expect <expected outcome> because <reasoning>;
%  if <unexpected outcome>, <diagnostic action>]
```

Requirements:
- Every XX.X placeholder MUST have a corresponding annotation
- Every annotation MUST reference a specific script in `code/analysis/`
- Annotations are LaTeX comments (`%`) so the paper compiles cleanly
- Include both expected outcome AND diagnostic action for unexpected results
- Annotations are removed in the final submitted version

Example:
```latex
Our method achieves XX.X\% accuracy on CellType classification.
% [Analysis: generate_tables.py --table main;
%  compute mean±std over 3 seeds for all methods on all datasets;
%  expect our method top-1 on all datasets with ~2-5% margin;
%  if margin <1%, check if data augmentation or longer training helps;
%  source: analysis/comparison_analysis.py --detailed]
```

---

## Supplementary Material Strategy

### What Goes Where

| Content | Main Paper | Supplementary |
|---------|:----------:|:-------------:|
| Core results table | Yes | Extended version with per-dataset breakdown |
| Key ablation table | Yes (top 5) | Full ablation with all variants |
| Architecture figure | Yes | Detailed sub-module diagrams |
| Theorem statements | Yes | Full proofs |
| 2-3 key visualizations | Yes | All visualizations |
| Method pseudocode | Summary in main | Full algorithm |
| Hyperparameters | Mention key ones | Complete table for all methods |
| Baseline verification | Reference | Full reproduction results |
| Dataset details | Summary statistics | Full preprocessing pipeline |
| Additional experiments | — | Sensitivity, extra datasets, extra metrics |
| Biological validation | Key results | Extended GO analysis, full gene lists |

### Supplementary Structure Template

```latex
\appendix
\section{Proof of Theorem 1} \label{app:proof}

\section{Implementation Details} \label{app:impl}
  \subsection{Hyperparameters} % Table for all methods
  \subsection{Baseline Verification} % Reproduction vs published results
  \subsection{Training Details} % Learning curves, convergence plots

\section{Additional Experimental Results} \label{app:experiments}
  \subsection{Per-Dataset Breakdown}
  \subsection{Sensitivity Analysis}
  \subsection{Additional Ablation Variants}
  \subsection{Computational Cost Breakdown}

\section{Biological Validation Details} \label{app:bio}
  \subsection{GO Enrichment Full Results}
  \subsection{Marker Gene Lists}
  \subsection{Additional Visualizations}
```

### Conference-Specific Supplementary Rules

| Conference | Supplementary limit | Reviewer obligation | Strategy |
|-----------|:---:|:---:|---------|
| AAAI | Limited pages | Not required to read | Keep it short, only essential proofs |
| IJCAI | Unlimited | Not required to read | Put proofs + extra experiments |
| ICML | Unlimited | Encouraged to read | Comprehensive; proofs must be here |
| NeurIPS | Unlimited | Encouraged to read | Thorough; reviewers often check proofs |
| ICLR | Unlimited | Often read (open review) | Very thorough; public scrutiny |

### Referencing Conventions

**In main paper, write:**
"Due to space constraints, the full proof is provided in Appendix A. Here we state the main result."

"Complete hyperparameter settings and baseline verification results are in Appendix B."

"Additional visualizations and per-dataset breakdowns are in Appendix C."

**Never write:** "See supplementary for important details" — this signals the main paper is incomplete.

---

# PART B: Journal Paper Writing Guide (Nature/Science/Cell Family)

Use this section when `{VENUE_TYPE}` is `journal` or `dual`.

## Journal Paper Structure

```
Abstract (150-300 words)
Introduction (500-800 words, no numbered contributions, no "Related Work")
Results (3-5 titled subsections, each paired with 1 compound figure)
Discussion (600-1000 words)
Methods (at end, 1500-3000 words, or separate file)
```

## Journal Abstract (150-300 words)

Nature/Science: Unstructured, 150-200 words. Cell: Can be structured, up to 300 words.

Template:
```
[One sentence: biological context and importance]
[One sentence: gap in current approaches]
[One sentence: what we developed and the key principle]
[2-3 sentences: main findings with specific numbers]
[One sentence: significance and what this enables]
```

Start with biology, not algorithms. No method acronyms in the first sentence.

## Journal Introduction (500-800 words, 4-6 paragraphs)

1. **The biological problem.** Why does this matter? Cite 2-3 biology papers.
2. **Current approaches and limitations.** What tools exist? Why are they insufficient?
3. **The opportunity.** What recent advance makes a new approach possible?
4. **What we did and found.** "Here, we present [Tool]..." NO numbered contribution lists.

## Journal Results (3-5 Narrative Subsections)

Each subsection has a **finding-based title**: "CellAgent identifies rare cell types across tissues" (NOT "RQ1: Main Results").

Each follows: Opening > Approach > Finding (reference Fig panels) > Interpretation > Bridge.

### Story Arc
| Section | Role | Figure |
|---------|------|--------|
| 1 | "Here is our tool" | Fig 1: Framework + validation |
| 2 | "It works well" | Fig 2: Benchmarking |
| 3 | "Here is why" | Fig 3: Mechanism + bio insight |
| 4 | "Here is what it reveals" | Fig 4: Application + discovery |
| 5 (optional) | "Broader impact" | Fig 5: Scalability, clinical |

## Journal Discussion (600-1000 words)

1. Main contribution in context (not repeat of Results)
2. Relation to prior work
3. Broader implications
4. Limitations (honest, specific)
5. Future directions (concrete)

Final sentence: Forward-looking statement about the field.

## Journal Methods (1500-3000 words, at end)

**Placement by journal**:
- Nature/Nature Methods: Online Methods (separate file)
- Nature Commun/NMI/NCS: End of main text
- Science: Supplementary Materials
- Cell family: STAR Methods (structured)

**STAR Methods structure** (Cell family):
```
RESOURCE AVAILABILITY
  Lead contact: [name, email]
  Materials availability: This study did not generate new materials.
  Data and code availability: [GEO/Zenodo/GitHub URLs]

KEY RESOURCES TABLE
  | REAGENT/RESOURCE | SOURCE | IDENTIFIER |
  Software, datasets, models listed with RRIDs

METHOD DETAILS
  [Detailed computational methods, all equations here]

QUANTIFICATION AND STATISTICAL ANALYSIS
  [Tests, sample sizes, software]
```

## Journal Figure Legends

Self-contained paragraphs (100-200 words each):
```
Figure X: [Bold title stating finding].
(a) [Panel description]. (b) [Description, test, n=X].
(c) Error bars: mean +/- s.e.m. (d) *P<0.05, **P<0.01 (two-sided Wilcoxon).
Data from N independent experiments.
```

## Journal-Specific Items

- **Highlights** (Nature Methods): 3-4 bullets, ~15 words each
- **Graphical Abstract** (Cell family): 1-page visual summary
- **CRediT Author Statement**: Role assignments per CRediT taxonomy
- **ORCID**: Required for all authors
- **Data/Code Availability**: GEO/Zenodo/GitHub with DOIs
- **Cover letter**: Tailored to journal (see `references/cover_letter_guide.md`)
- **Reviewer suggestions**: 3-5 experts with emails

## Journal Supplementary Material

| Content | Main Paper | Extended Data (Nature) | Supplementary |
|---------|:---:|:---:|:---:|
| Core results | Yes | | |
| Full benchmarks | | Yes | Yes |
| Proofs | | | Yes |
| Hyperparameters | | | Yes |
| Additional datasets | | Yes | |
| All visualizations | | | Yes |

---

# PART C: Dual-Track Strategy

When producing both conference and journal papers from the same research:

**Shared**: Code, experiments, analysis scripts, bibliography, core results
**Conference paper**: RQ-structured, math in main text, TikZ figures, theoretical emphasis
**Journal paper**: Narrative Results, Methods at end, compound figures, biology-first

| Element | Conference | Journal |
|---------|-----------|--------|
| Contributions | Numbered list | Woven into Introduction |
| Related Work | Separate section | Integrated into Introduction |
| Experiments | RQ-based | Finding-based titles |
| Math | In Method section | In Methods (at end) |
| Figures | TikZ, single-purpose | Compound multi-panel |
| Framing | "Algorithm X achieves Y" | "Tool reveals biology Z" |

**Timeline**: Submit conference first (fixed deadline). Adapt for journal after decision.
