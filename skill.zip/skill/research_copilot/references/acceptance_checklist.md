# Acceptance Checklist (Conference + Journal Unified)

This guide addresses the most common reasons papers are rejected at top conferences (AAAI/IJCAI/ICML/NeurIPS/ICLR) and high-impact journals (Nature/Science/Cell family), with specific prevention strategies and reviewer anticipation patterns.

---

## 1. Experimental Scope Requirements

### 1.1 Minimum Quantities

| Element | Minimum | Recommended | Single-dataset papers? |
|---------|:-------:|:-----------:|:----------------------:|
| Datasets | 3 | 4-5 | Not acceptable (except established hard benchmarks) |
| Baselines | 5 | 7-8 | Fewer only if domain has few methods |
| Metrics per dataset | 3 | 4-5 | Single-metric only if it's the sole standard |
| Seeds per experiment | 3 | 5 | Fewer is unacceptable |
| Ablation variants | 5 | One per component + 2 extra | Fewer means incomplete analysis |

### 1.2 Dataset Selection Criteria

Datasets must cover diversity:
- **Scale diversity**: At least 1 small (<10K samples) and 1 large (>100K) dataset
- **Domain diversity**: At least 2 different sub-domains (e.g., cell type + drug response)
- **Difficulty diversity**: Include both "easy" benchmarks (show competitiveness) and "hard" ones (show advantage)

Unacceptable dataset selection:
- All datasets from the same source/paper
- All datasets of similar scale
- Only datasets where your method happens to work (cherry-picking)

### 1.3 Baseline Selection Strategy

**Must-have baseline categories** (5 minimum total):

| Category | Count | Purpose | Selection rule |
|----------|:-----:|---------|---------------|
| Traditional/Classical | 1 | Show DL advantage | Best non-DL method for this task |
| DL (non-LLM) | 2 | Show LLM/Agent advantage | CNN/GNN/Transformer baselines, 2022+ |
| LLM/Foundation model | 1-2 | Show your method's specific advantage | Most recent, same domain, open-source |
| Your simplified variant | 1 | Isolate your key contribution | Your method minus the core innovation |

**Baseline quality checklist**:
- [ ] All baselines published 2022 or later (except classical methods)
- [ ] >= 50% baselines have open-source code you can run
- [ ] Baseline results on your data are within 2% of their reported results
- [ ] No "straw man" baselines (obviously weak methods just to pad the table)
- [ ] The strongest baseline is genuinely competitive (not something you easily beat by 20%)

### 1.4 Result Reporting Format

Every result must be: **XX.X ± X.X** (mean ± std over 3+ seeds)

In tables:
- **Bold** the best result
- **Underline** the second-best
- Add `*` for statistically significant improvements (p < 0.05)
- Add `**` for p < 0.01
- Include a table footnote: "Results averaged over N seeds. * indicates p < 0.05 vs. best baseline (paired t-test)."

---

## 2. Fair Comparison Protocol

This is the #1 reason for desk rejection at ICML/NeurIPS. **Every method must be compared under identical conditions.**

### 2.1 Identical Training Conditions

All methods (ours + all baselines) must use:
- **Same hardware**: 1x A100 80GB
- **Same data splits**: Identical train/val/test, generated with same seed
- **Same epochs**: All methods train for the same number of epochs (or same wall-clock budget)
- **Same early stopping**: Same patience, same metric for stopping
- **Same seeds**: All methods run with seeds {42, 123, 456} (or {42, 123, 456, 789, 1024} for 5 seeds)

### 2.2 Hyperparameter Tuning Fairness

If you tune your method's hyperparameters:
- **Option A (recommended)**: Use published hyperparameters for all baselines (no tuning). Clearly state this.
- **Option B**: Give all methods the same tuning budget (e.g., 20 trials of random search each). Report the budget.
- **Never**: Tune your method extensively while using default settings for baselines.

### 2.3 Hyperparameter Transparency

Include in the appendix:

| Method | LR | Batch | Epochs | Optimizer | Scheduler | Method-specific params |
|--------|:--:|:-----:|:------:|:---------:|:---------:|:---------------------:|
| Ours | ... | ... | ... | ... | ... | ... |
| Baseline A | ... | ... | ... | ... | ... | ... |
| Baseline B | ... | ... | ... | ... | ... | ... |

### 2.4 In the Paper

Include this text block (adapt to your method):

```latex
\paragraph{Fair Comparison Protocol.}
All methods are trained on identical data splits (seed=42) using the same hardware (1$\times$ A100 80GB).
Baselines use published hyperparameters from their original papers; our method's hyperparameters
are selected via grid search on the validation set only. All results are averaged over 3 independent
runs. We verified baseline implementations against published results ($<$2\% deviation; see Appendix~\ref{app:baseline_verification}).
```

---

## 3. Statistical Significance Standards

### 3.1 When to Claim "Outperforms"

| p-value | Effect Size (Cohen's d) | Verdict | How to report |
|:-------:|:-----------------------:|---------|---------------|
| p < 0.01 | d >= 0.5 | Strong claim | "significantly outperforms (p < 0.01)" |
| p < 0.05 | d >= 0.5 | Standard claim | "outperforms (p < 0.05)" |
| p < 0.05 | d < 0.2 | Weak claim | "statistically significant but modest improvement" |
| p >= 0.05 | any | No claim | "comparable performance" or analyze why |
| any | d < 0.2 | Marginal | Do not claim as main contribution |

### 3.2 What to Do with Marginal Results

If improvement is < 2% or p > 0.05:
1. **Do not claim** this as a main contribution in abstract/title
2. **Do report** it honestly in the results section
3. **Do analyze** why: "The modest improvement on Dataset X may be due to [analysis]"
4. **Strengthen** other contributions: theoretical analysis, efficiency gains, interpretability
5. **Run more seeds** (5-10) to reduce variance if time permits
6. Consider **additional metrics** where your method may show clearer advantage

### 3.3 The "Consistent Improvement" Argument

Even if individual gains are small, consistent improvement across ALL datasets and metrics is powerful:

```latex
While individual improvements are modest (1.2-2.8\%), our method consistently outperforms
all baselines across all 4 datasets and 3 metrics (12 out of 12 comparisons), suggesting
a genuine rather than stochastic advantage.
```

---

## 4. Performance Improvement Strategy

### 4.1 Design Validation Loop

**Phase 1: Quick Sanity Check** (Week 2, before full experiments)
- Train on smallest dataset, 1/10 data, 10 epochs
- If method beats simplest baseline by > 5%: proceed
- If not: debug implementation or revisit method design

**Phase 2: Single-Dataset Full Run** (Week 3)
- Full training on one dataset with default hyperparameters
- Compare against 2-3 key baselines
- If competitive: scale to all datasets
- If not: diagnose (see troubleshooting below)

**Phase 3: Full Experiment Suite** (Week 4-6)
- All datasets, all baselines, all seeds
- Run ablation experiments in parallel

### 4.2 When Method Underperforms — Diagnosis Checklist

Check in this order:

1. **Implementation bugs** (most common):
   - [ ] Data loading: correct number of samples, correct labels
   - [ ] Model forward pass: output shape matches loss function expectation
   - [ ] Loss value: starts in reasonable range, decreases over epochs
   - [ ] Gradient flow: no NaN/Inf gradients, gradients not vanishing

2. **Hyperparameters** (second most common):
   - [ ] Learning rate: try {1e-5, 3e-5, 1e-4, 3e-4, 1e-3}
   - [ ] Batch size: try {8, 16, 32, 64}
   - [ ] Warmup: try {0, 0.05, 0.1} of total steps
   - [ ] Weight decay: try {0, 0.01, 0.1}

3. **Data preprocessing**:
   - [ ] Normalization: is data on the same scale as baselines expect?
   - [ ] Tokenization: are special tokens handled correctly?
   - [ ] Missing values: how are they handled?

4. **Architecture issues**:
   - [ ] Is the model capacity sufficient? (try increasing hidden_dim)
   - [ ] Is the model overfitting? (check train vs val loss gap)
   - [ ] Does the novel component actually get gradients? (add gradient logging)

### 4.3 Improvement Decomposition

Before claiming "our method improves by X%", decompose:

| Source | Contribution |
|--------|:-----------:|
| Novel architecture component | +A% |
| Better hyperparameter tuning | +B% |
| Better data preprocessing | +C% |
| Better training recipe (warmup, scheduler) | +D% |
| **Total** | **A+B+C+D%** |

Only claim A% as your method's contribution. B+C+D should be available to baselines too.

To verify: run your architecture with baseline hyperparameters AND run baseline with your hyperparameters. The gap should still favor your method.

### 4.4 Fallback Strategies

| Situation | Strategy |
|-----------|----------|
| Method loses on all datasets | Revisit method; fall back to MPU from proposal |
| Method wins on 2/4 datasets | Analyze dataset characteristics; discuss when method works/fails |
| Improvement < 1% everywhere | Emphasize theoretical contribution + consistency + efficiency |
| One baseline is unbeatable | Acknowledge it; show complementary advantages (speed, interpretability) |
| Ablation shows a component doesn't help | Simplify method (remove that component); simpler is better |

---

## 5. Mandatory Experiment Checklist

Every paper must include ALL of the following. Missing any one is grounds for rejection.

### 5.1 Required Tables

| # | Table | Content | Where |
|:-:|-------|---------|:-----:|
| 1 | Main Results | All methods x all datasets x all metrics, with ±std | Main paper |
| 2 | Ablation Study | Full model vs removing each component | Main paper |
| 3 | Efficiency Comparison | Train time, inference time, GPU memory, #params | Main paper or appendix |
| 4 | Hyperparameter Table | All hyperparameters for all methods | Appendix |
| 5 | Baseline Verification | Your reproduction vs published results | Appendix |

### 5.2 Required Figures

| # | Figure | Content | Where |
|:-:|--------|---------|:-----:|
| 1 | Method Comparison | Traditional vs ours (overview) | Main paper |
| 2 | Architecture | Full model architecture | Main paper |
| 3 | Data Pipeline | Preprocessing steps | Main paper |
| 4 | Main Results Viz | Bar chart or radar chart of main results | Main paper |
| 5 | Ablation Viz | Heatmap or bar chart of ablation | Main paper |
| 6 | Case Study | Qualitative examples (success + failure) | Main paper |

### 5.3 Required Analysis Subsections

| Analysis | What it shows | Why reviewers care |
|----------|--------------|-------------------|
| Sensitivity analysis | Performance vs key hyperparameters | Is the method robust or fragile? |
| Efficiency analysis | Speed/memory vs baselines | Is the method practical? |
| Visualization (UMAP/t-SNE) | Learned representation quality | Does the model learn meaningful structure? |
| Case study (success) | Where method wins and why | Validates the innovation's purpose |
| Case study (failure) | Where method fails and why | Shows intellectual honesty |
| Cross-dataset generalization | Performance on unseen domains | Is the method generalizable? |

### 5.4 Conference-Specific Requirements

| Requirement | AAAI | IJCAI | ICML | NeurIPS | ICLR |
|-------------|:----:|:-----:|:----:|:-------:|:----:|
| Main results table | Required | Required | Required | Required | Required |
| Ablation study | Required | Required | Required | Required | Required |
| Statistical significance | Recommended | Recommended | Required | Required | Required |
| Complexity analysis | Optional | Recommended | Required | Recommended | Optional |
| Reproducibility checklist | Optional | Optional | Required | Required | Recommended |
| Broader impact | Recommended | Optional | Optional | Required | Optional |
| Ethics statement | Required | Optional | Optional | Optional | Optional |
| Failure case analysis | Recommended | Recommended | Recommended | Required | Required |

---

## 6. Reviewer Anticipation Guide

### 6.1 Top 10 Rejection Patterns and Prevention

| # | Rejection Pattern | Prevention | Paper section to address |
|:-:|-------------------|------------|:-----------------------:|
| 1 | "Limited novelty / just engineering" | Include theoretical analysis; at least 1 theorem | Method 3.4 |
| 2 | "Unfair comparison" | Fair comparison protocol (Section 2 above) | Experiments setup |
| 3 | "Not statistically significant" | 3+ seeds, p-values, effect sizes | Results tables |
| 4 | "Missing ablations" | 5+ ablation variants | Experiments 4.3 |
| 5 | "Insufficient experimental scope" | 3+ datasets, 5+ baselines, 3+ metrics | Experiments 4.1 |
| 6 | "Overclaiming" | Match claims to evidence; be honest about limitations | Abstract, Conclusion |
| 7 | "Poor writing quality" | Proofread; consistent notation; no grammar errors | Throughout |
| 8 | "Reproducibility concerns" | Full hyperparameters; code release promise; detailed setup | Appendix |
| 9 | "No failure analysis" | Include failure cases and analyze why | Experiments 4.4 |
| 10 | "Marginal practical impact" | Show efficiency gains or real-world applicability | Discussion |

### 6.2 Self-Review Checklist (Before Submission)

**Read the paper as a hostile reviewer and check:**

- [ ] Can I identify 3 clear contributions in the introduction?
- [ ] Is at least one contribution theoretical (not just "we propose X")?
- [ ] Would I be satisfied with the experimental setup if I were a competing author?
- [ ] Are all baselines recent (2022+) and competitive?
- [ ] Are all improvements statistically significant (p < 0.05)?
- [ ] Can I see error bars in all tables and relevant figures?
- [ ] Is there an ablation for EVERY novel component?
- [ ] Are failure cases honestly discussed?
- [ ] Is the fair comparison protocol clearly stated?
- [ ] Could I reproduce the experiments from the paper alone?
- [ ] Are all claims backed by evidence (citation or experiment)?
- [ ] Is the paper within page limit?
- [ ] Is the paper anonymous (no author names, no identifiable repos)?

### 6.3 Pre-Rebuttal Preparation

While writing the paper, prepare answers for these likely questions:

1. "Why not compare with [recent method X]?"
   → Have a prepared answer: either add it, or explain why it's not applicable

2. "What happens with different random seeds?"
   → Already have 3-5 seed results ready

3. "Is the improvement from your method or from better hyperparameter tuning?"
   → Have the improvement decomposition (Section 4.3) ready

4. "Does this generalize to other domains/datasets?"
   → Have at least one out-of-domain experiment or discuss limitations

5. "What is the computational overhead of your method?"
   → Have efficiency table ready (training time, inference time, memory)

6. "Why does the method fail on [dataset/case]?"
   → Have failure analysis ready with explanation

---

## 7. Code Robustness for Students

### 7.1 Training Stability Essentials

These must be in the training code to prevent experiments from failing:

```python
# In trainer.py — non-negotiable stability measures:

# 1. Gradient clipping (prevents exploding gradients)
torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

# 2. Learning rate warmup (prevents early instability)
# Use linear warmup for first 5-10% of steps

# 3. NaN detection (catch failures early)
if torch.isnan(loss):
    logger.error(f"NaN loss at step {step}. Stopping.")
    break

# 4. Gradient monitoring (detect vanishing/exploding)
total_norm = sum(p.grad.norm().item()**2 for p in model.parameters() if p.grad is not None)**0.5
if total_norm > 100:
    logger.warning(f"Large gradient norm: {total_norm:.2f}")

# 5. Checkpoint every N epochs (never lose progress)
if epoch % save_every == 0:
    save_checkpoint(model, optimizer, scheduler, epoch, path)

# 6. Early stopping with patience
if val_metric < best_metric:
    patience_counter += 1
    if patience_counter >= patience:
        logger.info("Early stopping triggered")
        break
```

### 7.2 Experiment Logging Requirements

Every experiment must log:
- Full config (YAML dump)
- Git commit hash of the code
- Random seeds used
- Training loss curve (per-step)
- Validation metrics curve (per-epoch)
- Peak GPU memory usage
- Wall-clock training time
- Final evaluation results (structured JSON)

### 7.3 Failure Recovery

```bash
# In scripts — always support resume:
python main.py --config configs/default.yaml \
    --checkpoint outputs/main/last.pt \
    --output_dir outputs/main

# The training code must:
# 1. Check if checkpoint exists at start
# 2. Load model + optimizer + scheduler + epoch from checkpoint
# 3. Continue from where it left off
# 4. Log "Resuming from epoch X"
```

### 7.4 Student Debugging Checklist

When an experiment fails, students should check in this order:
1. **OOM**: Reduce batch_size or enable gradient_checkpointing
2. **NaN loss**: Check learning rate (try 10x smaller), check data for NaN/Inf values
3. **Loss not decreasing**: Check data loading (are labels correct?), try different LR
4. **Val metric oscillating**: Reduce LR, increase warmup, check for data leakage
5. **Baseline can't reproduce**: Check their published hyperparameters, data version, preprocessing

---

## 8. Rebuttal and Revision Strategy

### 8.1 Review Parsing Framework

When reviews arrive, classify each comment:

| Category | Response Strategy | Priority |
|----------|------------------|:--------:|
| **Factual misunderstanding** | Politely correct with evidence from the paper | High |
| **Missing experiment** | Run it during rebuttal period (if feasible) | High |
| **Methodological concern** | Provide additional analysis or formal argument | High |
| **Writing/clarity issue** | Acknowledge and describe specific revision | Medium |
| **Novelty/scope concern** | Argue positioning; cite differences from related work | Critical |
| **Taste/preference** | Acknowledge respectfully; do not argue | Low |

### 8.2 Rebuttal Writing Template

For each reviewer, structure the response as:

```
We thank Reviewer [X] for the constructive feedback.

**[R1.Q1: Paraphrase their concern]**
[Your response with specific evidence. If you ran a new experiment, include the results table here.]

**[R1.Q2: Next concern]**
[Response...]

**Summary of changes**: 
- Added [experiment X] as suggested (Table R1)
- Clarified [section Y] in the revised manuscript
- [Other changes]
```

**Tone rules:**
- Never be defensive or dismissive
- Acknowledge valid points: "The reviewer raises an excellent point..."
- For disagreements: "We respectfully note that..." with evidence
- Always end positively: "We believe these changes address the reviewer's concerns"

### 8.3 Emergency Experiment Playbook

**Plan these during paper writing, not after reviews arrive.**

Pre-identify 3-4 quick experiments (3-5 days each) that address common reviewer demands:

| Emergency Experiment | When needed | Time to run |
|---------------------|-------------|:-----------:|
| Additional baseline (latest method) | "Missing baseline X" | 2-3 days |
| Additional dataset | "Only tested on N datasets" | 3-5 days |
| Sensitivity to key hyperparameter | "How sensitive is the method?" | 1-2 days |
| More seeds (5→10) | "Results not statistically significant" | 2-3 days |
| Biological validation experiment | "No biological interpretation" | 2-3 days |
| Computational cost comparison | "No efficiency analysis" | 1 day |

### 8.4 Handling Contradictory Reviews

| Situation | Strategy |
|-----------|----------|
| R1: "Too simple" / R3: "Too complex" | Show both can be addressed: simplify presentation, justify complexity with ablation |
| R1: "Novelty is limited" / R2: "Interesting approach" | Focus on R1's specific concerns; cite R2's positive assessment in AC discussion |
| All reviewers positive but one concern each | Address all concerns; easiest path to acceptance |
| Majority negative | Prioritize the most actionable concerns; acknowledge limitations honestly |

### 8.5 ICLR Discussion Period Strategy

ICLR uses an open discussion period instead of a traditional rebuttal:

- **Timing**: Respond within 48 hours of reviews appearing; don't wait for the deadline
- **Tone**: Collegial, like a conference discussion — not adversarial
- **Follow-up**: Monitor for reviewer responses; engage in multi-turn dialogue
- **New results**: Can upload revised PDF during discussion — include new experiments
- **Cross-reviewer**: If R1 makes a point that addresses R2's concern, reference it

### 8.6 Post-Rebuttal Decision

If the paper is:
- **Accepted**: Incorporate all promised changes into camera-ready
- **Rejected with strong reviews**: Revise thoroughly and resubmit to next venue (use the decision tree in `venue_profiles.md`)
- **Rejected with weak reviews**: Consider appealing only if there are clear factual errors in reviews
