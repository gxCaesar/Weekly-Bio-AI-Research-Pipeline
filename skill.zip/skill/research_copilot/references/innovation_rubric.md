# Innovation Rubric: Three-Dimensional Scoring

Every innovation point is evaluated on three independent dimensions. A strong submission to any venue requires balance across all three.

## The Three Dimensions

| Dimension | What it measures | Conference weight | Journal weight |
|-----------|-----------------|:-:|:-:|
| **Theoretical Depth** | Formal results, proofs, bounds, principled formulation | HIGH (ICML/NeurIPS) | MEDIUM (varies) |
| **Biological Significance** | New biology revealed, enabling new experiments, domain impact | MEDIUM | HIGH (Nature/Cell) |
| **Engineering Impact** | Practical tool, reproducible pipeline, community utility | MEDIUM | HIGH (Nature Methods) |

## Scoring Rubric (1-5 per dimension)

### Theoretical Depth

| Score | Description | Example |
|:-----:|-------------|---------|
| 1 | No formal analysis. Pure empirical method. | "We add attention and test on benchmarks" |
| 2 | Informal motivation with intuition. | "Our attention is inspired by GRN structure because biologically related genes should attend to each other" |
| 3 | Formal problem definition with principled objective derivation. | "We formulate cell annotation as structured prediction and derive a variational bound for our objective" |
| 4 | Theorem/proposition with proof in appendix. | "We prove our sparse attention converges to optimal under mild assumptions (Theorem 1)" |
| 5 | Novel theoretical framework with generalization bounds. | "We establish PAC-Bayes bounds for biological foundation models under covariate shift" |

### Biological Significance

| Score | Description | Example |
|:-----:|-------------|---------|
| 1 | Standard ML benchmark evaluation only. | "We test on Tabula Sapiens and report accuracy" |
| 2 | ML metrics + basic bio validation (UMAP, known markers). | "UMAP shows cell type separation; top genes overlap known markers" |
| 3 | Recovers known biological patterns + provides interpretable biological insights. | "Attention weights recover 73% of ENCODE TF-target interactions" |
| 4 | Reveals novel biological patterns validated against independent databases. | "Our model identifies a previously unreported regulatory module in CD8+ T cells, confirmed by ChIP-seq" |
| 5 | Enables fundamentally new biological analysis impossible before. | "Our virtual cell model accurately predicts cellular response to unseen drug perturbations" |

### Engineering Impact

| Score | Description | Example |
|:-----:|-------------|---------|
| 1 | Proof of concept, not runnable by others. | "We show it works on our setup" |
| 2 | Code available, reproduces paper results. | "GitHub repo with README" |
| 3 | Well-documented tool with tutorial, tested on multiple datasets. | "pip-installable, Colab tutorial, tested on 5 datasets" |
| 4 | Community-adopted tool with broad applicability. | "Used by 3+ labs, handles diverse data types" |
| 5 | Platform/framework that enables an ecosystem. | "Foundation for downstream tools, API, standardized interface" |

## Minimum Scores by Venue

| Venue | Theoretical | Biological | Engineering | Total (min) |
|-------|:---:|:---:|:---:|:---:|
| ICML | 4 | 2 | 3 | 11 |
| NeurIPS | 3 | 3 | 3 | 11 |
| ICLR | 3 | 3 | 3 | 11 |
| AAAI/IJCAI | 2 | 3 | 3 | 10 |
| Nature Methods | 2 | 4 | 4 | 12 |
| Nature Machine Intelligence | 3 | 3 | 3 | 11 |
| Nature Communications | 2 | 4 | 3 | 11 |
| Nature Comp Sci | 3 | 3 | 3 | 11 |
| PLOS Comp Bio | 2 | 3 | 4 | 10 |
| Genome Biology | 2 | 4 | 3 | 10 |

## Portfolio Optimization

A paper with 3 innovation points should cover all three dimensions:

**Balanced portfolio** (recommended for dual-track):
- Innovation 1: Theoretical (score 4+ on theoretical)
- Innovation 2: Biological (score 4+ on biological)
- Innovation 3: Engineering (score 4+ on engineering)

**Conference-optimized portfolio** (ICML/NeurIPS):
- Innovation 1: Theoretical (score 4-5)
- Innovation 2: Theoretical + Biological (score 3+3)
- Innovation 3: Engineering + Biological (score 3+3)

**Journal-optimized portfolio** (Nature Methods):
- Innovation 1: Biological (score 4-5)
- Innovation 2: Engineering (score 4-5)
- Innovation 3: Theoretical + Biological (score 3+3)

## Venue-Fit Matrix

For each candidate innovation, score venue fit:

| Innovation aspect | Best conference | Best journal |
|-------------------|----------------|-------------|
| Formal proof/bound | ICML, NeurIPS | Nature Comp Sci |
| New biological finding | AAAI (application) | Nature, Cell |
| Practical tool for biologists | AAAI | Nature Methods |
| Representation learning insight | ICLR | Nature Machine Intelligence |
| New benchmark/dataset | NeurIPS D&B | Genome Biology |
| Systems-level analysis | IJCAI | Cell Systems |
| Drug design advance | NeurIPS | Nature Biotechnology |
| Clinical application | AAAI | Cell Reports Medicine |

## Innovation Candidate Generation Strategy

When generating 5 candidates (over-generate, then user selects 3):

1. **Start from the gap**: Each identified research gap suggests at least one innovation.
2. **Apply the "what if" matrix**: For each gap, ask:
   - What if we formalize this as a learning problem? (theoretical candidate)
   - What if we prove why existing methods fail? (theoretical candidate)
   - What if we build a tool that solves this for biologists? (engineering candidate)
   - What if we apply this to reveal unknown biology? (biological candidate)
   - What if we combine two techniques in a principled way? (cross-dimensional candidate)
3. **Score all candidates** on the three dimensions.
4. **Present top 5** with recommended portfolio of 3.
