# Figure Guide (Conference TikZ + Journal Compound Unified)

## Conference-Specific Figure Settings

### Column Width Reference

| Conference | Single col width | Full page width | Notes |
|-----------|:---:|:---:|-------|
| AAAI | ~3.3in | ~6.75in | Narrower columns |
| IJCAI | ~3.3in | ~6.75in | Similar to AAAI |
| ICML | ~3.25in | ~6.75in | Slightly different margins |
| NeurIPS | ~3.25in | ~6.75in | Standard ML layout |
| ICLR | ~3.25in | ~6.75in | Same as NeurIPS in practice |

### Practical Guidelines

- **AAAI/IJCAI (7-page limit)**: Prefer single-column figures to save space. Use `figure*` (full-width) only for the architecture diagram (Fig 2). Maximum 2 full-width figures in main text.
- **ICML/NeurIPS/ICLR (8-9 pages)**: More room, but still use full-width sparingly. Maximum 3 full-width figures.

### Font Size Guidelines

All conferences use ~10pt body text. Figure text should be:
- Node labels: `\small` (9pt) or `\footnotesize` (8pt)
- Axis labels: `\small`
- Tick labels: `\scriptsize` (7pt) or `\footnotesize`
- Annotations: `\scriptsize`
- Never smaller than `\tiny` (5pt) — illegible in print

### Adaptive Width Macros

Add to preamble for conference-portable figures:
```latex
\newlength{\figcolwidth}
\setlength{\figcolwidth}{\columnwidth}
\newlength{\figfullwidth}
\setlength{\figfullwidth}{\textwidth}
```

Use `\figcolwidth` and `\figfullwidth` in all figure `width=` specifications.

---

## Figure 1: Method Comparison Diagram

This figure shows why existing approaches fall short and how ours is different.
Use a side-by-side layout: left = traditional pipeline, right = our pipeline.

```latex
\begin{figure*}[t]
\centering
\begin{tikzpicture}[
    node distance=0.8cm and 1.2cm,
    block/.style={rectangle, draw, rounded corners, minimum height=1cm, minimum width=2.2cm, align=center, font=\small},
    arrow/.style={->, >=stealth, thick},
    label/.style={font=\small\bfseries, above},
    dashedblock/.style={rectangle, draw, dashed, rounded corners, minimum height=1cm, minimum width=2.2cm, align=center, font=\small, draw=gray},
]

% Left side: Traditional approach
\node[label] (trad_label) {(a) Traditional Approach};
\node[block, below=0.3cm of trad_label, fill=blue!10] (trad_input) {Raw Data};
\node[block, below=of trad_input, fill=blue!10] (trad_proc) {Feature\\Engineering};
\node[block, below=of trad_proc, fill=blue!10] (trad_model) {Task-Specific\\Model};
\node[block, below=of trad_model, fill=red!10] (trad_out) {Limited\\Results};

\draw[arrow] (trad_input) -- (trad_proc);
\draw[arrow] (trad_proc) -- (trad_model);
\draw[arrow] (trad_model) -- (trad_out);

% Cross marks for limitations
\node[right=0.1cm of trad_proc, text=red, font=\small] {$\times$ Manual};
\node[right=0.1cm of trad_model, text=red, font=\small] {$\times$ Not scalable};

% Right side: Our approach
\node[label, right=4cm of trad_label] (our_label) {(b) Our Approach};
\node[block, below=0.3cm of our_label, fill=green!10] (our_input) {Raw Data};
\node[block, below=of our_input, fill=green!10] (our_enc) {Foundation\\Model};
\node[block, below=of our_enc, fill=green!10] (our_novel) {\textbf{Our Novel}\\Module};
\node[block, below=of our_novel, fill=green!20] (our_out) {Superior\\Results};

\draw[arrow] (our_input) -- (our_enc);
\draw[arrow] (our_enc) -- (our_novel);
\draw[arrow] (our_novel) -- (our_out);

% Check marks for advantages
\node[right=0.1cm of our_enc, text=green!60!black, font=\small] {\checkmark~Automated};
\node[right=0.1cm of our_novel, text=green!60!black, font=\small] {\checkmark~Scalable};

\end{tikzpicture}
\caption{\textbf{Comparison of traditional approaches and our method.} (a)~Traditional methods require manual feature engineering and task-specific models. (b)~Our approach uses a foundation model backbone with [Module Name] to enable end-to-end analysis without manual feature design.}
\label{fig:comparison}
\end{figure*}
```

## Figure 2: Model Architecture Diagram

The main architecture figure. Use blocks, arrows, and clear labeling.

```latex
\begin{figure*}[t]
\centering
\begin{tikzpicture}[
    node distance=0.6cm and 1.5cm,
    module/.style={rectangle, draw, rounded corners=3pt, minimum height=1.2cm, minimum width=2.5cm, align=center, font=\small},
    smallmod/.style={rectangle, draw, rounded corners=2pt, minimum height=0.8cm, minimum width=1.8cm, align=center, font=\scriptsize},
    arrow/.style={->, >=stealth, thick},
    darrow/.style={->, >=stealth, thick, dashed},
    bigarrow/.style={->, >=stealth, line width=1.5pt},
    label/.style={font=\scriptsize, midway},
    grouplabel/.style={font=\small\bfseries},
]

% Input
\node[module, fill=blue!15] (input) {Input\\Representation};

% Encoder block
\node[module, right=1.5cm of input, fill=orange!15] (encoder) {Encoder\\(Transformer)};

% Novel module (highlighted)
\node[module, right=1.5cm of encoder, fill=red!15, line width=1.5pt, draw=red!60] (novel) {\textbf{Our Novel}\\Module};

% Decoder/output
\node[module, right=1.5cm of novel, fill=green!15] (decoder) {Task Head};

% Output
\node[module, right=1.5cm of decoder, fill=gray!15] (output) {Prediction};

% Arrows
\draw[bigarrow] (input) -- (encoder);
\draw[bigarrow] (encoder) -- (novel);
\draw[bigarrow] (novel) -- (decoder);
\draw[bigarrow] (decoder) -- (output);

% Sub-components inside novel module (expanded below)
\node[grouplabel, below=1.5cm of novel] (detail_label) {Novel Module Detail};
\node[smallmod, below=0.3cm of detail_label, fill=red!8] (sub1) {Component A};
\node[smallmod, right=0.5cm of sub1, fill=red!8] (sub2) {Component B};
\node[smallmod, right=0.5cm of sub2, fill=red!8] (sub3) {Component C};

% Connection from main to detail
\draw[darrow, red!60] (novel.south) -- ++(0,-0.5) -| (sub1.north);
\draw[darrow, red!60] (novel.south) -- ++(0,-0.5) -| (sub2.north);
\draw[darrow, red!60] (novel.south) -- ++(0,-0.5) -| (sub3.north);

% Detail arrows
\draw[arrow] (sub1) -- (sub2);
\draw[arrow] (sub2) -- (sub3);

% Dimension annotations
\node[font=\scriptsize, above=0.15cm of input] {$\mathbb{R}^{N \times d}$};
\node[font=\scriptsize, above=0.15cm of encoder] {$\mathbb{R}^{N \times h}$};
\node[font=\scriptsize, above=0.15cm of output] {$\mathbb{R}^{N \times C}$};

% Loss
\node[module, below=1cm of output, fill=yellow!15] (loss) {Loss $\mathcal{L}$};
\draw[darrow] (output) -- (loss);

\end{tikzpicture}
\caption{\textbf{Overview of our proposed framework.} The model consists of [describe components]. The highlighted \textbf{Our Novel Module} is our key contribution, which [describe what it does]. Dashed arrows indicate the detailed structure shown in the expanded view below.}
\label{fig:architecture}
\end{figure*}
```

## Figure 3+: Additional Figure Templates

### Data Pipeline Figure

```latex
\begin{figure}[t]
\centering
\begin{tikzpicture}[
    node distance=0.5cm,
    step/.style={rectangle, draw, rounded corners, minimum height=0.8cm, minimum width=3cm, align=center, font=\small, fill=blue!8},
    arrow/.style={->, >=stealth, thick},
    data/.style={font=\scriptsize\itshape, text=gray},
]
\node[step] (s1) {Step 1: Raw Data};
\node[step, below=of s1] (s2) {Step 2: Filtering};
\node[step, below=of s2] (s3) {Step 3: Normalization};
\node[step, below=of s3] (s4) {Step 4: Tokenization};
\node[step, below=of s4] (s5) {Step 5: Ready for Training};

\draw[arrow] (s1) -- (s2) node[data, right, midway] {N samples};
\draw[arrow] (s2) -- (s3) node[data, right, midway] {N' samples};
\draw[arrow] (s3) -- (s4);
\draw[arrow] (s4) -- (s5);
\end{tikzpicture}
\caption{\textbf{Data preprocessing pipeline.} [Description]}
\label{fig:data_pipeline}
\end{figure}
```

### Results Bar Chart (placeholder)

```latex
\begin{figure}[t]
\centering
\begin{tikzpicture}
\begin{axis}[
    ybar,
    bar width=12pt,
    width=\columnwidth,
    height=5cm,
    ylabel={Performance (\%)},
    symbolic x coords={Method A, Method B, Method C, Ours},
    xtick=data,
    x tick label style={rotate=30, anchor=east, font=\small},
    ymin=70, ymax=100,
    legend style={at={(0.5,1.05)}, anchor=south, legend columns=2, font=\small},
    nodes near coords,
    nodes near coords style={font=\tiny},
    every node near coord/.append style={above},
]
% Placeholder values - replace with actual results
\addplot coordinates {(Method A, 82.3) (Method B, 84.1) (Method C, 86.5) (Ours, 91.2)};
\addplot coordinates {(Method A, 79.5) (Method B, 81.8) (Method C, 84.2) (Ours, 89.7)};
\legend{Metric 1, Metric 2}
\end{axis}
\end{tikzpicture}
\caption{\textbf{Main results comparison.} Our method outperforms all baselines. [Update with real numbers]}
\label{fig:main_results}
\end{figure}
```

### Ablation Heatmap (placeholder)

```latex
\begin{figure}[t]
\centering
\begin{tikzpicture}
\begin{axis}[
    colormap/YlOrRd,
    colorbar,
    point meta min=70, point meta max=95,
    width=\columnwidth,
    height=5cm,
    xlabel={Component},
    ylabel={Metric},
    xtick={0,1,2,3},
    xticklabels={Full, w/o A, w/o B, w/o C},
    ytick={0,1,2},
    yticklabels={Acc, F1, AUC},
    x tick label style={rotate=30, anchor=east, font=\small},
    y tick label style={font=\small},
]
% Placeholder values
\addplot[matrix plot*, mesh/cols=4, point meta=explicit] coordinates {
    (0,0) [91.2] (1,0) [87.3] (2,0) [85.1] (3,0) [83.8]
    (0,1) [89.7] (1,1) [85.2] (2,1) [83.5] (3,1) [81.9]
    (0,2) [93.1] (1,2) [89.8] (2,2) [87.2] (3,2) [86.5]
};
\end{axis}
\end{tikzpicture}
\caption{\textbf{Ablation study.} Removing any component degrades performance, confirming each module's contribution.}
\label{fig:ablation}
\end{figure}
```

---

## Compact Figure Variants (for AAAI/IJCAI 7-page limit)

When space is tight, use single-column compact layouts:

### Compact Architecture

```latex
\begin{figure}[t]
\centering
\begin{tikzpicture}[
    node distance=0.4cm,
    module/.style={rectangle, draw, rounded corners=2pt, minimum height=0.7cm,
                   minimum width=0.85\columnwidth, align=center, font=\scriptsize},
    arrow/.style={->, >=stealth, thick},
]
\node[module, fill=blue!15] (input) {Input Representation};
\node[module, below=of input, fill=orange!15] (enc) {Encoder (Transformer)};
\node[module, below=of enc, fill=red!15, draw=red!60, line width=1pt] (novel) {\textbf{Our Novel Module}};
\node[module, below=of novel, fill=green!15] (head) {Task Head};
\node[module, below=of head, fill=gray!15] (output) {Prediction};

\draw[arrow] (input) -- (enc);
\draw[arrow] (enc) -- (novel);
\draw[arrow] (novel) -- (head);
\draw[arrow] (head) -- (output);

% Dimension labels
\node[font=\tiny, left=0.1cm of input] {$\mathbb{R}^{N \times d}$};
\node[font=\tiny, left=0.1cm of output] {$\mathbb{R}^{N \times C}$};
\end{tikzpicture}
\caption{\textbf{Model architecture.} [Brief description.]}
\label{fig:architecture}
\end{figure}
```

### Compact Comparison (side-by-side in single column)

```latex
\begin{figure}[t]
\centering
\begin{tikzpicture}[
    node distance=0.3cm and 0.8cm,
    block/.style={rectangle, draw, rounded corners, minimum height=0.6cm,
                  minimum width=1.4cm, align=center, font=\tiny},
    arrow/.style={->, >=stealth},
    lbl/.style={font=\tiny\bfseries},
]
% Left: Traditional
\node[lbl] (l1) {(a) Traditional};
\node[block, below=0.2cm of l1, fill=blue!10] (t1) {Raw Data};
\node[block, below=of t1, fill=blue!10] (t2) {Features};
\node[block, below=of t2, fill=red!10] (t3) {Limited};
\draw[arrow] (t1)--(t2); \draw[arrow] (t2)--(t3);

% Right: Ours
\node[lbl, right=1.5cm of l1] (l2) {(b) Ours};
\node[block, below=0.2cm of l2, fill=green!10] (o1) {Raw Data};
\node[block, below=of o1, fill=green!10] (o2) {LLM/Agent};
\node[block, below=of o2, fill=green!20] (o3) {Superior};
\draw[arrow] (o1)--(o2); \draw[arrow] (o2)--(o3);
\end{tikzpicture}
\caption{\textbf{Approach comparison.} [Brief description.]}
\label{fig:comparison}
\end{figure}
```

---

## General TikZ Tips

1. **Colors**: Use pastel fills (`blue!10`, `green!15`) for readability
2. **Fonts**: Use `\small` or `\scriptsize` inside nodes for compact diagrams
3. **Arrows**: Use `>=stealth` for professional-looking arrowheads
4. **Highlighting**: Use thicker borders and brighter colors for novel components
5. **Spacing**: `node distance` controls default spacing; adjust per figure
6. **Width**: Use `\columnwidth` for single-column, `\textwidth` for full-width
7. **Required packages**: `\usepackage{tikz, pgfplots}` and `\usetikzlibrary{positioning, arrows.meta, calc, fit, backgrounds}`
8. **PDF output**: For matplotlib-generated figures, always save as PDF (`savefig('fig.pdf')`) for vector quality in LaTeX

## Figure Naming Convention

Save individual TikZ figures as separate `.tex` files in `paper/figures/`:
```
figures/
├── fig_comparison.tex
├── fig_architecture.tex
├── fig_data_pipeline.tex
├── fig_main_results.tex      # Placeholder bar chart
├── fig_ablation.tex          # Placeholder heatmap
└── fig_case_study.tex        # Placeholder
```

Include in main.tex with `\input{figures/fig_comparison.tex}`.

Post-experiment figures (generated by `analysis/generate_figures.py`) are saved as PDF:
```
figures/
├── fig4_main_bar.pdf         # Generated by analysis
├── fig5_ablation.pdf         # Generated by analysis
└── fig6_case_study.pdf       # Generated by analysis
```

---

# PART B: Journal Compound Multi-Panel Figures

Use this section when `{VENUE_TYPE}` is `journal` or `dual`.

## Journal Figure Style Settings (Python)

```python
JOURNAL_STYLE = {
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica"],
    "font.size": 7,             # Nature standard: 7pt
    "axes.labelsize": 8,
    "axes.titlesize": 8,
    "xtick.labelsize": 6,
    "ytick.labelsize": 6,
    "legend.fontsize": 6,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "axes.linewidth": 0.5,
}
COLORS = ["#0077BB", "#EE7733", "#009988", "#CC3311", "#33BBEE", "#EE3377", "#BBBBBB"]
```

## Journal Figure Size Reference

| Journal family | Single column | Full width | Max height |
|---------------|:---:|:---:|:---:|
| Nature | 88 mm | 180 mm | ~240 mm |
| Science | 85 mm | 174 mm | ~240 mm |
| Cell | 85 mm | 174 mm | ~240 mm |

## Compound Figure Template (Python)

```python
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

def create_compound_figure(n_panels=6, figsize=(180/25.4, 200/25.4)):
    plt.rcParams.update(JOURNAL_STYLE)
    fig = plt.figure(figsize=figsize)
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.4, wspace=0.3)
    axes = {}
    for i, label in enumerate("abcdef"[:n_panels]):
        row, col = divmod(i, 3)
        axes[label] = fig.add_subplot(gs[row, col])
        axes[label].text(-0.15, 1.05, label, transform=axes[label].transAxes,
                         fontsize=10, fontweight="bold", va="bottom")
    return fig, axes

def add_significance_annotation(ax, x1, x2, y, p_value, height=0.02):
    stars = "***" if p_value < 0.001 else "**" if p_value < 0.01 else "*" if p_value < 0.05 else "n.s."
    ax.plot([x1, x1, x2, x2], [y, y+height, y+height, y], color="black", linewidth=0.5)
    ax.text((x1+x2)/2, y+height, stars, ha="center", va="bottom", fontsize=7)
```

## Standard Journal Figures (4-6 Compound)

1. **Fig 1**: Framework + initial validation (a: schematic, b: example, c: metric, d: comparison)
2. **Fig 2**: Benchmarking (a: bar/dot plot, b: heatmap, c: per-dataset, d: statistical)
3. **Fig 3**: Mechanism + bio insight (a: UMAP, b: attention, c: GO enrichment, d: markers)
4. **Fig 4**: Application + discovery (a: scenario, b: new data, c: validation, d: novel finding)

## Journal Figure Legends

Self-contained paragraphs (100-200 words). Must include:
- [ ] Bold title stating finding
- [ ] Every panel described
- [ ] Statistical test named
- [ ] Sample sizes (n)
- [ ] Error bar definition
- [ ] Number of replicates

## Output Organization (Journal)

```
figures/
├── fig1/
│   ├── fig1a_workflow.pdf
│   ├── fig1b_validation.pdf
│   └── fig1_assembled.pdf    # Assembled in Inkscape
├── fig2/
├── extended_data/
└── supplementary/
```

Individual panels: Python scripts. Assembly: Inkscape or Adobe Illustrator.
