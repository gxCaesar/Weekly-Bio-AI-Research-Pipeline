---
name: rebuttal_plan
description: >
  Reviewer response planning and rebuttal package generation skill. Takes reviewer feedback on
  a submitted paper and produces a comprehensive rebuttal package: classified review analysis,
  per-comment response strategy, additional experiment design with time budget, paper revision
  diff, and submission checklist. Supports both conference rebuttals (AAAI/IJCAI/ICML/NeurIPS/ICLR)
  and journal Revise & Resubmit (Nature/Science/Cell family). Classifies comments by type
  (technical/experimental/writing/misunderstanding/bias) and priority (critical/important/minor).
  Operates in full interactive mode (default, pauses at each decision point) or express mode
  (only pauses for experiment decisions). Accepts reviewer feedback as plain text or markdown
  (automatically detected). Use after receiving reviewer comments. Also triggers for: reviewer
  response, response letter drafting, revision, R&R, rebuttal letter, paper revision after review,
  NeurIPS rebuttal, ICML rebuttal, Nature revision.
---

# Rebuttal Plan Skill

This skill converts reviewer feedback on a submitted paper into a comprehensive, time-budgeted
rebuttal package. It enforces a systematic approach to reviewer response: classify every
comment, design a response strategy, plan additional experiments within the rebuttal window,
revise the paper, and check the final package against submission requirements.

**Target venues**: Top CS conferences (AAAI/IJCAI/ICML/NeurIPS/ICLR) with rebuttal periods of
7-14 days; Nature/Science/Cell family journals with Revise & Resubmit decisions (typically
2-3 months).
**Interaction mode**: Full (default, pauses at 4 points) or Express (pauses only for experiment decisions).
**Input format**: Plain text or Markdown (auto-detected). PDF parsing not supported — user should copy-paste review text.
**Language convention**: Internal reports in Chinese; response letter and paper revisions in English.
**Writing style**: Polite but confident. No groveling, no arrogance. Direct acknowledgment of valid concerns, respectful rebuttal of incorrect claims. See `references/rebuttal_tone_guide.md`.

## When to Use

Invoke this skill when:
- You have received reviewer feedback on a submitted paper
- You need to draft a response letter
- You need to decide which supplementary experiments to run within the rebuttal window
- You need to revise the paper in response to reviews

**Do NOT** use this skill if:
- You are writing your original paper (use `paper_polish_conf` or `paper_polish_journal`)
- The paper was rejected and you are choosing a new venue (use `resubmission_plan`, when available)
- You have not yet received reviews

## Input Requirements

The user should provide:
1. **Reviewer comments** — one of:
   - Plain text (copy-pasted from OpenReview or email)
   - Markdown file with structured reviews
   - Path to a file containing the reviews
2. **Original paper project** — the project directory used for the submission (contains `paper/`, `code/`)
3. **Venue type** — `conference` or `journal` (affects response letter format)
4. **Rebuttal deadline** — for time-budgeting supplementary experiments
5. **(Optional) Interaction mode** — `full` (default) or `express`

## Output Structure

```
{project_name}/
└── rebuttal/
    ├── review_analysis.md            # Phase 0 — classification + priorities (Chinese)
    ├── response_draft.md             # Phase 1 — per-comment response strategies (Chinese)
    ├── additional_experiments.md     # Phase 2 — supplementary experiments (Chinese)
    ├── paper_diff.md                 # Phase 3 — paper revisions (Chinese)
    ├── response_letter.tex           # Final response letter (English)
    └── rebuttal_checklist.md         # Phase 4 — submission checklist (Chinese)
```

The original `paper/main.tex` is updated in place with revisions. A backup is saved as
`paper/main.tex.pre_rebuttal.bak`.

---

## Phase 0: Review Comment Analysis and Classification

Parse and classify every reviewer comment. This phase is the foundation — misclassification
here propagates through the entire rebuttal.

### Step 0.1: Parse Review Input

Auto-detect the input format:
- **Plain text**: Unformatted paragraphs, often with "Reviewer 1:" / "R1:" headers
- **Markdown**: Structured with headings (`##`), bullet points, code blocks
- **Mixed**: Some structure, some prose

Parse into a structured representation:
```
reviews = [
    {reviewer_id: 1, role: "general", text: "..."},
    {reviewer_id: 1, section: "Strengths", text: "..."},
    {reviewer_id: 1, section: "Weaknesses", text: "..."},
    {reviewer_id: 1, section: "Questions", comments: [
        {id: "R1Q1", text: "..."},
        {id: "R1Q2", text: "..."},
    ]},
    {reviewer_id: 2, ...},
]
```

If the format is ambiguous, ask the user to clarify reviewer boundaries.

### Step 0.2: Extract Individual Comments

Break each reviewer's feedback into discrete comments. One comment = one actionable item.

Heuristics:
- Each bullet point is a comment
- Each numbered question is a comment
- Each paragraph addressing a specific issue is a comment
- A single concern discussed across multiple sentences is one comment

Assign a unique ID to each comment: `{reviewer_id}.{comment_number}` (e.g., `R1.3` = Reviewer
1's 3rd comment).

### Step 0.3: Classify by Type

Read `references/review_classification_guide.md` for the detailed classification scheme.

**5 Types**:

| Type | Description | Response Strategy |
|---|---|---|
| **A. Technical Concern** | Reviewer identifies a flaw in the method, theory, or implementation | Acknowledge if valid; clarify if misunderstood; refute if incorrect |
| **B. Missing Experiment** | Reviewer asks for additional experiments, baselines, datasets | Run experiments if feasible; explain if infeasible |
| **C. Writing Issue** | Reviewer points out unclear writing, missing explanation, organization | Revise the relevant section, provide fixed text in response |
| **D. Misunderstanding** | Reviewer misinterpreted something you wrote | Clarify with pointer to original text; explain the intended meaning |
| **E. Subjective Opinion** | Reviewer's personal preference, not a rigorous critique | Acknowledge politely; explain your different choice |

### Step 0.4: Classify by Priority

**3 Priority Levels**:

| Priority | Definition | Handling |
|---|---|---|
| **Critical** | Directly affects accept/reject decision | Must be addressed thoroughly |
| **Important** | Strengthens the paper but not decisive | Should be addressed |
| **Minor** | Nice-to-have improvement | Addressed briefly or acknowledged |

Classification signals:
- **Critical**: Mentioned multiple times, affects main claim, prevents understanding
- **Important**: Specific concern about methodology, experiments, or clarity
- **Minor**: Typos, formatting, small terminology issues

### Step 0.5: Organize by Reviewer

Group comments by reviewer for easier response letter structure. Some comments are
**cross-reviewer** (multiple reviewers raise the same concern) — flag these as they deserve
special treatment (common concerns = high priority).

### Step 0.6: Write Review Analysis Report

Write `rebuttal/review_analysis.md` (Chinese):

```markdown
# Phase 0: 审稿意见分析报告

**提交时间**: {submission_date}
**收到审稿**: {review_date}
**Rebuttal 截止**: {deadline}
**剩余时间**: {days_remaining} 天

## 总体概况

- 审稿人数: {N}
- 总 comment 数: {M}
- Critical: {X}
- Important: {Y}
- Minor: {Z}

## 按类型分类

### A. 技术质疑 (N comments)
- [Critical] R1.2: ...
- [Important] R2.3: ...
- ...

### B. 实验缺失 (N comments)
- [Critical] R1.5: ...
- ...

### C. 写作问题 (N comments)
- ...

### D. 理解错误 (N comments)
- ...

### E. 主观偏好 (N comments)
- ...

## 跨审稿人共同关注
- {issue 1}: R1, R2 both mention
- {issue 2}: R1, R3 both mention

## 风险评估

- **Highest risk**: {main concern that could sink the paper}
- **Mitigation strategy**: {how to address}
- **Feasibility within deadline**: {Green / Yellow / Red}

## 初步策略预览

{one paragraph summary of how the rebuttal will proceed}
```

### Step 0.7: Interactive Pause (Full Mode)

Present the analysis and ask:
```
> 审稿意见解析完成:
>   - 共 {M} 条 comments，{N} 条 critical
>   - 主要风险: {top concern}
>   - 跨审稿人共同关注: {issues}
>
> 分类和优先级正确吗？需要调整吗？
>   (A) 全部正确，继续到 Phase 1
>   (B) 调整某些 comment 的分类或优先级
>   (C) 细化某些 comment 的解读
```

Express mode: skip pause, proceed to Phase 1 automatically.

---

## Phase 1: Per-Comment Response Strategy

For each comment, decide the response strategy and draft the English response. Read
`references/response_templates.md` for the 4 strategies and their opening templates.

### Step 1.1: Strategy Selection

For each comment, choose one of 4 strategies:

| Strategy | When to Use |
|---|---|
| **Accept** | Reviewer's concern is valid; acknowledge and commit to fixing |
| **Refute** | Reviewer's claim is incorrect; politely explain why with evidence |
| **Supplement** | Additional experiments or analysis needed (triggers Phase 2) |
| **Clarify** | Reviewer misunderstood; point to original text and re-explain |

**Hybrid strategies** are common:
- Accept + Supplement: "You're right; we'll add the requested experiment"
- Clarify + Refute: "We believe there's a misunderstanding; here's what we actually claim"
- Accept + Refute: "Part of your concern is valid (we accept X); however, Y is a misinterpretation (we refute)"

### Step 1.2: Draft Response Text

For each comment, draft an English response following this structure:

```
**Opening** (1 sentence):
{Template from response_templates.md based on strategy}

**Main response** (2-5 sentences):
{Address the specific concern with evidence, references to paper sections, new results, or
 explanations}

**Paper change** (if applicable):
{"We have revised Section X to clarify this point." / "We have added Table Y with additional
  results." / "We have included a new discussion of Z in the Limitations section."}

**Closing** (1 sentence, optional):
{"We thank the reviewer for raising this important point." / "We hope this clarifies the
 concern."}
```

### Step 1.3: Tone Audit

Read `references/rebuttal_tone_guide.md`. Check each response for:
- **Politeness**: "We thank the reviewer" / "We appreciate the careful reading" (but not excessive)
- **Confidence**: "We respectfully disagree" is fine; "You are wrong" is not
- **Specificity**: Point to specific lines, sections, equations
- **Defensiveness**: Avoid. Even if reviewer is wrong, explain calmly
- **Arrogance**: Avoid. Reviewer is a peer, not an adversary

### Step 1.4: Response Draft Document

Write `rebuttal/response_draft.md` (Chinese annotations for your notes + English response text):

```markdown
# Phase 1: 逐条回应草稿

## R1.1 [Type B - 实验缺失] [Priority: Critical]

**Reviewer comment**:
> "The paper lacks comparison with XYZ method which is the current state-of-the-art..."

**Strategy**: Supplement (run new experiment)

**Draft response**:
> We thank the reviewer for pointing out this important baseline. We agree that XYZ [cite]
> represents an important point of comparison. In the revised paper, we have added XYZ as a
> baseline and reran our main experiments. Table 2 in the revised paper now includes XYZ:
> our method achieves [X.X]% vs XYZ's [Y.Y]% on the primary benchmark (paired t-test, p < 0.01).
> This further strengthens our main claim that...

**Paper change**:
- Added XYZ baseline to Table 2
- Updated RQ1 discussion to compare with XYZ
- Added XYZ citation to references

**Experiment required**:
- Run XYZ on our 3 datasets (~2 GPU-days)
- Document: additional_experiments.md

---

## R1.2 [Type A - 技术质疑] [Priority: Critical]

**Reviewer comment**:
> "The theoretical analysis in Section 4 assumes independence of X and Y, which is not
> realistic..."

**Strategy**: Clarify + Refute (partial acceptance)

**Draft response**:
> We appreciate the reviewer's careful reading of our theoretical analysis. We acknowledge
> that the independence assumption is strong. However, we note that (a) this assumption is
> standard in the literature (see [cite]), and (b) our experimental results hold even when
> the assumption is violated (see new Appendix B.3). Specifically, we derived a weaker
> version of Theorem 1 under a covariance constraint, which still gives non-trivial bounds.

**Paper change**:
- Added Appendix B.3 with relaxed theorem
- Updated Section 4 to acknowledge the assumption and refer to Appendix B.3

---

[... continue for all comments ...]
```

### Step 1.5: Interactive Pause (Full Mode)

Present summary to user:
```
> 逐条回应策略:
>   - Accept: {X} comments
>   - Refute: {Y} comments
>   - Supplement: {Z} comments (triggers Phase 2)
>   - Clarify: {W} comments
>
> Critical comments 回应:
>   R1.1: Supplement - add XYZ baseline
>   R1.2: Clarify + Refute - explain assumption + add relaxed theorem
>   ...
>
> 审批策略？
>   (A) 全部通过
>   (B) 修改某些回应
>   (C) 重新考虑某些 strategy
```

Express mode: skip pause, write draft, proceed to Phase 2.

---

## Phase 2: Additional Experiment Design and Time Budgeting

For every "Supplement" strategy from Phase 1, design the experiment and fit it into the
rebuttal window.

### Step 2.1: List Required Experiments

Collect all experiments needed:
- From Phase 1 Supplement comments
- Plus any experiments needed for Refute strategies (need evidence)

For each experiment, document:
- **Purpose**: Which comment it addresses
- **What to run**: Specific method, dataset, metric
- **Expected time**: Hours or GPU-days
- **Expected outcome**: What result would satisfy the reviewer
- **Priority**: Critical / Important / Nice-to-have

### Step 2.2: Resource Allocation

Given 1x A100 80GB and the rebuttal deadline:
- Total available compute: (deadline_days - 1) × 24 hours × 0.8 utilization = X GPU-hours
- Minus: time for running existing baselines, writing, buffering = Y GPU-hours
- Net available for new experiments: (X - Y) GPU-hours

### Step 2.3: Prioritization

Greedy allocation:
1. Start with all Critical Supplement experiments
2. If budget remains, add Important Supplement experiments
3. If more budget remains, add Nice-to-have
4. Stop when budget exhausted

For experiments that don't fit:
- Document that they are infeasible within the rebuttal window
- Propose a smaller version (e.g., "due to time constraints, we report results on 1 dataset")
- Acknowledge in the response letter

### Step 2.4: Time Schedule

Create a day-by-day schedule:
```
Day 1 (today): Experiment design, kickoff
Day 2-3: Run XYZ baseline on 3 datasets
Day 4: Run ablation variant requested by R2
Day 5: Analyze results, update paper
Day 6: Write response letter
Day 7 (buffer): Final review, submission
```

### Step 2.5: Additional Experiments Document

Write `rebuttal/additional_experiments.md` (Chinese):

```markdown
# Phase 2: 补充实验设计

**Rebuttal 截止**: {deadline}
**可用计算时间**: {X} GPU-hours
**实验总需求**: {Y} GPU-hours
**可行性**: Feasible / Tight / Infeasible

## 实验清单（按优先级）

### Critical 实验（必须做）

#### Exp 1: [Name]
- **对应 comment**: R1.1 (XYZ baseline missing)
- **描述**: Run XYZ on Tabula Sapiens, PBMC, Pancreas
- **命令**: `python baselines/run_xyz.py --dataset {D}`
- **预计时间**: 6 GPU-hours (2 hours/dataset × 3 datasets)
- **预期结果**: XYZ 应达到约 [X.X]%，我们的方法应保持领先
- **失败应对**: 如果 XYZ 超过我们，需要调整 narrative 为"互补优势"

#### Exp 2: ...

### Important 实验（应该做）

#### Exp 3: ...

### Nice-to-have 实验（时间允许）

#### Exp 4: ...

### 无法完成的实验

#### Exp N: [Name]
- **对应 comment**: R3.5
- **原因**: 需要 2 周的预训练，远超 rebuttal 窗口
- **替代方案**: 在 response letter 中解释限制，提供在小规模数据上的证据

## 时间表

| 天 | 活动 | 预计 GPU 小时 |
|---|---|:---:|
| Day 1 | 实验启动 + 脚本准备 | 2 |
| Day 2 | Exp 1 (dataset 1) | 2 |
| Day 3 | Exp 1 (datasets 2-3) + Exp 2 | 5 |
| Day 4 | Exp 3 | 4 |
| Day 5 | 结果分析 + paper 更新 | 0 |
| Day 6 | Response letter 撰写 | 0 |
| Day 7 | Buffer + 最终审查 + 提交 | 0 |

## 风险与应急预案

1. 如果 Exp 1 显示 XYZ 超过我们 → ...
2. 如果 Exp 2 OOM → ...
3. 如果某数据集下载失败 → ...
```

### Step 2.6: Interactive Pause (MANDATORY, even in Express mode)

This pause is critical because experiments have real time cost. Present to user:
```
> 补充实验计划:
>
> Critical 实验 ({X} 个):
>   - Exp 1: XYZ baseline ({time})
>   - Exp 2: ... ({time})
>
> Important 实验 ({Y} 个):
>   - Exp 3: ... ({time})
>
> 无法完成 ({Z} 个):
>   - Exp N: (原因: ...)
>
> 总时间需求: {X} GPU-hours / {Y} GPU-hours 可用
> 可行性评级: Feasible / Tight / Infeasible
>
> 决策:
>   (A) 按此计划执行
>   (B) 调整优先级 (跳过某些)
>   (C) 扩展时间（推迟其他任务）
>   (D) 如果 Infeasible，重新评估 response letter 的 refute/clarify 策略
```

The user MUST confirm the experiment plan before proceeding to Phase 3. Do not guess the
user's time priorities.

---

## Phase 3: Paper Revision

Based on the response strategies and (future) experiment results, revise the paper.

### Step 3.1: Revision Types

Categorize the revisions needed:
- **Additive**: Add new tables, figures, sections, paragraphs
- **Rewrite**: Rewrite unclear sections
- **Clarify**: Add explanations for misunderstood parts
- **Strengthen**: Add more evidence for challenged claims

### Step 3.2: Backup Original

Before any edits, backup:
```
cp paper/main.tex paper/main.tex.pre_rebuttal.bak
```

### Step 3.3: Apply Revisions

For each response strategy:
- If **Accept/Supplement**: Add new content (tables, sections, paragraphs)
- If **Refute**: Strengthen the original argument or add counter-evidence
- If **Clarify**: Rewrite for clarity at the specific location
- If **Clarify (no change)**: No paper change; clarification only in response letter

### Step 3.4: Experiment Results Integration

For Supplement strategies where experiments are newly run:
- Wait for experiment results (or run via `code/analysis/`)
- Update tables and figures in the paper with new data
- Reference the new results in the response letter

**Important**: The skill should not assume experiments have been run. If results are not yet
available, it should:
- Mark placeholder sections (`[RESULTS PENDING - will update after experiments]`)
- Track TODO list for the user
- Re-invoke after experiments complete

### Step 3.5: Revision Marking

Journal R&R submissions often require tracked changes or a "marked up" version:
- Generate a diff view: `diff paper/main.tex.pre_rebuttal.bak paper/main.tex`
- Or use LaTeX `changes` package for tracked changes
- Or generate a `paper/main.tex.marked` with highlighted changes

Conferences typically don't require tracked changes but the skill can generate them for user
reference.

### Step 3.6: Paper Diff Report

Write `rebuttal/paper_diff.md` (Chinese):

```markdown
# Phase 3: 论文修订报告

## 修订摘要

- 新增章节: {N}
- 重写章节: {M}
- 增加表格: {X}
- 增加图表: {Y}
- 字数变化: +{Z} words

## 按 comment 的修订

### R1.1 (XYZ baseline missing)
- **修订类型**: Additive
- **位置**: Table 2 (rows added), Section 5.2 (paragraph added)
- **变更摘要**: Added XYZ to main results table; discussion in RQ1
- **新内容预览**:
  > "Additionally, we compare with XYZ [cite], a recent state-of-the-art method. As shown in
  > Table 2, our method outperforms XYZ by ..."

### R1.2 (Theoretical assumption)
- **修订类型**: Additive
- **位置**: Appendix B.3 (new subsection), Section 4.2 (clarification)
- **变更摘要**: Added relaxed theorem with weaker independence assumption
- ...

[... continue for all revisions ...]

## 未修订的 comment

这些 comment 只在 response letter 中回应，不修订论文:
- R2.3 (minor typo — fixed silently)
- R3.1 (misunderstanding — clarified only in response)
```

---

## Phase 4: Submission Preparation

Finalize the rebuttal package and check for submission readiness.

### Step 4.1: Response Letter Compilation

Assemble the final English response letter from Phase 1 drafts. Format by venue:

**Conference format**:
```
Response to Reviewers

We thank all reviewers for their constructive feedback. Below we address each concern
point-by-point.

# Reviewer 1

**R1.1**: [original comment excerpt]

[Our response]

**R1.2**: [original comment excerpt]

[Our response]

...

# Reviewer 2

...
```

**Journal format (letter-style)**:
```
Dear Dr. [Editor],

We thank you and the reviewers for the constructive feedback on our manuscript. We have
revised the paper substantially in response to the reviewers' comments. Below we provide
point-by-point responses to each concern, with references to the revised manuscript.

[Reviewer 1 responses]

[Reviewer 2 responses]

...

We hope these revisions address the reviewers' concerns. We look forward to your decision.

Sincerely,
[Author]
```

Read `references/venue_response_formats.md` for detailed format differences.

### Step 4.2: Final Response Letter File

Write `rebuttal/response_letter.tex`:
- LaTeX format for professional look
- Match venue conventions (conference vs journal)
- Include all responses from Phase 1
- Cross-reference paper changes (e.g., "(see revised Section 5.2)")

### Step 4.3: Submission Checklist

Write `rebuttal/rebuttal_checklist.md` (Chinese):

```markdown
# Phase 4: Rebuttal 提交前检查

## 内容完整性
- [ ] 所有 critical comment 已回应
- [ ] 所有 important comment 已回应
- [ ] Minor comment 已回应或已确认可忽略
- [ ] 所有补充实验已完成（或明确标注未能完成的原因）
- [ ] 论文已根据 response 更新
- [ ] 论文 diff 与 response letter 一致

## 格式合规

### 会议 rebuttal
- [ ] Response letter 字数在限制内（通常 1000-2000 词）
- [ ] Points-by-point 格式
- [ ] 没有超出允许的新图表数量
- [ ] 保持匿名（double-blind）

### 期刊 R&R
- [ ] Response letter 为 letter 格式
- [ ] 引用 reviewer 编号
- [ ] 修订版论文有 tracked changes 或 marked-up 版本
- [ ] Cover letter 更新（提到已响应 reviewer 意见）

## 语气检查
- [ ] 礼貌但不卑微
- [ ] 有信心但不傲慢
- [ ] 没有对 reviewer 的人身攻击
- [ ] 没有情绪化表达

## 数据一致性
- [ ] Response letter 中的数字与论文一致
- [ ] 新增的 baseline 在 Table 2 和正文中一致
- [ ] 新增的实验在 response letter 和 paper 中都有描述

## 最终判决
- **总体就绪度**: Ready / Needs minor fix / Needs significant work
- **剩余工作时间**: {hours}
- **风险评估**: {green/yellow/red}

## 提交前最后一步
- [ ] 在 OpenReview / 期刊系统上上传 response letter
- [ ] 上传修订版 PDF
- [ ] 上传修订版 supplementary (如果有)
- [ ] 确认提交按钮
```

### Step 4.4: Interactive Pause (Full Mode)

Present the final package to user:
```
> Rebuttal 包已就绪:
>
> 文件清单:
>   - rebuttal/review_analysis.md
>   - rebuttal/response_draft.md
>   - rebuttal/additional_experiments.md
>   - rebuttal/paper_diff.md
>   - rebuttal/response_letter.tex  ← Final
>   - rebuttal/rebuttal_checklist.md
>   - paper/main.tex (已修订)
>
> 检查项:
>   ✓/✗ 所有 critical 已回应
>   ✓/✗ 补充实验已完成
>   ✓/✗ 论文与 response 一致
>   ✓/✗ 语气恰当
>
> 剩余时间: {days}
> 总体就绪度: Ready / Minor fix / Significant work
>
> 审批提交？
```

Express mode: auto-finalize all documents, present summary without pause.

---

## Interaction Modes

### Full Interactive Mode (Default)

Pauses at:
- Phase 0 Step 0.7 — Classification approval (after comment analysis)
- Phase 1 Step 1.5 — Response strategy approval (after drafting responses)
- Phase 2 Step 2.6 — Experiment plan approval (MANDATORY, never skipped)
- Phase 4 Step 4.4 — Final rebuttal package review

### Express Mode

Pauses only at:
- Phase 2 Step 2.6 — Experiment plan approval (MANDATORY, never skipped)

All other phases run automatically. User reviews the final package before submission.

To invoke express mode: pass `--express` flag or say "express mode" / "快速模式" when starting.

---

## Important Notes

- **Phase 2 always pauses**. Even in express mode, experiment decisions require user input. The
  skill never auto-commits compute resources.
- **Tone matters**. Rebuttals can easily come across as defensive or arrogant. Read
  `references/rebuttal_tone_guide.md` carefully. A well-toned "refute" beats a harsh "accept".
- **Time is the scarcest resource**. Rebuttal windows are short (7-14 days for conferences).
  Allocate time wisely, buffer for unexpected issues.
- **Critical comments need thorough response**. Do not skimp on the most important concerns.
- **Cross-reviewer concerns**. If multiple reviewers raise the same issue, address it
  prominently (even in the opening of the response letter).
- **Misclassification of type A vs D is dangerous**. A genuine technical flaw classified as
  "misunderstanding" will sink the paper. A misunderstanding classified as "technical concern"
  will make you overhaul a working method unnecessarily.
- **Never argue with reviewer tone**. If a reviewer is harsh, respond calmly to the content,
  ignore the tone.
- **Paper revisions must match response letter claims**. If you claim "we have added Table 3",
  Table 3 must actually be in the paper. Inconsistencies are caught by reviewers and editors.
- **Symlinked references**: This skill has no external symlinks; all references are local.
  Review materials are skill-specific and not shared with other skills.
- **Input format**: Plain text or Markdown only. PDF parsing not implemented. Users should
  copy-paste review text from OpenReview or journal submission systems.
