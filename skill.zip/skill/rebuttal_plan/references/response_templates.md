# Response Templates (Phase 1)

Templates and patterns for drafting English responses to reviewer comments. Used in Phase 1 of
`rebuttal_plan/SKILL.md`.

## The 4 Response Strategies

### Strategy 1: Accept

Use when the reviewer's concern is valid and you agree with it.

**Opening templates**:
- "We thank the reviewer for this important observation. We agree that..."
- "The reviewer raises a valid point. We have [action taken] to address this."
- "We appreciate this feedback and have revised the paper to..."
- "This is an excellent suggestion that strengthens the paper. We have..."

**Structure**:
1. Thank + acknowledge
2. Describe what you changed
3. Reference the specific paper location
4. (Optional) Explain how the change improves the paper

**Example**:

> We thank the reviewer for raising this important concern about the theoretical justification.
> We agree that the independence assumption was insufficiently motivated in the original
> submission. In the revised paper, we have added Appendix B.3, which provides a derivation
> under a relaxed assumption (bounded covariance rather than independence). This derivation
> yields similar guarantees, and we have updated Section 4.2 to reference this extended
> analysis.

### Strategy 2: Refute

Use when the reviewer's claim is factually incorrect.

**Opening templates**:
- "We respectfully disagree with this characterization. As shown in..."
- "We believe there may be a misunderstanding here. Specifically..."
- "While we appreciate the reviewer's careful reading, we would like to clarify that..."
- "We would like to point out that..."

**Structure**:
1. Polite disagreement (no "you're wrong")
2. Evidence for your position (reference specific sections, equations, results)
3. (Optional) Additional support for your claim
4. Closing that acknowledges the reviewer's perspective

**Example**:

> We respectfully disagree with the characterization that our method "cannot scale to large
> datasets". As shown in Table 5 (Efficiency Analysis), our method achieves 3x throughput on
> the Tabula Sapiens dataset (500K cells) compared to the strongest baseline, with memory
> usage well within the 80GB limit. We have clarified this in Section 5.3 and added a
> dedicated scalability subsection with wall-clock time measurements across dataset sizes
> from 10K to 500K cells.

**Critical**: Always provide evidence. Refuting without evidence comes across as dismissive.

### Strategy 3: Supplement

Use when additional experiments or analyses are needed.

**Opening templates**:
- "We thank the reviewer for this valuable suggestion. In the revised paper, we have added..."
- "This is an important point. We have conducted additional experiments to address it."
- "The reviewer is right that [X] would strengthen the paper. We have added..."
- "In response to this suggestion, we have run additional experiments..."

**Structure**:
1. Thank + acknowledge value
2. Describe the experiment run
3. Report the result with specific numbers
4. Explain how the result affects the main claim
5. Point to the paper section where results are integrated

**Example**:

> We thank the reviewer for pointing out the missing comparison with XYZ [Author et al., 2024].
> We agree this is an important baseline. In the revised paper, we have added XYZ to our main
> comparison. Specifically, we trained XYZ on all three datasets using the authors' published
> code and default hyperparameters. The results are now included in Table 2: XYZ achieves
> 71.2 ± 1.3% F1 on Tabula Sapiens, 68.5 ± 1.1% on Pancreas, and 74.3 ± 0.9% on Lung, while
> our method achieves 83.4, 79.2, and 82.1% respectively. This comparison further supports our
> main claim that incorporating GRN structure improves rare cell type annotation (p < 0.001,
> paired t-test on all three datasets).

**Critical**: Be specific with numbers and statistical tests. Vague additions ("we ran more
experiments") are unconvincing.

### Strategy 4: Clarify

Use when the reviewer misunderstood something, and the issue is (or can be) addressed in the
paper.

**Opening templates**:
- "We apologize for the unclear presentation. To clarify..."
- "We appreciate the reviewer's careful reading and would like to clarify that..."
- "We thank the reviewer for this question. In the paper, we address this in..."
- "We understand the concern. To clarify our claim..."

**Structure**:
1. Polite acknowledgment (never "as we clearly stated")
2. Point to the specific paper location
3. Re-explain the original content in different words
4. (Optional) Commit to improving the clarity in revision

**Example**:

> We apologize for the unclear presentation and would like to clarify that our method does
> handle batch effects. As described in Section 3.2 (and now expanded in the revised version),
> we apply batch normalization at the embedding level using the Harmony [Korsunsky et al., 2019]
> approach before feeding representations to the classifier. This is shown schematically in
> Figure 2c. The main results in Table 2 are already computed with batch effect correction,
> and we have added an ablation in the revised paper (new Table 6) showing the effect of this
> preprocessing step.

**Critical**: Never scold the reviewer for missing something. Assume the fault is in your
writing.

## Hybrid Strategies

### Accept + Supplement

When the reviewer is right and new experiments are needed to fix it.

**Template**:
> We thank the reviewer for this important observation. We agree that [concern], and we have
> addressed it by [new experiment/analysis]. Specifically, [result]. This strengthens the
> paper by [impact].

### Clarify + Refute

When the reviewer misunderstands AND their concern is also invalid.

**Template**:
> We appreciate this careful reading. There may be a misunderstanding here: what we claim in
> Section X is [original claim], not [reviewer's interpretation]. Additionally, even under the
> reviewer's interpretation, [counter-evidence].

### Accept + Refute (Partial)

When the reviewer raises multiple points, some valid, some not.

**Template**:
> We appreciate the reviewer's thorough analysis. We agree with [point A] and have revised
> [action]. However, we respectfully disagree with [point B], because [evidence]. We have
> added [clarification] to address any remaining concerns.

## Tone Patterns

### Politeness (without groveling)

**Use**:
- "We thank the reviewer for..."
- "We appreciate this feedback..."
- "This is an important observation..."
- "We respectfully disagree..."

**Avoid**:
- Excessive "we deeply apologize" (once is enough)
- "The reviewer is absolutely correct" (too fawning)
- Capitalization for emphasis ("CRITICAL point")

### Confidence (without arrogance)

**Use**:
- "As shown in Table X..."
- "Our results demonstrate..."
- "The evidence supports..."
- "We stand by our claim that..."

**Avoid**:
- "Clearly..." / "Obviously..."
- "The reviewer is wrong..."
- "This is a trivial point..."
- Dismissive language

### Specificity (always)

**Use**:
- "In Section 4.2 (line 234)..."
- "Equation 3 shows..."
- "Table 2 row 5 reports..."
- "(p < 0.001, paired t-test, n = 5 seeds)"

**Avoid**:
- "As discussed in the paper..."
- "We clearly showed..."
- "It is trivial to see..."

## Per-Comment Response Template

```markdown
### {Comment ID}

**Original comment**:
> "{verbatim quote or summary}"

**Type**: A/B/C/D/E
**Priority**: Critical/Important/Minor
**Strategy**: Accept / Refute / Supplement / Clarify / Hybrid

**Draft response**:

{Opening following strategy template}

{Main response: address specifically with evidence}

{Paper change, if any: "We have revised/added [specific change] in [specific location]."}

{Closing, optional: "We hope this clarifies / addresses the reviewer's concern."}

**Paper changes triggered**:
- [ ] {Change 1}
- [ ] {Change 2}

**Experiments triggered** (if Supplement):
- [ ] {Experiment 1}
- [ ] {Experiment 2}
```

## Length Guidelines

Per comment response length by priority:

- **Critical**: 100-200 words per response (detailed, thorough)
- **Important**: 50-100 words per response
- **Minor**: 20-50 words per response

Total response letter length:
- **Conference**: 2-4 pages (rebuttal word limits vary: NeurIPS 5000 chars, ICML ~1 page per reviewer)
- **Journal**: 5-15 pages for major revision (no strict limit)

## Common Mistakes to Avoid

1. **Dismissing criticism**: "This is not a valid concern because..." — sounds arrogant
2. **Over-apologizing**: "We sincerely apologize for the many flaws..." — sounds unconfident
3. **Vague promises**: "We will address this in the final version..." — not convincing
4. **Hand-waving**: "It is straightforward to show..." without showing
5. **Ignoring tone**: Responding harshly to a harsh reviewer
6. **Contradicting yourself**: Accepting on one point, refuting the opposite elsewhere
7. **Inconsistency with paper**: Claiming changes that aren't actually in the revised paper
8. **Ignoring requests**: Not addressing a critical concern
9. **Telephone game**: Response claims different numbers from what's in the paper
10. **Bad typos in response**: Undermines confidence in the paper's rigor

## Response Letter Assembly

Combine individual responses into a full response letter using the venue format from
`references/venue_response_formats.md`.
