# Review Classification Guide (Phase 0)

Guide for classifying reviewer comments by type and priority. Used in Phase 0 of
`rebuttal_plan/SKILL.md`.

## The 5 Types

### Type A: Technical Concern

The reviewer identifies a claimed flaw in your method, theory, implementation, or experimental
design. These are the most serious and require careful handling.

**Examples**:
- "The convergence proof relies on assumption X which is not realistic"
- "The loss function is not consistent because..."
- "The architecture has a bottleneck that prevents..."
- "The claimed invariance property does not hold because..."
- "Your method is equivalent to [existing method] under renaming"

**How to recognize**:
- Specific reference to a technical component (equation, theorem, architecture)
- Claim that the technique is flawed, not just suboptimal
- Reviewer provides reasoning for why it's flawed

**Response strategy options**:
1. **Accept** (valid concern): Acknowledge, explain the impact, revise the paper
2. **Clarify** (the reviewer misread): Point to specific text, re-explain
3. **Refute** (the claim is wrong): Provide evidence, counter-example, or derivation
4. **Partial acceptance**: Acknowledge some validity, defend the rest

**Critical factors**:
- Does the claim affect the main result? (If yes: critical priority)
- Is the flaw fixable or fundamental?
- Would fixing it change the headline claim?

**Common pitfalls**:
- Dismissing a valid technical concern (reviewers remember and re-raise)
- Over-explaining an invalid concern (signals defensiveness)
- Refuting without evidence (comes across as hand-waving)

---

### Type B: Missing Experiment

The reviewer requests additional experiments, baselines, datasets, or analyses.

**Examples**:
- "You should compare with [X method] which is the current SOTA"
- "The paper would be stronger with a sensitivity analysis on [hyperparameter]"
- "Please report results on [additional dataset]"
- "An ablation on [component] would clarify its contribution"
- "What about larger models / smaller models / different tasks?"

**How to recognize**:
- Reviewer uses words like "should", "need to", "missing", "add"
- Specific mention of an experiment, baseline, or dataset
- Request can be satisfied by running something

**Response strategy**:
- **Supplement** (run the experiment if feasible)
- **Refute** (explain why this experiment is unnecessary or misleading — rare)
- **Accept + Acknowledge limitation** (commit to running in a future version, if truly infeasible)

**Critical factors**:
- Feasibility within rebuttal window (time + compute)
- Whether the experiment likely confirms or challenges your method
- Relevance to the main claim

**Common pitfalls**:
- Running too many experiments and not having time to write up results
- Skipping a critical baseline that multiple reviewers requested
- Claiming "infeasible" when it's actually just inconvenient
- Running only easy experiments and ignoring the hard-but-important ones

---

### Type C: Writing Issue

The reviewer points out unclear writing, missing explanation, organization issues, or
terminology problems.

**Examples**:
- "Section 3 is hard to follow — please add more explanation"
- "The notation is inconsistent between Sections 2 and 4"
- "Figure 2 is cluttered and hard to read"
- "The relation to [prior work] should be explained more clearly"
- "The abstract doesn't mention X"

**How to recognize**:
- Reviewer mentions clarity, readability, organization
- Suggests rewording or reorganization
- May not disagree with the content, just the presentation

**Response strategy**:
- **Accept + Revise** (rewrite the section)
- **Clarify + Accept** (explain intent, then still revise for clarity)

**Critical factors**:
- Usually "important" priority, not "critical"
- Easy to fix — low cost, high goodwill
- Accumulation matters: 5 writing comments suggest the paper is generally unclear

**Common pitfalls**:
- Dismissing writing comments ("we'll fix this in the final version")
- Not actually revising after promising to
- Ignoring notation / consistency issues

---

### Type D: Misunderstanding

The reviewer misinterpreted what you wrote. The paper already addresses the concern, but
unclearly.

**Examples**:
- Reviewer: "You don't compare with X"
- Reality: Comparison is in Table 3, but reviewer didn't see it

- Reviewer: "The method doesn't scale"
- Reality: Complexity analysis is in Section 4, but buried

- Reviewer: "You claim universal applicability, but..."
- Reality: Paper claims a narrower applicability but reviewer misread

**How to recognize**:
- Reviewer's concern is factually addressed in the paper
- You can point to a specific section/equation/table that refutes the concern
- The misunderstanding is usually a writing issue that caused the reviewer to miss something

**Response strategy**:
- **Clarify** (point to the relevant section, re-explain briefly)
- **Clarify + Revise** (also improve the original text to prevent future misunderstanding)

**Critical factors**:
- Never accuse the reviewer of not reading carefully
- Use respectful language: "We apologize for the unclear presentation" or "To clarify..."
- If multiple reviewers misunderstand the same thing, it's a writing issue on your end

**Common pitfalls**:
- Defensive "as we clearly stated on page 3..." (comes across as hostile)
- Not revising the original text (same misunderstanding will happen with new reviewers)
- Classifying as Type A (technical concern) when it's actually Type D — leads to unnecessary work

---

### Type E: Subjective Opinion

The reviewer expresses a personal preference or stylistic opinion that isn't backed by
rigorous analysis.

**Examples**:
- "I would have preferred a different approach"
- "The paper would be more interesting if it focused on X instead of Y"
- "I don't find this topic exciting"
- "The presentation style is not my preference"

**How to recognize**:
- Subjective language ("I think", "I would prefer", "it seems to me")
- No specific technical or experimental basis
- Often contradicts another reviewer's opinion (good sign of subjectivity)

**Response strategy**:
- **Acknowledge politely** (don't dismiss)
- **Explain your choice** (why you made the decision you did)
- **Don't overhaul the paper** for subjective opinions

**Critical factors**:
- Usually "minor" priority
- Hardest to address because there's nothing factual to refute
- Goodwill gesture: acknowledge the alternative perspective

**Common pitfalls**:
- Taking subjective opinions too seriously and rewriting the paper
- Being defensive or combative
- Ignoring (can hurt the meta-reviewer's impression)

---

## Classification Decision Tree

```
Does the comment mention a specific technical component (equation, theorem, architecture)?
├─ YES → Does it claim the component is flawed?
│        ├─ YES → Type A (Technical Concern)
│        └─ NO  → Type C (Writing Issue) or Type D (Misunderstanding)
└─ NO  → Does the comment request an experiment or analysis?
         ├─ YES → Type B (Missing Experiment)
         └─ NO  → Is the concern factually addressed in the paper?
                  ├─ YES → Type D (Misunderstanding)
                  └─ NO  → Is the concern subjective?
                           ├─ YES → Type E (Subjective Opinion)
                           └─ NO  → Type C (Writing Issue)
```

## The 3 Priorities

### Critical

**Definition**: The comment directly affects the accept/reject decision. If not addressed, the
paper will likely be rejected.

**Signals**:
- Multiple reviewers raise the same concern
- The comment questions the main claim
- The reviewer uses strong language ("fatal", "unclear how the paper stands without")
- The comment identifies an experimental gap that makes the claim unverifiable
- A meta-reviewer (AC/SC) raised the concern

**Examples**:
- "The main baseline is missing" (can't validate without it)
- "The theorem proof has an error" (undermines the theoretical contribution)
- "The main experiment has a confound" (can't trust the result)

### Important

**Definition**: The comment strengthens the paper but the paper can still be accepted without
full resolution.

**Signals**:
- One reviewer raises the concern
- The comment is specific but not fatal
- A reasonable fix or clarification satisfies the concern

**Examples**:
- "Could you add a sensitivity analysis on hyperparameter X?"
- "The related work section is missing paper Y"
- "Section 3 could be more clearly written"

### Minor

**Definition**: Nice-to-have improvements; addressing them adds polish but doesn't change the
paper's standing.

**Signals**:
- Typos, formatting, small terminology
- Stylistic preferences
- Optional additional analyses
- Acknowledgments, citations

**Examples**:
- "There's a typo on page 5"
- "Figure 3 would look better with larger fonts"
- "Cite additional reference for context"

## Priority Inference from Tone

**Critical signals** (strong words):
- "fatal", "serious", "major", "fundamental"
- "cannot be accepted", "must be addressed"
- "I have significant concerns"
- Strong negative language

**Important signals**:
- "I recommend", "the paper would benefit", "please consider"
- Specific but moderate concerns
- Neutral or mildly negative tone

**Minor signals**:
- "small point", "nit", "typo"
- "while reading, I noticed..."
- Parenthetical comments
- Positive tone with minor suggestions

## Cross-Reviewer Pattern Detection

Flag these patterns:
- **Same concern from 2+ reviewers**: Upgrade to at least Important, likely Critical
- **Contradictory comments between reviewers**: Neither is critical (reviewers disagree)
- **Concern repeated by meta-reviewer (AC/SC)**: Always critical
- **Unanimous concern**: Critical + high-urgency

## Classification Report Template

```markdown
## Comment {R}.{N}

**Type**: A / B / C / D / E (with rationale)
**Priority**: Critical / Important / Minor (with rationale)
**Cross-reviewer**: Yes (also raised by R2.X) / No
**Raw text**:
> {quoted comment}

**Why this type**:
{1-2 sentences}

**Why this priority**:
{1-2 sentences}

**Initial response direction**:
{Accept / Refute / Supplement / Clarify, with preview}
```
