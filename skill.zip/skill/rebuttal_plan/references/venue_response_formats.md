# Venue Response Formats

Different venues have different conventions for rebuttal / response letters. This guide
defines the format, length, and submission requirements for each target venue. Used by
Phase 4 of `rebuttal_plan/SKILL.md`.

## Conference vs Journal

The fundamental distinction:

| Aspect | Conference | Journal |
|---|---|---|
| **Time window** | 7-14 days (strict) | 2-3 months (flexible) |
| **Response scope** | Focused on specific reviewer questions | Comprehensive, full paper revision |
| **Format** | Points-by-points | Letter-style + points-by-points |
| **Length** | Short (strict limits) | Long (no strict limits) |
| **Revision of paper** | Minor edits allowed (varies by venue) | Full revision expected |
| **Multiple rounds** | Single rebuttal round | Often multiple R&R rounds |
| **Acceptance criteria** | "Rebuttal useful for decision" | "Addresses reviewer concerns" |

## Conference Format: Points-by-Points

### Structure

```
Response to Reviewers

We thank all reviewers for their constructive feedback. Below we address each
concern point-by-point.

# Reviewer 1

**Summary of strengths** (as mentioned by reviewer):
- {if included in review, acknowledge}

**Response to concerns**:

**R1.C1** [{Reviewer's quote or summary, 1-2 lines}]

{Your response, 50-150 words}

**R1.C2** [{Reviewer's quote or summary}]

{Your response}

...

# Reviewer 2

...

# Reviewer 3

...
```

### NeurIPS Specifics

- **Length limit**: 5000 characters per reviewer (strict, enforced by OpenReview)
- **Format**: Plain text or Markdown (OpenReview formatting)
- **New experiments**: Can be discussed, new results should be briefly summarized
- **Paper revision**: Minor edits to the submitted PDF are allowed; large changes discouraged
- **Tone**: Professional, direct
- **Submission**: Post via OpenReview "Reply" to each reviewer, or as a general rebuttal

### ICML Specifics

- **Length limit**: Typically 1 page per reviewer, but varies by year (check call for papers)
- **Format**: PDF uploaded to OpenReview
- **New experiments**: Summarized, not detailed
- **Paper revision**: Usually not allowed during rebuttal (except for corrections)
- **Tone**: Professional, technical
- **Submission**: Upload single PDF to OpenReview

### ICLR Specifics

- **Length limit**: Flexible (OpenReview threads)
- **Format**: Discussion thread with reviewers (iterative dialogue)
- **New experiments**: Can be added throughout the discussion period
- **Paper revision**: Revisions allowed and encouraged during the discussion
- **Tone**: Conversational but professional (this is an open-review venue)
- **Submission**: Post replies in OpenReview discussion thread

### AAAI Specifics

- **Length limit**: 2 pages (strict)
- **Format**: PDF via the author response system
- **New experiments**: Can discuss, not always submit
- **Paper revision**: Not allowed until camera-ready
- **Tone**: Formal, concise

### IJCAI Specifics

- **Length limit**: Similar to AAAI (check call for papers)
- **Format**: PDF via IJCAI submission system
- **New experiments**: Discussed
- **Paper revision**: Not allowed until camera-ready

## Journal Format: Letter-Style + Points-by-Points

### Structure

```
Dear Dr. [Editor Name],

We thank you and the reviewers for the thoughtful feedback on our manuscript
[title]. We have carefully considered each comment and have substantially
revised the paper in response. Below, we provide a point-by-point response
to each reviewer's concerns, with references to the revised manuscript.

Summary of major changes:
1. [Change 1, e.g., "Added XYZ baseline to main comparisons"]
2. [Change 2, e.g., "Revised theoretical analysis under relaxed assumption"]
3. [Change 3, e.g., "Added biological validation on Tabula Sapiens"]

# Response to Reviewer 1

We thank Reviewer 1 for the detailed feedback. Below, we address each concern.

## R1.1 {Comment summary}

**Reviewer's comment**:
> {verbatim quote, indented}

**Response**:
{100-300 words including:
- Acknowledgment or clarification
- What was done
- Where in the revised paper
- Specific numbers or section references}

**Revision in manuscript**: Section X (lines Y-Z), new Table W.

## R1.2 {Comment summary}

...

# Response to Reviewer 2

...

# Response to Reviewer 3

...

# Additional Changes

In addition to responding to the reviewers' comments, we have made the
following additional improvements:
- {Improvement 1}
- {Improvement 2}

We hope the revised manuscript addresses the reviewers' concerns. We look
forward to your decision.

Sincerely,
[Corresponding Author]
[Institution]
[Email]
```

### Journal-Specific Variations

**Nature family (Nature, Nature Methods, Nature Communications, etc.)**:
- Length: 5-20 pages (no strict limit, but editors prefer concise)
- Format: Single PDF file, uploaded as supplementary material
- Revisions: Tracked changes in main manuscript expected
- Additional experiments: Expected for major revisions
- Cover letter: Updated to mention the revision

**Science family (Science, Science Advances, etc.)**:
- Length: Similar to Nature, perhaps more concise
- Format: PDF with tracked changes in main manuscript
- Cover letter: Updated for the revision

**Cell family (Cell, Cell Systems, Cell Reports, etc.)**:
- Length: Comprehensive (10-25 pages common)
- Format: Detailed response with embedded figures showing new results
- Tracked changes required in main manuscript

**PLOS family (PLOS Computational Biology, etc.)**:
- Length: Flexible
- Format: Plain text or PDF
- Tracked changes expected

**Bioinformatics / Briefings in Bioinformatics**:
- Length: Moderate
- Format: Word or PDF
- Tracked changes expected in main manuscript

## Response Letter Template (LaTeX)

Save as `rebuttal/response_letter.tex`:

```latex
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{times}
\usepackage{xcolor}
\usepackage{hyperref}

% Reviewer comment style
\newenvironment{rcomment}{%
    \begin{quote}\itshape
}{%
    \end{quote}
}

% Response style
\newcommand{\response}[1]{\textbf{Response:} #1\par\medskip}

\title{Response to Reviewers\\
       \large Manuscript: \emph{[Title]}}
\author{}
\date{}

\begin{document}

\maketitle

We thank all reviewers for their constructive feedback. Below, we address
each concern point-by-point.

\section*{Summary of Changes}

\begin{itemize}
    \item [Major change 1]
    \item [Major change 2]
    \item [Major change 3]
\end{itemize}

\section*{Reviewer 1}

\subsection*{R1.1: [Comment topic]}

\begin{rcomment}
[Verbatim quote from reviewer]
\end{rcomment}

\response{
[Your response, 100-300 words.]
[Include: acknowledgment, specific action, paper location reference.]
}

\subsection*{R1.2: [Comment topic]}

\begin{rcomment}
[Verbatim quote]
\end{rcomment}

\response{
[Response]
}

% ... more comments ...

\section*{Reviewer 2}

% ... similar structure ...

\section*{Reviewer 3}

% ... similar structure ...

\end{document}
```

## Length Budgeting

### Conference

- 3 reviewers × 5-10 comments = 15-30 total responses
- NeurIPS: 5000 chars per reviewer ≈ 900 words per reviewer ≈ 90-180 words per comment
- ICML: ~1 page per reviewer ≈ 400 words per reviewer ≈ 40-80 words per comment
- AAAI: 2 pages total ≈ 1000 words ≈ 30-70 words per comment

### Journal

- 3-4 reviewers × 10-20 comments = 30-80 total responses
- No strict limit, but keep each response focused
- Critical comments: 200-400 words
- Important comments: 100-200 words
- Minor comments: 30-100 words

## Cross-Venue Similarities

Regardless of venue, every response letter should:
1. Thank the reviewers
2. Summarize major changes
3. Address every comment (none can be skipped)
4. Provide specific evidence
5. Reference paper sections for revisions
6. Maintain professional tone
7. Be error-free (typos undermine credibility)

## Special Sections

### "Common Concerns" Section (Optional)

For concerns raised by multiple reviewers, some authors include a dedicated section at the
start of the rebuttal:

```
# Common Concerns

Several reviewers (R1, R2) raised concerns about [X]. We address this collectively here:
[Comprehensive response]

Individual reviewer responses below reference this section.
```

This saves space and avoids repetition.

### "Additional Experiments" Section

Some authors list all new experiments at the start:

```
# Summary of Additional Experiments

In response to reviewer feedback, we ran the following new experiments:
1. [Experiment 1] — addresses R1.3, R2.1
2. [Experiment 2] — addresses R1.5
3. [Experiment 3] — addresses R3.2

Results are integrated into the revised paper (Sections X, Y, Z) and discussed in the
per-comment responses below.
```

## Submission Checklist by Venue

### Conference Rebuttal Submission

- [ ] Response letter fits within character/page limit
- [ ] Each reviewer is addressed
- [ ] Summary of changes at the top (if allowed)
- [ ] Formatted correctly (plain text, Markdown, or PDF)
- [ ] Posted via the correct system (OpenReview, CMT, etc.)
- [ ] Submitted before the deadline

### Journal R&R Submission

- [ ] Response letter (PDF)
- [ ] Revised manuscript (with tracked changes)
- [ ] Clean version of revised manuscript
- [ ] Updated cover letter
- [ ] All figures updated
- [ ] Supplementary materials updated
- [ ] Revised response to previous reviewers (if not first round)
- [ ] All uploaded via journal submission system
- [ ] Cover letter notes this is a revised submission

## Tone Reminders

Regardless of venue:
- Thank the reviewers (even harsh ones)
- Be specific (numbers, sections, equations)
- Be concise (length is not a virtue)
- Be confident (not groveling)
- Be polite (never attack)
- Read `rebuttal_tone_guide.md` for detailed tone guidance
