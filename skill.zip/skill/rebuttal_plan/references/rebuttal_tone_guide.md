# Rebuttal Tone Guide

The tone of a rebuttal matters as much as its content. A correct but poorly-toned response can
lose a paper; a well-toned response can recover from a difficult review. This guide defines
the principles and provides examples. Used by all Phases of `rebuttal_plan/SKILL.md`.

## Core Principles

### 1. Treat reviewers as peers, not adversaries

Reviewers are (usually) other researchers who are volunteering their time. They are your
future collaborators, co-authors, and PhD committee members. Even when they are wrong, they
deserve respect.

**Wrong mental model**: "I need to defeat this reviewer's objections."
**Right mental model**: "I need to help this reviewer understand my contribution."

### 2. Polite but confident

**Politeness** signals respect and goodwill. **Confidence** signals belief in your work.
Either alone is insufficient.

- Only polite: sounds weak, reviewer may push harder
- Only confident: sounds arrogant, reviewer will push back out of spite
- Both: reviewer is likely to give you benefit of the doubt

### 3. Acknowledge valid concerns genuinely

If a reviewer raises a valid issue, acknowledge it without hedging. Reviewers can tell when
you're reluctantly admitting something vs. genuinely accepting feedback.

**Grudging**: "While we partly agree..."
**Genuine**: "We agree that this is a valid concern, and we have addressed it by..."

### 4. Disagree respectfully when necessary

Not every reviewer comment is valid. Disagreeing is acceptable, but:
- Disagree with **substance**, not the reviewer's competence
- Provide **evidence**, not just assertion
- Leave a **face-saving exit** for the reviewer (suggest a charitable interpretation)

**Bad**: "The reviewer is wrong. As anyone in the field knows..."
**Good**: "We respectfully disagree. There may be a different interpretation here. As shown
         in Section X..."

### 5. Be specific, always

Vague language suggests you don't have a good answer. Specificity builds trust.

**Vague**: "We have addressed this concern in the revision."
**Specific**: "We have added Section 4.3 (lines 234-256) and new Table 4 to address this
              concern, showing..."

## Language Register

### Formal, Academic

Rebuttals are formal documents. Use academic register:
- "We thank the reviewer" (not "Thanks for the comment")
- "We have revised Section X" (not "We rewrote Section X")
- "Our experiments demonstrate" (not "Our experiments show")
- "This suggests" (not "This proves", unless you really mean it)

### First Person Plural

Use "we" even for single-author papers (academic convention):
- ✅ "We thank the reviewer..."
- ✅ "We have added..."
- ❌ "I thank the reviewer..."
- ❌ "I added..."

### No Contractions

- ✅ "We have not..."
- ❌ "We haven't..."
- ✅ "We do not..."
- ❌ "We don't..."

## Phrases to Use

### Acknowledgment
- "We thank the reviewer for this [important/valuable/insightful] [observation/question/point]."
- "We appreciate the [careful/thorough/detailed] review and the constructive feedback."
- "We agree that..."
- "The reviewer raises a valid point..."

### Politely Disagreeing
- "We respectfully disagree with..."
- "We believe there may be a [misunderstanding/different interpretation] here."
- "While we appreciate the reviewer's perspective, we would like to clarify that..."
- "We would like to respectfully point out that..."

### Clarifying
- "To clarify..."
- "We apologize for the unclear presentation..."
- "We realize our original phrasing was ambiguous..."
- "What we intended to convey is..."

### Introducing New Content
- "In the revised paper, we have..."
- "We have added..."
- "We have revised Section X to..."
- "The revised paper now includes..."

### Pointing to Evidence
- "As shown in Table X..."
- "Section Y describes..."
- "Equation Z gives..."
- "Figure W illustrates..."
- "(p < 0.001, paired t-test, n = 5 seeds)"

### Closing a Response
- "We hope this [clarifies/addresses] the reviewer's concern."
- "We believe these [revisions/additions] strengthen the paper."
- "We thank the reviewer for raising this important issue."
- "We welcome further discussion on this point."

## Phrases to Avoid

### Dismissive
- "This is a trivial point..."
- "As anyone in the field knows..."
- "Clearly..."
- "Obviously..."
- "It goes without saying..."

### Aggressive
- "The reviewer is wrong..."
- "The reviewer did not read carefully..."
- "The reviewer seems to misunderstand fundamental concepts..."
- "The reviewer's criticism is unfounded..."

### Groveling
- "We sincerely apologize for the many flaws..."
- "The reviewer's insight has revolutionized our understanding..."
- "We are deeply grateful beyond words..."
- "We humbly acknowledge..."

### Vague
- "We have addressed this concern." (how?)
- "The paper is clearer now." (where?)
- "This is discussed in the paper." (section?)

### Overclaiming
- "We definitively prove..."
- "Our method solves..."
- "This is the first..."
- "We achieve perfect..."

### AI-ish
- "Leverages", "utilizes", "delve into", "dive deep"
- "Seamlessly", "robustly", "substantially"
- "In conclusion,", "In summary,"
- Em-dash chains

## Situational Tone

### When the reviewer is hostile

Some reviewers are harsh or dismissive. Do NOT match their tone. Respond calmly:

**Reviewer**: "This paper is a rehash of well-known techniques with no novelty."

**Bad response** (matching hostile tone):
> "The reviewer's characterization is completely incorrect. Our work is clearly novel..."

**Good response** (calm, evidence-based):
> "We appreciate the reviewer's feedback. We believe the paper's novelty lies in [specific
> technical contribution, with evidence]. Specifically, Section 3.2 introduces [X], which,
> to our knowledge, has not been proposed before. Table 2 shows that this contribution leads
> to [Y.Y]% improvement over methods that do not use [X]. We have revised the Introduction
> to make this contribution clearer."

### When the reviewer praises your paper

Some reviewers are positive but still have minor concerns. Don't get overconfident:

**Reviewer**: "This is an excellent paper with strong results. However, I would like to see..."

**Bad response** (celebrating):
> "We thank the reviewer for the positive assessment of our work!"

**Good response** (maintaining focus):
> "We thank the reviewer for the feedback. To address the [specific concern], we have..."

### When multiple reviewers raise the same concern

This is a critical signal. Address it prominently:

**Template**:
> Several reviewers (R1, R2) raised concerns about [X]. We take this cross-reviewer concern
> seriously and have addressed it in the revised paper by [specific action]. Specifically,
> [details]. We believe this revision [strengthens/clarifies] the paper's main contribution.

### When the reviewer's concern requires a major change

Don't be defensive. Acknowledge and address:

**Template**:
> The reviewer's concern about [X] is fundamental to our work. We have taken this seriously
> and reworked [section/experiment] in the revised paper. Specifically, [detailed description
> of changes]. We believe this rework [does / does not] change the main conclusion, and we
> have updated [Introduction/Discussion] accordingly.

### When you genuinely cannot address a concern

Some concerns cannot be fully addressed within the rebuttal window. Honesty is the best
policy:

**Template**:
> We agree that [concern] would strengthen the paper. Unfortunately, [running the full
> experiment / providing the theoretical analysis] is not feasible within the rebuttal
> window. However, we have [partial solution]. We will address this fully in a future
> extension of this work, and we have acknowledged this as a limitation in the revised
> Discussion section.

Don't pretend to address a concern you haven't.

## Per-Strategy Tone Guide

### Tone for Accept

- Genuine appreciation
- Concrete action described
- Not too much thanking (once per response is enough)

### Tone for Refute

- Respectful disagreement
- Evidence-based
- Leave face-saving exit
- Never aggressive

### Tone for Supplement

- Grateful for the suggestion
- Specific about what was run
- Numbers first, narrative second

### Tone for Clarify

- Apologetic for unclear writing
- Never accusatory ("as we clearly stated")
- Commit to improving the original text

## Read-Aloud Test

Before finalizing, read each response aloud (or imagine doing so):
- Does it sound respectful?
- Does it sound confident?
- Is it specific?
- Is it concise?
- Would you be comfortable if the reviewer saw your internal Slack messages about them?

If any answer is "no", revise.

## Cultural Considerations

Academic tone conventions vary slightly by region:

- **US/UK**: Direct but polite. Expected to disagree openly when warranted.
- **Germany/Europe**: More formal, more hedged.
- **East Asia**: More deferential, but overly deferential rebuttals are seen as weak.

Default to US/UK academic tone unless you know the target venue prefers otherwise.

## Final Checklist

Before submitting the response letter:

- [ ] Every response opens with thanks or acknowledgment
- [ ] Every response is specific (no "we addressed this")
- [ ] No dismissive language ("trivial", "obvious")
- [ ] No aggressive language ("wrong", "misunderstands")
- [ ] No groveling ("deeply apologize")
- [ ] No contractions
- [ ] No AI-ish phrases
- [ ] Numbers where claimed
- [ ] Specific paper section references
- [ ] Length appropriate to concern priority
- [ ] Read-aloud test passes
- [ ] No typos or grammar errors
