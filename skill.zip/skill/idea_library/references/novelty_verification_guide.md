# Novelty Verification Guide

Methodology for verifying whether a research idea is novel. Used by Phase 1 of
`idea_library/SKILL.md`.

## Why Verification Matters

**Most "new" ideas are rediscoveries.** The AI/bioinformatics literature grows by ~300 papers
per week on arXiv alone. Every intuitive idea has probably been at least attempted. Before
investing weeks or months of development, spend 30 minutes verifying novelty.

**The cost asymmetry**:
- **Cost of verification**: 30 minutes
- **Cost of not verifying**: Months of work on a done idea, then discovering a reference, then
  having to reframe or abandon the project

This is one of the highest-ROI activities in research.

## The 3-Layer Verification

### Layer 1: Internal Library (5 minutes)

Check your own accumulated knowledge first. You may have already encountered this idea and
forgotten.

**Search targets**:
- `~/idea_library/ideas/` — Active ideas
- `~/idea_library/retired/` — Ideas you've already dismissed
- `~/idea_library/clusters/` — Thematic groupings
- `~/paper_library/papers/` — Papers you've read with idea-trigger notes
- `~/paper_library/insights/` — Cross-paper syntheses

**Search methods**:
- Keyword grep across all files
- Topic tag matching
- Title similarity (fuzzy)
- Trigger source match (same paper that sparked this idea)

**Possible findings**:
- **Exact match**: You already had this idea. What happened? Why is it here again?
- **Partial match**: A related idea exists. Is this an evolution or duplicate?
- **Tangential match**: Related papers or insights but no direct idea. Use as context.

**Action**:
- Exact match → classify as redundant or evolution (user decides)
- Partial match → link the two, consider if they should merge
- No match → proceed to Layer 2

### Layer 2: Paper Library (10 minutes)

Check the papers you've read for implementations of this idea.

**Search targets**:
- `~/paper_library/papers/*.md` — Paper notes with keywords
- `~/paper_library/topics/*.md` — Topic-organized papers
- `~/paper_library/insights/*.md` — Synthesis notes

**Search methods**:
- Keyword search in paper note content (your notes reflect what you understood, so this is
  more reliable than searching paper PDFs)
- Topic tag matches
- Connection graph traversal (papers connected to the most recent paper you read that
  triggered this idea)

**Possible findings**:
- **Direct implementation**: Some paper has already done this. Classify as redundant.
- **Related but different**: Papers address the same problem differently. Note the
  differentiation.
- **Background / foundation**: Papers that your idea builds on but doesn't duplicate.
- **No match**: Proceed to Layer 3

**Action**:
- Direct implementation → move idea to retired with link to the paper
- Related but different → document what makes your idea different
- No match → proceed to Layer 3

### Layer 3: Web Search (15 minutes)

Check the broader literature via WebSearch.

**Query patterns**:

**Pattern 1: Direct keyword search**
```
{main keywords} 2024 2025 2026
```
Finds recent papers matching the core terms.

**Pattern 2: Venue-specific**
```
{main keywords} NeurIPS ICML ICLR 2024 2025 accepted
{main keywords} Nature Methods 2024 2025
{main keywords} arXiv bioinformatics 2024 2025
```
Finds papers at top venues where this would likely be published.

**Pattern 3: Technical term search**
```
"{specific technical phrase}" filetype:pdf
```
Finds papers that use the exact technical terminology. Use quotes for exact match.

**Pattern 4: Prior art search**
```
{main keywords} survey review 2024 2025
```
Finds surveys, which are fastest way to learn what's been tried.

**Pattern 5: Author + topic**
```
{known expert name} {topic} 2024 2025
```
Find if a leading expert has worked on this.

**Evaluate the hits**:
For each top-5 hit, quickly assess (~1 min each):
1. Title match: Does the title describe my idea?
2. Abstract match: Does the abstract confirm the hit does what I'm proposing?
3. Method match: Does their method overlap with mine?
4. Claim match: Are the claims the same as what I'd claim?

**Possible findings**:
- **Already done, exactly**: Redundant. Move idea to retired.
- **Already done, differently**: Differentiated. Document the differentiation.
- **Partial overlap**: Consider refining the idea to focus on non-overlap.
- **Not found**: Probable novelty. Proceed.

**Action**:
- Found direct implementation → retired
- Found differentiated work → document differentiation
- Found no direct match → classify as novel

## The 4 Verdicts

### Verdict 1: Novel

**Criteria**: No prior work found in any layer.

**Interpretation**: This idea is genuinely new. Proceed with confidence.

**Action**:
- Mark as novel in the idea file
- Note the specific queries you ran (for future reference)
- Proceed to Phase 2 (scoring)

### Verdict 2: Differentiated

**Criteria**: Prior work exists that is related but has a meaningful difference. You can
articulate the differentiation in 1-2 sentences.

**Interpretation**: The idea is new in its specific form, but context exists. You will need
to clearly cite and differentiate in any future paper.

**Examples of valid differentiation**:
- **New domain**: "X has been done for NLP; we apply it to bio"
- **New mechanism**: "Y uses dense attention; we use sparse attention for the same goal"
- **New setting**: "Z was done in supervised setting; we do it in self-supervised"
- **New guarantee**: "W has empirical results; we add theoretical analysis"
- **New scale**: "V was done on 10K samples; we scale to 10M"

**Examples of NOT valid differentiation** (red flags):
- "Our architecture is slightly different" (how? why does it matter?)
- "We use a different dataset" (trivial; not a contribution)
- "We use a different loss function" (unless the loss fundamentally changes the result)
- "Our writing is better" (not a research contribution)

**Action**:
- Document the differentiation in the idea file
- Link to the prior work papers
- Proceed to Phase 2, noting the differentiation in the T/B scoring

### Verdict 3: Overlapping

**Criteria**: Prior work addresses part of what you were thinking, but there's a clear
un-addressed portion.

**Interpretation**: Refine the idea to focus on the un-addressed portion.

**Examples**:
- Your idea: "GRN-guided attention for cell type annotation"
- Found: "GRN-guided attention for cell embedding (not classification)"
- Refinement: Focus specifically on how GRN guidance helps classification, not embedding

**Action**:
- Rewrite the idea's core description to focus on the un-addressed portion
- Link to the partial-overlap work
- Re-run Layer 3 with refined keywords if needed
- Proceed to Phase 2 with the refined idea

### Verdict 4: Redundant

**Criteria**: Prior work has already implemented this idea, and your differentiation is
superficial or absent.

**Interpretation**: The idea is not publishable as-is. Move to retired/.

**Action**:
- Move the idea file to `~/idea_library/retired/`
- Document the prior work and why you consider it redundant
- Consider: can you spot an insight that the retired idea suggests? Save that as a new idea.
- Do NOT feel bad. Retirement is healthy triage.

## Search Term Generation

### From Core Idea to Search Terms

The quality of your novelty search depends on how well you translate the idea into search
terms. This is an art.

**Good search terms**:
- Specific technical phrases ("sparse attention", "GRN-guided")
- Domain-specific terminology ("single-cell RNA-seq", "cell type annotation")
- Novel terms that match your idea's essence

**Bad search terms**:
- Generic words ("deep learning", "method", "novel", "approach")
- Over-specific phrases ("our proposed sparse attention mechanism")
- Made-up acronyms you invented

### Progressive Query Refinement

Start broad, narrow down:

1. **Query 1**: Broad keywords
   - Example: `sparse attention single-cell transformer`
   - Goal: See the landscape

2. **Query 2**: Specific technical combination
   - Example: `GRN-guided attention scRNA-seq`
   - Goal: Find closest matches

3. **Query 3**: Exact phrase search
   - Example: `"GRN guided attention"`
   - Goal: Find papers using exact terminology

4. **Query 4**: Domain-specific venue
   - Example: `Nature Methods GRN attention 2024 2025`
   - Goal: Check if a top venue has published on this

5. **Query 5**: Negative keyword check
   - Example: `attention cell typing -transformer` (find non-transformer approaches)
   - Goal: Ensure you're not missing approaches that use different naming

## Red Flags (Signs to Dig Deeper)

If you encounter any of these, don't stop until you resolve them:

1. **"I feel like I've seen this before"**: Trust the feeling. Search harder.
2. **Many close-but-not-exact hits**: Suggests the idea is in the zeitgeist; someone has
   probably done it.
3. **Survey from 2024+ on the topic**: Surveys organize the field; if your idea isn't in one
   of them, double-check whether you missed a related sub-area.
4. **Idea came from a paper you just read**: High risk — the paper may have already done it,
   or the paper's authors may have already planned it as follow-up.
5. **Idea is "obvious in hindsight"**: If it's obvious, others probably thought of it too.
   Search extra carefully.

## Verification Report Template

Write as part of the idea file:

```markdown
## 新颖性评估 (Novelty Assessment)

**执行日期**: {YYYY-MM-DD}
**总耗时**: {X} 分钟

### Layer 1: Internal Library
- 搜索位置: {list}
- 搜索关键词: {keywords}
- 发现: {none | list of related ideas}

### Layer 2: Paper Library
- 搜索位置: `~/paper_library/`
- 搜索关键词: {keywords}
- 发现: {none | list of related papers}

### Layer 3: Web Search
- Query 1: `{query}` → {results summary}
- Query 2: `{query}` → {results summary}
- Query 3: `{query}` → {results summary}
- Query 4: `{query}` → {results summary}
- Query 5: `{query}` → {results summary}

### 判决: {Novel | Differentiated | Overlapping | Redundant}

### Differentiation (if applicable)
{1-2 sentences explaining what makes this idea different from the closest prior work}

### 最接近的 prior work
1. {paper 1 — how it relates}
2. {paper 2 — how it relates}
3. {paper 3 — how it relates}

### 风险
- {Risk 1: e.g., "Concurrent work at NeurIPS 2026"}
- {Risk 2: e.g., "This approach has been tried in a different domain"}
```

## When to Re-Verify

Ideas decay. An idea that was novel when you captured it may not be novel 6 months later.
Re-verify when:

- Starting to execute the idea (most important)
- New papers in the area get published
- A major conference or journal publishes many papers in the area
- You've been thinking about it for >6 months

Re-verification is quick (most is already documented). Only re-run Layer 3 with updated date
filters.

## Collaborator Verification

If possible, ask a domain expert:
- "Has anyone done X to Y?"
- "Is this idea well-known in your community?"
- "Whose work should I be citing?"

Experts often know about relevant work that doesn't surface in keyword searches. This is
especially valuable for cross-domain ideas (AI → bio) where the AI side might not know the
bio literature well.
