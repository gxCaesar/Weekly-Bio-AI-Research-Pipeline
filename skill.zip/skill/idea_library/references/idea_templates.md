# Idea Templates

Structured templates for idea files, cluster files, and index files. Used by Phase 2 of
`idea_library/SKILL.md`.

## Full Idea File Template

Used for ideas that complete Phase 0-2 (full interactive). Save as
`~/idea_library/ideas/{YYYY-MM-DD}_{slug}.md`.

```markdown
---
title: "{Short title, <60 chars}"
slug: "{slug_with_underscores}"
type: "method | application | theory | benchmark | observation"
status: "active | sleeping | executing | retired"
created: "{YYYY-MM-DD}"
last_updated: "{YYYY-MM-DD}"
domain: [{domain_tag_1}, {domain_tag_2}]
scores:
  theoretical: {T, 1-5}
  biological: {B, 1-5}
  feasibility: {F, 1-5}
  trend: {Tr, 1-5}
portfolio_category: "PEAK | TT | BB | TB | IGNO"
novelty_verdict: "novel | differentiated | overlapping | redundant"
triggered_by:
  type: "paper | meeting | self | prior_idea"
  reference: "{paper_id or idea_id or description}"
related_papers: [{paper_1}, {paper_2}]
related_ideas: [{idea_1}, {idea_2}]
target_venues: [{venue_1}, {venue_2}]
---

# {Title}

## 核心想法 (Core Idea)

{1-3 paragraphs describing the idea in full. Use plain language; assume you're explaining to
yourself in 6 months.}

## 背景与动机 (Background and Motivation)

### 触发来源
{What made you think of this?}

### 解决的问题
{What specific problem or question does this address?}

### 为什么现在相关
{Why is this timely?}

## 技术 sketch (Technical Sketch)

### 核心技术
{If method: architecture, algorithm, or key insight}
{If application: what gets applied to what}
{If theory: what would be proved or characterized}
{If benchmark: what data or evaluation protocol}
{If observation: what phenomenon would be investigated}

### 预期架构 (if method idea)
```
[Input] → [Stage 1] → [Stage 2] → [Output]
```
{Brief description of each stage}

### 关键公式 (if theoretical)
{Mathematical formulation — just sketch, not rigorous}

## 新颖性评估 (Novelty Assessment)

**判决**: {novel | differentiated | overlapping | redundant}
**评估日期**: {YYYY-MM-DD}

### Layer 1: Internal Library
- 发现: {none | brief list}

### Layer 2: Paper Library
- 发现: {none | brief list}

### Layer 3: Web Search
- Key queries run: {list}
- Found similar work: {list with URLs}

### Differentiation (if not "novel")
{What makes this different from closest prior work?}

## 评分 (Scoring)

### 理论深度 (T): {score}/5
**理由**: {1-2 sentences}

### 生物意义 (B): {score}/5
**理由**: {1-2 sentences}

### 可行性 (F): {score}/5
**理由**: {1 sentence, includes compute/data/time considerations}

### 热点对齐 (Tr): {score}/5
**理由**: {1 sentence on how trendy the topic is}

### Portfolio 定位
**Quadrant**: {PEAK | TT | BB | TB | IGNO}

## 预期结果 (Expected Outcomes)

### 技术结果
{What would success look like technically? Expected numbers, if any.}

### 生物学发现
{What biological insight would this enable?}

### 影响
{Who would use this? What would change?}

## 候选 Venue (Candidate Venues)

### 主要候选
- **{Venue 1}**: {why this fits}
- **{Venue 2}**: {why this fits}

### 备选
- **{Venue 3}**: {why it's a backup}

## 可行性细节 (Feasibility Details)

### 硬件
- **最小配置**: {e.g., 1x A100 80GB}
- **估计显存**: {e.g., 45GB peak}
- **估计训练时间**: {e.g., 2 weeks on 1x A100}

### 数据
- **必需数据集**: {list}
- **数据可用性**: {all public / partially public / requires collection}

### 前置工作
- **已有工具**: {list of open-source tools you'd build on}
- **需要自建**: {list of things you'd have to build}

### 时间估计
- **从开始到可报告结果**: {weeks/months}
- **从可报告结果到可发表**: {weeks/months}

## 相关工作 (Related Work)

### 核心相关论文 (from paper_library)
- [[{paper_1}]] — {relationship: extends | contrasts | complements | inspired_by}
- [[{paper_2}]] — {relationship}
- [[{paper_3}]] — {relationship}

### 核心相关想法 (from idea_library)
- [[{idea_1}]] — {relationship}
- [[{idea_2}]] — {relationship}

### 所属 cluster
- [[clusters/{cluster_name}]]

## 下一步 (Next Steps)

### Immediate (this week)
- [ ] {Concrete action 1}
- [ ] {Concrete action 2}

### Short-term (this month)
- [ ] {Action 3}
- [ ] {Action 4}

### If green-lit for execution
- [ ] Pass to research_copilot with --from-idea-library flag
- [ ] Write formal proposal
- [ ] Begin coding

## 风险 (Risks)

1. **{Risk 1}**: {description and mitigation}
2. **{Risk 2}**: {description and mitigation}
3. **{Risk 3}**: {description and mitigation}

## 更新日志 (Update Log)

- **{YYYY-MM-DD}**: 创建 (initial scores: T={T}, B={B}, F={F}, Tr={Tr})
- **{YYYY-MM-DD}**: {update description}
```

## Quick Intake Template (Express Mode)

Used for Express mode intake — fast capture with minimal fields. Post-process later.

```markdown
---
title: "{Short title}"
slug: "{slug}"
type: "method | application | theory | benchmark | observation"
status: "active"
created: "{YYYY-MM-DD}"
last_updated: "{YYYY-MM-DD}"
domain: [{domain}]
scores:
  theoretical: null
  biological: null
  feasibility: null
  trend: null
novelty_verdict: "pending"
triggered_by:
  type: "{type}"
  reference: "{ref}"
notes: "Quick intake — needs review and full scoring."
---

# {Title}

## 核心想法
{1-2 paragraphs, raw text from intake}

## 触发来源
{What sparked this?}

## 初步 sketch
{Any rough technical notes}

## TODO (Post-intake)
- [ ] Run Phase 1 novelty verification
- [ ] Complete Phase 2 scoring
- [ ] Link to related papers
- [ ] Add concrete next steps
```

## Cluster File Template

Used when multiple ideas form a thematic group. Save as
`~/idea_library/clusters/{cluster_slug}.md`.

```markdown
---
cluster_name: "{Cluster Name}"
created: "{YYYY-MM-DD}"
last_updated: "{YYYY-MM-DD}"
theme: "{1 sentence description of what unites these ideas}"
member_ideas: [
  {idea_1},
  {idea_2},
  {idea_3}
]
cluster_domain: [{domain_1}, {domain_2}]
---

# Cluster: {Cluster Name}

## 主题 (Theme)

{1-2 paragraphs describing what these ideas have in common and what overall direction they
point to.}

## 成员想法

### [[{idea_1}]]
- **T/B**: {T}/{B}
- **Status**: {status}
- **Key contribution**: {1 sentence}

### [[{idea_2}]]
- **T/B**: {T}/{B}
- **Status**: {status}
- **Key contribution**: {1 sentence}

### [[{idea_3}]]
- **T/B**: {T}/{B}
- **Status**: {status}
- **Key contribution**: {1 sentence}

## 共同的研究问题

{What common question do these ideas try to answer?}

## 关键洞见

{If multiple ideas converge on a realization, capture it here.}

## 可能的统一视角

{Sometimes a cluster reveals a deeper pattern. Is there a theory, framework, or new problem
formulation that would unify the cluster?}

## 推荐策略

### Option A: Execute the strongest member
{Which idea has highest T+B? Start there.}

### Option B: Synthesize into a unified project
{If the ideas are tightly coupled, can one larger project cover them all?}

### Option C: Pursue in parallel (if resources allow)
{If resources allow, pursue multiple in parallel for portfolio diversification.}

## 相关 paper_library
- [[{topic_file}]] — Related topic
- [[{insight_file}]] — Related insight

## 更新日志
- **{YYYY-MM-DD}**: Cluster created with {N} ideas
- **{YYYY-MM-DD}**: {update}
```

## Master Index Template

The main `~/idea_library/index.md` file tracks all ideas.

```markdown
# Idea Library Index

Last updated: {YYYY-MM-DD}
Total ideas: {N} (active: {X}, sleeping: {Y}, retired: {Z}, executing: {W})

## Active Ideas (sorted by T+B)

| Date | Title | T | B | F | Category | Status |
|---|---|:---:|:---:|:---:|:---:|:---:|
| {YYYY-MM-DD} | [[{idea_slug}]] | {T} | {B} | {F} | {cat} | active |
| {YYYY-MM-DD} | [[{idea_slug}]] | {T} | {B} | {F} | {cat} | active |
| ... |

## Recent Intake (last 30 days)

- **{YYYY-MM-DD}**: [[{idea}]] — T{T}B{B}, {one-line summary}
- **{YYYY-MM-DD}**: [[{idea}]] — T{T}B{B}, {one-line summary}

## Clusters

- [[clusters/cluster_1]] ({N} ideas) — {theme}
- [[clusters/cluster_2]] ({M} ideas) — {theme}

## Sleeping Ideas

Ideas not currently being developed but still considered active direction.

- [[{idea}]] — sleeping since {date}, reason: {reason}
- ...

## Executing Ideas

Ideas currently being implemented (linked to research_copilot projects).

- [[{idea}]] — started {date}, project: {project_path}
- ...

## Retired Ideas

See `~/idea_library/retired/index.md`.

## Statistics

### Score distribution
- **PEAK** (T>=4, B>=4): {N} ideas
- **TT** (T>=4, B<=2): {N} ideas
- **BB** (T<=2, B>=3): {N} ideas
- **TB** (T=3, B=3): {N} ideas
- **IGNO** (T<=2, B<=2): {N} ideas

### Domain distribution
- single-cell analysis: {N}
- drug design: {N}
- virtual cells: {N}
- gene regulatory networks: {N}
- other: {N}

### Monthly intake rate
- Last 30 days: {N}
- Last 90 days: {M}
- Average per month: {average}
```

## Retired Idea Format

When an idea is moved to `~/idea_library/retired/`, preserve it with reason:

```markdown
---
title: "{Original title}"
slug: "{slug}"
created: "{original creation date}"
retired: "{YYYY-MM-DD}"
retirement_reason: "redundant | infeasible | not_interesting | executed"
original_type: "{type}"
---

# {Title} (RETIRED)

**Retired**: {YYYY-MM-DD}
**Reason**: {specific reason}

## 原始想法
{Original core idea description}

## 退役原因

### 如果 redundant
- **Prior work**: [paper references]
- **Similarity**: {why the prior work already addresses this}

### 如果 infeasible
- **Blocker**: {what makes it infeasible}
- **Could revisit if**: {conditions under which it could become feasible}

### 如果 not_interesting
- **Reconsidered reason**: {why you no longer find it interesting}

### 如果 executed
- **Project**: {link to the project that executed it}
- **Outcome**: {what happened}
- **Paper**: {if published}

## 可能的重启条件 (if retired for redundancy or infeasibility)

{What would need to change for this idea to be revived? E.g., "if someone releases a new
dataset that would enable X".}

## 原始评分 (for reference)
- T: {T}/5
- B: {B}/5
- F: {F}/5
- Tr: {Tr}/5
```

## Intake Log Template

Chronological log of all intake sessions. Save as `~/idea_library/intake_log.md`.

```markdown
# Idea Intake Log

## {YYYY-MM} (Month)

### {YYYY-MM-DD}

**Session**: {morning brainstorm | paper reading | post-meeting | ...}
**Ideas captured**: {N}

1. [[{idea_1}]] — T{T}B{B}, from {source}
2. [[{idea_2}]] — T{T}B{B}, from {source}

**Reflection**: {optional 1-sentence note on why these came up today}

### {YYYY-MM-DD}

**Session**: {type}
**Ideas captured**: {N}

...

## Monthly Summary

### {Month Year}
- **Total ideas**: {N}
- **Novel verdict**: {X}
- **Differentiated**: {Y}
- **Overlapping**: {Z}
- **Redundant**: {W}
- **Most common source**: {source type}
- **Dominant domain**: {domain}
- **Average T/B**: {T_avg}/{B_avg}
- **Top idea**: [[{top_idea}]] — why
```

## Naming Conventions

### Idea filenames

Format: `{YYYY-MM-DD}_{slug}.md`

Examples:
- `2026-04-11_grn_sparse_attention.md`
- `2026-04-11_cell_state_theorem.md`
- `2026-04-12_drug_agent_benchmark.md`

Rules:
- Date first (enables chronological sorting)
- Slug uses underscores
- Slug 2-5 words describing the idea
- Under 50 characters

### Cluster filenames

Format: `{cluster_slug}.md`

Examples:
- `rare_cell_identification.md`
- `llm_agent_bio_workflows.md`
- `theoretical_cell_typing.md`

### Retired filenames

Same format as active ideas, just moved to `~/idea_library/retired/` directory.
