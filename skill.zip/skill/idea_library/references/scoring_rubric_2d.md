# 2D Scoring Rubric: Theoretical Depth × Biological Significance

Guide for scoring research ideas on two orthogonal dimensions. Used by Phase 2 of
`idea_library/SKILL.md`. Complements the 3D rubric in
`research_copilot/references/innovation_rubric.md` by focusing on the two dimensions most
relevant for AI/bioinformatics research.

## Why Two Dimensions?

For AI/bioinformatics research targeting top venues, two dimensions matter most:

1. **Theoretical depth (T)**: How much formal/mathematical contribution?
2. **Biological significance (B)**: How much biological impact?

A 1D "quality" score hides crucial structure. Consider:
- Idea A: T=5, B=1 (pure theoretical ML, no bio application) → ICML/NeurIPS theory track
- Idea B: T=1, B=5 (empirical bio tool, no theory) → Nature Methods
- Idea C: T=4, B=4 (balanced) → NeurIPS or Nature Methods (your choice)
- Idea D: T=2, B=2 (marginal both) → probably not publishable at top venues

These ideas all differ vastly, but a 1D score might rank them similarly. The 2D scoring
reveals the venue strategy implicit in the idea.

The 3rd dimension ("engineering impact") from `research_copilot`'s 3D rubric is important for
*execution* but less so for *idea capture*. `idea_library` focuses on theoretical and
biological because those are the dimensions that determine publishability at top venues.

## Theoretical Depth Scale (T, 1-5)

### T=1: Engineering (Pure Implementation)

**Criteria**: Applying known techniques with no formal analysis or novel formulation.

**Examples**:
- "Use scGPT with different hyperparameters on a new dataset"
- "Fine-tune BERT on cell typing"
- "Combine methods A and B in a pipeline"

**Publishability**:
- Conference workshops: possible
- Top conferences: not accepted (lacks novelty)
- Journals: possible if biological finding is strong (high B)

**Improvement path to T=2+**: Add an analysis or theoretical component.

### T=2: Incremental

**Criteria**: Small extension of existing formulation; minor mathematical variation.

**Examples**:
- "Modify attention mechanism to weight by distance to nearest marker gene"
- "Replace L2 loss with L1 for more sparsity"
- "Add regularization term for interpretability"

**Publishability**:
- Top conferences: possible if empirical results are strong
- Journals: plausible with high B

**Improvement path to T=3+**: Show why the extension matters (theoretical or empirical
characterization).

### T=3: Compositional

**Criteria**: Novel combination of known techniques with clear motivation and analysis.

**Examples**:
- "GRN-guided sparse attention: combines graph structure (from GNN literature) with sparse
  attention (from efficient transformers) for cell typing"
- "Theoretical analysis of why this specific combination works on rare cells"
- "New problem formulation: few-shot cell typing as meta-learning"

**Publishability**:
- Top conferences: yes, if well-executed
- Journals: yes, if well-motivated by biology

**Improvement path to T=4+**: Derive a formal property or theorem.

### T=4: Structural (New Formulation or Framework)

**Criteria**: New way of framing a problem; new analysis framework; new theoretical
perspective on existing methods.

**Examples**:
- "Reframe cell type annotation as a graph matching problem between cells and a GRN ontology"
- "Information-theoretic analysis of why attention captures gene regulation"
- "Generalization bound for cell typing as a function of reference atlas size"

**Publishability**:
- Top conferences: strong fit
- Journals: possible if the new framing leads to biological insight

**Improvement path to T=5**: Prove a new theorem or derive a new foundational result.

### T=5: Foundational

**Criteria**: New theorem, new bound, new fundamental perspective. Contributions that future
researchers will cite for years.

**Examples**:
- "Proof that cell type annotation is solvable with sub-logarithmic samples under a GRN
  structure assumption"
- "Characterization of when transformers provably beat specialized methods for cell typing"
- "New theoretical framework connecting GRN inference to causal discovery"

**Publishability**:
- Top theory venues: strong fit
- Conferences: excellent
- Journals: possible if paired with strong empirical work

**Caveat**: Very few ideas are actually T=5. Don't inflate your scores.

## Biological Significance Scale (B, 1-5)

### B=1: Methodological (No Direct Bio Application)

**Criteria**: Pure ML paper with only nominal biological framing.

**Examples**:
- "New attention mechanism, tested on cell data (but data is interchangeable)"
- "Benchmark study of efficient transformers using scRNA-seq as a task"
- "Theoretical analysis using biological data as illustration"

**Publishability**:
- AI venues (NeurIPS/ICML/ICLR): yes if T is high
- Bio venues (Nature Methods etc.): no

**Signal**: Biology is backdrop, not substance.

### B=2: Tool (Useful Tool for Existing Questions)

**Criteria**: Builds a tool that biologists can use for existing questions; improves a
standard task.

**Examples**:
- "Better cell type annotation tool, 10% more accurate on standard benchmarks"
- "Faster implementation of existing alignment algorithm"
- "More robust version of existing integration method"

**Publishability**:
- Bio journals (Bioinformatics, PLOS CB): yes
- Top bio journals (Nature Methods): possible if improvement is large
- AI venues: possible if theoretical contribution is added

**Signal**: Useful, incremental, not field-changing.

### B=3: Application (New Approach to Recognized Bio Problem)

**Criteria**: Applies new approach to a recognized biological problem; may enable new types
of analysis.

**Examples**:
- "LLM-based automated scRNA-seq pipeline (first time)"
- "Agent architecture for drug discovery (new paradigm)"
- "Causal inference for gene regulatory networks from perturbation data"

**Publishability**:
- Top bio journals: yes
- AI venues: yes if T>=3

**Signal**: New approach, known problem, clear biological value.

### B=4: Discovery-Enabling

**Criteria**: Enables a new type of biological analysis or discovery that wasn't possible
before. Opens a research direction.

**Examples**:
- "First method to identify rare cell types at <1% abundance"
- "First method to predict protein structure from single-cell context"
- "Framework that enables in silico perturbation experiments at scale"

**Publishability**:
- Top bio journals (Nature Methods, Nature Biotechnology): strong fit
- Top AI venues: strong fit if T>=3

**Signal**: Opens doors for new science; becomes a widely-used method.

### B=5: Fundamental (Reveals New Biology)

**Criteria**: The work reveals new biological mechanisms, changes how biology is done, or
uncovers fundamental biological principles.

**Examples**:
- "Computational method that reveals a new cell type in the human immune system"
- "Method that identifies a previously unknown regulatory mechanism"
- "Tool that enables the first systematic study of a biological phenomenon"

**Publishability**:
- Nature/Science/Cell: candidate
- Top bio journals: strong fit
- AI venues: possible if T is also high

**Caveat**: Very few ideas reach B=5. Most great papers are B=4.

## Portfolio Categories

The (T, B) plane divides into meaningful regions for venue strategy:

```
                    Biological Significance (B)
                    1       2       3       4       5
                ┌───────┬───────┬───────┬───────┬───────┐
              5 │  TT   │  TT   │  TB   │  TT   │  TT   │
                │       │       │       │       │       │
                ├───────┼───────┼───────┼───────┼───────┤
              4 │  TT   │  TT   │  TB   │ ⭐PEAK │  TT   │
                │       │       │       │       │       │
  Theoretical   ├───────┼───────┼───────┼───────┼───────┤
  Depth (T)   3 │  TT   │  TB   │  TB   │  BB   │  BB   │
                │       │       │       │       │       │
                ├───────┼───────┼───────┼───────┼───────┤
              2 │ IGNO  │ IGNO  │  BB   │  BB   │  BB   │
                │       │       │       │       │       │
                ├───────┼───────┼───────┼───────┼───────┤
              1 │ IGNO  │ IGNO  │  BB   │  BB   │  BB   │
                │       │       │       │       │       │
                └───────┴───────┴───────┴───────┴───────┘

Legend:
  PEAK  = Top-tier candidate (T>=4, B>=4) — best papers come from here
  TT    = Theory-heavy (T>=4, B<=2) — ICML/NeurIPS theory track
  TB    = Balanced (T=3-4, B=3-4) — flexible venue choice
  BB    = Bio-heavy (T<=2, B>=3) — Nature Methods, Bioinformatics
  IGNO  = Low-value (T<=2, B<=2) — reconsider or retire
```

### PEAK Quadrant (T>=4, B>=4)

These are your best ideas. Strong theory AND strong biology. They:
- Fit top conferences AND top journals
- Are the foundation for seminal papers
- Require careful execution but have high upside

**Strategy**: Prioritize execution. Use `research_copilot` with conference+journal dual-track.

### TT Quadrant (T>=4, B<=2)

Theory-heavy ideas. Best suited for ML conferences (ICML/NeurIPS/COLT). The biology is
backdrop.

**Strategy**: Pitch to ML conferences with a focus on the theoretical contribution. Use
`conference_plan` targeting ICML/NeurIPS.

### BB Quadrant (T<=2, B>=3)

Bio-heavy ideas. Best suited for bio journals (Nature Methods, Bioinformatics).

**Strategy**: Pitch to bio journals with focus on the biological significance. Use
`journal_plan`.

### TB Quadrant (T=3-4, B=3-4)

Balanced ideas. Flexible venue choice.

**Strategy**: Depends on maturity and what conferences/journals are closer. Use
`research_copilot` full interactive to decide.

### IGNO Quadrant (T<=2, B<=2)

Low-value ideas. Either the theory is incremental and the biology is marginal.

**Strategy**:
- Option A: Reconsider — can you strengthen T or B? If yes, refine.
- Option B: Retire — not worth developing.
- Option C: Use as stepping stone — a T=2 B=2 idea might inspire a T=4 B=4 variant.

## Scoring Calibration

### Common Mistakes

1. **Inflation**: Everyone thinks their idea is T=4 B=4. It's usually T=3 B=3 at best.
2. **Underselling**: Underestimating biological significance because you're an ML person.
3. **Confusing novelty with depth**: A novel application (not done before) is not theoretically
   deep.
4. **Confusing difficulty with importance**: A hard idea is not the same as an important idea.
5. **Recency bias**: Over-scoring ideas sparked by recent papers.

### Calibration Exercises

**Exercise 1**: For each T score, find an example paper in your library that matches.
- T=1: ?
- T=2: ?
- T=3: ?
- T=4: ?
- T=5: ?

**Exercise 2**: For each B score, find an example paper.
- B=1: ?
- B=2: ?
- B=3: ?
- B=4: ?
- B=5: ?

**Exercise 3**: Score 3-5 of your past accepted papers on the T/B scale. How well does the
scoring predict the venue and impact?

### Sanity Checks

Before committing to a score, ask:
- **T sanity check**: "Could I write a theorem about this?" If yes → T>=4. If no → T<=3.
- **B sanity check**: "Would a biologist (not a computer scientist) care?" If strongly yes →
  B>=4. If meh → B<=2.

### External Validation

When you share the idea with a collaborator, note their reaction:
- "Interesting technically but not sure about the biology" → Your T is too high or B is too low
- "Great biology question, but where's the novelty?" → Your B is too high or T is too low
- "Both strong — let's do this" → Your scoring may be accurate

## Feasibility (F) and Trend (Tr) — Secondary Scores

Beyond T and B, two secondary scores help prioritization:

### Feasibility (F, 1-5)

How realistic is executing this idea with 1x A100 80GB?

- F=5: Can start tomorrow, all data ready, base repo exists, <1 week to first result
- F=4: Can start this week, some setup needed, <2 weeks to first result
- F=3: Can start this month, significant setup, 1-2 months to first result
- F=2: Would take a lot of groundwork (dataset collection, tool building), 3-6 months
- F=1: Infeasible on 1x A100 (needs pretraining, large compute, wet-lab, etc.)

Low F is not a dealbreaker but should be noted. Some great ideas are infeasible now but may
become feasible later.

### Trend Alignment (Tr, 1-5)

How well does this align with current hot topics?

- Tr=5: Exactly the topic everyone's working on right now
- Tr=4: Adjacent to a hot topic, bandwagon opportunity
- Tr=3: In a relevant area but not hot
- Tr=2: In a niche area
- Tr=1: Contrarian / anachronistic (possibly interesting but harder to publish)

High Tr is a double-edged sword: easier to publish, but more competition. Low Tr ideas can be
valuable if they are genuinely interesting — less competition, possibly novel, possibly lost
to history.

## Scoring Output Template

```markdown
## 评分

### 理论深度 (T): {score}/5
**理由**: {1-2 sentences explaining the T score}

Examples at this level: {1-2 example papers from your library}

### 生物意义 (B): {score}/5
**理由**: {1-2 sentences}

Examples at this level: {1-2 example papers}

### 可行性 (F): {score}/5
**理由**: {1 sentence}

### 热点对齐 (Tr): {score}/5
**理由**: {1 sentence}

### Portfolio 定位
**Quadrant**: {PEAK / TT / BB / TB / IGNO}
**推荐 venue**: {NeurIPS / Nature Methods / ICML / ...}
**理由**: {why this venue}

### Sanity checks
- 我能写一个定理吗？ Y/N → 验证 T>=4 假设
- 生物学家会关心吗？ Y/N → 验证 B>=4 假设
- 1x A100 可行吗？ Y/N → 验证 F
```

## Periodic Re-scoring

Scores can change over time:
- **T** can increase: Further thinking may reveal theoretical depth not initially obvious
- **T** can decrease: New papers may reveal that your theoretical contribution is not as new
- **B** can increase: New biological context may make the idea more significant
- **B** can decrease: New bio understanding may show the problem is already solved
- **F** can increase: New tools, datasets, or compute can make infeasible ideas feasible
- **Tr** can change rapidly as the field moves

Re-score ideas periodically (e.g., when starting execution, or every 6 months for active
ideas).
