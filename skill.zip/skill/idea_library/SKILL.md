---
name: idea_library
description: >
  Research idea accumulation and novelty verification skill for AI/bioinformatics research.
  Takes a research idea (from brainstorming, paper reading, or direct input), verifies its
  novelty via WebSearch and comparison to existing library, scores it on a 2D rubric (theoretical
  depth × biological significance), and stores it in a persistent ~/idea_library/ with rich
  metadata. Integrates with paper_reader (incoming ideas from paper reading) and research_copilot
  (outgoing ideas for project planning via --from-idea-library flag). Use for idea capture,
  novelty check, research direction planning, and long-term idea accumulation. Also triggers
  for: save idea, research idea, novelty verification, brainstorming, 想法记录, 灵感库.
---

# Idea Library Skill

Ideas are ephemeral. A good research idea at 2 AM is forgotten by noon. This skill captures
ideas the moment they occur, verifies novelty, scores them on dimensions that matter for your
research, and stores them in a persistent, searchable library that grows with you.

**Primary storage**: `~/idea_library/` (default; configurable)
**Interaction mode**: Full interactive (pauses for user validation at 2 points). Express mode available.
**Language convention**: Ideas and notes in Chinese; technical terms and paper references in English.
**Integration**: Receives ideas from `paper_reader`; provides ideas to `research_copilot --from-idea-library`.

## When to Use

Invoke this skill when:
- A new research idea occurs to you (daily brainstorming)
- You finished reading a paper that sparked an idea (handed off from `paper_reader`)
- You are preparing to start a new project and want to pick from past ideas
- You want to review which ideas have stood the test of time
- You want to check if an idea is novel (someone may have already done it)

**Do NOT** use this skill if:
- You are executing a chosen idea (use `research_copilot` / `conference_plan`)
- You are doing a literature review (use `paper_reader`)
- You are capturing a fleeting task or todo (use a todo list, not idea_library)

## Core Design Principles

1. **Over-capture, under-execute**: Save every idea, even if it seems silly. You'll evaluate
   later. The cost of capturing is low; the cost of losing a good idea is high.

2. **Novelty must be verified**: Many "new" ideas are rediscoveries. The skill runs novelty
   checks against prior work before committing to development.

3. **2D scoring, not 1D ranking**: For AI/bioinformatics research, two dimensions matter:
   - **Theoretical depth**: Formal novelty, mathematical insight, theoretical guarantee
   - **Biological significance**: Real-world biological question, impact, interpretability
   
   Some great ideas score high on one dimension and low on the other. Forcing a 1D ranking
   hides this structure.

4. **Context matters**: Ideas are shaped by what you read, what projects you're running, and
   what the field is moving toward. Each idea is linked to its context.

5. **Graveyard without shame**: Not all ideas survive scrutiny. Moving an idea to the "retired"
   section is normal, not a failure.

## Library Layout

```
~/idea_library/
├── index.md                          # Master index, all active ideas
├── ideas/                            # Individual idea files
│   ├── {date}_{slug}.md              # e.g., 2026-04-11_grn_sparse_attention.md
│   └── ...
├── clusters/                         # Thematic groupings
│   ├── rare_cell_identification.md   # Multiple ideas on a related theme
│   └── ...
├── retired/                          # Archived ideas (not novel, infeasible, or done)
│   └── ...
├── heatmap.md                        # Current 2D scoring heatmap
└── intake_log.md                     # Chronological log of idea captures
```

If `~/idea_library/` doesn't exist, Phase 0 offers to create it.

## Workflow

### Phase 0: Idea Intake

Goal: Capture the idea in full, with all relevant context.

#### Step 0.1: Input Parsing

Accepts one of:
1. **Direct text**: User types the idea description
2. **From paper_reader**: Handed off with the source paper's context
3. **From prior idea**: Evolution of an existing idea in the library
4. **From discussion/meeting**: User dictates or types from a meeting

Parse for:
- **Core idea** (1-3 sentences): What is the proposal?
- **Context**: What triggered this idea?
- **Intended domain**: AI methodology, bioinformatics application, specific disease, etc.

#### Step 0.2: Structured Intake Form

Ask the user to fill in (interactive form, with sensible defaults):

```
> 让我们捕获这个想法:
>
> 标题 (短): ________
> 类型:
>   (A) 新方法 (novel technique)
>   (B) 新应用 (novel application of existing method)
>   (C) 新理论 (theoretical analysis)
>   (D) 新基准 (benchmark or dataset)
>   (E) 新观察 (empirical observation to investigate)
>   (F) 综合/跨类型
>
> 核心想法 (1-3 段，可随时补充):
> ________
>
> 触发来源:
>   (A) 自发思考
>   (B) 阅读论文: [paper ID / title]
>   (C) 讨论/会议
>   (D) 其他想法的演化: [existing idea ID]
>
> 目标应用领域:
>   [] single-cell analysis
>   [] drug discovery
>   [] protein/molecule generation
>   [] virtual cell modeling
>   [] gene regulatory networks
>   [] spatial transcriptomics
>   [] 其他: ________
>
> 初步可行性 (gut feel, 1-5):
> 初步创新度 (gut feel, 1-5):
> 初步生物意义 (gut feel, 1-5):
```

If the idea comes from `paper_reader`, the source paper context pre-fills the trigger source
and potentially the domain.

### Phase 1: Novelty Verification

Goal: Check whether this idea has been done before.

Read `references/novelty_verification_guide.md` for the detailed methodology.
Read `references/sources_guide.md` for API endpoints, rate limits, and field mappings for
each source used in Layer 3 (external search). The same source coverage that `paper_reader`
uses for daily reading applies here for novelty verification — especially bioRxiv and PubMed,
which are frequently overlooked by CS-focused researchers.

#### Step 1.1: Internal Check (Against Your Library)

Search `~/idea_library/ideas/` and `~/idea_library/retired/` for:
- Similar titles or slugs
- Similar core ideas (by keyword overlap)
- Same trigger source (same paper)

If matches found, present them:
```
> 在你的 idea_library 中发现相似想法:
>   1. [2025-12-03] GRN attention for cell typing (retired, reason: "Ma et al. 2024 did this")
>   2. [2026-02-14] Sparse attention for rare cells (active, similarity: 40%)
>
> 新想法与已有的是:
>   (A) 独立的新想法（继续）
>   (B) 已有想法的演化（链接并升级）
>   (C) 已有想法的重复（与之前一样）
```

#### Step 1.2: Paper Library Check (Against Your Read Papers)

Search `~/paper_library/` for papers that may have implemented this idea:
- Keyword search across paper notes
- Topic tag match
- Insight note match

If matches found, present them and ask user to assess:
```
> 在你的 paper_library 中发现相关论文:
>   1. [[2024_ma_scgpt]] — GRN-aware attention (but global, not sparse)
>   2. [[2025_chen_sparse_cell]] — Sparse attention for cells (but no GRN)
>
> 这些论文是否已经实现了你的想法？
>   (A) 不，我的想法与它们不同
>   (B) 是，但我有 differentiation
>   (C) 不确定 → 继续深度检索
```

#### Step 1.3: Multi-Source Prior Work Verification

Use multiple sources to check external literature. Execute in this order (each adds coverage):

**Round 1: Semantic Scholar (cross-domain semantic search)**
```
Query: {main keywords}
API:   https://api.semanticscholar.org/graph/v1/paper/search?query={keywords}&fields=title,authors,year,venue,abstract&limit=10
```
Semantic Scholar indexes both CS papers (arXiv) and biology papers (PubMed/bioRxiv) in one
search. This is the single most comprehensive novelty check for AI/bioinformatics ideas.

**Round 2: arXiv (CS/AI/ML papers)**
- Query: `{main keywords} arXiv 2024 2025 2026` via WebSearch
- Query: `{main keywords} NeurIPS ICML ICLR 2024 2025 accepted`
- Covers: ML theory, AI methods, computational biology papers on arXiv

**Round 3: bioRxiv + PubMed (biology papers)**
- Query: `{main keywords} bioinformatics 2024 2025` via WebSearch (or bioRxiv API)
- Query: `{main keywords} Nature Methods Genome Biology 2024 2025`
- Query: PubMed E-utilities: `{technical term} AND {domain} AND {year range}`
- Covers: Biology/bioinformatics papers that may not appear on arXiv

**Round 4: OpenReview (conference papers, peer-review visibility)**
- Query: `{specific technical term} ICLR NeurIPS 2024 2025` via WebSearch or OpenReview API
- Useful for checking if an idea was submitted but rejected (still prior art)

**Round 5: Survey / systematic review check**
- Query: `{main keywords} survey review 2024 2025`
- If a survey exists, it organizes the landscape and is fastest to review

**Present all hits, ask user to review**:
```
> 多源搜索发现可能相关的论文（共 {N} 条）:
>
>   来自 Semantic Scholar:
>   1. "Sparse attention for biomolecule..." (arXiv 2024.xx) — 似乎相关
>   2. "GRN-guided transformer..." (NeurIPS 2024) — 可能重叠
>
>   来自 bioRxiv/PubMed:
>   3. "Gene-network-aware annotation..." (Nature Methods 2025) — 部分相关
>
>   来自 OpenReview:
>   4. "Attention mechanism for single-cell..." (ICLR 2024, rejected) — 方向相关
>
> 你的想法是否已被做过？
>   (A) 没有，相关但不同
>   (B) 部分重叠，但有明显差异
>   (C) 已被完全做过 → 移到 retired
```

**Focus on biology-side coverage**: For AI/bioinformatics ideas, the most common blind spot is
not checking bioRxiv and PubMed. An ML researcher may miss a Nature Methods paper that already
did exactly this. Rounds 3-4 specifically close this gap.

#### Step 1.4: Novelty Verdict

Based on the above, classify:

| Verdict | Criteria | Action |
|---|---|---|
| **Novel** | No prior work found | Proceed to scoring |
| **Differentiated** | Prior work exists, but your idea has clear differentiation | Document the differentiation, proceed |
| **Overlapping** | Prior work partially addresses this | Refine the idea to focus on what's new |
| **Redundant** | Prior work has done this | Move to retired, link to the paper |

#### Step 1.5: Document Novelty Assessment

Write the verification result into the idea note:

```markdown
## 新颖性评估 (Novelty Assessment)

**判决**: Novel / Differentiated / Overlapping / Redundant

**检索证据**:
- Internal library: {findings}
- Paper library: {findings}
- Web search: {findings}

**Differentiation** (if applicable):
{What makes this idea different from prior work?}

**Date of assessment**: {YYYY-MM-DD}
```

### Phase 2: 2D Scoring and Structured Storage

Goal: Score the idea and save it with full metadata.

Read `references/scoring_rubric_2d.md` for detailed scoring criteria.

#### Step 2.1: Theoretical Depth Score (T, 1-5)

Score on:
- **T=1 (Engineering)**: Pure implementation, no new theory
- **T=2 (Incremental)**: Small extension of existing formulation
- **T=3 (Compositional)**: New combination of known techniques with clear motivation
- **T=4 (Structural)**: New problem formulation or new analysis framework
- **T=5 (Foundational)**: New theorem, bound, or fundamentally new theoretical perspective

Ask user to self-score, and provide sanity check:
```
> 理论深度自评 (1-5): __
>
> 根据你的描述，我评估为: {skill's estimate}
>
> 理由:
>   - {reason 1}
>   - {reason 2}
>
> 是否同意？
```

#### Step 2.2: Biological Significance Score (B, 1-5)

Score on:
- **B=1 (Methodological)**: Pure ML paper, no clear bio application
- **B=2 (Tool)**: Builds a useful tool for existing bio questions
- **B=3 (Application)**: Addresses a recognized bio problem with new approach
- **B=4 (Discovery-enabling)**: Enables a new type of biological analysis or finding
- **B=5 (Fundamental)**: Reveals new biological mechanism or changes how biology is done

Ask user to self-score, and provide sanity check (same pattern as T).

#### Step 2.3: Compute Derived Metrics

From (T, B):
- **Portfolio category**: Which quadrant does this idea fall into?
  - **High-T High-B (4+, 4+)**: "Top-tier candidate" — potential Nature Methods / NeurIPS strong paper
  - **High-T Low-B (4+, 1-2)**: "Theory-heavy" — best for ML conferences (ICML/NeurIPS)
  - **Low-T High-B (1-2, 4+)**: "Bio-heavy" — best for bio journals (Nature Methods)
  - **Low-T Low-B (1-2, 1-2)**: "Low-value" — reconsider or retire

- **Feasibility score** (F, 1-5): How realistic is this with 1x A100?
- **Trend alignment** (Tr, 1-5): How well does this align with current hot topics?

#### Step 2.4: Save Idea File

Write `~/idea_library/ideas/{YYYY-MM-DD}_{slug}.md`:

```markdown
---
title: "{short title}"
slug: "{slug}"
type: "method | application | theory | benchmark | observation"
status: "active | sleeping | executing | retired"
created: "{YYYY-MM-DD}"
last_updated: "{YYYY-MM-DD}"
domain: [{domain1}, {domain2}]
scores:
  theoretical: {1-5}
  biological: {1-5}
  feasibility: {1-5}
  trend: {1-5}
novelty_verdict: "novel | differentiated | overlapping | redundant"
triggered_by: "paper: [[{paper_ref}]] | meeting | self | idea: [[{prior_idea}]]"
---

# {Title}

## 核心想法
{1-3 paragraphs describing the idea.}

## 背景与动机
{Why did this idea occur? What problem does it address?}

## 技术 sketch
{If it's a method idea: rough architecture, algorithm, or analysis.}
{If it's an application: what gets applied to what.}
{If it's a theoretical idea: what would be proved.}

## 与相关工作的差异
{Based on Phase 1 novelty check.}

## 预期结果
{What would success look like? Expected numbers, findings, implications.}

## 可行性评估
- **硬件**: {feasibility with 1x A100?}
- **数据**: {are datasets available?}
- **时间**: {how long to execute?}
- **前置依赖**: {other ideas or tools needed first?}

## 评分

### 理论深度 (T): {score}/5
{Rationale: why this T score.}

### 生物意义 (B): {score}/5
{Rationale: why this B score.}

### 可行性 (F): {score}/5
### 热点对齐 (Tr): {score}/5

**Portfolio category**: {Top-tier / Theory-heavy / Bio-heavy / Low-value}

## 候选 venue
- **主要**: {NeurIPS / Nature Methods / ...}
- **备选**: {other venues}
- **理由**: {why these venues}

## 相关论文 (from paper_library)
- [[{paper_1}]] — {relationship}
- [[{paper_2}]] — {relationship}

## 相关想法 (from idea_library)
- [[{idea_1}]] — {relationship}
- [[{idea_2}]] — {relationship}

## 下一步
- [ ] {Concrete next step 1}
- [ ] {Concrete next step 2}
- [ ] {Concrete next step 3}

## 更新日志
- **{YYYY-MM-DD}**: 创建
- **{YYYY-MM-DD}**: {update}
```

#### Step 2.5: Update Index and Heatmap

Append to `~/idea_library/index.md`:

```markdown
- **{YYYY-MM-DD}** ⭐T{T}B{B} [{title}](ideas/{file}.md) — {one-line summary}
```

Update `~/idea_library/heatmap.md` — a 2D visualization of ideas on the T/B plane:

```
Biological ─→
         1    2    3    4    5
    ┌────┬────┬────┬────┬────┐
  5 │    │    │    │ ●  │    │  T=5
    ├────┼────┼────┼────┼────┤
  4 │    │ ●  │    │ ●● │ ●  │  T=4
    ├────┼────┼────┼────┼────┤
  3 │    │ ●  │ ●● │ ●  │    │  T=3
    ├────┼────┼────┼────┼────┤
  2 │ ●  │    │ ●  │    │    │  T=2
    ├────┼────┼────┼────┼────┤
  1 │    │    │    │    │    │  T=1
    └────┴────┴────┴────┴────┘
Theoretical ↑
```

This heatmap reveals where your idea library is concentrated and where gaps exist.

#### Step 2.6: Interactive Confirmation

Present to user:
```
> 想法已保存:
>   📁 ideas/{filename}.md
>
> 评分:
>   T (理论深度): {T}/5
>   B (生物意义): {B}/5
>   F (可行性): {F}/5
>   Tr (热点): {Tr}/5
>
> 定位: {portfolio category}
> Venue 建议: {venues}
>
> 你的 idea library 现在有 {N} 个 active ideas
> Heatmap 更新: {added to T={T}, B={B}}
>
> 下一步:
>   (A) 完成
>   (B) 再补充细节
>   (C) 启动 research_copilot 开始执行（将此 idea 传入）
```

Option (C) triggers: `research_copilot --from-idea-library=ideas/{filename}.md`

---

## Optional Phases

### Phase 3 (Optional): Idea Clustering

Periodically (e.g., monthly), review all active ideas and identify clusters:
- Multiple ideas on the same theme → create a cluster note
- Clusters become `~/idea_library/clusters/{theme}.md`
- Clusters help you see where your interest is concentrating

Can be invoked via `/idea_library cluster` or automatically when a new idea joins an existing
cluster (T/B/domain overlap).

### Phase 4 (Optional): Idea Review

Periodically review ideas:
- **Active ideas**: Still relevant? Still novel?
- **Sleeping ideas**: Should they wake up (new papers, new tools)?
- **Recent intake**: Any patterns in what you've been thinking about?

Can be invoked via `/idea_library review` on a weekly/monthly cadence.

---

## Interaction Modes

### Full Interactive Mode (Default)

Pauses at:
- Phase 0 Step 0.2 — Intake form completion
- Phase 1 Step 1.4 — Novelty verdict (may require judgment)
- Phase 2 Step 2.1-2.2 — Scoring validation
- Phase 2 Step 2.6 — Final confirmation

### Express Mode

Pauses only at:
- Phase 0 Step 0.2 — Brief intake (just title and core idea)
- Phase 1 Step 1.4 — Novelty verdict (cannot be skipped — user must confirm)

All other steps auto-fill with the skill's best estimate. User can review and edit the saved
idea file afterward.

Useful for high-volume idea capture: "I just thought of 5 things, save them quickly".

---

## Integration with Other Skills

### From `paper_reader`

When `paper_reader` Phase 3 detects an idea trigger, it hands off to `idea_library` with:
- Source paper reference (becomes trigger source)
- Paper-derived context (becomes initial idea description)
- Paper topics (become initial domain tags)

### To `research_copilot`

When starting a new project, `research_copilot` can read from `~/idea_library/` to:
- List all active ideas scored above a threshold
- Filter by domain
- Sort by T/B/F scores
- Help user pick a starting idea

Usage: `research_copilot --from-idea-library` (scans library); or with specific ID:
`research_copilot --from-idea-library=2026-04-11_grn_sparse_attention`

### Between `idea_library` entries

Ideas can evolve. When you have a new idea that's an evolution of an existing one:
- Link to the prior idea
- Move the prior idea to "sleeping" or "superseded" status
- Inherit context (domain, related papers)

---

## Important Notes

- **Over-capture is fine**. The cost of saving a bad idea is low; the cost of losing a good
  idea is high.
- **Novelty verification is not optional**. Many "new" ideas are rediscoveries. Phase 1 catches
  this early, saving months of wasted work.
- **2D scoring reveals structure**. A T=5 B=1 idea (pure theory) goes to ICML; a T=2 B=5 idea
  (bio tool) goes to Nature Methods. Knowing this upfront saves venue selection headaches.
- **Retirement is normal**. If an idea turns out to be already done (Redundant verdict), move
  it to retired/. This isn't failure; it's learning.
- **Graveyard has value**. The retired/ directory is searchable too. When you have a "new"
  idea, check if past-you already considered it.
- **Weekly review habit**. The skill works best with weekly/monthly review passes (optional
  Phase 4) to prevent ideas from going stale.
- **Link everything**. Ideas → papers (paper_library), ideas → ideas, ideas → clusters. The
  graph is the value.
- **Language convention**: Ideas in Chinese for personal use; paper titles, technical terms,
  venue names in English.
- **Backup**: `~/idea_library/` is all markdown. Put it in git, push to a private repo. Do
  NOT lose this data.
