# Journal Profiles: Nature / Science / Cell Family

## Quick Comparison

| Journal | IF (approx) | Word Limit | Main Figs | Methods Location | Desk Reject | Best Fit |
|---------|:---:|:---:|:---:|---|:---:|---------|
| Nature | ~64 | 3-5K | 4-6 | Online Methods | ~85% | Paradigm-shifting discoveries |
| Science | ~63 | 2.5-3.5K | 3-4 | Supplementary | ~85% | Transformative findings |
| Cell | ~64 | 5-7K | 6-7 | STAR Methods | ~75% | Biological mechanism insights |
| Nature Methods | ~48 | 3-5K | 5-7 | Online Methods | ~60% | New methods for biology |
| Nature Machine Intelligence | ~23 | 5-6K | 5-7 | End of main text | ~55% | AI with real-world impact |
| Nature Computational Science | ~12 | 4-5K | 5-7 | End of main text | ~55% | Computational methodology |
| Nature Communications | ~17 | 4-6K | 6-8 | End of main text | ~45% | Solid subfield advances |
| Science Advances | ~13 | 5-7K | 5-7 | End of main text | ~45% | Significant advances |
| Cell Reports Medicine | ~14 | 5-6K | 6-7 | STAR Methods | ~50% | Clinical/translational |

---

## Detailed Profiles

### Nature

**Scope**: Breakthrough discoveries of broad scientific interest across all disciplines.

**Paper structure**: Abstract (150 words) > Main text (no section headings for Articles, or brief headings) > Methods (Online Methods, separate) > References > Extended Data (up to 10 figs) > Supplementary Information

**What editors screen for** (desk reject ~85%):
- Is this of interest to scientists outside this subfield?
- Does it represent a conceptual advance, not just a technical one?
- Will it change how people think about a problem?

**What reviewers evaluate**:
- Biological validity and depth of characterization
- Independent dataset validation
- Clarity and impact of the main message
- Figure quality and information density

**For AI/LLM/Agent bioinformatics**: Extremely ambitious target. Requires a computational framework that enables a fundamentally new type of biological analysis or reveals biology impossible to discover otherwise. Possible for: virtual cell models that accurately predict cellular responses, or AI-driven drug design with experimental validation.

**Figure conventions**: 4-6 compound figures, each full-page with 4-8 panels. Panel (a) is often a schematic. Extended Data for supporting results. Professional vector graphics (not TikZ).

**Citation style**: Numbered superscript.

---

### Nature Methods

**Scope**: New methods and tools for biological and biomedical research. The primary target for computational biology methods.

**Paper structure**: Abstract (150 words) > Main text with Results subsections > Discussion > Online Methods > References > Extended Data > Supplementary

**What editors screen for** (desk reject ~60%):
- Is the method broadly applicable to multiple biological questions?
- Does it enable analysis that was previously impossible or impractical?
- Is there thorough benchmarking on real biological data?

**What reviewers evaluate**:
- Comprehensive benchmarking against existing tools
- Validation on independent, real-world biological datasets
- Software quality, documentation, usability
- Biological insights from the method's application
- Scalability to realistic dataset sizes

**For AI/LLM/Agent bioinformatics**: BEST FIT for this user's domain. An LLM-based tool for single-cell analysis, or an Agent framework for automated biological analysis, with strong validation on multiple real datasets, would be competitive.

**Key requirements**:
- Software must be publicly available (GitHub with documentation)
- Must test on datasets from multiple independent labs
- Must show biological validation (not just ML metrics)
- Benchmarking must be fair and comprehensive
- A "Protocol" or tutorial for end users is a plus

---

### Nature Machine Intelligence

**Scope**: AI and ML research with demonstrated real-world applications and societal implications.

**Paper structure**: Abstract > Main text with titled sections > Methods (end of main text) > References > Supplementary

**What editors screen for** (desk reject ~55%):
- Is the AI methodology novel?
- Is the application domain significant?
- Are broader implications for AI discussed?

**What reviewers evaluate**:
- Novelty of the AI approach (not just application)
- Rigor of experimental evaluation
- Real-world impact demonstration
- Responsible AI considerations
- Comparison with both AI and domain-specific baselines

**For AI/LLM/Agent bioinformatics**: Strong fit. Accepts papers that are more algorithm-focused than Nature Methods, but requires clear domain application. Good for LLM/Agent architectures with biological application.

---

### Nature Computational Science

**Scope**: Computational and mathematical methods for scientific discovery across disciplines.

**Paper structure**: Similar to Nature Machine Intelligence.

**What editors screen for** (desk reject ~55%):
- Is the computational methodology a significant advance?
- Does it enable new scientific insights?
- Is there cross-disciplinary relevance?

**For AI/LLM/Agent bioinformatics**: Good fit for virtual cell models, large-scale computational frameworks, and simulation tools. Values the computational methodology itself.

---

### Nature Communications

**Scope**: Significant advances across all natural sciences. More specialized than Nature.

**Paper structure**: Abstract > Introduction > Results (titled subsections) > Discussion > Methods (end) > References > Supplementary

**What editors screen for** (desk reject ~45%):
- Is this a significant advance in its specific subfield?
- Is the work thorough and well-executed?
- Does it go beyond incremental improvement?

**For AI/LLM/Agent bioinformatics**: Most realistic Nature-family target. A well-executed computational biology paper with comprehensive experiments, biological validation, and clear utility to the biology community is competitive. Accepts more specialized topics.

---

### Science / Science Advances

**Science**: Ultra-tight word limit (2,500-3,500), Methods in Supplementary, 3-4 dense figures. Extremely competitive (desk reject ~85%). Paradigm shifts only.

**Science Advances**: More generous (5,000-7,000 words), Methods at end, 5-7 figures. Good for comprehensive computational studies with strong data. Accepts significant advances that are too specialized for Science main.

---

### Cell / Cell Reports Medicine

**Cell**: Biological mechanism focus. STAR Methods (structured). 6-7 large figures. Requires deep biological characterization. Hard for purely computational papers unless the computational predictions are experimentally validated.

**Cell Reports Medicine**: Translational/clinical focus. Good for drug design papers with patient data relevance, or single-cell analysis of clinical samples.

**STAR Methods structure**:
- Resource Table (key resources: software, datasets, models)
- Lead Contact information
- Materials Availability
- Data and Code Availability
- Method Details (detailed computational methods)
- Quantification and Statistical Analysis

---

## Additional Journals (Also Accept Computational AI/Bio Papers)

### Nature Biotechnology (IF ~33)
**Scope**: Biological technology and applications. Accepts computational tools that enable new biotech applications.
**For AI/LLM bioinformatics**: Strong fit for AI-driven synthetic biology, protein design, or drug discovery tools with clear biotech applications. Expects practical impact beyond benchmarks.

### Nature Genetics (IF ~24)
**Scope**: Genetics and genomics research. Accepts large-scale computational genetics studies.
**For AI/LLM bioinformatics**: Good for genome-scale LLM applications (variant interpretation, regulatory genomics, population genetics with AI).

### Nature Biomedical Engineering (IF ~20)
**Scope**: Engineering approaches for biology and medicine.
**For AI/LLM bioinformatics**: Fits AI tools with clear biomedical engineering application (diagnostic tools, treatment planning).

### Nature Protocols (IF ~13)
**Scope**: Step-by-step reproducible protocols. Good follow-up after a methods paper.
**For AI/LLM bioinformatics**: If your tool from Nature Methods becomes widely used, a Protocol paper documents the full workflow.

### Cell Systems (IF ~9)
**Scope**: Systems biology, computational biology, multi-scale modeling.
**For AI/LLM bioinformatics**: Strong fit for virtual cell models, multi-omics integration, systems-level computational studies. More computation-friendly than Cell main.

### Cell Reports (IF ~8)
**Scope**: Broad life sciences, high volume. Accepts solid specialized advances.
**For AI/LLM bioinformatics**: Good backup for specialized computational biology studies.

### PLOS Computational Biology (IF ~4.8)
**Scope**: Primary venue for computational biology and bioinformatics methods. CRITICAL venue for this domain.
**For AI/LLM bioinformatics**: Excellent fit for all AI/LLM bioinformatics papers. Lower bar than Nature family but still respected. Good for first publications in a new direction. Accepts methods + application papers.
**Advantage**: Higher acceptance rate (~25-30%), faster review, strong computational biology community readership.

### Genome Biology (IF ~12)
**Scope**: Genomics methods and biological insights from genomics data.
**For AI/LLM bioinformatics**: Good for LLM-based genomics tools, single-cell methods, and genome analysis frameworks.

### Bioinformatics (IF ~5.8)
**Scope**: Core bioinformatics methods journal (Oxford).
**For AI/LLM bioinformatics**: Accepts application notes and full method papers. Fast review. Good for tool papers.

### Briefings in Bioinformatics (IF ~9.5)
**Scope**: Reviews and methods in bioinformatics.
**For AI/LLM bioinformatics**: Good for survey/benchmark papers or methods with comprehensive evaluation.

---

## Journal Selection Decision Tree

For AI/LLM/Agent bioinformatics papers:

1. **New computational tool with broad biological utility?**
   > Nature Methods (best) > Nature Communications > Genome Biology > PLOS Computational Biology

2. **AI/ML advance with biological application?**
   > Nature Machine Intelligence > Nature Computational Science > Science Advances

3. **Method reveals new biology (cell types, mechanisms)?**
   > Nature Communications > Cell Systems > Genome Biology

4. **Virtual cell / simulation framework?**
   > Nature Computational Science > Cell Systems > Nature Communications

5. **Drug design / biotech application?**
   > Nature Biotechnology > Cell Reports Medicine > Science Advances

6. **GRN inference / regulatory genomics?**
   > Nature Genetics (if genomics focus) > Genome Biology > Nature Methods

7. **Benchmark / community resource?**
   > Nature Communications > Genome Biology > PLOS Computational Biology

8. **Paradigm-shifting discovery?**
   > Nature > Science > Cell (extraordinary results only)

### Tiered Submission Strategy

Plan a submission cascade (if rejected, submit to next tier):

| Tier | Journals | Desk reject | Timeline |
|:----:|---------|:---:|---------|
| 1 | Nature Methods, Nature Machine Intelligence | 55-65% | Submit first |
| 2 | Nature Communications, Nature Computational Science, Science Advances | 40-55% | If T1 rejected |
| 3 | Genome Biology, Cell Systems, Briefings in Bioinformatics | 30-40% | If T2 rejected |
| 4 | PLOS Computational Biology, Bioinformatics | 25-30% | Backup |

**Pragmatic recommendation**: For a 1-2 month computational project with 1x A100, target Tier 1-2 as primary. Always have a Tier 3-4 backup plan.

---

## Cover Letter Essentials

Every submission needs a cover letter. Structure:

1. **Opening**: "Dear Editor, we submit [Title] for consideration as a [Article/Brief Communication] in [Journal]."
2. **Why this journal**: "This work is particularly suited for [Journal] because [specific reason tied to journal scope]."
3. **What we found**: 2-3 sentences summarizing the main findings and significance.
4. **Why it matters**: 1-2 sentences on broader impact.
5. **Related papers in this journal**: "Our work builds on recent publications in [Journal], including [Author et al., Year] and [Author et al., Year], extending the field by..."
6. **Closing**: Confirm no conflicts, data availability, suggest reviewers.

See `references/cover_letter_guide.md` for full templates.
