# Compound Figure Guide for Nature/Science/Cell

Nature/Science/Cell figures are **compound multi-panel figures**. Each figure occupies up to a full page and contains 4-8 panels telling a complete sub-story.

## Key Differences from Conference Figures

| Aspect | CS Conferences | Nature/Science/Cell |
|--------|---------------|-------------------|
| Figure type | Single-purpose (one chart) | Compound (4-8 panels per figure) |
| Rendering | TikZ/pgfplots in LaTeX | Python (matplotlib/seaborn) + Illustrator assembly |
| Architecture diagrams | TikZ block diagrams | Professional schematics (BioRender style) |
| Number | 6+ small figures | 4-6 large compound figures |
| Legends | 1-2 sentence captions | Detailed paragraphs (100-200 words each) |
| Resolution | Vector (PDF in LaTeX) | 300+ DPI, TIFF/EPS/PDF, separate files |
| Statistical annotations | * in tables | * / ** / *** on figure panels with p-values |

---

## Standard Figure Layout (4-6 Main Figures)

### Figure 1: Framework and Initial Validation

**Purpose**: Introduce the method and show it works in principle.

**Typical panels**:
- (a) Workflow/framework schematic (conceptual, not architecture diagram)
- (b) Input data representation and processing pipeline
- (c) Initial performance metric on one dataset
- (d) Comparison with 1-2 key baselines on simple task

**Design notes**: Panel (a) should be understandable by a biologist. Use biological language, not ML jargon. Show data flowing from biological input to biological output.

### Figure 2: Comprehensive Benchmarking

**Purpose**: Main results across all datasets and baselines.

**Typical panels**:
- (a) Bar/dot plot of primary metric across all methods (all datasets combined or best dataset)
- (b) Heatmap of all methods x all datasets x primary metric
- (c) Per-dataset breakdown (faceted bar charts or dot plots)
- (d) Statistical comparison matrix (pairwise significance)
- (e) Radar/spider chart showing performance across multiple metrics (optional)

### Figure 3: Mechanism and Biological Insight

**Purpose**: Show WHY the method works and what biological patterns it captures.

**Typical panels**:
- (a) UMAP/t-SNE of learned embeddings, colored by cell type / condition
- (b) Attention weight or feature importance analysis on biological features
- (c) Gene Ontology enrichment dot plot for top features
- (d) Marker gene recovery comparison (bar chart)
- (e) Expression heatmap of top genes grouped by predicted cluster (optional)

### Figure 4: Application and Discovery

**Purpose**: Apply the method to a new scenario and show biological discovery.

**Typical panels**:
- (a) Application scenario schematic
- (b) Results on the new/harder dataset
- (c) Biological validation (overlap with known database, pathway analysis)
- (d) Novel finding visualization (new cell type, new interaction, new drug candidate)

### Figure 5-6: Extension and Scalability (if needed)

Additional results, clinical application, scalability analysis, or cross-domain transfer.

---

## Compound Figure Code Template (Python)

```python
"""Generate a Nature-style compound figure with multiple panels."""
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import numpy as np

# Nature-family style settings
NATURE_STYLE = {
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica"],
    "font.size": 7,           # Nature uses 7pt for figure text
    "axes.labelsize": 8,
    "axes.titlesize": 8,
    "xtick.labelsize": 6,
    "ytick.labelsize": 6,
    "legend.fontsize": 6,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "axes.linewidth": 0.5,
    "xtick.major.width": 0.5,
    "ytick.major.width": 0.5,
}

# Colorblind-friendly palette
COLORS = ["#0077BB", "#EE7733", "#009988", "#CC3311", "#33BBEE", "#EE3377", "#BBBBBB"]


def create_compound_figure(n_panels=6, figsize=(180/25.4, 200/25.4)):
    """Create a compound figure grid.
    
    Args:
        n_panels: Number of panels (4-8)
        figsize: Figure size in inches (Nature full width = 180mm = 7.09in)
    
    Returns:
        fig, axes dict keyed by panel letter
    """
    plt.rcParams.update(NATURE_STYLE)
    
    fig = plt.figure(figsize=figsize)
    
    # Example: 2x3 grid for 6 panels
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.4, wspace=0.3)
    axes = {
        "a": fig.add_subplot(gs[0, 0]),
        "b": fig.add_subplot(gs[0, 1]),
        "c": fig.add_subplot(gs[0, 2]),
        "d": fig.add_subplot(gs[1, 0]),
        "e": fig.add_subplot(gs[1, 1]),
        "f": fig.add_subplot(gs[1, 2]),
    }
    
    # Add panel labels
    for label, ax in axes.items():
        ax.text(-0.15, 1.05, label, transform=ax.transAxes,
                fontsize=10, fontweight="bold", va="bottom")
    
    return fig, axes


def add_significance_annotation(ax, x1, x2, y, p_value, height=0.02):
    """Add significance bracket and stars to a bar plot."""
    if p_value < 0.001:
        stars = "***"
    elif p_value < 0.01:
        stars = "**"
    elif p_value < 0.05:
        stars = "*"
    else:
        stars = "n.s."
    
    ax.plot([x1, x1, x2, x2], [y, y+height, y+height, y], color="black", linewidth=0.5)
    ax.text((x1+x2)/2, y+height, stars, ha="center", va="bottom", fontsize=7)
```

---

## Biological Visualization Templates

### UMAP with Cell Type Annotations

```python
def plot_umap_nature_style(adata, color_key, output_path, title=""):
    """Publication-quality UMAP for Nature-family journals."""
    import scanpy as sc
    
    plt.rcParams.update(NATURE_STYLE)
    fig, ax = plt.subplots(figsize=(88/25.4, 88/25.4))  # Single column width
    
    sc.pl.umap(adata, color=color_key, ax=ax, show=False,
               frameon=False, title=title, size=5,
               legend_loc="right margin", legend_fontsize=5)
    
    plt.savefig(output_path, dpi=300, bbox_inches="tight", format="pdf")
```

### GO Enrichment Dot Plot

```python
def plot_go_enrichment(go_results, output_path, top_n=15):
    """GO enrichment dot plot (Nature style)."""
    plt.rcParams.update(NATURE_STYLE)
    
    df = go_results.head(top_n).sort_values("Adjusted P-value")
    
    fig, ax = plt.subplots(figsize=(88/25.4, 100/25.4))
    scatter = ax.scatter(
        -np.log10(df["Adjusted P-value"]),
        range(len(df)),
        s=df["Overlap"].str.split("/").str[0].astype(int) * 3,
        c=-np.log10(df["Adjusted P-value"]),
        cmap="Reds", edgecolors="black", linewidths=0.3
    )
    ax.set_yticks(range(len(df)))
    ax.set_yticklabels(df["Term"], fontsize=5)
    ax.set_xlabel("-log10(Adjusted P-value)")
    ax.set_title("GO Biological Process Enrichment")
    
    plt.savefig(output_path, dpi=300, bbox_inches="tight", format="pdf")
```

### Expression Heatmap

```python
def plot_expression_heatmap(adata, genes, groupby, output_path):
    """Gene expression heatmap grouped by cell type."""
    import scanpy as sc
    plt.rcParams.update(NATURE_STYLE)
    
    sc.pl.heatmap(adata, var_names=genes, groupby=groupby,
                  swap_axes=True, show_gene_labels=True,
                  cmap="RdBu_r", figsize=(180/25.4, 120/25.4),
                  save=False, show=False)
    plt.savefig(output_path, dpi=300, bbox_inches="tight", format="pdf")
```

---

## Figure Size Reference

| Journal | Single column | 1.5 column | Full width |
|---------|:---:|:---:|:---:|
| Nature family | 88 mm | 120 mm | 180 mm |
| Science family | 85 mm | 114 mm | 174 mm |
| Cell family | 85 mm | 114 mm | 174 mm |

Maximum height for any figure: ~240 mm (to fit on one page with legend).

---

## Figure Naming and Output

```
figures/
├── fig1/
│   ├── fig1a_workflow.pdf          # Individual panel
│   ├── fig1b_validation.pdf
│   ├── fig1c_metrics.pdf
│   ├── fig1d_comparison.pdf
│   └── fig1_assembled.pdf          # Assembled in Illustrator/Inkscape
├── fig2/
│   ├── fig2a_performance.pdf
│   ...
├── extended_data/
│   ├── ed_fig1_full_benchmark.pdf
│   ...
└── supplementary/
    ├── supp_fig1_sensitivity.pdf
    ...
```

Individual panels are generated by Python scripts. Assembly into compound figures can be done in Inkscape (free) or Adobe Illustrator. The assembled PDF is what gets submitted.

---

## Extended Data Figures (Nature Family Only)

Up to 10 Extended Data figures, each compound. These are peer-reviewed and displayed in the HTML article. Use for:
- Full benchmark tables that are too large for main text
- Additional datasets not in main results
- Sensitivity analyses
- Detailed ablation studies
- Additional biological validations
