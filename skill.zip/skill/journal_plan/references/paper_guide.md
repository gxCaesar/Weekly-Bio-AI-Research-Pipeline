# Paper Writing Guide for Nature/Science/Cell Family

## Paper Structure Overview

Nature/Science/Cell papers are structured as **scientific narratives**, not modular technical reports. Methods go at the end. Results tell a story.

### Standard Structure

```
Abstract (150-300 words)
Introduction (untitled in Nature/Science; titled in Cell)
Results
  Section 1: [Finding-based title] ← paired with Fig 1
  Section 2: [Finding-based title] ← paired with Fig 2
  Section 3: [Finding-based title] ← paired with Fig 3
  Section 4: [Finding-based title] ← paired with Fig 4
Discussion
Methods / Online Methods / STAR Methods (at end or separate)
References
Extended Data (Nature family only)
Supplementary Information
```

### Methods Placement by Journal

| Journal | Where | Format |
|---------|-------|--------|
| Nature, Nature Methods | Online Methods (separate) | Free-form |
| Nature Machine Intelligence, Nat Comp Sci, Nat Commun | End of main text | Free-form |
| Science | Supplementary Materials | Brief in main, detail in supp |
| Science Advances | Materials and Methods (end) | Free-form |
| Cell, Cell Reports Medicine | STAR Methods (end) | Structured template |

---

## Writing Style

### Core Principles

These journals demand **accessible, narrative scientific writing**. The audience includes biologists who are not ML experts.

**Lead with biology, not algorithms.** Instead of "We propose a transformer-based architecture," write "To address the challenge of annotating rare cell types in heterogeneous tissues, we developed CellAgent, a framework that integrates gene regulatory knowledge with large language models."

**Show, don't list.** Instead of numbered contribution lists, weave findings into the narrative. The reader should discover contributions naturally through the Results.

**Minimize jargon.** Define every technical term at first use. Replace ML jargon with intuitive descriptions in the main text. Reserve formal definitions for Methods.

### Forbidden Patterns (Same as Conference + Additional)

| Pattern | BAD | GOOD |
|---------|-----|------|
| Numbered contributions | "Our contributions are: (1)... (2)... (3)..." | Weave into the last paragraph of Introduction |
| "State-of-the-art" | "achieves state-of-the-art results" | "outperforms existing methods on X" (be specific) |
| Heavy math in main text | Equations in Results section | Move all equations to Methods/Supplementary |
| "Leverages/utilizes" | "Our method leverages LLMs" | "Our method uses LLMs" or "builds on" |
| Em-dash overuse | "Our method -- which is novel -- works" | Use commas, parentheses, or separate sentences |
| "Respectively" | "X, Y, and Z achieved A, B, and C, respectively" | Restructure into separate sentences or a table |
| Passive voice excess | "It was observed that..." | "We found that..." or "The analysis revealed..." |

### Tense Conventions

- **Present tense**: Established facts ("Gene X regulates pathway Y")
- **Past tense**: What was done in this study ("We trained the model on...")
- **Present tense**: What figures show ("Figure 2a shows...")

### Paragraph Length

3-5 sentences per paragraph. Never exceed 6 sentences. Each paragraph makes exactly one point.

---

## Section-by-Section Guide

### Abstract (150-300 words)

Nature/Science: Unstructured paragraph, 150-200 words.
Cell: Can be structured (Background/Objective/Results/Conclusion), up to 300 words.

Template:
```
[One sentence: biological context and importance]
[One sentence: gap in current approaches]
[One sentence: what we developed and the key principle behind it]
[2-3 sentences: main findings, with specific numbers]
[One sentence: significance and what this enables]
```

Key rule: No method names or acronyms in the first sentence. Start with biology.

### Introduction (500-800 words, 4-6 paragraphs)

**Paragraph 1: The biological problem.** Why does this matter? What is the biological question? Cite 2-3 key biological papers.

**Paragraph 2: Current approaches and their limitations.** What tools exist? What can they not do? Be specific about limitations (not vague "they are limited").

**Paragraph 3: The opportunity.** What recent advance (in AI/LLM/biology) makes a new approach possible now? Why is the timing right?

**Paragraph 4: What we did and what we found.** "Here, we present [ToolName], a [brief description]. We show that [main finding 1]. We further demonstrate that [main finding 2]. Our analysis reveals [biological insight]."

No numbered contributions list. No "The remainder of this paper is organized as follows."

### Results (3-5 subsections, each 400-800 words)

Each subsection has a **finding-based title** (states the result, not the method):
- GOOD: "CellAgent accurately identifies rare immune subtypes across tissues"
- BAD: "Performance comparison on benchmark datasets"
- BAD: "RQ1: Main Results"

Each subsection follows this pattern:
1. **Opening** (1-2 sentences): What question or goal motivates this section?
2. **Approach** (1-2 sentences): What we did (briefly, save details for Methods).
3. **Finding** (2-4 sentences): What we found, referencing specific figure panels. Use inline figure references: (Fig. 2a,b).
4. **Interpretation** (1-2 sentences): What this means biologically.
5. **Bridge** (1 sentence): Connects to the next section.

### Results Section Story Arc

| Section | Role | Figure | Content |
|---------|------|--------|---------|
| 1 | "Here is our tool" | Fig 1 | Framework overview + initial validation |
| 2 | "It works well" | Fig 2 | Comprehensive benchmarking, main results |
| 3 | "Here is why" | Fig 3 | Mechanism analysis, what the model learns |
| 4 | "Here is what it reveals" | Fig 4 | Biological discovery or application |
| 5 (optional) | "Here is the broader impact" | Fig 5 | Scalability, new applications, clinical |

### Discussion (600-1000 words, 4-6 paragraphs)

**Paragraph 1**: Summarize the main contribution in the context of the field. Not a repeat of Results. Frame as: "Our work demonstrates that [principle], which addresses the longstanding challenge of [problem]."

**Paragraph 2**: Relate to prior work. How does this change the landscape? What does it add to what was known? Cite 3-5 related papers and explain the advance.

**Paragraph 3**: Broader implications. What does this enable? What new questions can now be asked? What experiments become possible?

**Paragraph 4**: Limitations. Be honest and specific. "Our approach currently requires [X], which limits application to [Y]. Future work could address this by [Z]." Reviewers strongly prefer papers that acknowledge limitations.

**Paragraph 5**: Future directions. 2-3 concrete next steps. Not vague ("future work could improve this") but specific ("extending this framework to spatial transcriptomics data would enable...").

**Final sentence**: A forward-looking statement about the field, not your method.

### Methods (1500-3000 words)

Methods go at the end but must be thorough enough for reproduction.

**Word count guidance**:
- Nature / Nature Methods (Online Methods): 2000-3000 words, no limit on equations
- Nature Communications / Nature Comp Sci / NMI: 1500-2500 words at end of main text
- Science (Supplementary Materials): 1000-1500 words in main, details in supplement
- Cell family (STAR Methods): 2000-3000 words, structured format

**Free-form Methods structure** (Nature / Science / NatCommun):
1. **Data collection and preprocessing**: What datasets, how obtained, preprocessing steps, accession numbers
2. **Model architecture**: Full technical description with equations (all equations go here, not in Results)
3. **Training procedure**: Optimizer, learning rate, batch size, hardware, training time
4. **Baseline methods**: How each baseline was run, source of code
5. **Evaluation metrics**: Definition of each metric
6. **Statistical analysis**: What tests, significance thresholds, multiple testing correction
7. **Software and hardware**: Versions, GPU specs (1x A100 80GB), code availability URL

**STAR Methods structure** (Cell / Cell Reports / Cell Systems):
```
STAR Methods

RESOURCE AVAILABILITY
Lead contact: [name, email]
Materials availability: This study did not generate new materials. 
  All data and code are publicly available.
Data and code availability:
  - Processed data: [Zenodo DOI]
  - Code: [GitHub URL], archived at [Zenodo DOI]
  - Model weights: [HuggingFace URL]

KEY RESOURCES TABLE
| REAGENT/RESOURCE | SOURCE | IDENTIFIER |
|-----------------|--------|-----------|
| Software: PyTorch 2.x | pytorch.org | RRID:SCR_018536 |
| Software: scanpy 1.9 | scanpy.readthedocs.io | RRID:SCR_018139 |
| Dataset: Tabula Sapiens | CZI | GSE123456 |
| Model: scGPT | GitHub | https://github.com/... |

METHOD DETAILS
[Detailed computational methods, 1500-2500 words]

QUANTIFICATION AND STATISTICAL ANALYSIS
[Statistical tests, sample sizes, software used for stats]
```

---

## Required Supplementary Items by Journal

### Highlights (Required: Nature Methods, some Nature sub-journals)

3-4 bullet points, each ~15 words:
```
Highlights:
- [ToolName] integrates gene regulatory networks with large language models 
  for single-cell analysis
- The framework identifies rare cell types missed by existing computational tools
- Biological validation confirms recovery of known marker genes and regulatory 
  interactions
- [ToolName] scales to atlas-sized datasets on a single GPU
```

### Graphical Abstract (Required: Cell family journals)

One-page visual summary (separate from Figure 1). Should show:
- Input data on the left
- Your method in the center
- Key output/finding on the right
- Use same color scheme as main figures
- Must be understandable without reading the paper

Generate using Python (matplotlib/seaborn) or design in BioRender/Illustrator.

### Author Contributions (CRediT Statement, Required: All target journals)

```
Author Contributions:
Conceptualization: A.B., C.D.
Methodology: A.B.
Software: A.B., E.F.
Validation: A.B., G.H.
Formal Analysis: A.B.
Investigation: A.B.
Data Curation: A.B., E.F.
Writing - Original Draft: A.B.
Writing - Review & Editing: A.B., C.D., G.H.
Visualization: A.B.
Supervision: C.D.
Funding Acquisition: C.D.
```

### ORCID (Required: All Nature/Science/Cell journals)

All authors must provide ORCID identifiers. Register at orcid.org if needed. Include in the author list:
```
Author Name^{1,*} \orcid{0000-0000-0000-0000}
```

### Data Availability Statement

```
Data Availability:
The datasets used in this study are publicly available:
- [Dataset1]: GEO accession GSE123456
- [Dataset2]: available at [URL]
Processed data and model weights are deposited at Zenodo (DOI: 10.5281/zenodo.XXXXXXX).

Code Availability:
All code is available at https://github.com/[username]/[repo] 
and archived at Zenodo (DOI: 10.5281/zenodo.XXXXXXX).
```

---

## Figure-Section Mapping

Every main figure maps to exactly one Results subsection. Plan them together.

| Results Section | Figure | Panel a | Panel b | Panel c | Panel d | Panel e-f |
|----------------|--------|---------|---------|---------|---------|-----------|
| 1: Framework | Fig 1 | Workflow schematic | Input/output example | Initial validation metric | Comparison on simple task | |
| 2: Main results | Fig 2 | Performance comparison (bar/dot) | Per-dataset breakdown | Statistical comparison | Ranking heatmap | |
| 3: Mechanism | Fig 3 | UMAP/embedding | Attention/feature analysis | GO enrichment | Marker gene recovery | |
| 4: Application | Fig 4 | Application scenario | Results on new data | Biological validation | Case study | |

---

## Figure Legend Format

Figure legends are substantial paragraphs. Each legend must be self-contained: a reader should understand the figure from the legend alone, without reading the main text.

### Template

```
Figure X: [Bold title stating the main finding of this figure].
(a) [Description of panel a, including what is plotted, axes, colors].
(b) [Description of panel b]. [Statistical test used], n = [sample size].
(c) [Description of panel c]. Error bars represent [mean +/- s.e.m. or median with IQR].
(d) [Description of panel d]. P values: * P < 0.05, ** P < 0.01, *** P < 0.001
([statistical test name], [correction method if applicable]).
Data from [n] independent [experiments/datasets/samples].
```

### Legend Checklist
- [ ] Bold title that states the finding
- [ ] Every panel (a,b,c,...) described
- [ ] Statistical test named for every comparison
- [ ] Sample sizes (n) stated
- [ ] Error bar definition (s.e.m., s.d., IQR)
- [ ] P value thresholds defined
- [ ] Number of independent experiments/replicates stated

---

## Supplementary Material Strategy

### Main vs Extended Data vs Supplementary

| Content | Main Paper | Extended Data (Nature only) | Supplementary |
|---------|:---:|:---:|:---:|
| Core results | Yes | | |
| Method validation | | Yes | |
| Full benchmark tables | | Yes | Yes |
| Proofs/derivations | | | Yes |
| Hyperparameters | | | Yes |
| Additional datasets | | Yes | |
| All visualizations | | | Yes |
| Code documentation | | | Yes |

### Supplementary Structure

```
Supplementary Information

Supplementary Note 1: Detailed method description
Supplementary Note 2: Theoretical analysis
Supplementary Table 1-N: Full result tables
Supplementary Figure 1-N: Additional visualizations
Supplementary Data: Source data for all figures
```
