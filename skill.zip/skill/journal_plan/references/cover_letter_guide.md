# Cover Letter Guide

The cover letter is critical for surviving editorial screening. At Nature/Science/Cell, the editor reads the cover letter before the abstract. A weak cover letter leads to immediate desk rejection.

---

## Template

```
Dear Editor,

We submit our manuscript entitled "[Title]" for consideration as a 
[Article / Brief Communication / Resource] in [Journal Name].

[WHY THIS JOURNAL - 2-3 sentences]:
This work is particularly suited for [Journal] because [specific reason 
tied to journal scope]. Our study addresses [topic] that is of broad 
interest to [Journal]'s readership, as evidenced by recent publications 
in [Journal] on related topics, including [Author1 et al., Year] and 
[Author2 et al., Year].

[WHAT WE FOUND - 3-4 sentences]:
We developed [ToolName], a [brief description] that [key capability].
Using [data description], we demonstrate that [main finding 1].
We further show that [main finding 2], revealing [biological insight].
Our analysis of [application] identifies [discovery], which [significance].

[WHY IT MATTERS - 2 sentences]:
This work provides [specific advance] that enables [concrete new capability] 
for the [biology/medicine] community. We believe our findings will interest 
researchers in [field 1], [field 2], and [field 3].

[LOGISTICS]:
We confirm that this work is original, has not been published elsewhere, 
and is not under consideration at another journal. All authors have approved 
the manuscript. All data and code are available at [URL].

We suggest the following reviewers with relevant expertise:
1. [Name], [Institution] ([email]) - expertise in [area]
2. [Name], [Institution] ([email]) - expertise in [area]
3. [Name], [Institution] ([email]) - expertise in [area]

We request that the following researchers not review this manuscript due 
to potential conflicts of interest: [names if applicable, otherwise omit].

Sincerely,
[Corresponding Author]
```

---

## Per-Journal Customization

### Nature Methods
Emphasize: method applicability to multiple biological problems, software availability, benchmark comprehensiveness. Mention the biological community that will benefit.

### Nature Machine Intelligence
Emphasize: AI novelty, broader implications for AI in science, responsible AI considerations. Bridge technical innovation with societal impact.

### Nature Communications
Emphasize: significance within the subfield, thoroughness of experiments, biological validation. Lower the "paradigm shift" bar but emphasize completeness.

### Science Advances
Emphasize: the advance beyond current knowledge, interdisciplinary relevance, data quality and quantity.

### Cell Family
Emphasize: biological mechanism, clinical relevance, STAR Methods compliance, resource availability.

---

## Cover Letter Checklist

- [ ] Addresses the correct editor/journal
- [ ] States why THIS journal (not generic)
- [ ] Cites 2-3 related papers from THIS journal
- [ ] Summarizes findings in 3-4 sentences (not the full abstract)
- [ ] States broader impact clearly
- [ ] Lists 3-5 suggested reviewers with emails
- [ ] Mentions data and code availability
- [ ] Confirms originality and no dual submission
- [ ] Length: 1 page, never more than 1.5 pages
