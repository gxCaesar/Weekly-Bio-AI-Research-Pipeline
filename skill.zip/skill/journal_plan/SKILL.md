---
name: journal_plan
description: >
  High-impact journal research planning skill for AI/LLM/Agent bioinformatics papers targeting
  Nature, Science, Cell family journals and sub-journals. Produces complete publication-ready
  deliverables with narrative-driven paper structure, compound multi-panel figures, biological
  validation, cover letter, and Methods section in journal format. Use this skill when the user
  wants to: plan a journal submission for Nature/Science/Cell family, prepare a research project
  for a high-impact biology or AI journal, produce publication-quality deliverables for journal
  submission, or design experiments for bioinformatics+AI research targeting journals rather than
  conferences. Also triggers for: journal paper preparation, Nature Methods submission,
  Nature Communications submission, research plan for high-impact journal.
---

# Journal Plan Skill

This skill takes a research direction (or helps the user discover one) and produces a complete,
publication-ready research package targeting a specific Nature/Science/Cell family journal.
The paper follows journal conventions: narrative Results sections, Methods at end, compound
multi-panel figures with detailed legends, and cover letter.

**Target journals**: Nature/Science/Cell family and sub-journals, including but not limited to: Nature, Nature Methods, Nature Machine Intelligence, Nature Computational Science, Nature Communications, Nature Biotechnology, Nature Genetics, Nature Biomedical Engineering, Science, Science Advances, Cell, Cell Systems, Cell Reports Medicine, Genome Biology, PLOS Computational Biology, Briefings in Bioinformatics, Bioinformatics
**Domain focus**: AI/LLM/Agent for bioinformatics (virtual cells, single-cell, drug design, biomolecular generation)
**Research type**: Purely computational (all validation is in silico using public datasets)
**Hardware constraint**: 1x NVIDIA A100 80GB (strict, no multi-GPU)
**Tech focus**: LLM and Agent-based approaches
**Timeline**: 1-2 months (8 weeks) with parallel execution schedule
**Framework**: PyTorch + HuggingFace Transformers
**Language convention**: Survey, proposal, technical manual, post-experiment guide in Chinese; paper, cover letter, and code in English
**Writing style**: Narrative, accessible scientific English. Lead with biology, not algorithms. No AI-sounding text. See `references/paper_guide.md`.

## Output Structure

```
{project_name}/
├── survey.md                    # Literature survey (Chinese)
├── proposal.md                  # Research proposal (Chinese, feasibility-validated)
├── code/                        # Complete code project
│   ├── configs/
│   ├── data/
│   ├── models/
│   ├── baselines/
│   ├── training/
│   ├── evaluation/
│   ├── analysis/                # Result analysis + biological validation + compound figures
│   ├── scripts/
│   ├── ablation/
│   ├── main.py
│   ├── requirements.txt
│   └── README.md
├── paper/                       # Journal-format paper
│   ├── main.tex                 # Abstract + Introduction + Results + Discussion
│   ├── methods.tex              # Methods (separate, at end or online)
│   ├── supplementary.tex        # Supplementary Information
│   ├── extended_data.tex        # Extended Data (Nature family)
│   ├── cover_letter.tex         # Cover letter to editor
│   ├── references.bib
│   ├── figures/                 # Compound multi-panel figures
│   │   ├── fig1/
│   │   ├── fig2/
│   │   ├── fig3/
│   │   └── fig4/
│   ├── extended_data_figures/
│   ├── supplementary_figures/
│   └── reviewer_suggestions.md
├── technical_manual.md          # Technical manual (Chinese)
├── presentation.html            # Project presentation
└── post_experiment_guide.md     # Post-experiment guide (Chinese)
```

---

## Phase 0: Journal Selection & Topic Discovery

**Interactive phase.** Present options and wait for user selection.

### Step 1: Journal Selection

If not already specified, present journal options grouped by tier:

**Tier 1 (IF > 30, desk reject > 70%)**:
- Nature, Science, Cell, Nature Biotechnology, Nature Methods

**Tier 2 (IF 12-30, desk reject 45-60%)**:
- Nature Machine Intelligence, Nature Computational Science, Nature Communications, Nature Genetics, Nature Biomedical Engineering, Science Advances

**Tier 3 (IF 4-15, desk reject 25-40%)**:
- Cell Systems, Cell Reports Medicine, Genome Biology, Briefings in Bioinformatics, PLOS Computational Biology, Bioinformatics

Read `references/journal_profiles.md` for detailed profiles and **tiered submission strategy** (plan a submission cascade if rejected). Set `{JOURNAL}` for all subsequent phases.

**Pragmatic recommendation**: For a 1-2 month computational project, target Tier 2-3 journals. Tier 1 requires extraordinary results.

### Step 2: Topic Discovery

Same as conference_plan: either user provides direction (Path A) or trending topic search (Path B).

For journals, additionally search:
- `{JOURNAL} recent publications LLM bioinformatics`
- `{JOURNAL} editorial commentary AI biology`
- Recent Perspective/Review articles in the target journal (shows what editors care about)

### Step 3: Confirmation

Confirm: journal + topic + 1x A100 + computational-only. Proceed automatically after confirmation.

---

## Phase 1: Literature Survey

Same structure as conference_plan, with these journal-specific adjustments:

- Search target journal specifically for recent related publications
- Identify 2-3 papers in the target journal to cite in the cover letter
- Focus gap analysis on **biological significance** (not just algorithmic novelty)
- Survey guide's "theoretical gaps" section becomes "scientific understanding gaps"

Read `references/survey_guide.md` for template.

Write to `{project_name}/survey.md` in Chinese.

---

## Phase 2: Research Proposal

Same structure as conference_plan, with these key differences:

### Innovation Framing (Scientific Significance)

Innovation must be framed as scientific significance, not algorithmic novelty:
- "This enables [new type of biological analysis]" > "This is a new algorithm"
- "This reveals [biological mechanism]" > "This achieves SOTA on benchmarks"
- "This provides [tool for the biology community]" > "This has theoretical guarantees"

### Proposal must include:

1-14. Same as conference_plan (innovation points, feasibility, baselines, etc.)
15. **Cover letter plan**: Which 2-3 papers in the target journal to cite, why this work fits
16. **Reviewer suggestions**: 3-5 potential reviewers with expertise and emails
17. **Data deposition plan**: Where to deposit data (GEO, Zenodo, etc.)
18. **Biological validation plan**: Expanded from conference_plan. At least 3 types of biological validation (see `references/bio_validation_guide.md`).

Read `references/proposal_guide.md` for template.

Write to `{project_name}/proposal.md` in Chinese.

---

## Phase 3: Code Implementation

Same as conference_plan, plus:

### Additional analysis scripts for journals:

- `bio_validation.py`: Marker gene recovery, GO enrichment, embedding quality metrics
- `bio_visualization.py`: UMAP, expression heatmaps, attention-on-network
- `compound_figures.py`: Assemble individual panels into compound multi-panel figures
- `domain_specific_analysis.py`: Task-specific biological validation

### Figure generation must produce:

- Individual panel PDFs (for assembly)
- Compound figure PDFs (assembled with proper panel labels a, b, c...)
- Extended Data figures
- Supplementary figures
- All at 300+ DPI, Arial/Helvetica font, 7pt text, colorblind-friendly palette

Read `references/code_structure.md` and `references/figure_guide.md`.

---

## Phase 4: Code Review

Same as conference_plan, plus:

- Verify figure generation produces journal-quality output (300 DPI, correct fonts, panel labels)
- Verify bio_validation scripts run and produce meaningful results
- Verify compound figure assembly works correctly

---

## Phase 5: Technical Manual

Same as conference_plan. Add section on:
- How to run biological validation experiments
- How to generate compound figures
- How to deposit data to GEO/Zenodo

---

## Phase 6: Paper Draft

This phase is fundamentally different from conference_plan. The paper follows journal structure.

### Template Acquisition

Use WebSearch to find the target journal's LaTeX template or author guidelines. Nature family journals often use a simple format (no special .sty file). Cell family requires STAR Methods template.

### Paper Structure

Read `references/paper_guide.md` for detailed guidance.

**Writing style**: Narrative, accessible, biology-first. No AI jargon in main text. No numbered contribution lists. No "Related Work" section. Follow `references/paper_guide.md` Writing Style section strictly.

Write these files:

**main.tex**: Abstract + Introduction + Results (3-5 titled subsections) + Discussion

1. **Abstract**: 150-300 words per journal guidelines. Start with biology, not algorithms.
2. **Introduction**: 4-6 paragraphs. Biology problem > current limitations > opportunity > what we did and found. No numbered contributions.
3. **Results**: 3-5 titled subsections, each paired with one compound figure. Titles state findings ("CellAgent identifies...") not questions. Follow the narrative story arc from `references/experiment_narrative_guide.md`.
4. **Discussion**: Significance > relation to field > broader implications > limitations > future directions.

**methods.tex**: Complete computational methods. All equations go here. Enough detail for reproduction.

**supplementary.tex**: Supplementary Notes, Tables, Figures.

**extended_data.tex**: Up to 10 Extended Data figures (Nature family).

**cover_letter.tex**: Tailored to the target journal. Read `references/cover_letter_guide.md`.

**reviewer_suggestions.md**: 3-5 suggested reviewers with names, affiliations, emails, expertise.

### Figures

Read `references/figure_guide.md`. Create 4-6 compound multi-panel figures:
- Fig 1: Framework + initial validation (panels a-d)
- Fig 2: Main benchmarking results (panels a-e)
- Fig 3: Mechanism + biological insight (panels a-d)
- Fig 4: Application + discovery (panels a-d)

All pre-experiment figures (schematics) drawn fully. Post-experiment panels have structure defined with placeholder descriptions.

### Results Section Strategy

Same XX.X placeholder approach as conference_plan, but with journal-style annotations:
```latex
% [Analysis: bio_validation.py --marker_genes;
%  show that top attention genes overlap with known markers;
%  expect >60% overlap (significantly above random, Fisher's exact test);
%  this validates that the model captures real biological signal]
```

Annotations must emphasize **biological significance**, not just metric values.

### Journal-Specific Supplementary Items

Based on `{JOURNAL}`, also produce:
- **Highlights** (Nature Methods and some Nature sub-journals): 3-4 bullet points, ~15 words each. See `references/paper_guide.md`.
- **Graphical Abstract** (Cell family journals): One-page visual summary. Generate with Python or describe for Illustrator.
- **CRediT Author Statement**: Author contribution roles per CRediT taxonomy. See `references/paper_guide.md`.
- **ORCID**: Ensure all authors have ORCID identifiers.
- **Data Availability Statement**: Specify GEO/Zenodo accession numbers (or placeholder).
- **Code Availability Statement**: GitHub URL with version tag.

---

## Phase 7: Presentation

Same as conference_plan, adapted for journal context. Show target journal name. Add slide on biological validation and cover letter highlights.

---

## Phase 8: Final Assembly & Verification

Same as conference_plan, plus:

### Journal-Specific Checks
- [ ] Paper structure matches target journal (Methods at end, no Related Work)
- [ ] Word count within journal limit
- [ ] Figure count within journal limit (4-6 main, up to 10 ED)
- [ ] Figure legends are self-contained paragraphs with statistical details
- [ ] Cover letter tailored to specific journal, cites 2-3 papers from that journal
- [ ] Reviewer suggestions prepared
- [ ] Data deposition plan ready (GEO/Zenodo accession numbers or placeholder)
- [ ] Code repository prepared (GitHub with README and tutorial)
- [ ] All biological validation completed

### Deliverables Summary

| Deliverable | File | Status | Journal Check |
|---|---|---|---|
| Literature Survey | survey.md | ... | Journal-specific papers identified |
| Research Proposal | proposal.md | ... | Scientific significance framed |
| Code Project | code/ | ... | 1x A100, bio validation scripts |
| Analysis + Figures | code/analysis/ + figures/ | ... | Compound figures, 300 DPI |
| Technical Manual | technical_manual.md | ... | Bio validation + figure assembly |
| Paper Draft | paper/ | ... | {JOURNAL} structure |
| Cover Letter | paper/cover_letter.tex | ... | Tailored to {JOURNAL} |
| Reviewer Suggestions | paper/reviewer_suggestions.md | ... | 3-5 experts listed |
| Presentation | presentation.html | ... | Journal name shown |
| Post-Experiment Guide | post_experiment_guide.md | ... | Journal submission checklist |

---

## Phase 9: Post-Experiment Guide

Same structure as conference_plan, adapted for journal workflow:

### Key additions:
- **Figure assembly workflow**: Individual panels > compound figures in Inkscape/Illustrator
- **Data deposition steps**: How to submit to GEO/Zenodo
- **Cover letter finalization**: Fill in specific results
- **Revision preparation**: Pre-plan responses to common reviewer concerns (see `references/acceptance_checklist.md` Section 6)

### Submission checklist: Use `references/acceptance_checklist.md` Section 8.

---

## Important Notes

- **Phase 0 is interactive.** All other phases run automatically.
- **Biology first**: Every deliverable leads with biological significance, not algorithmic novelty.
- **Figures are critical**: Journal editors judge papers by figures first. Invest heavily in figure quality.
- **Cover letter matters**: It determines whether the editor reads the paper.
- **Computational only**: All validation is in silico. No wet-lab experiments.
- **1x A100 is a hard constraint.** Verify at Phase 2, Phase 4, Phase 8.
- **Writing style**: Narrative, accessible, no AI-sounding text.
